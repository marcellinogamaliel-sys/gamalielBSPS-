const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const regex = /\/\/ Chunked Upload Endpoint supporting automatic retry & file completion[\s\S]*?\}\);/g;

code = code.replace(regex, \`// Map untuk buffer chunk upload Firebase Storage
const chunkBuffer = new Map<string, Buffer[]>();

// Chunked Upload Endpoint supporting automatic retry & file completion (Firebase Storage)
app.post("/api/upload-chunk", express.json({ limit: "15mb" }), async (req, res) => {
  const { uploadId, chunkIndex, totalChunks, filename, chunkData } = req.body;
  if (!uploadId || chunkIndex === undefined || !totalChunks || !filename || !chunkData) {
    return res.status(400).json({ error: "Parameter chunk tidak lengkap" });
  }

  try {
    if (!chunkBuffer.has(uploadId)) chunkBuffer.set(uploadId, []);
    const chunks = chunkBuffer.get(uploadId);
    const base64Clean = chunkData.replace(/^data:[^;]+;base64,/, '');
    chunks[Number(chunkIndex)] = Buffer.from(base64Clean, 'base64');

    if (chunks.filter(Boolean).length === Number(totalChunks)) {
      const fullBuffer = Buffer.concat(chunks.filter(Boolean));
      chunkBuffer.delete(uploadId);
      
      const ext = path.extname(filename) || '.jpg';
      const storagePath = \\\`uploads/\\\${uploadId}\\\${ext}\\\`;
      const file = storage.bucket().file(storagePath);
      await file.save(fullBuffer, { metadata: { contentType: 'image/jpeg' }, public: true });
      
      const file_url = \\\`https://storage.googleapis.com/\\\${storage.bucket().name}/\\\${storagePath}\\\`;
      return res.json({ success: true, message: 'File berhasil diunggah!', file_url });
    }

    return res.json({ success: true, message: \\\`Chunk \\\${Number(chunkIndex) + 1}/\\\${totalChunks} diterima.\\\` });
  } catch(e: any) {
    logger.error("Error pada chunk upload handler", e);
    return res.status(500).json({ error: "Sistem server gagal memproses chunk." });
  }
});\`);

fs.writeFileSync('server.ts', code);
