const { Project, SyntaxKind } = require('ts-morph');
const fs = require('fs');

const project = new Project();
project.addSourceFileAtPath('server.ts');
const sf = project.getSourceFileOrThrow('server.ts');

const collections = [
  'villages', 'groups', 'stores', 'recipients', 'drpb_items', 
  'distributions', 'distribution_media', 'recipient_photos', 
  'findings', 'audit_logs', 'street_views', 'arahan', 'users', 'teams'
];

const callExpressions = sf.getDescendantsOfKind(SyntaxKind.CallExpression);
for (const call of callExpressions) {
  const expr = call.getExpression();
  if (expr.getText() === 'app.get' || expr.getText() === 'app.post' || expr.getText() === 'app.put' || expr.getText() === 'app.delete') {
    const args = call.getArguments();
    if (args.length >= 2) {
      const lastArg = args[args.length - 1];
      if (lastArg.getKind() === SyntaxKind.ArrowFunction || lastArg.getKind() === SyntaxKind.FunctionExpression) {
        lastArg.setIsAsync(true);
      }
    }
  }
}

// Just make all arrow functions in app.xxx async
sf.saveSync();
console.log("Made route handlers async.");
