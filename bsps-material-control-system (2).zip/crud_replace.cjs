const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

// Replace res.json(db.COLLECTION)
code = code.replace(/res\.json\(db\.([a-zA-Z_]+)\);/g, (match, coll) => {
  return "const snap = await db.collection(COLLECTIONS." + coll.toUpperCase() + ").get();\n  res.json(snap.docs.map(d => ({id: d.id, ...d.data()})));";
});

// Replace db.COLLECTION.find(r => r.id === id)
code = code.replace(/const ([a-zA-Z0-9_]+) = db\.([a-zA-Z_]+)\.find\([a-zA-Z0-9_]+ => [a-zA-Z0-9_]+\.id === ([a-zA-Z0-9_]+)\);/g, (match, varName, coll, idVar) => {
  return "const doc = await db.collection(COLLECTIONS." + coll.toUpperCase() + ").doc(" + idVar + ").get();\n  const " + varName + " = doc.exists ? { id: doc.id, ...doc.data() } : undefined;";
});

// Replace db.COLLECTION.push(newObj)
code = code.replace(/db\.([a-zA-Z_]+)\.push\(([a-zA-Z0-9_]+)\);/g, (match, coll, objVar) => {
  return "await db.collection(COLLECTIONS." + coll.toUpperCase() + ").doc(" + objVar + ".id).set(" + objVar + ");";
});

// Replace splice/delete
code = code.replace(/const index = db\.([a-zA-Z_]+)\.findIndex\([a-zA-Z0-9_]+ => [a-zA-Z0-9_]+\.id === ([a-zA-Z0-9_]+)\);\n\s*if \(index !== -1\) \{\n\s*db\.\1\.splice\(index, 1\);\n\s*\}/g, (match, coll, idVar) => {
  return "await db.collection(COLLECTIONS." + coll.toUpperCase() + ").doc(" + idVar + ").delete();";
});

fs.writeFileSync('server.ts', code);
console.log("Replaced common CRUD patterns");
