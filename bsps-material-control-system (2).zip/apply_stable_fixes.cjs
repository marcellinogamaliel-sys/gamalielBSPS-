const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

// 1. Add dotenv
if (!code.includes("dotenv/config")) {
  code = "import 'dotenv/config';\n" + code;
}

// 2. Hardcode PORT = 3000
code = code.replace(/const PORT = process\.env\.PORT \? parseInt\(process\.env\.PORT\) : 3000;/, "const PORT = 3000;");

// 3. Rewrite /api/tfl/daily-summary
const summaryRegex = /app\.get\("\/api\/tfl\/daily-summary", \(req, res\) => \{[\s\S]*?res\.json\(\{[\s\S]*?\}\);\n\}\);/m;
const summaryReplacement = `app.get("/api/tfl/daily-summary", async (req, res) => {
  try {
    const { tfl_team } = req.query;
    let recipientsRef = db.collection(COLLECTIONS.RECIPIENTS);
    if (tfl_team && tfl_team !== 'all') {
      recipientsRef = recipientsRef.where('tfl_team', '==', tfl_team);
    }
    const recipientsSnap = await recipientsRef.get();
    const recipients = recipientsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const recipientIds = recipients.map(r => r.id);

    const priorityVisits = recipients
      .filter(r => r.status === 'not_started' || r.status === 'in_progress')
      .map(r => ({ id: r.id, full_name: r.full_name, status: r.status, latitude: r.latitude, longitude: r.longitude }));

    const findingsSnap = await db.collection(COLLECTIONS.FINDINGS).where('resolved', '==', false).get();
    const unresolvedFindings = findingsSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      .filter(f => recipientIds.includes(f.recipient_id));

    const distSnap = await db.collection(COLLECTIONS.DISTRIBUTIONS).get();
    const allDistributions = distSnap.docs.map(d => ({ id: d.id, ...d.data() }));

    const pendingConfirmations = allDistributions.filter(
      d => recipientIds.includes(d.recipient_id) && d.confirmation_status === 'pending'
    );

    const disputedDistributions = allDistributions.filter(
      d => recipientIds.includes(d.recipient_id) && d.confirmation_status === 'disputed'
    );

    const drpbSnap = await db.collection(COLLECTIONS.DRPB_ITEMS).get();
    const allDrpb = drpbSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const tflDrpbItems = allDrpb.filter(item => recipientIds.includes(item.recipient_id));
    const tflDistributions = allDistributions.filter(dist => recipientIds.includes(dist.recipient_id));

    const materialProgress = {};

    tflDrpbItems.forEach(item => {
      const key = \`\${item.material_type} (\${item.unit})\`;
      if (!materialProgress[key]) {
        materialProgress[key] = {
          material: item.material_type,
          unit: item.unit,
          target: 0,
          actual: 0
        };
      }
      materialProgress[key].target += Number(item.required_qty) || 0;
    });

    tflDistributions.forEach(dist => {
      const item = tflDrpbItems.find(i => i.id === dist.drpb_item_id);
      if (item) {
        const key = \`\${item.material_type} (\${item.unit})\`;
        if (!materialProgress[key]) {
          materialProgress[key] = {
            material: item.material_type,
            unit: item.unit,
            target: 0,
            actual: 0
          };
        }
        materialProgress[key].actual += Number(dist.volume) || 0;
      }
    });

    res.json({
      priority_visits: priorityVisits,
      unresolved_findings: unresolvedFindings,
      pending_confirmations: pendingConfirmations,
      disputed_distributions: disputedDistributions,
      material_progress: Object.values(materialProgress)
    });
  } catch (err) {
    logger.error('Failed to get daily summary', err);
    res.status(500).json({ error: 'Gagal memuat summary' });
  }
});`;
code = code.replace(summaryRegex, summaryReplacement);

// 4. Global API 404 and JSON Error Handler
const middlewareRegex = /\/\/ Vite & Static Client Middleware\nasync function startServer\(\) \{/m;
const middlewareReplacement = `// Catch-all 404 for API routes so they don't return HTML
app.all('/api/*', (req, res) => {
  res.status(404).json({ error: 'Endpoint API tidak ditemukan' });
});

// Vite & Static Client Middleware
async function startServer() {`;
code = code.replace(middlewareRegex, middlewareReplacement);

const endRegex = /app\.listen\(PORT, "0\.0\.0\.0", \(\) => \{/m;
const endReplacement = `// Error handler to ensure JSON responses
  app.use((err, req, res, next) => {
    logger.error('Global Error:', err);
    res.status(500).json({ error: 'Terjadi kesalahan pada server' });
  });

  app.listen(PORT, "0.0.0.0", () => {`;
code = code.replace(endRegex, endReplacement);

// 5. Remove SSE api/sync if it exists
code = code.replace(/\/\/ Real-Time SSE Sync endpoint[\s\S]*?req\.on\("close"[\s\S]*?\}\);\n\}\);/m, "");

fs.writeFileSync('server.ts', code);
console.log("Applied stable fixes");
