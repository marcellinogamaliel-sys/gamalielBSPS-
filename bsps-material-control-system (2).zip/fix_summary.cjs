const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');
const regex = /app\.get\("\/api\/tfl\/daily-summary", \(req, res\) => \{[\s\S]*?res\.json\(\{[\s\S]*?\}\);\n\}\);/m;
const replacement = `app.get("/api/tfl/daily-summary", async (req, res) => {
  try {
    const { tfl_team } = req.query;
    let recipientsRef = db.collection(COLLECTIONS.RECIPIENTS);
    if (tfl_team && tfl_team !== 'all') {
      // @ts-ignore
      recipientsRef = recipientsRef.where('tfl_team', '==', tfl_team);
    }
    const recipientsSnap = await recipientsRef.get();
    const recipients = recipientsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const recipientIds = recipients.map(r => r.id);

    const priorityVisits = recipients
      .filter(r => r.status === 'not_started' || r.status === 'in_progress')
      .map(r => ({ id: r.id, full_name: r.full_name, status: r.status, latitude: r.latitude, longitude: r.longitude }));

    const findingsSnap = await db.collection(COLLECTIONS.FINDINGS).where('resolved', '==', false).get();
    const unresolvedFindings = findingsSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      .filter(f => recipientIds.includes(f.recipient_id));

    const distSnap = await db.collection(COLLECTIONS.DISTRIBUTIONS).get();
    const allDistributions = distSnap.docs.map(d => ({ id: d.id, ...d.data() }));

    const pendingConfirmations = allDistributions.filter(
      d => recipientIds.includes(d.recipient_id) && d.confirmation_status === 'pending'
    );

    const disputedDistributions = allDistributions.filter(
      d => recipientIds.includes(d.recipient_id) && d.confirmation_status === 'disputed'
    );

    const drpbSnap = await db.collection(COLLECTIONS.DRPB_ITEMS).get();
    const allDrpb = drpbSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const tflDrpbItems = allDrpb.filter(item => recipientIds.includes(item.recipient_id));
    const tflDistributions = allDistributions.filter(dist => recipientIds.includes(dist.recipient_id));

    const materialProgress: any = {};

    tflDrpbItems.forEach(item => {
      const key = \`\${item.material_type} (\${item.unit})\`;
      if (!materialProgress[key]) {
        materialProgress[key] = {
          material: item.material_type,
          unit: item.unit,
          target: 0,
          actual: 0
        };
      }
      materialProgress[key].target += Number(item.required_qty) || 0;
    });

    tflDistributions.forEach(dist => {
      const item = tflDrpbItems.find(i => i.id === dist.drpb_item_id);
      if (item) {
        const key = \`\${item.material_type} (\${item.unit})\`;
        if (!materialProgress[key]) {
          materialProgress[key] = {
            material: item.material_type,
            unit: item.unit,
            target: 0,
            actual: 0
          };
        }
        materialProgress[key].actual += Number(dist.volume) || 0;
      }
    });

    res.json({
      priority_visits: priorityVisits,
      unresolved_findings: unresolvedFindings,
      pending_confirmations: pendingConfirmations,
      disputed_distributions: disputedDistributions,
      material_progress: Object.values(materialProgress)
    });
  } catch (err) {
    logger.error('Failed to get daily summary', err);
    res.status(500).json({ error: 'Gagal memuat summary' });
  }
});`;
code = code.replace(regex, replacement);
fs.writeFileSync('server.ts', code);
