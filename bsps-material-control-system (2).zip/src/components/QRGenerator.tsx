/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { motion, AnimatePresence } from 'motion/react';
import { 
  QrCode, Filter, RefreshCw, Printer, 
  MapPin, Landmark, Sparkles, AlertCircle,
  Edit2, Save, X, User, CreditCard, ShoppingBag,
  Check, FileText, ChevronRight, Award, Scissors, CheckSquare
} from 'lucide-react';
import { Recipient, Village, Group, Store } from '../types';

interface QRGeneratorProps {
  recipients: Recipient[];
  villages: Village[];
  groups: Group[];
  stores: Store[];
  onRefresh?: () => void;
  showToast?: (message: string, type: 'success' | 'error') => void;
}

// Highly detailed vector crest for Ministry of Housing (Kementerian PKP) as fallback or secondary branding
const KementerianLogo = () => (
  <svg viewBox="0 0 100 100" className="w-12 h-12 shrink-0 print:w-11 print:h-11 animate-pulse" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M50 5 L85 20 C85 55, 50 85, 50 95 C50 85, 15 55, 15 20 L50 5 Z" fill="#07357A" stroke="#fbbf24" strokeWidth="2.5" />
    <path d="M50 9 L80 23 C80 52, 50 78, 50 88 C50 78, 20 52, 20 23 L50 9 Z" fill="#ffffff" />
    <rect x="28" y="32" width="44" height="6" fill="#ef4444" rx="1" />
    <rect x="28" y="38" width="44" height="6" fill="#e2e8f0" rx="1" />
    <path d="M50 48 L32 62 L35 65 L50 52 L65 65 L68 62 Z" fill="#07357A" />
    <path d="M50 52 L35 65 L40 65 L40 76 L60 76 L60 65 L65 65 Z" fill="#fbbf24" />
    <rect x="47" y="62" width="6" height="14" fill="#07357A" />
    <polygon points="50,14 52,18 56,18 53,21 54,25 50,22 46,25 47,21 44,18 48,18" fill="#fbbf24" />
  </svg>
);

export default function QRGenerator({
  recipients,
  villages,
  groups,
  stores,
  onRefresh,
  showToast
}: QRGeneratorProps) {
  const [selectedVillage, setSelectedVillage] = useState('all');
  const [selectedGroup, setSelectedGroup] = useState('all');
  const [qrCodes, setQrCodes] = useState<Record<string, string>>({});
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);

  // Custom print config
  const [printSize, setPrintSize] = useState<'a4' | 'a5' | 'poster'>('poster');
  const [kecamatan, setKecamatan] = useState('Kawangkoan');
  const [kabupaten, setKabupaten] = useState('Minahasa');
  const [tahunProgram, setTahunProgram] = useState('2026');

  // Editing state
  const [editingPbId, setEditingPbId] = useState<string | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({
    full_name: '',
    nik: '',
    kk_number: '',
    village_id: '',
    group_id: '',
    store_id: ''
  });

  // Filter lists
  const filteredPB = recipients.filter(r => {
    const matchesVillage = selectedVillage === 'all' || r.village_id === selectedVillage;
    const matchesGroup = selectedGroup === 'all' || r.group_id === selectedGroup;
    return matchesVillage && matchesGroup;
  });

  // Toggle selection
  const toggleSelection = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredPB.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredPB.map(pb => pb.id)));
    }
  };

  // Generate QR dataURIs for PBs
  const generateBatchQRs = async () => {
    setLoading(true);
    const newQRs: Record<string, string> = {};
    const hostUrl = window.location.origin;

    for (const pb of filteredPB) {
      try {
        const publicUrl = `${hostUrl}/public/${pb.id}`;
        const dataUrl = await QRCode.toDataURL(publicUrl, {
          width: 512, // Higher res for PDF
          margin: 1,
          color: {
            dark: '#002C6C',
            light: '#ffffff'
          }
        });
        newQRs[pb.id] = dataUrl;
      } catch (err) {
        console.error("Gagal men-generate QR untuk: " + pb.full_name, err);
      }
    }

    setQrCodes(newQRs);
    setLoading(false);
  };

  // PDF Export Function
  const exportToPDF = async () => {
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF('p', 'mm', 'a4');
    const selectedPBs = filteredPB.filter(pb => selectedIds.has(pb.id) || selectedIds.size === 0);
    
    if (selectedPBs.length === 0) {
      showToast?.("Pilih minimal satu penerima bantuan!", "error");
      return;
    }

    let x = 10;
    let y = 10;
    const cellWidth = 90;
    const cellHeight = 120;
    const padding = 5;

    for (let i = 0; i < selectedPBs.length; i++) {
        const pb = selectedPBs[i];
        const qrSrc = qrCodes[pb.id];
        if (!qrSrc) continue;

        if (i > 0 && i % 4 === 0) {
            doc.addPage();
            x = 10;
            y = 10;
        } else if (i % 2 === 0 && i > 0) {
            x = 10;
            y += cellHeight + padding;
        } else if (i % 2 !== 0) {
            x += cellWidth + padding;
        }

        // Draw card border
        doc.rect(x, y, cellWidth, cellHeight);
        
        // Add QR (Dominant)
        doc.addImage(qrSrc, 'PNG', x + 15, y + 10, 60, 60);
        
        // Add Text
        doc.setFontSize(10);
        doc.text(pb.full_name.toUpperCase(), x + cellWidth/2, y + 80, { align: 'center' });
        doc.setFontSize(8);
        doc.text(`ID: ${pb.id.slice(0, 8)}`, x + cellWidth/2, y + 90, { align: 'center' });
        doc.text(`${kecamatan}, ${kabupaten}`, x + cellWidth/2, y + 100, { align: 'center' });
    }

    doc.save(`Daftar_QR_PB_${new Date().toLocaleDateString()}.pdf`);
  };

  useEffect(() => {
    if (filteredPB.length > 0) {
      generateBatchQRs();
    }
    // Reset selection when filter changes
    setSelectedIds(new Set());
  }, [selectedVillage, selectedGroup, recipients.length]);

  // Open editor and load current values
  const startEditing = (pb: Recipient) => {
    setEditingPbId(pb.id);
    setEditForm({
      full_name: pb.full_name,
      nik: pb.nik,
      kk_number: pb.kk_number,
      village_id: pb.village_id,
      group_id: pb.group_id,
      store_id: pb.store_id
    });
  };

  // Close editor
  const cancelEditing = () => {
    setEditingPbId(null);
  };

  // Handle direct API updates
  const saveRecipientEdits = async (id: string) => {
    if (!editForm.full_name.trim() || !editForm.nik.trim() || !editForm.kk_number.trim()) {
      showToast?.("Nama, NIK, dan KK wajib diisi secara lengkap!", "error");
      return;
    }
    if (editForm.nik.length < 16) {
      showToast?.("Nomor NIK harus minimal 16 digit!", "error");
      return;
    }

    setSavingId(id);
    try {
      const res = await fetch(`/api/recipients/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: editForm.full_name.trim(),
          nik: editForm.nik.trim(),
          kk_number: editForm.kk_number.trim(),
          village_id: editForm.village_id,
          group_id: editForm.group_id,
          store_id: editForm.store_id,
          operator_id: "TIM22"
        })
      });

      if (res.ok) {
        showToast?.("Data PB berhasil diperbarui secara real-time!", "success");
        setEditingPbId(null);
        if (onRefresh) onRefresh();
      } else {
        const errObj = await res.json();
        showToast?.(errObj.error || "Gagal memperbarui data", "error");
      }
    } catch (err) {
      console.error(err);
      showToast?.("Kesalahan jaringan saat menyimpan", "error");
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Inject custom css styles for official government prints */}
      <style>{`
        .card-pattern-overlay {
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80' width='30' height='30' opacity='0.03'%3E%3Cpath d='M40 15 L10 40 L20 40 L20 70 L60 70 L60 40 L70 40 Z' fill='%23002C6C' stroke='%23002C6C' stroke-width='1'/%3E%3C/svg%3E");
          background-repeat: repeat;
        }
        
        @media print {
          body {
            background-color: white !important;
            color: black !important;
          }
          header, footer, nav, aside, .print\\:hidden {
            display: none !important;
          }
          #bulk-qr-printable-grid {
            display: grid !important;
            grid-template-cols: 1fr !important;
            gap: 15mm !important;
            background: white !important;
            padding: 0 !important;
            margin: 0 !important;
          }
          .custom-print-card {
            box-shadow: none !important;
            border-radius: 0px !important;
            page-break-inside: avoid !important;
            page-break-after: always !important;
            margin: 0 auto !important;
            background-color: white !important;
          }
          .print-size-a4 {
            width: 195mm !important;
            height: 275mm !important;
            padding: 10mm !important;
          }
          .print-size-a5 {
            width: 138mm !important;
            height: 195mm !important;
            padding: 6mm !important;
          }
          .print-size-poster {
            width: 138mm !important;
            height: 195mm !important;
            padding: 5mm !important;
            border: 3px solid #002C6C !important;
          }
          .crop-mark-line {
            display: block !important;
          }
        }
      `}</style>
      
      {/* Official State Title Panel */}
      <div className="bg-gradient-to-r from-[#002C6C] via-indigo-900 to-[#07357A] text-white rounded-2xl p-5 shadow-lg flex flex-col md:flex-row items-center justify-between gap-4 border border-[#002C6C]/30 print:hidden animate-in fade-in duration-500">
        <div className="flex items-center gap-4 text-center md:text-left">
          <img src="/logo.png" className="w-14 h-14 object-contain" alt="Logo Kementerian Swadaya" referrerPolicy="no-referrer" />
          <div>
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="text-[10px] font-black tracking-widest uppercase px-2 py-0.5 rounded-full bg-amber-500 text-slate-900 border border-amber-400">CETAK DRPB VERSI PERMANEN (v2)</span>
              <Sparkles size={13} className="text-amber-300 animate-pulse" />
            </div>
            <h1 className="text-lg md:text-xl font-extrabold tracking-tight font-display mt-0.5 uppercase">
              Kementerian Perumahan dan Kawasan Permukiman
            </h1>
            <p className="text-[11px] text-slate-300 font-medium uppercase font-mono tracking-wider mt-0.5">
              Portal Monitoring BSPS &bull; Rumah Penerima Bantuan Sosial Swadaya
            </p>
          </div>
        </div>
      </div>

      {/* PARAMETERS & PRINT STYLING PANEL */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs grid grid-cols-1 md:grid-cols-4 gap-4 print:hidden transition-all">
        {/* Village select */}
        <div>
          <label className="text-[10px] font-bold font-mono text-slate-500 uppercase block mb-1.5 flex items-center gap-1">
            <Landmark size={11} className="text-slate-400" />
            Saring Wilayah Desa
          </label>
          <select
            value={selectedVillage}
            onChange={(e) => {
              setSelectedVillage(e.target.value);
              setSelectedGroup('all');
            }}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-250 focus:ring-2 focus:ring-[#002C6C]/15 focus:border-[#002C6C] focus:outline-none bg-slate-50 transition-all font-semibold"
          >
            <option value="all">Semua Desa ({villages.length})</option>
            {villages.map(v => (
              <option key={v.id} value={v.id}>{v.name}</option>
            ))}
          </select>
        </div>

        {/* Group select */}
        <div>
          <label className="text-[10px] font-bold font-mono text-slate-500 uppercase block mb-1.5 flex items-center gap-1">
            <MapPin size={11} className="text-slate-400" />
            Saring Kelompok TFL
          </label>
          <select
            disabled={selectedVillage === 'all'}
            value={selectedGroup}
            onChange={(e) => setSelectedGroup(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-250 focus:ring-2 focus:ring-[#002C6C]/15 focus:border-[#002C6C] focus:outline-none bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-semibold"
          >
            <option value="all">Semua Kelompok</option>
            {groups
              .filter(g => selectedVillage === 'all' || g.village_id === selectedVillage)
              .map(g => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
          </select>
        </div>

        {/* Dynamic Card Sizer */}
        <div>
          <label className="text-[10px] font-bold font-mono text-slate-500 uppercase block mb-1.5 flex items-center gap-1">
            <Printer size={11} className="text-slate-400" />
            Ukuran Cetak & Layout
          </label>
          <div className="grid grid-cols-3 gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setPrintSize('a4')}
              className={`py-1 text-[10px] font-bold rounded-lg transition ${
                printSize === 'a4' 
                  ? 'bg-[#002C6C] text-white' 
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              A4 Portrait
            </button>
            <button
              onClick={() => setPrintSize('a5')}
              className={`py-1 text-[10px] font-bold rounded-lg transition ${
                printSize === 'a5' 
                  ? 'bg-[#002C6C] text-white' 
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              A5 Portrait
            </button>
            <button
              onClick={() => setPrintSize('poster')}
              className={`py-1 text-[10px] font-bold rounded-lg transition ${
                printSize === 'poster' 
                  ? 'bg-amber-500 text-slate-900 border border-amber-400' 
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
              title="Poster Rumah Bantuan 148x210 mm"
            >
              Poster Rumah
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center gap-2">
            <input 
              type="checkbox"
              checked={selectedIds.size === filteredPB.length && filteredPB.length > 0}
              onChange={toggleSelectAll}
              className="w-4 h-4 cursor-pointer"
            />
            <span className="text-xs font-bold text-slate-600">Pilih Semua ({selectedIds.size})</span>
          </div>
          <div className="flex items-end gap-2.5">
            <button
              onClick={generateBatchQRs}
              disabled={loading || filteredPB.length === 0}
              className="flex-1 py-1.5 px-3 border border-slate-205 hover:bg-slate-50 text-slate-705 bg-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition active:scale-95 disabled:opacity-40 shadow-xs h-[38px]"
            >
              <RefreshCw size={14} className={loading ? 'animate-spin text-slate-500' : 'text-slate-600'} />
              Muat Ulang
            </button>

            <button
              onClick={exportToPDF}
              disabled={loading || filteredPB.length === 0}
              className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition active:scale-95 shadow-md h-[38px]"
            >
              <FileText size={14} />
              PDF
            </button>

            <button
              onClick={() => window.print()}
              disabled={filteredPB.length === 0}
              className="flex-1 py-1.5 px-3 bg-[#002C6C] hover:bg-[#07357A] text-white rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition active:scale-95 shadow-md h-[38px]"
            >
              <Printer size={14} />
              Cetak Massal
            </button>
          </div>
        </div>
      </div>

      {/* METADATA GEOGRAFIS CONFIGURATOR (Sangat berguna untuk penyesuaian cetak resmi di lokasi manapun) */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-3 print:hidden">
        <div>
          <label className="text-[9px] font-bold font-mono text-slate-500 uppercase block mb-1">
            Kabupaten Resmi
          </label>
          <input
            type="text"
            value={kabupaten}
            onChange={(e) => setKabupaten(e.target.value)}
            className="w-full text-xs p-1.5 px-3 rounded-lg border border-slate-200 focus:outline-[#002C6C] font-semibold bg-white"
            placeholder="Kabupaten Minahasa"
          />
        </div>
        <div>
          <label className="text-[9px] font-bold font-mono text-slate-500 uppercase block mb-1">
            Kecamatan Resmi
          </label>
          <input
            type="text"
            value={kecamatan}
            onChange={(e) => setKecamatan(e.target.value)}
            className="w-full text-xs p-1.5 px-3 rounded-lg border border-slate-200 focus:outline-[#002C6C] font-semibold bg-white"
            placeholder="Kecamatan Kawangkoan"
          />
        </div>
        <div>
          <label className="text-[9px] font-bold font-mono text-slate-500 uppercase block mb-1">
            Tahun Anggaran Program
          </label>
          <input
            type="text"
            value={tahunProgram}
            onChange={(e) => setTahunProgram(e.target.value)}
            className="w-full text-xs p-1.5 px-3 rounded-lg border border-slate-200 focus:outline-[#002C6C] font-bold text-[#002C6C] bg-white"
            placeholder="2026"
          />
        </div>
      </div>

      {/* Grid Display Printable QR Cards */}
      <div className="space-y-4">
        <div className="flex justify-between items-center print:hidden">
          <h3 className="text-xs font-black text-slate-900 font-mono uppercase tracking-wider flex items-center gap-2">
            <QrCode size={16} className="text-[#002C6C] animate-pulse" />
            PREVIEW HASIL RENDERING KARTU MONITORING ({filteredPB.length} PB Terseleksi)
          </h3>
          <span className="text-[10px] text-[#002C6C] bg-indigo-50 border border-indigo-150 px-2 py-1 rounded-lg font-bold font-mono uppercase">
            Format Pilihan: {printSize === 'poster' ? 'Poster Rumah (148x210 mm Layout Tebal)' : printSize === 'a5' ? 'Kertas A5 Portrait' : 'Kertas A4 Portrait'}
          </span>
        </div>

        {loading ? (
          <div className="py-24 text-center text-xs text-slate-450 space-y-3 font-mono print:hidden">
            <div className="w-10 h-10 rounded-full border-2 border-slate-200 border-t-[#002C6C] animate-spin mx-auto" />
            <p className="text-[#002C6C] font-bold">Menyusun layout monitor nasional & QR Code...</p>
          </div>
        ) : filteredPB.length === 0 ? (
          <div className="bg-white border rounded-2xl p-16 text-center text-slate-400 text-xs shadow-2xs print:hidden">
            Tidak ada Penerima Bantuan yang sesuai dengan penyaringan di atas.
          </div>
        ) : (
          <div 
            className={`grid gap-6 print:gap-0 print:grid-cols-1 ${
              printSize === 'a4' 
                ? 'grid-cols-1 max-w-xl mx-auto' 
                : 'grid-cols-1 md:grid-cols-2'
            }`} 
            id="bulk-qr-printable-grid"
          >
            {filteredPB.map(pb => {
              const village_name = villages.find(v => v.id === pb.village_id)?.name || "-";
              const group_name = groups.find(g => g.id === pb.group_id)?.name || "-";
              const store_name = stores.find(s => s.id === pb.store_id)?.name || "-";
              const qrSrc = qrCodes[pb.id];
              const isEditing = editingPbId === pb.id;

              return (
                <div 
                  key={pb.id} 
                  className={`bg-white border-2 border-dashed border-slate-300 p-4 rounded-3xl relative transition-all duration-300 custom-print-card ${
                    printSize === 'a4' ? 'print-size-a4' : printSize === 'a5' ? 'print-size-a5' : 'print-size-poster'
                  } ${isEditing ? 'ring-4 ring-indigo-500/20 border-indigo-500' : 'hover:border-[#002C6C]'}`}
                  style={{ contentVisibility: 'auto' }}
                >
                  
                  {/* AUTOMATIC SCISSOR CROP MARKS (Garis potong otomatis saat print) */}
                  <div className="absolute -top-1.5 -left-1.5 w-6 h-6 border-t border-l border-slate-400 pointer-events-none select-none hidden crop-mark-line" />
                  <div className="absolute -top-1.5 -right-1.5 w-6 h-6 border-t border-r border-slate-400 pointer-events-none select-none hidden crop-mark-line" />
                  <div className="absolute -bottom-1.5 -left-1.5 w-6 h-6 border-b border-l border-slate-400 pointer-events-none select-none hidden crop-mark-line" />
                  <div className="absolute -bottom-1.5 -right-1.5 w-6 h-6 border-b border-r border-slate-400 pointer-events-none select-none hidden crop-mark-line" />
                  
                  {/* Scissors Icon floating indicators on screen preview */}
                  <div className="absolute top-1.5 left-1.5 flex items-center gap-1 bg-slate-100 text-[8.5px] font-bold text-slate-500 px-2 py-0.5 rounded-full border border-slate-200 print:hidden select-none">
                    <Scissors size={10} className="text-slate-400" />
                    Batas Potong Kartu
                  </div>

                  {/* Main Government styled Card layout */}
                  <div className="h-full border border-slate-200 rounded-2xl relative overflow-hidden flex flex-col justify-between card-pattern-overlay bg-white p-5">
                    
                    {/* Status Badge */}
                    <div className="absolute top-3 right-3 z-20 flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(pb.id)}
                        onChange={() => toggleSelection(pb.id)}
                        className="w-4 h-4 accent-[#002C6C] print:hidden cursor-pointer"
                      />
                      <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase text-white ${
                        pb.status === 'complete' ? 'bg-emerald-600' : 
                        pb.status === 'in_progress' ? 'bg-amber-500' : 'bg-slate-400'
                      }`}>
                        {pb.status === 'complete' ? 'Selesai' : pb.status === 'in_progress' ? 'Progres' : 'Baru'}
                      </span>
                    </div>

                    {/* Watermark Logo transparan (logo.png) centered in card background */}
                    <img 
                      src="/logo.png" 
                      className="absolute inset-0 m-auto w-44 h-44 object-contain opacity-[0.05] pointer-events-none select-none z-0" 
                      alt="Watermark Kementerian" 
                      referrerPolicy="no-referrer"
                    />

                    {/* HEADER */}
                    <div className="border-b-2 border-[#002C6C] pb-3 text-center relative z-10 flex flex-col items-center">
                      <img 
                        src="/logo.png" 
                        className="h-14 w-14 object-contain mb-1.5 print:h-12 print:w-12 mx-auto drop-shadow-sm" 
                        alt="Logo Kementerian" 
                        referrerPolicy="no-referrer"
                      />
                      <h4 className="text-[11px] font-black uppercase tracking-wider text-[#002C6C] max-w-xs leading-none">
                        PROGRAM BANTUAN STIMULAN PERUMAHAN SWADAYA (BSPS)
                      </h4>
                      <p className="text-[8.5px] font-extrabold text-slate-500 uppercase mt-1 tracking-wider">
                        Kartu Monitoring Digital Rumah Penerima Bantuan
                      </p>
                    </div>

                    {/* BODY */}
                    <div className="py-4 flex flex-col items-center justify-center gap-4 relative z-10">
                      
                      {/* DRPB LARGE QR CODE (DOMINAN) */}
                      <div className="flex flex-col items-center gap-1.5">
                        <div className={`rounded-2xl bg-white border-2 border-[#002C6C] p-2 relative shadow-md flex items-center justify-center ${
                          printSize === 'poster' ? 'w-[145px] h-[145px] scale-105' : 'w-[125px] h-[125px]'
                        }`}>
                          {/* Crosshair target design for camera autofocus scans */}
                          <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-[#002C6C] rounded-tl-md" />
                          <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-[#002C6C] rounded-tr-md" />
                          <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-[#002C6C] rounded-bl-md" />
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-[#002C6C] rounded-br-md" />
                          
                          {qrSrc ? (
                            <img 
                              src={qrSrc} 
                              alt={`QR Code ${pb.full_name}`} 
                              className="w-full h-full object-contain cursor-zoom-in" 
                            />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-slate-200 border-t-[#002C6C] animate-spin" />
                          )}
                        </div>
                        <span className="text-[8.5px] font-black text-[#002C6C] font-mono uppercase tracking-widest mt-1">STATUS: SCAN TO VERIFY</span>
                      </div>

                      {/* PB IDENTITY METADATA TABLE */}
                      <div className="w-full text-xs space-y-2 border-t border-b border-slate-150 py-3 px-1 text-slate-800 bg-white/70 backdrop-blur-xs rounded-xl pr-3">
                        <div className="grid grid-cols-3 gap-1 items-start">
                          <span className="text-[8.5px] font-bold text-slate-505 font-mono uppercase">Nama Penerima</span>
                          <span className="col-span-2 font-black text-slate-900 uppercase font-sans tracking-wide truncate">
                            : {pb.full_name}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-1 items-start">
                          <span className="text-[8.5px] font-bold text-slate-505 font-mono uppercase">Desa/Kelurahan</span>
                          <span className="col-span-2 font-semibold text-slate-800 uppercase truncate">
                            : {village_name}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-1 items-start">
                          <span className="text-[8.5px] font-bold text-slate-505 font-mono uppercase">Kecamatan</span>
                          <span className="col-span-2 font-semibold text-slate-800 uppercase">
                            : {kecamatan}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-1 items-start">
                          <span className="text-[8.5px] font-bold text-slate-505 font-mono uppercase">Kabupaten/Kota</span>
                          <span className="col-span-2 font-semibold text-slate-800 uppercase col-span-2">
                            : {kabupaten}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-1 items-start">
                          <span className="text-[8.5px] font-bold text-slate-505 font-mono uppercase">Tahun Program</span>
                          <span className="col-span-2 font-black text-[#002C6C] font-mono leading-none">
                            : {tahunProgram}
                          </span>
                        </div>
                      </div>

                    </div>

                    {/* FOOTER */}
                    <div className="pt-2 text-center relative z-10 space-y-2 border-t border-slate-150">
                      <p className="text-[7.5px] font-bold font-mono text-slate-500 italic max-w-sm mx-auto">
                        Scan QR untuk melihat progres pembangunan dan distribusi material
                      </p>
                      
                      <div className="flex items-center justify-between mt-1">
                        <div className="inline-flex items-center gap-1 bg-[#002C6C] text-white rounded-lg py-0.5 px-2 text-[8.5px] font-black tracking-wider uppercase">
                          <Award size={10} className="text-amber-400 mt-[-2px]" />
                          Monitoring Digital BSPS
                        </div>
                        <span className="text-[7.5px] font-bold font-mono text-slate-400">ID PB: {pb.id.slice(0, 8).toUpperCase()}</span>
                      </div>
                    </div>

                  </div>

                  {/* ACTION CONTROLS ON COMPONENT SCREEN PREVIEW */}
                  <div className="absolute bottom-2 right-2 flex items-center gap-1.5 print:hidden">
                    <button
                      onClick={() => startEditing(pb)}
                      disabled={isEditing}
                      className="px-2 py-1 bg-white border border-slate-200 hover:border-slate-300 text-slate-705 font-extrabold rounded-lg text-[9px] flex items-center gap-0.5 cursor-pointer disabled:opacity-40 transition"
                    >
                      <Edit2 size={9} />
                      Ubah Data
                    </button>
                    <button
                      onClick={() => window.print()}
                      className="px-2 py-1 bg-[#002C6C] hover:bg-[#07357A] text-white font-black rounded-lg text-[9px] flex items-center gap-0.5 cursor-pointer transition shadow-2xs"
                    >
                      <Printer size={9} />
                      Cetak
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Printing Guidelines */}
      <div className="p-4 bg-slate-900 text-slate-300 rounded-2xl border border-slate-800 flex items-start gap-3 text-xs leading-relaxed print:hidden">
        <AlertCircle size={17} className="text-amber-405 shrink-0 mt-0.5" />
        <div className="space-y-1 text-left">
          <span className="font-bold text-white uppercase font-mono tracking-wider text-[10px] block">Petunjuk Cetak DRPB Resmi Kementerian PKP:</span>
          <p>
            1. Saring wilayah desa untuk mengoleksi data PB yang ingin dicetak secara massal.<br />
            2. Atur parameter <strong>Kabupaten</strong>, <strong>Kecamatan</strong>, dan <strong>Tahun Anggaran</strong> agar data yang tercetak benar-benar sesuai dengan dokumen administrasi daerah.<br />
            3. Pilih <strong>"Poster Rumah" (Saran Utama)</strong> untuk ukuran sedang tebal, yang didesain agar mudah di scan dari luar rumah. Opsional, pakai A4/A5.<br />
            4. Klik <strong>"Cetak Massal"</strong> untuk membuka print browser. Gunakan setelan "Background graphics" untuk memunculkan logo watermark dan tekstur rumah di latar belakang kertas.
          </p>
        </div>
      </div>
    </div>
  );
}
