import React from 'react';
import { motion } from 'motion/react';
import { X, User, Home } from 'lucide-react';
import { Recipient, RecipientPhoto } from '../types';

interface ScannedDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipient: Recipient;
  photos: RecipientPhoto[];
  pbVillageName: string;
  pbGroupName: string;
  pbStoreName: string;
  formatDateOnly: (d: any) => string;
  galleryFilter: 'all' | 'before' | 'during' | 'after';
  setGalleryFilter: (val: 'all' | 'before' | 'during' | 'after') => void;
  setFullscreenImage: (img: string | null) => void;
  mapContainerRef: React.RefObject<HTMLDivElement | null>;
}

export const ScannedDetailModal: React.FC<ScannedDetailModalProps> = ({
  isOpen,
  onClose,
  recipient,
  photos,
  pbVillageName,
  pbGroupName,
  pbStoreName,
  formatDateOnly,
  galleryFilter,
  setGalleryFilter,
  setFullscreenImage,
  mapContainerRef,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-end justify-center">
      {/* 1. Backdrop Overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity"
      />

      {/* 2. Soft UI Bottom Sheet */}
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 220 }}
        className="relative w-full max-w-2xl bg-white border-t border-slate-200/80 rounded-t-[32px] shadow-[-5px_0px_30px_rgba(0,0,0,0.06)] max-h-[85vh] flex flex-col overflow-hidden text-slate-800"
      >
        {/* Soft Drag handle header */}
        <div className="pt-3 pb-2 w-full shrink-0">
          <div className="w-14 h-1.5 bg-slate-300 rounded-full mx-auto cursor-pointer" onClick={onClose} />
        </div>

        {/* Scrollable sheet body content */}
        <div className="overflow-y-auto px-6 pb-8 space-y-6">
          {/* Header inside sheet */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-500/10 text-amber-600 rounded-xl">
                <User size={20} />
              </div>
              <div>
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-sans">Informasi Logistik Penerima</h3>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">ID REG: #{recipient.id.substring(0, 10).toUpperCase()}</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 bg-slate-200/60 hover:bg-slate-200 text-slate-500 hover:text-slate-800 rounded-full transition cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Grid content splits */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            
            {/* Visual Image profile photo frame */}
            <div className="md:col-span-5 space-y-4">
              <div className="h-44 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 relative group shadow-xs">
                {photos.length > 0 ? (
                  <img src={photos[photos.length - 1].file_url} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300" alt="Rumah Real" />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-slate-400 font-mono text-center">
                    <Home size={32} className="text-slate-300 mb-1.5" />
                    <span className="text-[10px]">Belum Ada Unggahan Foto</span>
                  </div>
                )}
                <div className="absolute bottom-3 left-3 bg-slate-900/90 text-[8px] text-amber-500 font-black px-2 py-0.5 rounded-lg uppercase tracking-wider">
                  FOTO LAPANGAN
                </div>
              </div>

              <div className="bg-slate-50/50 p-4 border border-slate-150 rounded-2xl shadow-3xs space-y-1">
                <span className="text-[9px] font-mono text-slate-400 block uppercase">Alamat Rumah (Geografis)</span>
                <span className="text-slate-700 text-xs block font-sans font-medium line-clamp-2 leading-relaxed">
                  {recipient.address || "Kecamatan Kawangkoan, Kabupaten Minahasa, Sulawesi Utara"}
                </span>
              </div>
            </div>

            {/* Info credentials (Soft UI elegant cards) */}
            <div className="md:col-span-7 space-y-4 text-xs text-slate-700">
              <div className="bg-slate-50/50 p-4 border border-slate-150 rounded-2xl shadow-3xs grid grid-cols-2 gap-3 relative overflow-hidden">
                <div className="absolute right-0 top-0 opacity-[0.03] pointer-events-none">
                  <User className="w-24 h-24 text-slate-900" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono uppercase">Nama Penerima</span>
                  <strong className="text-xs font-black text-slate-900 uppercase font-sans tracking-tight">{recipient.full_name}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono uppercase">Status Stimulan</span>
                  <span className="text-emerald-600 font-bold uppercase block text-[10.5px]">BSPS STIMULAN</span>
                </div>
              </div>

              <div className="bg-slate-50/50 p-4 border border-slate-150 rounded-2xl shadow-3xs grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono uppercase">ID KTP (NIK)</span>
                  <span className="font-mono text-slate-800 font-semibold">{recipient.nik || "710203********"}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono uppercase">Nomor KK</span>
                  <span className="font-mono text-slate-800 font-semibold">{recipient.kk_number || "710204********"}</span>
                </div>
              </div>

              <div className="bg-slate-50/50 p-4 border border-slate-150 rounded-2xl shadow-3xs grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono uppercase">Desa Binaan</span>
                  <span className="font-bold text-slate-900 uppercase">{pbVillageName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono uppercase">Grup Pokman</span>
                  <span className="font-bold text-slate-900 uppercase">{pbGroupName}</span>
                </div>
              </div>

              <div className="bg-slate-50/50 p-4 border border-slate-150 rounded-2xl shadow-3xs flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">Toko Pemasok</span>
                  <span className="text-slate-800 font-black uppercase text-[10.5px]">{pbStoreName}</span>
                </div>
                <span className="text-[9px] font-mono bg-sky-50 text-sky-700 border border-sky-100 p-0.5 px-2.5 rounded-lg font-black uppercase tracking-wider">
                  MITRA AKTIF
                </span>
              </div>
            </div>

          </div>

          {/* PHOTO PROGRESS GALLERY */}
          <div className="border-t border-slate-100 pt-5 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h4 className="text-[10px] font-black font-mono uppercase tracking-widest text-slate-800 flex items-center gap-1.5">
                📸 Histori Foto Kemajuan Fisik Swadaya
              </h4>
              {/* Tab Selector */}
              <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs self-start sm:self-auto shadow-3xs">
                {(['all', 'before', 'during', 'after'] as const).map((phaseKey) => (
                  <button
                    key={phaseKey}
                    type="button"
                    onClick={() => setGalleryFilter(phaseKey)}
                    className={`text-[9.5px] py-1 px-3 rounded-lg font-extrabold cursor-pointer transition uppercase ${
                      galleryFilter === phaseKey ? 'bg-white text-slate-900 shadow-3xs' : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {phaseKey === 'all' ? 'Melihat Semua' : phaseKey === 'before' ? 'Awal' : phaseKey === 'during' ? 'Proses' : 'Final'}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {photos
                .filter(p => {
                  if (galleryFilter === 'all') return true;
                  if (galleryFilter === 'before') return p.phase === 'initial';
                  if (galleryFilter === 'during') return p.phase === 'mid';
                  return p.phase === 'final';
                })
                .map((p) => (
                  <div
                    key={p.id}
                    className="h-20 rounded-xl overflow-hidden border border-slate-200 bg-white relative cursor-zoom-in hover:border-slate-400 transition shadow-4xs"
                    onClick={() => setFullscreenImage(p.file_url)}
                  >
                    <img src={p.file_url} className="w-full h-full object-cover" alt="Progress detail" />
                  </div>
                ))}
            </div>
          </div>

          {/* STREET MAPS COORDINATES AND MAP INTERACTIVE */}
          <div className="border-t border-slate-100 pt-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50 p-3.5 rounded-2xl border border-slate-200 shadow-3xs">
              <div className="text-xs">
                <span className="text-[9px] text-slate-400 block font-mono uppercase">Koordinat Spasial Geotagging</span>
                <strong className="text-slate-800 block font-mono mt-0.5 text-[11px] tracking-tight">
                  LAT: {recipient.latitude || -1.3323} &bull; LNG: {recipient.longitude || 124.8456}
                </strong>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${recipient.latitude || -1.3323},${recipient.longitude || 124.8456}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-1.5 px-3 bg-slate-900 hover:bg-slate-850 text-white rounded-xl text-[10px] uppercase font-black tracking-wider transition flex items-center gap-1.5 cursor-pointer font-sans shadow-xs active:scale-95"
                >
                  Rute Google Maps 🗺️
                </a>
              </div>
            </div>

            {/* Street Maps Container */}
            <div className="h-32 w-full bg-slate-100 rounded-2xl border border-slate-200 relative z-10 overflow-hidden shadow-inner flex items-center justify-center">
              <div ref={mapContainerRef} className="w-full h-full absolute inset-0 rounded-2xl" />
            </div>
          </div>

          <div className="flex items-center justify-end pt-2 gap-2">
            <button
              onClick={onClose}
              className="py-3 px-8 w-full sm:w-auto bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-black text-xs uppercase cursor-pointer rounded-2xl shadow-sm transition"
            >
              Tutup Lembaran Detail
            </button>
          </div>

        </div>
      </motion.div>
    </div>
  );
};
