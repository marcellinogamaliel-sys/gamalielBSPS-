/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import * as animePkg from 'animejs';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, CheckCircle2, Clock, AlertTriangle, 
  Search, Info, ArrowUpRight,
  Check, X, Truck, ThumbsUp, Navigation, User,
  Target, Zap, ShieldAlert, CheckSquare, Layers,
  Maximize2, Minimize2, ChevronDown, ChevronUp
} from 'lucide-react';
import { Recipient, Store, Village, DRPBItem, Distribution } from '../types';

import MapControls from './maps/MapControls';
import MapSidebar from './maps/MapSidebar';
import MapFilters from './maps/MapFilters';
import MapSearch from './maps/MapSearch';
import { createAnimatedMarker, createClusterIcon, getColorByProgress } from './maps/RecipientMarker';
import { createStoreIcon, buildStorePopup } from './maps/StoreMarker';
import { drawRoutes } from './maps/RouteLayer';
import { drawHeatmap, isHeatmapAvailable } from './maps/HeatmapLayer';
import { drawRadiusCircles } from './maps/RadiusLayer';
import { buildPopup } from './maps/PopupContent';
import { isValidCoordinate } from './maps/CoordinateValidator';

// Safe anime function extractor to prevent crashes and provide fallbacks
const getAnime = (): any => {
  if (!animePkg) return null;
  const anyPkg = animePkg as any;
  if (typeof anyPkg === 'function') return anyPkg;
  if (anyPkg.default && typeof anyPkg.default === 'function') return anyPkg.default;
  if (anyPkg.animate) return anyPkg.animate;
  if (anyPkg.default && anyPkg.default.animate) return anyPkg.default.animate;
  return null;
};
const anime = getAnime();

function getRecipientProgress(pb: Recipient, drpbItems: DRPBItem[], distributions: Distribution[]): number {
  if (pb.status === 'complete') return 100;
  if (pb.status === 'not_started') return 0;
  if (pb.status === 'has_finding') return 25;
  
  const rItems = drpbItems.filter(item => item.recipient_id === pb.id);
  if (rItems.length === 0) return 50;
  
  const completedCount = rItems.filter(item => {
    const deliveredVol = distributions
      .filter(dist => dist.recipient_id === pb.id && dist.drpb_item_id === item.id)
      .reduce((sum, curr) => sum + Number(curr.volume), 0);
    return deliveredVol >= item.required_qty;
  }).length;
  
  const pct = Math.round((completedCount / rItems.length) * 100);
  return Math.min(99, Math.max(1, pct));
}

interface MapTrackerProps {
  recipients: Recipient[];
  stores: Store[];
  villages: Village[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  onNavigate: (path: string, recipientId?: string) => void;
}

export default function MapTracker({
  recipients,
  stores,
  villages,
  drpbItems,
  distributions,
  onNavigate
}: MapTrackerProps) {
  const mapRef = useRef<any>(null);
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  const tileLayerRef = useRef<any>(null);
  const markersRef = useRef<{ [key: string]: any }>({});
  
  // Layer references
  const markerGroupRef = useRef<any>(null);
  const clusterGroupRef = useRef<any>(null);
  const heatmapLayerRef = useRef<any>(null);
  const radiusGroupRef = useRef<any>(null);
  const routeGroupRef = useRef<any>(null);
  const storeGroupRef = useRef<any>(null);

  // States
  const [searchTerm, setSearchTerm] = useState('');
  const [isLeafletReady, setIsLeafletReady] = useState(() => typeof window !== 'undefined' && !!(window as any).L);
  const [mapStyle, setMapStyle] = useState<'dark' | 'satellite' | 'terrain' | 'light'>('satellite');
  const [showMarkers, setShowMarkers] = useState(true);
  const [showClusters, setShowClusters] = useState(true);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [showRadius, setShowRadius] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isFiltersExpanded, setIsFiltersExpanded] = useState(true);
  const [mobileSidebarExpanded, setMobileSidebarExpanded] = useState(false);

  // Filters State
  const [selectedVillageFilter, setSelectedVillageFilter] = useState('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('all');
  const [selectedProgressFilter, setSelectedProgressFilter] = useState('all');
  
  // Active selected flying detail element
  const [activePin, setActivePin] = useState<any | null>(null);

  const TILE_LAYERS = {
    dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    terrain: 'https://tile.opentopomap.org/{z}/{x}/{y}.png',
    light: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
  };
  const TILE_ATTRIBUTIONS = {
    dark: '&copy; OpenStreetMap &copy; CARTO',
    satellite: 'Tiles &copy; Esri',
    terrain: 'Map data &copy; OpenTopoMap',
    light: '&copy; OpenStreetMap'
  };

  // Leaflet and plugins dynamic loader
  useEffect(() => {
    const loadScript = (src: string) => {
      return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) {
          resolve(true);
          return;
        }
        const script = document.createElement("script");
        script.src = src;
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
    };

    const loadCss = (href: string) => {
      if (document.querySelector(`link[href="${href}"]`)) return;
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;
      document.head.appendChild(link);
    };

    async function initializeLeaflet() {
      try {
        loadCss("https://unpkg.com/leaflet@1.9.4/dist/leaflet.css");
        loadCss("https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css");
        loadCss("https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css");

        await loadScript("https://unpkg.com/leaflet@1.9.4/dist/leaflet.js");
        await loadScript("https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js");
        await loadScript("https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js");
        
        setIsLeafletReady(true);
      } catch (e) {
        console.error("Failed to load Leaflet:", e);
      }
    }

    initializeLeaflet();
  }, []);

  // Synchronize Leaflet layout on fullscreen toggle
  useEffect(() => {
    if (mapRef.current) {
      const timer = setTimeout(() => {
        mapRef.current.invalidateSize();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isFullscreen]);

  // Handle standard mapped dataset with memoized calculations
  const mappedPBs = useMemo(() => {
    return recipients.map((r, index) => {
      const vName = villages.find(v => v.id === r.village_id)?.name || 'Desa Binaan';
      const progress = getRecipientProgress(r, drpbItems, distributions);
      
      let status_material = 'Belum Penyaluran';
      if (r.status === 'complete') status_material = 'Lengkap (100%)';
      else if (r.status === 'in_progress') status_material = 'Sedang Dikirim';
      else if (r.status === 'has_finding') status_material = 'Temuan Teknis';

      return {
        ...r,
        nomor_urut: index + 1,
        nama: r.full_name,
        desa: vName,
        kelompok: 'Kelompok ' + (r.group_id ? r.group_id.slice(-4).toUpperCase() : 'BSPS'),
        progress,
        status_material,
      };
    });
  }, [recipients, villages, drpbItems, distributions]);

  // Overall statistics row counters
  const globalStats = useMemo(() => {
    return {
      total: mappedPBs.length,
      complete: mappedPBs.filter(p => p.progress === 100).length,
      inProgress: mappedPBs.filter(p => p.progress > 0 && p.progress < 100).length,
      notStarted: mappedPBs.filter(p => p.progress === 0).length
    };
  }, [mappedPBs]);

  // Search, village and statuses filtering pipeline
  const filteredPBs = useMemo(() => {
    return mappedPBs.filter(pb => {
      const matchesSearch = pb.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            pb.nik.includes(searchTerm) ||
                            pb.desa.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesDesa = selectedVillageFilter === 'all' || pb.village_id === selectedVillageFilter;
      const matchesStatus = selectedStatusFilter === 'all' || pb.status === selectedStatusFilter;
      
      let matchesProgress = true;
      if (selectedProgressFilter === 'complete') matchesProgress = pb.progress === 100;
      else if (selectedProgressFilter === 'process') matchesProgress = pb.progress > 0 && pb.progress < 100;
      else if (selectedProgressFilter === 'unstarted') matchesProgress = pb.progress === 0;

      return matchesSearch && matchesDesa && matchesStatus && matchesProgress;
    });
  }, [mappedPBs, searchTerm, selectedVillageFilter, selectedStatusFilter, selectedProgressFilter]);

  // Inject Leaflet Style modifications and cleanup properly on component unmount
  useEffect(() => {
    let customStyles = document.getElementById('marker-styles-injection');
    if (!customStyles) {
      customStyles = document.createElement('style');
      customStyles.id = 'marker-styles-injection';
      customStyles.innerHTML = `
        :root {
          --map-bg: #0f1117;
          --panel-bg: rgba(26, 29, 39, 0.88);
          --panel-border: rgba(45, 49, 72, 0.4);
          --panel-blur: blur(12px);
          --text-primary: #e2e8f0;
          --text-secondary: #94a3b8;
          --accent: #7c83ff;
        }
        .map-panel {
          background: var(--panel-bg);
          backdrop-filter: var(--panel-blur);
          -webkit-backdrop-filter: var(--panel-blur);
          border: 1px solid var(--panel-border);
          border-radius: 12px;
        }
        .custom-marker { background: transparent; border: none; }
        .marker-wrapper {
          position: relative;
          width: 44px;
          height: 54px;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .radar-ring {
          position: absolute;
          width: 32px;
          height: 32px;
          border: 1.5px solid;
          border-radius: 50%;
          top: 2px;
          opacity: 0;
          pointer-events: none;
          animation: radarPing 2.5s infinite cubic-bezier(0.25, 0, 0, 1);
        }
        .radar-ring.ring-2 { animation-delay: 1.25s; }
        .marker-body {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          border: 2px solid #ffffff;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #ffffff;
          font-weight: bold;
          position: relative;
          z-index: 2;
          transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .marker-icon { font-size: 13px; line-height: normal; }
        .marker-tail {
          width: 0; height: 0;
          border-left: 6px solid transparent; border-right: 6px solid transparent;
          border-top: 8px solid; position: absolute; top: 35px; z-index: 1;
        }
        .marker-badge {
          position: absolute; top: -4px; right: -4px;
          background: #0f172a; color: #ffffff; font-size: 8px; font-weight: 900;
          padding: 1px 3.5px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, 0.25);
          z-index: 3; font-family: monospace;
        }
        @keyframes markerPulse {
          0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.8); }
          50% { transform: scale(1.15); box-shadow: 0 0 0 15px rgba(239, 68, 68, 0); }
          100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }
        @keyframes radarPing {
          0% { transform: scale(0.5); opacity: 1; }
          100% { transform: scale(3.5); opacity: 0; }
        }
        @keyframes markerBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes markerRotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes markerGlow {
          0%, 100% { box-shadow: 0 0 10px 2px rgba(59, 130, 246, 0.6); }
          50% { box-shadow: 0 0 25px 8px rgba(59, 130, 246, 0.85); }
        }
        @keyframes markerSparkle {
          0%, 100% { transform: scale(1); filter: brightness(1); }
          25% { transform: scale(1.18); filter: brightness(1.4); }
          75% { transform: scale(0.95); filter: brightness(1.15); }
        }
        .leaflet-popup-content-wrapper {
          background: #0b0f19 !important;
          color: #f1f5f9 !important;
          box-shadow: 0 12px 36px rgba(0, 0, 0, 0.85), inset 0 0 0 1px rgba(99, 102, 241, 0.15) !important;
          border-radius: 16px !important;
          border: none !important;
        }
        .leaflet-popup-tip {
          background: #0b0f19 !important;
          box-shadow: none !important;
          border: none !important;
        }
        .leaflet-popup-content {
          margin: 0 !important;
          padding: 10px 12px !important;
        }
        .leaflet-popup-close-button {
          color: #94a3b8 !important;
        }
        .custom-cluster { background: transparent; border: none; }
        .cluster-wrapper { position: relative; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; }
        .cluster-ring { position: absolute; border-radius: 50%; border: 2px solid; pointer-events: none; }
        .cluster-ring.outer { width: 60px; height: 60px; animation: clusterPulseOuter 3s infinite linear; }
        .cluster-ring.middle { width: 48px; height: 48px; animation: clusterPulseMiddle 2s infinite ease-in-out; }
        @keyframes clusterPulseOuter {
          0% { transform: scale(1); opacity: 0.12; }
          50% { transform: scale(1.15); opacity: 0.4; }
          100% { transform: scale(1); opacity: 0.12; }
        }
        @keyframes clusterPulseMiddle {
          0% { transform: scale(1); opacity: 0.25; }
          50% { transform: scale(1.12); opacity: 0.65; }
          100% { transform: scale(1); opacity: 0.25; }
        }
        .cluster-body {
          width: 38px; height: 38px; border-radius: 50%; border: 2px solid #ffffff;
          display: flex; flex-direction: column; align-items: center; justify-content: center;
          color: #ffffff; font-weight: 900; box-shadow: 0 4px 15px rgba(0,0,0,0.35); z-index: 2;
        }
        .cluster-count { font-size: 13.5px; line-height: 1; }
        .cluster-label { font-size: 7px; text-transform: uppercase; font-weight: 953; letter-spacing: 0.4px; }
        .cluster-mini-bar {
          position: absolute; bottom: 4px; width: 34px; height: 4.5px;
          background: rgba(0,0,0,0.45); border-radius: 3.5px; padding: 0.6px;
          z-index: 3; overflow: hidden; border: 0.5px solid rgba(255,255,255,0.25);
        }
        .desa-label-text { box-shadow: 0 4px 12px rgba(0,0,0,0.5); font-family: monospace; }
        
        /* Mobile Scrollbar filter optimizations */
        .mobile-filter-scroller {
          scrollbar-width: none;
        }
        .mobile-filter-scroller::-webkit-scrollbar {
          display: none;
        }
        @media (max-width: 1024px) {
          .map-control-panel { 
            position: absolute !important; bottom: 0 !important; left: 0 !important; right: 0 !important; top: auto !important;
            width: 100% !important; border-radius: 16px 16px 0 0 !important; max-height: 38vh !important; overflow-y: auto !important; z-index: 1000 !important;
          }
          .marker-body { width: 30px !important; height: 30px !important; }
        }
      `;
      document.head.appendChild(customStyles);
    }
    return () => {
      const el = document.getElementById('marker-styles-injection');
      if (el) el.remove();
    };
  }, []);

  // Register action hooks on the window scope for Leaflet native HTML Popups, with automatic cleanup
  useEffect(() => {
    (window as any).openPBDetail = (id: string | number) => {
      onNavigate('recipient_detail', id.toString());
    };
    (window as any).focusOnMap = (lat: number, lng: number) => {
      if (mapRef.current && isValidCoordinate(lat, lng)) {
        mapRef.current.setView([Number(lat), Number(lng)], 17, { animate: true, duration: 1.2 });
      }
    };
    
    return () => {
      delete (window as any).openPBDetail;
      delete (window as any).focusOnMap;
    };
  }, [onNavigate]);

  // Clean, resilient Leaflet Map Initializer
  useEffect(() => {
    const L = (window as any).L;
    if (!L || !container) return;

    // Remove any existing leaflet map before laying down a new one
    if (mapRef.current) {
      try {
        mapRef.current.off();
        mapRef.current.remove();
      } catch (e) {
        console.warn("Leaflet dispose error: ", e);
      }
      mapRef.current = null;
    }

    // Centroid calculations with strict coordinates validation
    let centerLat = -6.9147;
    let centerLng = 107.6098;
    
    const validCoors = mappedPBs.filter(pb => isValidCoordinate(pb.latitude, pb.longitude));

    if (validCoors.length > 0) {
      centerLat = validCoors.reduce((sum, p) => sum + Number(p.latitude), 0) / validCoors.length;
      centerLng = validCoors.reduce((sum, p) => sum + Number(p.longitude), 0) / validCoors.length;
    }

    const map = L.map(container, { zoomControl: false }).setView([centerLat, centerLng], 12);
    mapRef.current = map;

    // Zoom controller on top-right
    L.control.zoom({ position: 'topright' }).addTo(map);

    // Style tiles layer configuration
    tileLayerRef.current = L.tileLayer(TILE_LAYERS[mapStyle], {
      maxZoom: 19,
      attribution: TILE_ATTRIBUTIONS[mapStyle]
    }).addTo(map);

    // Setup map groups
    markerGroupRef.current = L.layerGroup().addTo(map);
    
    // Check and initialize Cluster group fallback gracefully
    const isClusterSupported = typeof (L as any).markerClusterGroup === 'function';
    if (isClusterSupported) {
      clusterGroupRef.current = (L as any).markerClusterGroup({
        maxClusterRadius: 50,
        iconCreateFunction: (c: any) => createClusterIcon(L, c)
      }).addTo(map);
    } else {
      clusterGroupRef.current = L.layerGroup().addTo(map);
    }

    radiusGroupRef.current = L.layerGroup().addTo(map);
    routeGroupRef.current = L.layerGroup().addTo(map);
    storeGroupRef.current = L.layerGroup().addTo(map);

    // Standard Entrance Zoom / Fade-in transitions
    if (anime) {
      anime({
        targets: '#map-leaflet-element',
        opacity: [0, 1],
        duration: 900,
        easing: 'easeOutQuad'
      });
    }

    return () => {
      if (mapRef.current) {
        try {
          mapRef.current.off();
          mapRef.current.remove();
        } catch (err) {
          console.warn("Clean unmount warning: ", err);
        }
        mapRef.current = null;
      }
    };
  }, [isLeafletReady]);

  // Dynamic Tile Layer Style update
  useEffect(() => {
    const L = (window as any).L;
    if (!mapRef.current || !tileLayerRef.current || !L) return;

    mapRef.current.removeLayer(tileLayerRef.current);
    tileLayerRef.current = L.tileLayer(TILE_LAYERS[mapStyle], {
      maxZoom: 19,
      attribution: TILE_ATTRIBUTIONS[mapStyle]
    }).addTo(mapRef.current);
  }, [mapStyle, isLeafletReady]);

  // Layers redrawing pipeline
  useEffect(() => {
    const L = (window as any).L;
    const map = mapRef.current;
    if (!L || !map) return;

    // Safe resets
    if (markerGroupRef.current) markerGroupRef.current.clearLayers();
    if (clusterGroupRef.current) clusterGroupRef.current.clearLayers();
    if (radiusGroupRef.current) radiusGroupRef.current.clearLayers();
    if (routeGroupRef.current) routeGroupRef.current.clearLayers();
    if (storeGroupRef.current) storeGroupRef.current.clearLayers();

    if (heatmapLayerRef.current) {
      map.removeLayer(heatmapLayerRef.current);
      heatmapLayerRef.current = null;
    }

    // 1. Draw Stores safely with coordinates validation
    stores.forEach(st => {
      const lat = Number(st.latitude);
      const lng = Number(st.longitude);
      
      if (!isValidCoordinate(lat, lng)) return;
      
      const storeIcon = createStoreIcon(L);
      if (!storeIcon) return;

      const stMarker = L.marker([lat, lng], { icon: storeIcon });
      stMarker.bindPopup(buildStorePopup(st), { maxWidth: 220 });

      stMarker.on('click', () => {
        setActivePin(st);
        setMobileSidebarExpanded(true);
      });

      if (storeGroupRef.current) {
        storeGroupRef.current.addLayer(stMarker);
      }
    });

    // 2. Draw Recipient Markers or Clusters
    const mDict: { [key: string]: any } = {};

    filteredPBs.forEach(pb => {
      const lat = Number(pb.latitude);
      const lng = Number(pb.longitude);
      
      if (!isValidCoordinate(lat, lng)) return;

      const markerIcon = createAnimatedMarker(L, pb);
      if (!markerIcon) return;

      const marker = L.marker([lat, lng], { 
        icon: markerIcon,
        progress: pb.progress 
      } as any);

      // Simple popup without memory leak chart structures!
      const popupHtml = buildPopup(pb);
      marker.bindPopup(popupHtml, { maxWidth: 300 });

      marker.on('click', () => {
        setActivePin(pb);
        setMobileSidebarExpanded(true);
      });

      mDict[pb.id] = marker;

      // Add to corresponding layer or cluster group
      if (!showHeatmap) {
        if (showClusters && clusterGroupRef.current) {
          clusterGroupRef.current.addLayer(marker);
        } else if (showMarkers && markerGroupRef.current) {
          markerGroupRef.current.addLayer(marker);
        }
      }
    });

    markersRef.current = mDict;

    // 3. Draw routes path connections
    drawRoutes(L, routeGroupRef.current, filteredPBs, stores);

    // 4. Draw village distribution circles
    if (showRadius) {
      drawRadiusCircles(L, radiusGroupRef.current, mappedPBs, villages);
    }

    // 5. Draw Thermal Heatmap Layer
    if (showHeatmap) {
      const hLayer = drawHeatmap(L, map, filteredPBs);
      if (hLayer) {
        heatmapLayerRef.current = hLayer;
        if (anime) {
          anime({ targets: '.leaflet-marker-pane', opacity: 0, duration: 400 });
        }
      } else {
        // Fallback: Enable normal markers if heatmap can't initialize
        if (showClusters && clusterGroupRef.current) {
          filteredPBs.forEach(pb => {
            const m = markersRef.current[pb.id];
            if (m) clusterGroupRef.current.addLayer(m);
          });
        }
      }
    } else {
      if (anime) {
        anime({ targets: '.leaflet-marker-pane', opacity: 1, duration: 300 });
      }
    }
  }, [filteredPBs, showClusters, showMarkers, showHeatmap, showRadius, stores, villages, mappedPBs, isLeafletReady]);

  // Zoom center map on selection
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !activePin) return;
    
    const lat = Number(activePin.latitude);
    const lng = Number(activePin.longitude);
    
    if (isValidCoordinate(lat, lng)) {
      map.setView([lat, lng], 15, { animate: true });
    }
  }, [activePin]);

  // Focus transition flying helpers
  const flyToPB = (pbId: string) => {
    const pb = mappedPBs.find(p => p.id === pbId);
    if (!pb || !mapRef.current) return;
    
    const map = mapRef.current;
    const lat = Number(pb.latitude);
    const lng = Number(pb.longitude);
    
    if (!isValidCoordinate(lat, lng)) return;

    map.flyTo([lat, lng], 17, {
      animate: true,
      duration: 1.5
    });

    setActivePin(pb);

    map.once('moveend', () => {
      const marker = markersRef.current[pbId];
      if (marker) {
        marker.openPopup();
        const wrapper = document.querySelector(`.marker-wrapper[data-id="${pbId}"] .marker-body`);
        if (wrapper && anime) {
          anime({
            targets: wrapper,
            scale: [1, 1.45, 1],
            duration: 600,
            easing: 'easeInOutBack'
          });
        }
      }
    });
  };

  const sidebarElement = (
    <MapSidebar 
      activePin={activePin}
      setActivePin={setActivePin}
      filteredPBs={filteredPBs}
      mappedPBs={mappedPBs}
      drpbItems={drpbItems}
      distributions={distributions}
      flyToPB={flyToPB}
      onNavigate={onNavigate}
      isFullscreen={isFullscreen}
    />
  );

  // Error screen fallbacks
  if (!isLeafletReady && typeof window !== 'undefined') {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-white my-10 space-y-4 max-w-md mx-auto shadow-2xl">
        <AlertTriangle size={48} className="text-amber-500 mx-auto animate-bounce" />
        <h3 className="font-extrabold text-lg tracking-tight">Memuat Sistem Peta...</h3>
        <p className="text-sm text-slate-400">Menghubungkan ke satelit geolokasi dan mengunduh peta. Jika terlalu lamban, silakan muat ulang halaman.</p>
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mt-2" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Top Floating Dashboard Metric Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 block font-bold font-mono tracking-wide uppercase">Total Penerima</span>
            <div className="text-2xl font-black text-white mt-1">
              {globalStats.total}
            </div>
            <span className="text-[10px] text-indigo-400 font-medium">Bahan Fisik Terdata</span>
          </div>
          <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl">
            <User size={20} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 block font-bold font-mono tracking-wide uppercase">Lengkap (100%)</span>
            <div className="text-2xl font-black text-green-400 mt-1">
              {globalStats.complete}
            </div>
            <span className="text-[10px] text-green-400 font-medium">Bantuan Tersalurkan</span>
          </div>
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <CheckCircle2 size={20} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 block font-bold font-mono tracking-wide uppercase">Progres Penyaluran</span>
            <div className="text-2xl font-black text-amber-400 mt-1">
              {globalStats.inProgress}
            </div>
            <span className="text-[10px] text-amber-400 font-medium">Drop Material</span>
          </div>
          <div className="p-3 bg-amber-500/10 text-amber-500 rounded-xl">
            <Truck size={20} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 block font-bold font-mono tracking-wide uppercase">Belum Dropping</span>
            <div className="text-2xl font-black text-rose-400 mt-1">
              {globalStats.notStarted}
            </div>
            <span className="text-[10px] text-rose-400 font-medium">Antrean Tertunda</span>
          </div>
          <div className="p-3 bg-rose-500/10 text-rose-500 rounded-xl">
            <Clock size={20} />
          </div>
        </div>
      </div>

      {/* Main Map Split Screen and Floating Panels controller */}
      <div className={`grid ${isFullscreen ? 'grid-cols-1 gap-0' : 'grid-cols-1 lg:grid-cols-12 gap-6'} items-stretch`}>
        
        {/* Left Side: Map Container */}
        <div className={`${isFullscreen ? 'fixed inset-0 z-[9999] w-screen h-screen rounded-none border-none' : 'col-span-1 lg:col-span-8 flex flex-col h-[580px] rounded-3xl border border-slate-800'} relative overflow-hidden bg-slate-950 shadow-2xl`}>
          
          {/* Floating Search overlay */}
          <MapSearch searchTerm={searchTerm} setSearchTerm={setSearchTerm} />

          {/* Fullscreen Button Floating */}
          <div className="absolute top-4 right-16 z-[1000] pointer-events-auto flex items-center gap-2">
            <button
              id="map-fullscreen-btn"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-3 bg-slate-900/90 backdrop-blur-md hover:bg-slate-800 text-white border border-slate-700/60 rounded-2xl shadow-2xl transition duration-200 active:scale-95 cursor-pointer flex items-center gap-1.5 font-bold text-xs"
              title={isFullscreen ? "Keluar Layar Penuh" : "Buka Layar Penuh"}
            >
              {isFullscreen ? (
                <>
                  <Minimize2 size={14} className="text-amber-400" />
                  <span className="hidden sm:inline font-mono uppercase text-[9.5px]">Keluar</span>
                </>
              ) : (
                <>
                  <Maximize2 size={14} className="text-indigo-400" />
                  <span className="hidden sm:inline font-mono uppercase text-[9.5px]">Layar Penuh</span>
                </>
              )}
            </button>
          </div>

          {/* Core Leaflet map rendering hook context */}
          <div ref={setContainer} id="map-leaflet-element" className="w-full h-full" />

          {/* Floating Layers controller panel */}
          <AnimatePresence mode="wait">
            {!isFiltersExpanded ? (
              <motion.div 
                key="filters-collapsed"
                initial={{ opacity: 0, scale: 0.9, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 15 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
                onClick={() => setIsFiltersExpanded(true)}
                className="absolute bottom-4 left-4 z-[1000] pointer-events-auto map-panel map-control-panel p-2 px-3 text-white text-xs shadow-2xl select-none hover:bg-slate-900/95 transition duration-200 cursor-pointer flex items-center gap-2"
              >
                <Layers size={13} className="text-indigo-400" />
                <span className="font-extrabold uppercase font-mono text-[10px] tracking-wide">Buka Filter &amp; Layer</span>
                <ChevronUp size={14} className="text-slate-400 animate-bounce" />
              </motion.div>
            ) : (
              <motion.div 
                key="filters-expanded"
                initial={{ opacity: 0, scale: 0.92, x: -30 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.92, x: -30 }}
                transition={{ type: "spring", stiffness: 350, damping: 26 }}
                className="absolute bottom-4 left-4 z-[1000] w-64 pointer-events-auto map-panel map-control-panel p-4 text-white text-xs space-y-3 shadow-2xl max-h-[80%] overflow-y-auto"
              >
                <div className="flex items-center justify-between border-b border-slate-700/50 pb-2">
                  <div className="flex items-center gap-1.5">
                    <Layers size={13} className="text-indigo-400" />
                    <span className="font-extrabold uppercase font-mono text-[10.5px] tracking-wide">FILTER &amp; LAPISAN</span>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsFiltersExpanded(false);
                    }}
                    className="p-1 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
                    title="Sembunyikan"
                  >
                    <ChevronDown size={14} />
                  </button>
                </div>

                <MapControls 
                  mapStyle={mapStyle}
                  setMapStyle={setMapStyle}
                  showMarkers={showMarkers}
                  setShowMarkers={setShowMarkers}
                  showClusters={showClusters}
                  setShowClusters={setShowClusters}
                  showHeatmap={showHeatmap}
                  setShowHeatmap={setShowHeatmap}
                  showRadius={showRadius}
                  setShowRadius={setShowRadius}
                  isHeatmapSupported={isHeatmapAvailable((window as any).L)}
                />

                <MapFilters 
                  villages={villages}
                  selectedVillageFilter={selectedVillageFilter}
                  setSelectedVillageFilter={setSelectedVillageFilter}
                  selectedProgressFilter={selectedProgressFilter}
                  setSelectedProgressFilter={setSelectedProgressFilter}
                  selectedStatusFilter={selectedStatusFilter}
                  setSelectedStatusFilter={setSelectedStatusFilter}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Quick Legend Bottom Right overlay */}
          <div className="absolute bottom-4 right-4 z-[999] bg-slate-900/90 backdrop-blur-md px-3 py-2.5 rounded-xl border border-slate-800 text-[9px] space-y-1 text-white shadow-2xl min-w-[130px] hidden md:block select-none font-sans">
            <span className="font-extrabold font-mono text-[8.5px] text-indigo-400 block pb-1 border-b border-slate-800 uppercase tracking-widest">Warna Status</span>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" /><span>0% (Belum Mulai)</span></div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#f97316]" /><span>25% (Drop Awal)</span></div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#eab308]" /><span>50% (Konstruksi)</span></div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]" /><span>75% (Hampir Selesai)</span></div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#22c55e]" /><span>100% (Selesai Lunas)</span></div>
          </div>

          {/* Fullscreen Overlay Side flight panel */}
          {isFullscreen && (
            <div className="absolute top-[72px] right-4 z-[1000] w-80 max-h-[calc(100%-100px)] overflow-y-auto pointer-events-auto shadow-2xl flex flex-col gap-4">
              {sidebarElement}
            </div>
          )}
        </div>

        {/* Standard sidebar column layout desktop (when NOT in fullscreen) */}
        {!isFullscreen && (
          <div className="col-span-1 lg:col-span-4 hidden lg:flex flex-col gap-4">
            {sidebarElement}
          </div>
        )}

        {/* Mobile bottom sheet overlay layout */}
        {!isFullscreen && (
          <div className="block lg:hidden mt-2">
            <button 
              id="map-mobile-panel-toggle-btn"
              onClick={() => setMobileSidebarExpanded(!mobileSidebarExpanded)}
              className="w-full py-2 bg-indigo-650 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <span>📋</span> {mobileSidebarExpanded ? 'Sembunyikan Panel Detail' : 'Tampilkan Panel Detail / Daftar Material'}
            </button>
            <AnimatePresence>
              {mobileSidebarExpanded && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-4 border-2 border-slate-800 rounded-3xl p-1 overflow-hidden"
                >
                  {sidebarElement}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

      </div>
    </div>
  );
}
