/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  History, Search, Filter, FileSpreadsheet, 
  MapPin, Clock, ShieldCheck, RefreshCw 
} from 'lucide-react';
import { AuditLog } from '../types';
import { formatDate } from '../utils';

interface AuditTrailProps {
  logs: AuditLog[];
  onRefresh: () => Promise<void>;
}

export default function AuditTrail({
  logs,
  onRefresh
}: AuditTrailProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [refreshing, setRefreshing] = useState(false);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const formatJsonPretty = (valStr?: string) => {
    if (!valStr) return <span className="text-slate-400 italic font-sans text-xs">Kosong / Tidak ada data</span>;
    try {
      const obj = JSON.parse(valStr);
      return (
        <div className="space-y-1 font-mono text-[10.5px]">
          {Object.entries(obj).map(([key, value]) => {
            if (typeof value === 'object' && value !== null) return null;
            return (
              <div key={key} className="grid grid-cols-12 gap-1 py-1 border-b border-zinc-100 last:border-0 hover:bg-slate-50/50 px-1 rounded transition">
                <span className="col-span-4 font-extrabold text-slate-500 truncate" title={key}>{key}</span>
                <span className="col-span-8 text-slate-800 font-sans font-medium break-all">{String(value)}</span>
              </div>
            );
          })}
        </div>
      );
    } catch (err) {
      return <span className="break-all whitespace-pre-wrap">{valStr}</span>;
    }
  };

  // Filter lists
  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          log.user_id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    
    return matchesSearch && matchesAction;
  });

  const getLogActions = () => {
    const actions = new Set<string>();
    logs.forEach(l => actions.add(l.action));
    return Array.from(actions);
  };

  const handleExcelExport = () => {
    // Generate simple tab-separated or csv format
    let csvContent = "\uFEFF"; // UTF-8 BOM
    csvContent += "Waktu Tanggal;Operator ID;Jenis Aksi;Tipe Entitas;Entitas ID;Deskripsi;IP Address;Latitude;Longitude\n";

    filteredLogs.forEach(l => {
      csvContent += `"${l.created_at}";"${l.user_id}";"${l.action}";"${l.entity_type || ''}";"${l.entity_id || ''}";"${l.description.replace(/"/g, '""')}";"${l.ip_address || ''}";"${l.gps_latitude || ''}";"${l.gps_longitude || ''}"\n`;
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "audit-logs-bsps2026.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const triggerRefresh = async () => {
    setRefreshing(true);
    await onRefresh();
    setRefreshing(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Filtering header and sheet export actions */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 tracking-tight flex items-center gap-1.5 font-sans">
            <History size={20} className="text-slate-800" />
            Audit Trail Keamanan Sistem (Immutable)
          </h2>
          <p className="text-xs text-slate-500">Log perekaman aktivitas transaksi database oleh operator TFL. Tidak dapat diubah/dihapus (Policy RLS INSERT-Only).</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={triggerRefresh}
            disabled={refreshing}
            className="p-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-705 rounded-xl cursor-pointer disabled:opacity-45"
            title="Muat Ulang Data"
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
          </button>

          <button
            onClick={handleExcelExport}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1 transition active:scale-95 shadow-xs"
          >
            <FileSpreadsheet size={14} className="text-emerald-400" />
            Ekspor Histori ke Excel
          </button>
        </div>
      </div>

      {/* FILTER SEARCH CRITERIA */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="col-span-1 sm:col-span-2 relative">
          <Search size={14} className="absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Cari deskripsi audit atau ID Operator..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8 pr-3 py-2 w-full text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          />
        </div>

        <div>
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          >
            <option value="all">Seluruh Kategori Aksi</option>
            {getLogActions().map(act => (
              <option key={act} value={act}>{act}</option>
            ))}
          </select>
        </div>
      </div>

      {/* AUDIT TIMELINE TABLE */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs bg-white">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-150 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-4 font-bold">Waktu & Tanggal</th>
                <th className="py-2.5 px-3 font-bold">Operator ID</th>
                <th className="py-2.5 px-3 font-bold">Aksi Database</th>
                <th className="py-2.5 px-4 font-bold">Uraian / Deskripsi Kegiatan</th>
                <th className="py-2.5 px-3 font-bold">IP & GPS Signatures</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 font-sans">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-405 italic">
                    Tidak ada catatan aktivitas audit yang terekam.
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <React.Fragment key={log.id}>
                    <tr className="hover:bg-slate-50/20">
                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {formatDate(log.created_at)}
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="font-bold text-slate-900 bg-slate-100 hover:bg-slate-200 px-2.5 py-0.5 rounded font-mono text-[10px]">
                          {log.user_id}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="font-mono text-[10px] font-extrabold uppercase py-0.2 px-1.5 rounded bg-slate-950 text-white border border-slate-800">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">
                        <div>{log.description}</div>
                        {(log.prev_value || log.post_value) && (
                          <div className="mt-2.5">
                            <button
                              onClick={() => setExpandedLogId(expandedLogId === log.id ? null : log.id)}
                              className="inline-flex items-center gap-1.5 text-[10.5px] font-bold text-[#b45309] bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2.5 py-1 rounded-lg transition active:scale-95 cursor-pointer shadow-3xs"
                            >
                              <span>⚡ {expandedLogId === log.id ? 'Tutup Perbandingan' : 'Lihat Data Prev/Post (Verifikasi Audit)'}</span>
                            </button>
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-slate-500 font-mono text-[10px] whitespace-nowrap space-y-0.5">
                        <span className="block text-slate-700 font-semibold flex items-center gap-0.5">
                          <ShieldCheck size={11} className="text-slate-400" />
                          IP: {log.ip_address}
                        </span>
                        {log.gps_latitude && log.gps_longitude ? (
                          <span className="block text-sky-700 flex items-center gap-0.5 font-bold">
                            <MapPin size={9} />
                            GPS: {log.gps_latitude.toFixed(4)}, {log.gps_longitude.toFixed(4)}
                          </span>
                        ) : null}
                      </td>
                    </tr>
                    {expandedLogId === log.id && (log.prev_value || log.post_value) && (
                      <tr className="bg-amber-50/20">
                        <td colSpan={5} className="p-5 px-6 border-t border-slate-200">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                            {/* PREV VALUE */}
                            <div className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-3xs space-y-3">
                              <span className="text-[10px] font-mono font-black text-slate-500 uppercase block tracking-wide">
                                ⏪ SEBELUM PERUBAHAN (PREVIOUS STATE)
                              </span>
                              <div className="bg-slate-50/50 p-2.5 rounded-lg border border-slate-105 max-h-64 overflow-y-auto">
                                {formatJsonPretty(log.prev_value)}
                              </div>
                            </div>

                            {/* POST VALUE */}
                            <div className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-3xs space-y-3">
                              <span className="text-[10px] font-mono font-black text-rose-800 uppercase block tracking-wide">
                                ⏩ SESUDAH PERUBAHAN (POST-TRANSACTION STATE)
                              </span>
                              <div className="bg-slate-50/50 p-2.5 rounded-lg border border-slate-105 max-h-64 overflow-y-auto">
                                {formatJsonPretty(log.post_value)}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
