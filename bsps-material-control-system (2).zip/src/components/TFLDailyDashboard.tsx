import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AlertTriangle, 
  MapPin, 
  Clock, 
  ShieldAlert, 
  CheckCircle2, 
  Sparkles, 
  Shield, 
  Compass, 
  HelpCircle,
  TrendingUp,
  Inbox,
  Search,
  Filter,
  Calendar,
  Eye,
  Users,
  ChevronRight,
  User,
  UserCheck,
  Check,
  XCircle,
  RefreshCw,
  Layers,
  ArrowRight
} from 'lucide-react';
import TFLDashboardCharts from './TFLDashboardCharts';
import {
  ResponsiveContainer,
  BarChart as RechartsBarChart,
  Bar as RechartsBar,
  XAxis as RechartsXAxis,
  YAxis as RechartsYAxis,
  CartesianGrid as RechartsCartesianGrid,
  Tooltip as RechartsTooltip,
  Legend as RechartsLegend
} from 'recharts';

interface TFLDailyDashboardProps {
  tflTeam?: string;
  onNavigateToRecipient: (id: string) => void;
  onNavigateToFindings: () => void;
  recipients?: any[];
  villages?: any[];
  groups?: any[];
  distributions?: any[];
}

export default function TFLDailyDashboard({ 
  tflTeam, 
  onNavigateToRecipient, 
  onNavigateToFindings,
  recipients = [],
  villages = [],
  groups = [],
  distributions = []
}: TFLDailyDashboardProps) {
  const [summary, setSummary] = useState<any>({ 
    priority_visits: [], 
    material_progress: [], 
    total_pb: 0, 
    priority_visits_count: 0, 
    disputed_distributions_count: 0, 
    unresolved_findings_count: 0, 
    pending_confirmations_count: 0 
  });
  const [loading, setLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  // Filter States for Daily Progress
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVillage, setSelectedVillage] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'all' | 'inputted' | 'pending' | 'disputed'>('all');

  // Fetch summary on load or team filter changes
  const fetchSummary = async () => {
    setLoading(true);
    try {
      const params = tflTeam ? `?tfl_team=${encodeURIComponent(tflTeam)}` : '';
      const res = await fetch(`/api/tfl/daily-summary${params}`);
      const data = await res.json();
      setSummary(data);
      setHasError(false);
    } catch (e) {
      console.error("Gagal memuat ringkasan harian TFL:", e);
      setHasError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSummary();
  }, [tflTeam]);

  // Filter PBs under current TFL team
  const tflRecipients = useMemo(() => {
    if (!recipients) return [];
    if (!tflTeam || tflTeam === 'all') return recipients;
    return recipients.filter(r => r.tfl_team === tflTeam);
  }, [recipients, tflTeam]);

  // Compute inputs for each PB
  const pbActivityList = useMemo(() => {
    return tflRecipients.map(pb => {
      const pbDists = (distributions || []).filter(d => d.recipient_id === pb.id);
      
      const pbConfirmedDists = pbDists.filter(d => d.confirmation_status === 'confirmed_by_recipient');
      const pbDisputedDists = pbDists.filter(d => d.confirmation_status === 'disputed');
      const pbPendingDists = pbDists.filter(d => !d.confirmation_status || d.confirmation_status === 'pending');
      
      const hasInputted = pbConfirmedDists.length > 0 || pbDisputedDists.length > 0;
      const totalVolume = pbDists.reduce((acc, curr) => acc + Number(curr.volume || 0), 0);
      const confirmedVolume = pbConfirmedDists.reduce((acc, curr) => acc + Number(curr.volume || 0), 0);
      const disputedVolume = pbDisputedDists.reduce((acc, curr) => acc + Number(curr.volume || 0), 0);
      
      // Latest activity date
      let lastInputDate: string | null = null;
      const confirmedDates = pbConfirmedDists.map(d => d.confirmed_at || d.distribution_date).filter(Boolean);
      const disputedDates = pbDisputedDists.map(d => d.confirmed_at || d.distribution_date).filter(Boolean);
      const allDates = [...confirmedDates, ...disputedDates].sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
      if (allDates.length > 0) {
        lastInputDate = allDates[0];
      }

      return {
        pb,
        pbDists,
        pbConfirmedDists,
        pbDisputedDists,
        pbPendingDists,
        hasInputted,
        totalVolume,
        confirmedVolume,
        disputedVolume,
        lastInputDate
      };
    });
  }, [tflRecipients, distributions]);

  // Apply Search + Select Filters
  const filteredActivityList = useMemo(() => {
    return pbActivityList.filter(item => {
      // 1. Village filter
      if (selectedVillage && item.pb.village_id !== selectedVillage) return false;
      
      // 2. Group filter
      if (selectedGroup && item.pb.group_id !== selectedGroup) return false;
      
      // 3. Status filter
      if (selectedStatusFilter === 'inputted' && !item.hasInputted) return false;
      if (selectedStatusFilter === 'pending' && item.hasInputted) return false;
      if (selectedStatusFilter === 'disputed' && item.pbDisputedDists.length === 0) return false;
      
      // 4. Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const nameMatch = item.pb.full_name?.toLowerCase().includes(query);
        const nikMatch = item.pb.nik?.toLowerCase().includes(query);
        const kkMatch = item.pb.kk_number?.toLowerCase().includes(query);
        return nameMatch || nikMatch || kkMatch;
      }
      
      return true;
    }).sort((a, b) => {
      // Sort by last input timestamp if existing, otherwise alphabetical or by name
      if (a.lastInputDate && b.lastInputDate) {
        return new Date(b.lastInputDate).getTime() - new Date(a.lastInputDate).getTime();
      }
      if (a.lastInputDate) return -1;
      if (b.lastInputDate) return 1;
      return a.pb.full_name.localeCompare(b.pb.full_name);
    });
  }, [pbActivityList, selectedVillage, selectedGroup, selectedStatusFilter, searchQuery]);

  // Dynamic filter dropdown items based on actual data
  const uniqueVillagesInTeam = useMemo(() => {
    const vIds = Array.from(new Set(tflRecipients.map(r => r.village_id)));
    return villages.filter(v => vIds.includes(v.id));
  }, [tflRecipients, villages]);

  const uniqueGroupsInTeam = useMemo(() => {
    let recsInTeam = tflRecipients;
    if (selectedVillage) {
      recsInTeam = recsInTeam.filter(r => r.village_id === selectedVillage);
    }
    const gIds = Array.from(new Set(recsInTeam.map(r => r.group_id)));
    return groups.filter(g => gIds.includes(g.id));
  }, [tflRecipients, selectedVillage, groups]);

  // General counters for stats headers
  const stats = useMemo(() => {
    const totalCount = tflRecipients.length;
    const inputtedCount = pbActivityList.filter(item => item.hasInputted).length;
    const pendingCount = totalCount - inputtedCount;
    const disputedCount = pbActivityList.filter(item => item.pbDisputedDists.length > 0).length;
    
    return {
      totalCount,
      inputtedCount,
      pendingCount,
      disputedCount
    };
  }, [tflRecipients, pbActivityList]);

  // Real-time distribution achievements comparison among villages, groups, or PBs currently filtered
  const capaianChartData = useMemo(() => {
    let groupingType: 'village' | 'group' | 'pb' = 'village';
    if (selectedVillage) {
      if (selectedGroup) {
        groupingType = 'pb';
      } else {
        groupingType = 'group';
      }
    }

    const MapStore: Record<string, {
      name: string;
      id: string;
      "Diterima (✓)": number;
      "Sedang Dropping (•)": number;
      "Disangkal (⚠️)": number;
      total: number;
    }> = {};

    filteredActivityList.forEach(item => {
      let key = '';
      let categoryName = '';

      if (groupingType === 'village') {
        key = item.pb.village_id;
        categoryName = villages.find(v => v.id === item.pb.village_id)?.name || 'Tidak Diketahui';
      } else if (groupingType === 'group') {
        key = item.pb.group_id;
        categoryName = groups.find(g => g.id === item.pb.group_id)?.name || 'Umum';
      } else {
        key = item.pb.id;
        categoryName = item.pb.full_name;
      }

      if (!MapStore[key]) {
        MapStore[key] = {
          name: categoryName,
          id: key,
          "Diterima (✓)": 0,
          "Sedang Dropping (•)": 0,
          "Disangkal (⚠️)": 0,
          total: 0
        };
      }

      const pbPendingVolume = item.pbPendingDists.reduce((acc: number, curr: any) => acc + Number(curr.volume || 0), 0);

      MapStore[key]["Diterima (✓)"] += Number(item.confirmedVolume || 0);
      MapStore[key]["Disangkal (⚠️)"] += Number(item.disputedVolume || 0);
      MapStore[key]["Sedang Dropping (•)"] += pbPendingVolume;
      MapStore[key].total += Number(item.totalVolume || 0);
    });

    const sortedData = Object.values(MapStore).sort((a, b) => b.total - a.total);
    // Limit lists to reasonable counts for readability
    const limit = groupingType === 'pb' ? 12 : 15;

    return {
      type: groupingType,
      data: sortedData.slice(0, limit)
    };
  }, [filteredActivityList, selectedVillage, selectedGroup, villages, groups]);

  // AI Insights calculation specifically tailored for TFL
  const aiInsights = useMemo(() => {
    const list: string[] = [];
    if (!summary || hasError) return list;
    
    // 1. Visit Ratio
    const total = summary.total_pb || 0;
    const left = summary.priority_visits_count || 0;
    const progress = total > 0 ? Math.round(((total - left) / total) * 100) : 100;
    list.push(`Laju kunjungan verifikasi lapangan mencapai ${progress}%. Desa di wilayah tugas Anda membutuhkan mobilisasi intensif secara berkala.`);

    // 2. Material comparison
    if (summary.material_progress && summary.material_progress.length > 0) {
      const sem = summary.material_progress.find((m: any) => m.material.toLowerCase().includes('semen'));
      if (sem) {
        const pct = sem.target > 0 ? Math.round((sem.actual / sem.target) * 100) : 0;
        list.push(`Penyaluran komoditas Semen berada di kisaran ${pct}% dari total volume target DRPB Swadaya.`);
      } else {
        list.push(`Model memprediksi kesiapan material semen, besi, dan kayu penunjang berada dalam batas deviasi aman.`);
      }
    } else {
      list.push(`Tidak ada data rencana material DRPB aktif yang terdeteksi untuk wilayah tugas Anda.`);
    }

    // 3. Confirmations and receipts
    if (summary.pending_confirmations_count > 0) {
      list.push(`Keterlambatan konfirmasi tanda terima DRPB oleh beberapa penerima manfaat berisiko menghambat kelancaran pencairan termin berikutnya.`);
    } else {
      list.push(`Seluruh tanda terima DRPB dari penerima manfaat dalam kondisi 100% tuntas terkonfirmasi tanpa hambatan.`);
    }

    return list;
  }, [summary, hasError]);

  const aiAnomalies = useMemo(() => {
    const list: string[] = [];
    if (!summary || hasError) return list;

    if (summary.disputed_distributions_count > 0) {
      list.push(`⚠️ Terdeteksi ${summary.disputed_distributions_count} transaksi ditolak (disputed) oleh penerima bantuan. Cek dokumentasi foto drop-off.`);
    }
    if (summary.unresolved_findings_count > 0) {
      list.push(`⚠️ Ada ${summary.unresolved_findings_count} laporan temuan penyimpangan atau material cacat yang belum diselesaikan.`);
    }
    if (summary.priority_visits_count > ((summary.total_pb || 0) * 0.5)) {
      list.push(`⚠️ Lebih dari 50% Penerima Bantuan belum memulai pengerjaan fisik konstruksi atau belum dikunjungi.`);
    }

    if (list.length === 0) {
      list.push(`✅ Bersih: Tidak mendeteksi anomali spasial, kargo, ataupun penolakan volume di lapangan saat ini.`);
    }
    return list;
  }, [summary, hasError]);

  const aiRecommendations = useMemo(() => {
    const list: string[] = [];
    if (!summary || hasError) return list;

    if (summary.priority_visits_count > 0) {
      list.push(`Dahulukan peninjauan langsung ke ${summary.priority_visits_count} PB dengan status pengerjaan belum mulai.`);
    }
    if (summary.disputed_distributions_count > 0) {
      list.push(`Kunjungi PB yang menyangkal kiriman material untuk melakukan mediasi tiga pihak bersama Supplier.`);
    }
    if (summary.pending_confirmations_count > 0) {
      list.push(`Dampingi penerima melakukan scan QR konfirmasi untuk melunasi status penyerahan material.`);
    }

    if (list.length === 0) {
      list.push(`Monitor progres drop-off harian secara rutin dan lakukan sinkronisasi data dikoordinasikan dengan Korkab.`);
    }
    return list;
  }, [summary, hasError]);

  if (loading) {
    return (
      <div className="p-12 text-center text-sm text-slate-500 font-medium flex flex-col items-center gap-3">
        <div className="w-8 h-8 rounded-full border-4 border-slate-200 border-t-amber-600 animate-spin" />
        <span>Memuat ringkasan pekerjaan lapangan hari ini...</span>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="p-8 text-center text-sm text-rose-500 bg-rose-50 rounded-2xl border border-rose-100 font-semibold">
        Gagal memuat data ringkasan pendukung TFL. Silakan coba lagi nanti.
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* SECTION 1: ANALISIS AI SEBAGAI INSIGHT UTAMA (ATAS) */}
      <div className="relative bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl p-6.5 shadow-md overflow-hidden">
        {/* Background glow effects */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-60 h-60 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5 border-b border-white/10 pb-5">
          <div className="space-y-1">
            <h2 className="text-base font-black tracking-tight flex items-center gap-2">
              <Sparkles className="text-amber-400 w-5 h-5 animate-pulse" />
              Asisten Analisis &amp; Kognitif AI TFL
            </h2>
          </div>
          <p className="text-[10px] text-slate-400 font-medium font-sans">
              Layanan deteksi dini botol leher, kepatuhan koordinat spasial, dan asisten pembuat keputusan fasilitator lapangan.
          </p>
          <div className="flex items-center gap-1.5 self-start sm:self-auto bg-amber-400/20 border border-amber-400/30 px-3 py-1 rounded-full text-[9px] font-mono font-black text-amber-350 uppercase tracking-widest">
            🤖 COGNITIVE TFL AGENT ACTIVE
          </div>
        </div>

        {/* 3-Column Responsive AI Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 relative z-10">
          {/* Column A: Predictive Insights */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5 space-y-3 shadow-2xs flex flex-col justify-between">
            <div className="space-y-2.5">
              <div className="flex items-center gap-2 border-b border-white/10 pb-2">
                <Compass className="text-amber-400 w-4 h-4" />
                <span className="text-[10.5px] font-black text-slate-300 uppercase tracking-wider font-mono">Wawasan Lapangan (Insights)</span>
              </div>
              <ul className="space-y-2 text-[10.5px] text-slate-250 leading-relaxed list-none pl-0 animate-fade-in">
                {loading ? (
                    Array.from({ length: 3 }).map((_, i) => (
                      <li key={i} className="flex items-start gap-2 animate-pulse">
                        <div className="w-2 h-2 bg-slate-600 rounded-full mt-1 shrink-0" />
                        <div className="h-3 bg-slate-600 rounded-full w-full" />
                      </li>
                    ))
                ) : aiInsights.map((insight, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-black mt-0.5 shrink-0">•</span>
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Column B: Alerts / Anomalies */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5 space-y-3 shadow-2xs flex flex-col justify-between">
            <div className="space-y-2.5">
              <div className="flex items-center gap-2 border-b border-white/10 pb-2">
                <AlertTriangle className="text-rose-400 w-4 h-4" />
                <span className="text-[10.5px] font-black text-slate-300 uppercase tracking-wider font-mono">Peringatan &amp; Anomali</span>
              </div>
              <ul className="space-y-2 text-[10.5px] text-slate-250 leading-relaxed list-none pl-0">
                {loading ? (
                    Array.from({ length: 2 }).map((_, i) => (
                      <li key={i} className="flex items-start gap-2 bg-rose-950/20 border border-rose-900/30 p-2 rounded-xl animate-pulse">
                        <div className="w-4 h-4 bg-rose-900 rounded-full shrink-0" />
                        <div className="h-3 bg-rose-900 rounded-full w-full" />
                      </li>
                    ))
                ) : aiAnomalies.map((anomaly, idx) => (
                  <li key={idx} className="flex items-start gap-2 bg-rose-950/20 border border-rose-900/30 p-2 rounded-xl text-rose-200">
                    <span className="text-rose-400 font-extrabold mt-0.5 shrink-0">⚠️</span>
                    <span>{anomaly}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Column C: Action Recommendations */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5 space-y-3 shadow-2xs flex flex-col justify-between">
            <div className="space-y-2.5">
              <div className="flex items-center gap-2 border-b border-white/10 pb-2">
                <Shield className="text-sky-400 w-4 h-4" />
                <span className="text-[10.5px] font-black text-slate-300 uppercase tracking-wider font-mono">Rekomendasi Tindakan</span>
              </div>
              <ul className="space-y-2 text-[10.5px] text-slate-250 leading-relaxed list-none pl-0">
                {loading ? (
                    Array.from({ length: 3 }).map((_, i) => (
                      <li key={i} className="flex items-start gap-2 bg-sky-950/20 border border-sky-900/30 p-2 rounded-xl animate-pulse">
                        <div className="w-2 h-2 bg-sky-900 rounded-full mt-1.5 shrink-0" />
                        <div className="h-3 bg-sky-900 rounded-full w-full" />
                      </li>
                    ))
                ) : aiRecommendations.map((rec, idx) => (
                  <li key={idx} className="flex items-start gap-2 bg-sky-950/20 border border-sky-900/30 p-2 rounded-xl text-sky-200">
                    <span className="w-1.5 h-1.5 bg-sky-400 rounded-full mt-1.5 shrink-0" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: CHARTS DAN GRAFIK STATISTIK (TENGAH) */}
      <TFLDashboardCharts summary={summary} />
      
      {/* SECTION 3: QUICK COUNTS & DISPUTES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Priority Visit Count */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-3xs flex items-center gap-4 text-left">
          <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
            <MapPin size={22} />
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Belum Dikunjungi</h4>
            <p className="text-xl font-black text-slate-800">{summary?.priority_visits_count ?? 0}</p>
            <p className="text-[9.5px] text-slate-500 font-semibold">Penerima Manfaat butuh monitoring</p>
          </div>
        </div>

        {/* Unresolved Findings Count */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-3xs flex items-center gap-4 text-left">
          <div className="p-3 bg-rose-50 rounded-xl text-rose-600">
            <AlertTriangle size={22} />
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Temuan Terbuka</h4>
            <p className="text-xl font-black text-slate-800">{summary?.unresolved_findings_count ?? 0}</p>
            <p className="text-[9.5px] text-slate-500 font-semibold">Masalah perlu ditindaklanjuti segera</p>
          </div>
        </div>

        {/* Pending Confirmations Count */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 shadow-3xs flex items-center gap-4 text-left">
          <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
            <Clock size={22} />
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Menunggu Verifikasi PB</h4>
            <p className="text-xl font-black text-slate-800">{summary?.pending_confirmations_count ?? 0}</p>
            <p className="text-[9.5px] text-slate-500 font-semibold">Tanda terima material terkirim</p>
          </div>
        </div>
      </div>

      {(summary?.disputed_distributions_count ?? 0) > 0 && (
        <div className="bg-rose-50 border-2 border-rose-200 rounded-2xl p-4 flex items-start gap-3 text-left">
          <ShieldAlert size={20} className="text-rose-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-rose-800">
              {summary.disputed_distributions_count} Penyaluran Disangkal oleh Penerima Bantuan
            </p>
            <p className="text-[10.5px] text-rose-650 mt-1">
              Ada perbedaan volume atau ketidaksesuaian barang dari supplier yang dilaporkan. Segera lakukan pengecekan fisik.
            </p>
            <button
              onClick={onNavigateToFindings}
              className="mt-2 text-[10px] font-extrabold text-rose-700 hover:text-rose-900 uppercase tracking-wider font-mono bg-rose-100 border border-rose-200 px-2.5 py-1 rounded cursor-pointer transition text-left"
            >
              Buka Layanan Pengaduan &amp; Temuan →
            </button>
          </div>
        </div>
      )}
      
      {/* SECTION 4: PROGRES HARIAN & KONFIRMASI MANDIRI PB */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm text-left">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5 mb-5">
          <div className="space-y-1">
            <h3 className="text-sm font-black font-mono text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Users size={18} className="text-indigo-600" />
              Progres Pelaporan &amp; Input Mandiri Penerima Bantuan (PB)
            </h3>
            <p className="text-[11px] text-slate-500 font-medium">
              Monitor progres harian siapa saja keluarga penerima bantuan yang telah menginput data konfirmasi barang atau melaporkan kendala lewat QR-code.
            </p>
          </div>
          
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[10px] font-bold font-mono bg-slate-100 border border-slate-200 px-3 py-1 rounded-full text-slate-700 uppercase tracking-wider">
              Tim Lapangan: {tflTeam && tflTeam !== 'all' ? tflTeam : 'Seluruh Wilayah'}
            </span>
          </div>
        </div>

        {/* METRICS PANEL */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 mb-5">
          <div className="bg-slate-50/60 border border-slate-200 rounded-2xl p-4 text-left">
            <span className="text-[9px] font-bold text-slate-450 uppercase tracking-wider block font-mono">Total Binaan TFL</span>
            <span className="text-lg font-black text-slate-800 block mt-0.5">{stats.totalCount} PB</span>
          </div>
          <div className="bg-emerald-50/40 border border-emerald-150 rounded-2xl p-4 text-left">
            <span className="text-[9px] font-bold text-emerald-700 uppercase tracking-wider block font-mono">Tuntas Input QR</span>
            <span className="text-lg font-black text-emerald-600 block mt-0.5">{stats.inputtedCount} PB</span>
          </div>
          <div className="bg-amber-50/40 border border-amber-150 rounded-2xl p-4 text-left">
            <span className="text-[9px] font-bold text-amber-700 uppercase tracking-wider block font-mono">Belum Scan/Konfirmasi</span>
            <span className="text-lg font-black text-amber-600 block mt-0.5">{stats.pendingCount} PB</span>
          </div>
          <div className="bg-rose-50/40 border border-rose-150 rounded-2xl p-4 text-left">
            <span className="text-[9px] font-bold text-rose-700 uppercase tracking-wider block font-mono">Mengajukan Sangkalan</span>
            <span className="text-lg font-black text-rose-600 block mt-0.5">{stats.disputedCount} PB</span>
          </div>
        </div>

        {/* FILTER BAR PANEL WITH CASCADE DROP-DOWNS */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-5 space-y-4">
          <div className="flex flex-col lg:flex-row gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3.5 top-3 text-slate-400" />
              <input 
                type="text"
                placeholder="Cari Penerima Bantuan (Nama, NIK, atau KK)..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white rounded-xl border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 shadow-3xs"
              />
            </div>

            {/* Select Desa / Wilayah */}
            <div className="w-full lg:w-48 relative">
              <label className="absolute -top-2 left-3 bg-slate-50 px-1.5 text-[8px] font-black uppercase text-slate-400 font-mono tracking-wider">Saring Desa</label>
              <select
                value={selectedVillage}
                onChange={e => {
                  setSelectedVillage(e.target.value);
                  setSelectedGroup(''); // Reset group cascade search when village selection changes
                }}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 shadow-3xs cursor-pointer"
              >
                <option value="">Semua Desa</option>
                {uniqueVillagesInTeam.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>

            {/* Select Kelompok Pokman */}
            <div className="w-full lg:w-48 relative">
              <label className="absolute -top-2 left-3 bg-slate-50 px-1.5 text-[8px] font-black uppercase text-slate-400 font-mono tracking-wider">Saring Pokman</label>
              <select
                value={selectedGroup}
                onChange={e => setSelectedGroup(e.target.value)}
                disabled={!selectedVillage && uniqueGroupsInTeam.length === 0}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 shadow-3xs disabled:opacity-60 cursor-pointer"
              >
                <option value="">Semua Kelompok</option>
                {uniqueGroupsInTeam.map(g => (
                  <option key={g.id} value={g.id}>{g.name}</option>
                ))}
              </select>
            </div>

            {/* Select Status Input */}
            <div className="w-full lg:w-44 relative">
              <label className="absolute -top-2 left-3 bg-slate-50 px-1.5 text-[8px] font-black uppercase text-slate-400 font-mono tracking-wider">Status Validasi</label>
              <select
                value={selectedStatusFilter}
                onChange={e => setSelectedStatusFilter(e.target.value as any)}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 shadow-3xs cursor-pointer"
              >
                <option value="all">Semua Status</option>
                <option value="inputted">Telah Mengonfirmasi</option>
                <option value="pending">Belum Konfirmasi</option>
                <option value="disputed">Mengajukan Sangkalan</option>
              </select>
            </div>
          </div>

          {/* Active Filtering Tag Indicators */}
          {(selectedVillage || selectedGroup || selectedStatusFilter !== 'all' || searchQuery) && (
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200/60">
              <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-slate-500">
                <Filter size={12} className="text-slate-400 shrink-0" />
                <span>Filter Aktif Berjalan:</span>
                {selectedVillage && (
                  <span className="bg-indigo-50 text-indigo-700 border border-indigo-150 font-bold px-2 py-0.5 rounded-md">
                    Desa: {villages.find(v => v.id === selectedVillage)?.name}
                  </span>
                )}
                {selectedGroup && (
                  <span className="bg-teal-50 text-teal-700 border border-teal-150 font-bold px-2 py-0.5 rounded-md">
                    Kelompok: {groups.find(g => g.id === selectedGroup)?.name}
                  </span>
                )}
                {selectedStatusFilter !== 'all' && (
                  <span className="bg-amber-50 text-amber-700 border border-amber-150 font-bold px-2 py-0.5 rounded-md">
                    Filter: {selectedStatusFilter === 'inputted' ? 'Telah Input' : selectedStatusFilter === 'pending' ? 'Belum Input' : 'Ada Sangkalan'}
                  </span>
                )}
                {searchQuery && (
                  <span className="bg-slate-100 text-slate-700 border border-slate-200 font-semibold px-2 py-0.5 rounded-md max-w-xs truncate">
                    Draft: "{searchQuery}"
                  </span>
                )}
              </div>

              <button
                onClick={() => {
                  setSelectedVillage('');
                  setSelectedGroup('');
                  setSelectedStatusFilter('all');
                  setSearchQuery('');
                }}
                className="text-[10px] text-indigo-600 hover:text-indigo-800 font-extrabold tracking-wide uppercase font-mono bg-white hover:bg-slate-100 border border-slate-200 py-1 px-2.5 rounded-lg cursor-pointer transition shadow-3xs"
              >
                Reset Saringan
              </button>
            </div>
          )}
        </div>

        {/* REAL-TIME COMPARISON BAR CHART (RECHARTS) */}
        {capaianChartData.data.length > 0 && (
          <div className="mb-6 bg-slate-50 border border-slate-200 rounded-2xl p-4.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-200/60">
              <div className="space-y-0.5">
                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest font-mono block">STATISTIK REAL-TIME</span>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-tight flex items-center gap-1.5">
                  <TrendingUp size={14} className="text-indigo-650" />
                  {capaianChartData.type === 'village' && "Perbandingan Capaian Penyaluran Antar Desa"}
                  {capaianChartData.type === 'group' && "Perbandingan Capaian Penyaluran Antar Kelompok (Pokman)"}
                  {capaianChartData.type === 'pb' && "Perbandingan Capaian Penyaluran Individu Penerima Manfaat"}
                </h4>
                <p className="text-[9.5px] text-slate-500 font-semibold">
                  {capaianChartData.type === 'village' && "Mengakumulasi volume barang tersalurkan per wilayah desa binaan TFL."}
                  {capaianChartData.type === 'group' && "Membandingkan progress pembagian material antar kelompok swadaya."}
                  {capaianChartData.type === 'pb' && "Menampilkan rincian progres dropping 12 keluarga penerima bantuan teratas."}
                </p>
              </div>
              <div className="flex items-center gap-1 bg-white border border-slate-200 px-2.5 py-1 rounded-lg text-[9px] font-mono text-slate-500">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                <span>FILTER AKTIF TERINTEGRASI</span>
              </div>
            </div>

            <div className="h-68 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart
                  data={capaianChartData.data}
                  margin={{ top: 10, right: 5, left: -25, bottom: 5 }}
                >
                  <RechartsCartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <RechartsXAxis 
                    dataKey="name" 
                    fontSize={9} 
                    tick={{ fill: '#475569', fontWeight: 600 }} 
                    stroke="#cbd5e1"
                  />
                  <RechartsYAxis 
                    fontSize={9} 
                    tick={{ fill: '#475569' }}
                    stroke="#cbd5e1"
                  />
                  <RechartsTooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      fontSize: '11px', 
                      border: '1px solid #e1e7f0', 
                      boxShadow: '0 4px 12px -2px rgb(0 0 0 / 0.15)',
                      backgroundColor: 'rgba(255, 255, 255, 0.98)'
                    }} 
                  />
                  <RechartsLegend 
                    wrapperStyle={{ fontSize: '10px', paddingTop: 10 }}
                    verticalAlign="bottom"
                    iconSize={10}
                    iconType="circle"
                  />
                  <RechartsBar dataKey="Diterima (✓)" stackId="capaian" fill="#10b981" radius={[2, 2, 0, 0]} />
                  <RechartsBar dataKey="Sedang Dropping (•)" stackId="capaian" fill="#6366f1" radius={[2, 2, 0, 0]} />
                  <RechartsBar dataKey="Disangkal (⚠️)" stackId="capaian" fill="#ef4444" radius={[2, 2, 0, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* DATA CONTAINER LIST */}
        <div className="space-y-3">
          <div className="text-[11px] font-bold text-slate-500 mb-2 font-mono flex items-center justify-between">
            <span>Hasil Penyaringan ({filteredActivityList.length} keluarga PB)</span>
            <span>Diurutkan berdasarkan waktu konfirmasi QR terbaru</span>
          </div>

          <AnimatePresence mode="popLayout">
            {filteredActivityList.length === 0 ? (
              <motion.div 
                key="empty-daily-activity"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="p-12 text-center text-slate-400 bg-slate-50 rounded-2xl border border-slate-200 border-dashed flex flex-col items-center justify-center gap-2"
              >
                <Inbox size={32} className="text-slate-350" />
                <span className="text-xs font-bold text-slate-600">Tidak ada keluarga PB yang sesuai kriteria saringan</span>
                <span className="text-[10px] text-slate-400">Silakan ubah filter Desa, Pokman atau kata kunci pencarian Anda.</span>
              </motion.div>
            ) : (
              filteredActivityList.map(({
                pb,
                pbDists,
                pbConfirmedDists,
                pbDisputedDists,
                hasInputted,
                lastInputDate
              }) => {
                const docDesa = villages.find(v => v.id === pb.village_id)?.name || '-';
                const docGroup = groups.find(g => g.id === pb.group_id)?.name || 'Umum';

                return (
                  <motion.div
                    key={pb.id}
                    layout
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    whileHover={{ 
                      scale: 1.008, 
                      backgroundColor: hasInputted ? 'rgba(240, 253, 244, 0.4)' : 'rgba(248, 250, 252, 0.95)',
                      boxShadow: '0 10px 25px -10px rgba(15, 23, 42, 0.08)'
                    }}
                    transition={{ type: "spring", stiffness: 350, damping: 28 }}
                    className={`border rounded-2xl p-4.5 transition-colors duration-200 ${
                      hasInputted 
                        ? (pbDisputedDists.length > 0 ? 'bg-rose-50/10 border-rose-200' : 'bg-emerald-50/10 border-emerald-200')
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      {/* Left: General Info and materials confirmed */}
                      <div className="flex gap-4 items-start min-w-0 flex-1">
                        <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                          hasInputted 
                            ? (pbDisputedDists.length > 0 ? 'bg-rose-100 text-rose-700 animate-pulse' : 'bg-emerald-100 text-emerald-700')
                            : 'bg-slate-100 text-slate-500'
                        }`}>
                          <User size={18} />
                        </div>
                        
                        <div className="space-y-1.5 min-w-0">
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                            <h4 
                              onClick={() => onNavigateToRecipient(pb.id)}
                              className="text-xs font-black text-slate-800 hover:text-indigo-600 transition cursor-pointer flex items-center gap-1"
                              title="Silakan klik untuk membuka Portal Detail PB"
                            >
                              {pb.full_name}
                              <Eye size={12} className="text-slate-400 hover:text-indigo-600 cursor-pointer text-indigo-500 hover:scale-115 transition" />
                            </h4>
                            <span className="text-[10px] text-slate-450 font-mono font-bold">NIK/KK: {pb.nik} &bull; {pb.kk_number}</span>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[10px] text-slate-500 font-mono">
                            <span className="flex items-center gap-0.5 text-slate-800 font-semibold uppercase">
                              <Layers size={11} className="text-slate-400 shrink-0" />
                              Desa: {docDesa}
                            </span>
                            <span>&bull;</span>
                            <span className="flex items-center gap-0.5 text-slate-700 uppercase">
                              Kelompok: {docGroup}
                            </span>
                          </div>

                          {/* Render exact material transaction badges and volumes */}
                          <div className="pt-1.5">
                            {pbDists.length === 0 ? (
                              <p className="text-[10px] italic text-slate-400 font-medium">Belum ada komoditas dropping material dicatatkan untuk PB ini oleh supplier.</p>
                            ) : (
                              <div className="flex flex-wrap gap-1.5">
                                {pbDists.map((dist: any) => {
                                  let badgeTheme = "bg-slate-50 text-slate-600 border-slate-200";
                                  let statusText = "Menunggu Kirim";
                                  
                                  if (dist.confirmation_status === 'confirmed_by_recipient') {
                                    badgeTheme = "bg-emerald-100/70 text-emerald-805 border-emerald-200 font-semibold";
                                    statusText = "Diterima ✓";
                                  } else if (dist.confirmation_status === 'disputed') {
                                    badgeTheme = "bg-rose-100/70 text-rose-805 border-rose-200 font-black";
                                    statusText = "Disangkal ⚠️";
                                  }

                                  return (
                                    <span 
                                      key={dist.id} 
                                      className={`text-[9.5px] font-mono font-medium px-2 py-0.5 rounded-lg border ${badgeTheme} shrink-0 max-w-[280px] truncate`}
                                      title={dist.notes ? `Catatan: ${dist.notes}` : "Tanpa keterangan"}
                                    >
                                      <strong>{statusText}</strong> &bull; Volume: {dist.volume} &bull; Tgl: {new Date(dist.distribution_date).toLocaleDateString('id-ID')}
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Confirmations states, timing & redirect action */}
                      <div className="flex lg:flex-col items-end gap-3 shrink-0 self-stretch md:self-center justify-between lg:justify-center border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
                        <div className="text-right">
                          {hasInputted ? (
                            pbDisputedDists.length > 0 ? (
                              <span className="inline-flex items-center gap-1 text-[9.5px] font-black uppercase font-mono bg-rose-50 border border-rose-200 text-rose-600 px-2.5 py-0.5 rounded-full">
                                <XCircle size={11} className="shrink-0" />
                                Dispute Dilaporkan
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[9.5px] font-black uppercase font-mono bg-emerald-50 border border-emerald-250 text-emerald-600 px-2.5 py-0.5 rounded-full">
                                <Check size={11} className="shrink-0" />
                                Terverifikasi Mandiri
                              </span>
                            )
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[9.5px] font-medium uppercase font-mono bg-slate-50 border border-slate-200 text-slate-450 px-2.5 py-0.5 rounded-full">
                              <Clock size={11} className="shrink-0" />
                              Sedang Dropping
                            </span>
                          )}

                          {lastInputDate && (
                            <span className="block text-[8.5px] text-zinc-400 font-mono font-medium mt-1">
                              Selesai: {new Date(lastInputDate).toLocaleDateString('id-ID')} &mdash; {new Date(lastInputDate).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                            </span>
                          )}
                        </div>

                        <button
                          onClick={() => onNavigateToRecipient(pb.id)}
                          className="px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-250 hover:border-slate-350 text-slate-700 text-[10px] font-extrabold rounded-lg cursor-pointer transition flex items-center gap-1 font-mono tracking-wider shadow-3xs"
                        >
                          BUKA PORTAL PB
                          <ChevronRight size={11} />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* SECTION 5: DETAIL VISITATION PRIORITIES */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-3xs text-left">
        <h3 className="text-xs font-black font-mono text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <MapPin size={15} className="text-amber-600" />
          Daftar Prioritas Kunjungan Lapangan TFL
        </h3>
        
        {summary?.priority_visits?.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400 flex flex-col items-center gap-2">
            <CheckCircle2 size={32} className="text-emerald-400" />
            <span className="font-semibold text-slate-500">Semua wilayah binaan TFL berada dalam pengerjaan lancar!</span>
            <span className="text-[10px]">Penerima manfaat telah divalidasi dengan koordinat akurat.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {summary.priority_visits.map((pb: any) => (
              <button
                key={pb.id}
                onClick={() => onNavigateToRecipient(pb.id)}
                className="w-full text-left flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-amber-300 hover:bg-amber-50/50 transition cursor-pointer shadow-3xs"
              >
                <div className="space-y-0.5">
                  <p className="text-xs font-extrabold text-slate-700">{pb.full_name}</p>
                  <p className="text-[10.5px] text-slate-450 flex items-center gap-1">
                    <Compass size={11} className="text-slate-400" />
                    <span>Geo: {pb.latitude && pb.longitude ? `${Number(pb.latitude).toFixed(4)}, ${Number(pb.longitude).toFixed(4)}` : 'Belum di-tag'}</span>
                  </p>
                </div>
                <span className={`text-[8.5px] font-mono font-black uppercase px-2 py-0.5 rounded-full ${
                  pb.status === 'not_started' ? 'bg-slate-100 text-slate-500 border border-slate-200' : 'bg-amber-100 text-amber-700 border border-amber-200'
                }`}>
                  {pb.status === 'not_started' ? 'Belum Mulai' : 'Dalam Proses'}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
