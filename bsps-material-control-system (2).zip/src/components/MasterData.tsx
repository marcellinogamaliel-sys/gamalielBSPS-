/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building, Landmark, Layers, Plus, Trash2, 
  MapPin, Edit3, Save, X, Phone, User, Compass 
} from 'lucide-react';
import { Village, Group, Store, Recipient } from '../types';

interface MasterDataProps {
  villages: Village[];
  groups: Group[];
  stores: Store[];
  recipients: Recipient[];
  onVillageAction: (action: 'add' | 'edit' | 'delete', data: any) => Promise<void>;
  onGroupAction: (action: 'add' | 'edit' | 'delete', data: any) => Promise<void>;
  onStoreAction: (action: 'add' | 'edit' | 'delete', data: any) => Promise<void>;
  showToast: (message: string, type: 'success' | 'error') => void;
}

export default function MasterData({
  villages,
  groups,
  stores,
  recipients,
  onVillageAction,
  onGroupAction,
  onStoreAction,
  showToast
}: MasterDataProps) {
  const [activeTab, setActiveTab] = useState<'villages' | 'groups' | 'stores'>('villages');

  // Village Form State
  const [newVillageName, setNewVillageName] = useState('');
  const [editingVillageId, setEditingVillageId] = useState<string | null>(null);
  const [editingVillageName, setEditingVillageName] = useState('');

  // Group Form State
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupVillageId, setNewGroupVillageId] = useState('');
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editingGroupName, setEditingGroupName] = useState('');
  const [editingGroupVillageId, setEditingGroupVillageId] = useState('');

  // Store Form State
  const [storeForm, setStoreForm] = useState({
    id: '', name: '', owner_name: '', address: '', phone_number: '', latitude: '', longitude: ''
  });
  const [isEditingStore, setIsEditingStore] = useState(false);
  const [geolocationLoading, setGeolocationLoading] = useState(false);

  // Deletion Modal States
  const [villageToDelete, setVillageToDelete] = useState<Village | null>(null);
  const [groupToDelete, setGroupToDelete] = useState<Group | null>(null);
  const [storeToDelete, setStoreToDelete] = useState<Store | null>(null);

  // Stats Helpers
  const getVillageStats = (vId: string) => {
    const vGroups = groups.filter(g => g.village_id === vId).length;
    const vPBs = recipients.filter(r => r.village_id === vId).length;
    return { groupsCount: vGroups, pbsCount: vPBs };
  };

  const getGroupStats = (gId: string) => {
    const gPBs = recipients.filter(r => r.group_id === gId).length;
    return { pbsCount: gPBs };
  };

  const getStoreStats = (sId: string) => {
    const sPBs = recipients.filter(r => r.store_id === sId).length;
    return { pbsCount: sPBs };
  };

  // GPS Fetching Helper on Browser Geolocation APIS
  const fetchCurrentLocation = () => {
    setGeolocationLoading(true);
    if (!navigator.geolocation) {
      showToast("GPS tidak didukung", "error");
      setGeolocationLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setStoreForm(prev => ({
          ...prev,
          latitude: position.coords.latitude.toFixed(6),
          longitude: position.coords.longitude.toFixed(6)
        }));
        setGeolocationLoading(false);
      },
      (error) => {
        showToast("gagal mengambil GPS", "error");
        setGeolocationLoading(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const cleanStoreForm = () => {
    setStoreForm({ id: '', name: '', owner_name: '', address: '', phone_number: '', latitude: '', longitude: '' });
    setIsEditingStore(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Mini Tabs */}
      <div className="flex border-b border-slate-150" id="master-tabs-bar">
        <button
          onClick={() => setActiveTab('villages')}
          className={`py-3 px-4 text-xs font-bold font-mono tracking-wider uppercase border-b-2 transition flex items-center gap-1.5 cursor-pointer ${activeTab === 'villages' ? 'border-emerald-500 text-emerald-600 font-black font-display' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
        >
          <Landmark size={13} className={activeTab === 'villages' ? 'text-emerald-505' : ''} />
          Desa ({villages.length})
        </button>
        <button
          onClick={() => setActiveTab('groups')}
          className={`py-3 px-4 text-xs font-bold font-mono tracking-wider uppercase border-b-2 transition flex items-center gap-1.5 cursor-pointer ${activeTab === 'groups' ? 'border-emerald-500 text-emerald-600 font-black font-display' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
        >
          <Layers size={13} className={activeTab === 'groups' ? 'text-emerald-505' : ''} />
          Kelompok ({groups.length})
        </button>
        <button
          onClick={() => setActiveTab('stores')}
          className={`py-3 px-4 text-xs font-bold font-mono tracking-wider uppercase border-b-2 transition flex items-center gap-1.5 cursor-pointer ${activeTab === 'stores' ? 'border-emerald-500 text-emerald-600 font-black font-display' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
        >
          <Building size={13} className={activeTab === 'stores' ? 'text-emerald-505' : ''} />
          Toko Rekanan ({stores.length})
        </button>
      </div>

      {/* VILLAGE TAB CONTENT */}
      {activeTab === 'villages' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="master-villages-section">
          {/* Add-Edit Form Left Panel */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 h-fit shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 font-mono uppercase mb-4">
              {editingVillageId ? 'Edit Wilayah Desa' : 'Tambah Desa Baru'}
            </h3>
            
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-slate-500 font-bold text-[10px] font-mono tracking-wider uppercase">Nama Desa</label>
                <input
                  type="text"
                  placeholder="Contoh: Desa Sukamaju"
                  value={editingVillageId ? editingVillageName : newVillageName}
                  onChange={(e) => editingVillageId ? setEditingVillageName(e.target.value) : setNewVillageName(e.target.value)}
                  className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-slate-950 font-sans"
                />
              </div>

              <div className="flex gap-2 pt-1">
                {editingVillageId ? (
                  <>
                    <button
                      onClick={async () => {
                        await onVillageAction('edit', { id: editingVillageId, name: editingVillageName });
                        setEditingVillageId(null);
                      }}
                      className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
                    >
                      <Save size={13} />
                      Simpan Perubahan
                    </button>
                    <button
                      onClick={() => setEditingVillageId(null)}
                      className="py-2 px-3 border border-slate-200 text-slate-600 rounded-xl text-xs font-bold cursor-pointer hover:bg-slate-50"
                    >
                      <X size={14} />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={async () => {
                      if (!newVillageName.trim()) return;
                      await onVillageAction('add', { name: newVillageName });
                      setNewVillageName('');
                    }}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
                  >
                    <Plus size={14} />
                    Tambah Wilayah
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* List Right Panel */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100">
              {villages.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">Belum ada data desa terdaftar.</div>
              ) : (
                villages.map(v => {
                  const { groupsCount, pbsCount } = getVillageStats(v.id);
                  return (
                    <div key={v.id} className="p-4 hover:bg-slate-50/50 flex justify-between items-center transition">
                      <div className="space-y-0.5 min-w-0">
                        <h4 className="text-sm font-bold text-slate-905 truncate">{v.name}</h4>
                        <div className="flex items-center gap-2.5 text-[10px] font-mono text-slate-500">
                          <span>{groupsCount} Kelompok</span>
                          <span>&bull;</span>
                          <span>{pbsCount} Penerima Bantuan (PB)</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => {
                            setEditingVillageId(v.id);
                            setEditingVillageName(v.name);
                          }}
                          className="p-2 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg cursor-pointer transition"
                        >
                          <Edit3 size={13} />
                        </button>
                        <button
                          onClick={() => setVillageToDelete(v)}
                          className="p-2 border border-rose-200 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer transition"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* GROUP TAB CONTENT */}
      {activeTab === 'groups' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="master-groups-section">
          {/* Add-Edit Form Left Panel */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 h-fit shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 font-mono uppercase mb-4">
              {editingGroupId ? 'Edit Kelompok PB' : 'Tambah Kelompok Baru'}
            </h3>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-slate-500 font-bold text-[10px] font-mono tracking-wider uppercase">Nama Kelompok</label>
                <input
                  type="text"
                  placeholder="Contoh: KMP Melati 1"
                  value={editingGroupId ? editingGroupName : newGroupName}
                  onChange={(e) => editingGroupId ? setEditingGroupName(e.target.value) : setNewGroupName(e.target.value)}
                  className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-slate-950 font-sans"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-500 font-bold text-[10px] font-mono tracking-wider uppercase">Wilayah Desa</label>
                <select
                  value={editingGroupId ? editingGroupVillageId : newGroupVillageId}
                  onChange={(e) => editingGroupId ? setEditingGroupVillageId(e.target.value) : setNewGroupVillageId(e.target.value)}
                  className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
                >
                  <option value="">Pilih Desa Rekanan</option>
                  {villages.map(v => (
                    <option key={v.id} value={v.id}>{v.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-1">
                {editingGroupId ? (
                  <>
                    <button
                      onClick={async () => {
                        await onGroupAction('edit', { id: editingGroupId, name: editingGroupName, village_id: editingGroupVillageId });
                        setEditingGroupId(null);
                      }}
                      className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
                    >
                      <Save size={13} />
                      Simpan Perubahan
                    </button>
                    <button
                      onClick={() => setEditingGroupId(null)}
                      className="py-2 px-3 border border-slate-200 text-slate-600 rounded-xl text-xs font-bold cursor-pointer hover:bg-slate-50"
                    >
                      <X size={14} />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={async () => {
                      if (!newGroupName.trim() || !newGroupVillageId) return;
                      await onGroupAction('add', { name: newGroupName, village_id: newGroupVillageId });
                      setNewGroupName('');
                    }}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
                  >
                    <Plus size={14} />
                    Tambah Kelompok
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* List Right Panel */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100">
              {groups.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">Belum ada data kelompok terdaftar.</div>
              ) : (
                groups.map(g => {
                  const village = villages.find(v => v.id === g.village_id);
                  const { pbsCount } = getGroupStats(g.id);
                  return (
                    <div key={g.id} className="p-4 hover:bg-slate-50/50 flex justify-between items-center transition">
                      <div className="space-y-0.5 min-w-0">
                        <h4 className="text-sm font-bold text-slate-905 truncate">{g.name}</h4>
                        <div className="flex items-center gap-2.5 text-[10px] font-mono text-slate-500">
                          <span className="text-slate-800 font-semibold flex items-center gap-0.5">
                            <Landmark size={10} className="text-slate-500 shrink-0" />
                            {village?.name || "Desa tidak ditemukan"}
                          </span>
                          <span>&bull;</span>
                          <span>{pbsCount} Penerima Bantuan (PB)</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => {
                            setEditingGroupId(g.id);
                            setEditingGroupName(g.name);
                            setEditingGroupVillageId(g.village_id);
                          }}
                          className="p-2 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg cursor-pointer transition"
                        >
                          <Edit3 size={13} />
                        </button>
                        <button
                          onClick={() => setGroupToDelete(g)}
                          className="p-2 border border-rose-200 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer transition"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* STORE TAB CONTENT */}
      {activeTab === 'stores' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="master-stores-section">
          {/* Add-Edit Form Left Panel */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 h-fit shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 font-mono uppercase mb-4">
              {isEditingStore ? 'Edit Toko Rekanan' : 'Tambah Toko Baru'}
            </h3>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase">Nama Toko</label>
                <div className="relative">
                  <Building size={14} className="absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Contoh: Toko Bangunan Berkah"
                    value={storeForm.name}
                    onChange={(e) => setStoreForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full py-2 pl-9 pr-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase">Nama Pemilik</label>
                <div className="relative">
                  <User size={14} className="absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Contoh: Bapak H. Ahmad"
                    value={storeForm.owner_name}
                    onChange={(e) => setStoreForm(prev => ({ ...prev, owner_name: e.target.value }))}
                    className="w-full py-2 pl-9 pr-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase">No. WA (62xxxx)</label>
                  <div className="relative">
                    <Phone size={14} className="absolute left-3 top-3 text-slate-400" />
                    <input
                      type="text"
                      placeholder="62812xxxxxx"
                      value={storeForm.phone_number}
                      onChange={(e) => setStoreForm(prev => ({ ...prev, phone_number: e.target.value }))}
                      className="w-full py-2 pl-9 pr-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase">Koordinat GPS</label>
                  <button
                    onClick={fetchCurrentLocation}
                    disabled={geolocationLoading}
                    className="w-full py-2 text-slate-800 disabled:opacity-50 border border-slate-200 bg-slate-50 hover:bg-slate-100 rounded-xl text-xs font-semibold cursor-pointer active:scale-95 transition flex items-center justify-center gap-1"
                  >
                    <Compass size={13} className={geolocationLoading ? 'animate-spin' : ''} />
                    {geolocationLoading ? 'Mendata GPS...' : 'Ambil GPS Sekarang'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase text-slate-450 font-mono">Latitude</label>
                  <input
                    type="number"
                    step="any"
                    placeholder="-6.914..."
                    value={storeForm.latitude}
                    onChange={(e) => setStoreForm(prev => ({ ...prev, latitude: e.target.value }))}
                    className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase text-slate-450 font-mono">Longitude</label>
                  <input
                    type="number"
                    step="any"
                    placeholder="107.610..."
                    value={storeForm.longitude}
                    onChange={(e) => setStoreForm(prev => ({ ...prev, longitude: e.target.value }))}
                    className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold font-mono tracking-wider ml-1 text-slate-500 uppercase">Alamat Lengkap Toko</label>
                <textarea
                  placeholder="Jl. Raya Sukamulya RT 02/05 No. 12"
                  value={storeForm.address}
                  rows={2}
                  onChange={(e) => setStoreForm(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                {isEditingStore ? (
                  <>
                    <button
                      onClick={async () => {
                        await onStoreAction('edit', storeForm);
                        cleanStoreForm();
                      }}
                      className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
                    >
                      <Save size={13} />
                      Simpan Perubahan
                    </button>
                    <button
                      onClick={cleanStoreForm}
                      className="py-2 px-3 border border-slate-200 text-slate-600 rounded-xl text-xs font-bold cursor-pointer hover:bg-slate-50"
                    >
                      <X size={14} />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={async () => {
                      if (!storeForm.name || !storeForm.owner_name) return;
                      await onStoreAction('add', storeForm);
                      cleanStoreForm();
                    }}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
                  >
                    <Plus size={14} />
                    Tambah Registrasi Toko
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* List Right Panel */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="divide-y divide-slate-100">
              {stores.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">Belum ada data toko terdaftar.</div>
              ) : (
                stores.map(s => {
                  const { pbsCount } = getStoreStats(s.id);
                  return (
                    <div key={s.id} className="p-4 hover:bg-slate-50/50 flex flex-col sm:flex-row justify-between sm:items-center gap-3 transition">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-extrabold text-slate-900 truncate">{s.name}</h4>
                          <span className="text-[10px] font-bold font-mono px-2 py-0.2 rounded bg-slate-100 text-slate-700">+{s.phone_number}</span>
                        </div>
                        <p className="text-xs text-slate-600">Pemilik: <span className="font-semibold">{s.owner_name}</span></p>
                        <p className="text-[11px] text-slate-550 truncate">{s.address}</p>
                        
                        <div className="flex items-center gap-2 text-[10px] text-slate-450 font-mono mt-0.5">
                          <span className="flex items-center gap-0.5 text-sky-600 font-bold">
                            <MapPin size={9} />
                            GPS: {s.latitude.toFixed(4)}, {s.longitude.toFixed(4)}
                          </span>
                          <span>&bull;</span>
                          <span>{pbsCount} PB Terdaftar</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                        <button
                          onClick={() => {
                            setStoreForm({
                              id: s.id,
                              name: s.name,
                              owner_name: s.owner_name,
                              address: s.address,
                              phone_number: s.phone_number,
                              latitude: String(s.latitude),
                              longitude: String(s.longitude)
                            });
                            setIsEditingStore(true);
                          }}
                          className="p-2 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg cursor-pointer transition"
                        >
                          <Edit3 size={13} />
                        </button>
                        <button
                          onClick={() => setStoreToDelete(s)}
                          className="p-2 border border-rose-200 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer transition"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL HAPUS WILAYAH */}
      {villageToDelete && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn fade-in-0 custom-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn zoom-in-95">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-rose-600">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                🗑️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Wilayah / Desa</h3>
                <p className="text-[10px] text-slate-505 font-mono">Menyeleksi {villageToDelete.name}</p>
              </div>
            </div>
            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>Hapus wilayah <strong>{villageToDelete.name}</strong>?</p>
              <p className="text-[10px] text-slate-500 italic">Seluruh kelompok di dalamnya akan terpengaruh.</p>
            </div>
            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={() => setVillageToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                onClick={async () => {
                  try {
                    await onVillageAction('delete', { id: villageToDelete.id });
                    setVillageToDelete(null);
                  } catch (err) {
                    showToast("Gagal menghapus desa", "error");
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-sm"
              >
                Hapus Wilayah
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL HAPUS KELOMPOK */}
      {groupToDelete && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn fade-in-0 custom-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn zoom-in-95">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-rose-600">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                🗑️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Kelompok PB</h3>
                <p className="text-[10px] text-slate-505 font-mono">Menyeleksi {groupToDelete.name}</p>
              </div>
            </div>
            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>Hapus kelompok penerima bantuan <strong>{groupToDelete.name}</strong>?</p>
            </div>
            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={() => setGroupToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                onClick={async () => {
                  try {
                    await onGroupAction('delete', { id: groupToDelete.id });
                    setGroupToDelete(null);
                  } catch (err) {
                    showToast("Gagal menghapus kelompok", "error");
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-sm"
              >
                Hapus Kelompok
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL HAPUS TOKO */}
      {storeToDelete && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn fade-in-0 custom-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn zoom-in-95">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-rose-600">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                ⚠️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Toko Penyedia</h3>
                <p className="text-[10px] text-slate-505 font-mono">Menyeleksi {storeToDelete.name}</p>
              </div>
            </div>
            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>Hapus entitas toko <strong>{storeToDelete.name}</strong>?</p>
              <p className="text-[10px] text-slate-500 italic">Seluruh PB yang terhubung akan kehilangan referensi penyedia.</p>
            </div>
            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={() => setStoreToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                onClick={async () => {
                  try {
                    await onStoreAction('delete', { id: storeToDelete.id });
                    setStoreToDelete(null);
                  } catch (err) {
                    showToast("Gagal menghapus toko", "error");
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-sm"
              >
                Ya, Hapus Toko
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
