/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ArrowLeft, Landmark, Layers, Building, MapPin, 
  Plus, Calendar, PlusCircle, CheckCircle2, AlertTriangle, 
  Trash2, FileText, Camera, Video, ClipboardCheck, 
  Clock, Check, Eye, Sparkles, Upload, RefreshCw, Loader2 
} from 'lucide-react';
import { 
  Recipient, Village, Group, Store, DRPBItem, 
  Distribution, DistributionMedia, RecipientPhoto, Finding, ShortageReason 
} from '../types';
import { formatDateOnly, obfuscateID, getStatusColor, getStatusLabel, formatFullDateTime } from '../utils';
import { scanDRPB, matchRecipient, OcrStep, validateImageDimensions } from '../services/drpbOcrService';
import { resizeImageForOCR } from '../services/utils/imageResize';

interface RecipientDetailProps {
  recipientId: string;
  onBack: () => void;
  // State from server/main
  villages: Village[];
  groups: Group[];
  stores: Store[];
  operatorId: string;
  recipients?: Recipient[];
  onChangeRecipient?: (id: string) => void;
  // Service Fetchers / API wrappers
  onAddDRPBItem: (recipientId: string, item: any) => Promise<void>;
  onDeleteDRPBItem: (itemId: string) => Promise<void>;
  onClearAllDRPB: (recipientId: string) => Promise<void>;
  onAddDistribution: (formData: any) => Promise<any>;
  onAddFinding: (recipientId: string, data: any) => Promise<void>;
  onResolveFinding: (findingId: string) => Promise<void>;
  showToast: (message: string, type: 'success' | 'error') => void;
}

export default function RecipientDetail({
  recipientId,
  onBack,
  villages,
  groups,
  stores,
  operatorId,
  recipients,
  onChangeRecipient,
  onAddDRPBItem,
  onDeleteDRPBItem,
  onClearAllDRPB,
  onAddDistribution,
  onAddFinding,
  onResolveFinding,
  showToast
}: RecipientDetailProps) {
  
  // Loading & State
  const [loading, setLoading] = useState(true);
  const [recipient, setRecipient] = useState<Recipient | null>(null);
  const [drpb, setDrpb] = useState<DRPBItem[]>([]);
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [media, setMedia] = useState<DistributionMedia[]>([]);
  const [photos, setPhotos] = useState<RecipientPhoto[]>([]);
  const [findings, setFindings] = useState<Finding[]>([]);

  // Form toggles
  const [showAddDRPB, setShowAddDRPB] = useState(false);
  const [showAddDist, setShowAddDist] = useState(false);
  const [showAddFinding, setShowAddFinding] = useState(false);

  // Deletion Modal States
  const [showClearDRPBConfirm, setShowClearDRPBConfirm] = useState(false);
  const [drpbItemToDelete, setDrpbItemToDelete] = useState<DRPBItem | null>(null);

  // AI DRPB States
  const [isScanning, setIsScanning] = useState(false);
  const [scannedFile, setScannedFile] = useState<string | null>(null);
  const [aiDraftItems, setAiDraftItems] = useState<{ material_type: string; unit: string; required_qty: number }[] | null>(null);
  const [draftMode, setDraftMode] = useState<'distribution' | 'drpb'>('distribution');
  const [bulkProofs, setBulkProofs] = useState({
    date: new Date().toISOString().split('T')[0],
    photo_during: '',
    receipt_base64: '',
    notes: '',
    shortage_reason: 'Lainnya',
    shortage_notes: 'Volume sesuai tanda terima fisik'
  });
  const [scannerError, setScannerError] = useState<string | null>(null);
  const [scanStep, setScanStep] = useState<"idle" | "uploading" | "api_processing" | "parsing" | "failed">("idle");
  const [scanStatus, setScanStatus] = useState<string>("");
  const [scanAttempt, setScanAttempt] = useState<number>(1);
  const [ocrStep, setOcrStep] = useState<OcrStep | null>(null);

  // Auto-switch draftMode based on current items presence to increase user UX flow
  useEffect(() => {
    if (aiDraftItems) {
      if (drpb && drpb.length > 0) {
        setDraftMode('distribution');
      } else {
        setDraftMode('drpb');
      }
    }
  }, [aiDraftItems, drpb]);

  // AI Analysis states
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<{
    progress_summary: string;
    issues: string[];
    recommendations: string[];
    estimated_percentage: number;
  } | null>(null);

  const handleRunAIAnalysis = async () => {
    if (!recipient) return;
    setIsAnalyzing(true);
    try {
      const res = await fetch("/api/ai/analyze-recipient", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipient,
          drpb,
          distributions,
          findings,
          operator_id: operatorId
        })
      });
      if (!res.ok) throw new Error("Gagal melakukan analisis AI.");
      const data = await res.json();
      setAiAnalysis(data.analysis);
    } catch (err: any) {
      showToast("gagal memproses analisis", "error");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const performAIScan = async (base64Str: string) => {
    try {
      const dimCheck = await validateImageDimensions(base64Str);
      if (!dimCheck.isValid) {
        setScannerError(dimCheck.error || "Foto tidak valid.");
        return;
      }
    } catch (err) {
      setScannerError("Gagal memvalidasi dimensi gambar.");
      return;
    }

    setIsScanning(true);
    setScannerError(null);
    setAiDraftItems(null);
    setOcrStep('Mengunggah foto...');
    setScanStep('uploading');
    setScanStatus('Menyiapkan berkas gambar dan muatan analisis...');
    
    try {
      const data = await scanDRPB({
        imageBase64: base64Str,
        operatorId,
        type: 'extract',
        maxAttempts: 3,
        onStepChange: (step) => {
          setOcrStep(step);
          if (step === 'Mengunggah foto...') {
            setScanStep('uploading');
            setScanStatus('Menyiapkan berkas gambar dan muatan analisis...');
          } else if (step === 'Menghubungi Gemini AI...') {
            setScanStep('api_processing');
            setScanStatus('Menghubungi Gemini 3.5-flash AI...');
          } else if (step === 'Membaca tabel...' || step === 'Memvalidasi hasil...') {
            setScanStep('parsing');
            setScanStatus('Membaca tabel & memvalidasi struktur hasil scan...');
          } else if (step === 'Selesai') {
            setScanStep('idle');
            setScanStatus('Selesai!');
          }
        },
      });

      if (data && data.success && data.items) {
        // Map Indonesian response terms to DB field structure safely
        const mappedItems = data.items.map((item: any) => ({
          material_type: String(item.nama_material || "").trim(),
          unit: String(item.satuan || "").trim(),
          required_qty: Number(item.volume) || 0
        })).filter((item: any) => item.required_qty > 0 && item.material_type !== "");

        const scannedName = data.nama_pb ? String(data.nama_pb).trim() : "";

        if (scannedName && recipients && onChangeRecipient) {
          // Use matchRecipient from drpbOcrService for robust matching including typos
          const matchedPB = matchRecipient(scannedName, recipients);

          if (matchedPB) {
            if (matchedPB.id !== recipientId) {
              showToast(`Ditemukan PB: "${matchedPB.full_name}" dari dokumen DRPB! Membuka halaman PB otomatis...`, "success");
              onChangeRecipient(matchedPB.id);
            } else {
              showToast(`Penerima terkonfirmasi: ${matchedPB.full_name}`, "success");
            }
            setAiDraftItems(mappedItems);
          } else {
            showToast(`Identitas DRPB (${scannedName}) tidak terdaftar dalam database. Mengisi ke penerima terpilih saat ini.`, "error");
            setAiDraftItems(mappedItems);
          }
        } else {
          setAiDraftItems(mappedItems);
        }

        setScanStep("idle");
        showToast("Berhasil mengekstrak DRPB via AI!", "success");
      } else {
        throw new Error("Format respon tidak sesuai.");
      }
    } catch (err: any) {
      console.error(err);
      setScanStep("failed");
      setScannerError(err.message || "Gagal memproses gambar setelah beberapa percobaan. Pastikan gambar jelas dan merupakan berkas DRPB.");
    } finally {
      setIsScanning(false);
      setOcrStep(null);
    }
  };

  const handleAIScanUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const resizedBase64 = await resizeImageForOCR(file);
      setScannedFile(resizedBase64);
      await performAIScan(resizedBase64);
    } catch (err: any) {
      setScannerError(err.message || 'Gagal memproses gambar sebelum dikirim untuk scan.');
    }
  };

  const saveDRPBPhoto = async () => {
    if (!scannedFile) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/recipients/${recipientId}/drpb-photo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photo_base64: scannedFile, operator_id: operatorId })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Gagal menyimpan foto");
      }
      showToast("Foto DRPB berhasil disimpan!", "success");
      setScannedFile(null);
    } catch (err: any) {
      showToast(err.message || "Gagal menyimpan foto", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleApplyAIDraft = async () => {
    if (!aiDraftItems || aiDraftItems.length === 0) return;
    
    setLoading(true);
    try {
      for (const item of aiDraftItems) {
        await onAddDRPBItem(recipientId, {
          material_type: item.material_type,
          unit: item.unit,
          required_qty: Number(item.required_qty)
        });
      }
      setAiDraftItems(null);
      setScannedFile(null);
      fetchPBDetails();
    } catch (err: any) {
      showToast("gagal menyimpan draf", "error");
    } finally {
      setLoading(false);
    }
  };

  const mappedDraftItems = useMemo(() => {
    if (!aiDraftItems) return [];
    return aiDraftItems.map((item, idx) => {
      const cleanDraft = String(item.material_type || "").toLowerCase().trim();
      const matchedDRPB = drpb.find(d => {
        const cleanDB = String(d.material_type || "").toLowerCase().trim();
        return cleanDB === cleanDraft || cleanDB.includes(cleanDraft) || cleanDraft.includes(cleanDB);
      });

      return {
        ...item,
        index: idx,
        matched_id: matchedDRPB ? matchedDRPB.id : '',
        matched_type: matchedDRPB ? matchedDRPB.material_type : '',
        matched_qty: matchedDRPB ? matchedDRPB.required_qty : 0,
      };
    });
  }, [aiDraftItems, drpb]);

  const handleApplyBulkDistribution = async () => {
    const proofBase64 = bulkProofs.photo_during || bulkProofs.receipt_base64;
    if (!proofBase64) {
      showToast("Gagal: Harap cantumkan minimal 1 Bukti Foto Penyaluran fisik lapangan atau Tanda Terima!", "error");
      return;
    }

    const itemsToSubmit = mappedDraftItems.filter(item => item.matched_id && item.required_qty > 0);
    if (itemsToSubmit.length === 0) {
      showToast("Gagal: Tidak ada item hasil scan yang terpetakan ke DRPB Warga.", "error");
      return;
    }

    setLoading(true);
    try {
      let successCount = 0;
      for (const item of itemsToSubmit) {
        // Calculate delivered to determine shortage
        const sumDelivered = distributions
          .filter(d => d.drpb_item_id === item.matched_id)
          .reduce((sum, curr) => sum + Number(curr.volume), 0);
        const futureDelivered = sumDelivered + Number(item.required_qty);
        const isShortage = futureDelivered < item.matched_qty;

        const payload = {
          drpb_item_id: item.matched_id,
          distribution_date: bulkProofs.date || new Date().toISOString().split('T')[0],
          volume: Number(item.required_qty),
          notes: bulkProofs.notes ? `${bulkProofs.notes} (Auto AI Scan)` : 'Dicatat melalui AI Scanner DRPB',
          shortage_reason: isShortage ? (bulkProofs.shortage_reason || "Lainnya") : '',
          shortage_notes: isShortage ? (bulkProofs.shortage_notes || "Volume kurang dari rencana DRPB") : '',
          photo_before: '',
          photo_during: bulkProofs.photo_during || '',
          photo_after: '',
          video_base64: '',
          video_duration: 15,
          receipt_base64: bulkProofs.receipt_base64 || '',
          recipient_id: recipientId,
          operator_id: operatorId
        };

        await onAddDistribution(payload);
        successCount++;
      }

      setAiDraftItems(null);
      setScannedFile(null);
      showToast(`Berhasil menyimpan ${successCount} catatan penyaluran otomatis!`, "success");
      fetchPBDetails();
    } catch (err: any) {
      console.error("Gagal bulk distribution:", err);
      showToast("Gagal memproses beberapa item penyaluran otomatis.", "error");
    } finally {
      setLoading(false);
    }
  };

  const loadPresetPackage = (type: 'bsps_standard' | 'structural' | 'roof_wall') => {
    let items: { material_type: string; unit: string; required_qty: number }[] = [];
    if (type === 'bsps_standard') {
      items = [
        { material_type: 'Semen', unit: 'sak', required_qty: 30 },
        { material_type: 'Besi Beton', unit: 'btg', required_qty: 15 },
        { material_type: 'Pasir Beton', unit: 'm3', required_qty: 8 },
        { material_type: 'Batu Belah', unit: 'm3', required_qty: 5 },
        { material_type: 'Kayu Usuk 5x7', unit: 'btg', required_qty: 25 },
        { material_type: 'Seng Gelombang', unit: 'lbr', required_qty: 20 },
        { material_type: 'Paku Campur', unit: 'kg', required_qty: 5 }
      ];
    } else if (type === 'structural') {
      items = [
        { material_type: 'Semen', unit: 'sak', required_qty: 25 },
        { material_type: 'Besi Beton', unit: 'btg', required_qty: 20 },
        { material_type: 'Kawat Bendrat', unit: 'kg', required_qty: 3 },
        { material_type: 'Batu Split 2/3', unit: 'm3', required_qty: 6 },
        { material_type: 'Pasir Pasang', unit: 'm3', required_qty: 10 }
      ];
    } else if (type === 'roof_wall') {
      items = [
        { material_type: 'Seng Gelombang', unit: 'lbr', required_qty: 40 },
        { material_type: 'Kalsiboard Dinding', unit: 'lbr', required_qty: 15 },
        { material_type: 'Kayu Reng 3x4', unit: 'btg', required_qty: 35 },
        { material_type: 'Paku Seng Payung', unit: 'kg', required_qty: 4 }
      ];
    }
    setAiDraftItems(items);
    setScannedFile(null);
    setScannerError(null);
  };

  // DRPB Form fields - now fully memory-based, no browser storage saving
  const [drpbForm, setDrpbForm] = useState({ material_type: 'Semen', unit: 'sak', required_qty: '' });

  // PB Editing States & Leaflet map configurations
  const [isEditingPB, setIsEditingPB] = useState(false);
  const [editForm, setEditForm] = useState({
    full_name: '',
    nik: '',
    kk_number: '',
    address: '',
    village_id: '',
    group_id: '',
    store_id: '',
    latitude: '',
    longitude: ''
  });

  const [mapLoaded, setMapLoaded] = useState(false);
  const editMapContainerRef = useRef<HTMLDivElement>(null);
  const editMapRef = useRef<any>(null);
  const editMarkerRef = useRef<any>(null);

  // Dynamic Leaflet loading or checking
  useEffect(() => {
    if ((window as any).L) {
      setMapLoaded(true);
      return;
    }

    let cssLink = document.getElementById('leaflet-css') as HTMLLinkElement;
    if (!cssLink) {
      cssLink = document.createElement('link');
      cssLink.id = 'leaflet-css';
      cssLink.rel = 'stylesheet';
      cssLink.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(cssLink);
    }

    let jsScript = document.getElementById('leaflet-js') as HTMLScriptElement;
    if (!jsScript) {
      jsScript = document.createElement('script');
      jsScript.id = 'leaflet-js';
      jsScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      jsScript.onload = () => setMapLoaded(true);
      document.body.appendChild(jsScript);
    } else {
      if ((window as any).L) {
        setMapLoaded(true);
      } else {
        jsScript.addEventListener('load', () => setMapLoaded(true));
      }
    }
  }, []);

  // Sync Leaflet map with edit state when editing and maploaded is ready
  useEffect(() => {
    if (!isEditingPB || !mapLoaded || !editMapContainerRef.current) return;

    const L = (window as any).L;
    if (!L) return;

    // Destroy existing map instance to recreate safely
    if (editMapRef.current) {
      try {
        editMapRef.current.remove();
      } catch (err) {
        console.warn(err);
      }
      editMapRef.current = null;
      editMarkerRef.current = null;
    }

    const initialLat = Number(editForm.latitude) || -6.9147;
    const initialLng = Number(editForm.longitude) || 107.6098;

    const map = L.map(editMapContainerRef.current).setView([initialLat, initialLng], 14);
    editMapRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    const markerIcon = L.divIcon({
      className: 'custom-edit-pb-pin',
      html: `
        <div style="
          width: 32px; 
          height: 32px; 
          background: #6366f1; 
          border: 3px solid white; 
          border-radius: 50% 50% 50% 0; 
          transform: rotate(-45deg); 
          display: flex; 
          align-items: center; 
          justify-content: center; 
          box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        ">
          <div style="
            width: 10px; 
            height: 10px; 
            background: white; 
            border-radius: 50%;
            transform: rotate(45deg);
          "></div>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 32]
    });

    const marker = L.marker([initialLat, initialLng], { 
      icon: markerIcon,
      draggable: true
    }).addTo(map);
    editMarkerRef.current = marker;

    // Map click drops marker & sets coordinates
    map.on('click', (e: any) => {
      const { lat, lng } = e.latlng;
      marker.setLatLng([lat, lng]);
      setEditForm(prev => ({
        ...prev,
        latitude: lat.toFixed(6),
        longitude: lng.toFixed(6)
      }));
    });

    // Marker drag sets coordinates
    marker.on('dragend', () => {
      const position = marker.getLatLng();
      setEditForm(prev => ({
        ...prev,
        latitude: position.lat.toFixed(6),
        longitude: position.lng.toFixed(6)
      }));
    });

    setTimeout(() => {
      map.invalidateSize();
    }, 250);

  }, [isEditingPB, mapLoaded]);

  // Support manual input synchronization
  const syncMapMarkerWithInputs = () => {
    const lat = Number(editForm.latitude);
    const lng = Number(editForm.longitude);
    if (isNaN(lat) || isNaN(lng)) {
      showToast("koordinat tidak valid", "error");
      return;
    }
    const L = (window as any).L;
    if (editMapRef.current && editMarkerRef.current && L) {
      editMarkerRef.current.setLatLng([lat, lng]);
      editMapRef.current.setView([lat, lng], 14);
    }
  };

  // Support automatic current geolocation fetching
  const handleAutoGPS = () => {
    if (!navigator.geolocation) {
      showToast("GPS tidak didukung", "error");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setEditForm(prev => ({
          ...prev,
          latitude: lat.toFixed(6),
          longitude: lng.toFixed(6)
        }));
        
        const L = (window as any).L;
        if (editMapRef.current && editMarkerRef.current && L) {
          editMarkerRef.current.setLatLng([lat, lng]);
          editMapRef.current.setView([lat, lng], 14);
        }
      },
      (error) => {
        showToast("gagal mengambil GPS", "error");
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Switch to editing mode prepopulated
  const startEditing = () => {
    if (!recipient) return;
    setEditForm({
      full_name: recipient.full_name,
      nik: recipient.nik,
      kk_number: recipient.kk_number,
      address: recipient.address || '',
      village_id: recipient.village_id || '',
      group_id: recipient.group_id || '',
      store_id: recipient.store_id || '',
      latitude: recipient.latitude ? String(recipient.latitude) : '',
      longitude: recipient.longitude ? String(recipient.longitude) : ''
    });
    setIsEditingPB(true);
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.full_name.trim()) {
      showToast("nama wajib diisi", "error");
      return;
    }
    if (!editForm.nik.trim() || editForm.nik.length !== 16) {
      showToast("NIK harus 16 digit", "error");
      return;
    }
    if (editForm.latitude === "" || editForm.longitude === "") {
      showToast("koordinat wajib diisi", "error");
      return;
    }

    try {
      const payload = {
        full_name: editForm.full_name,
        nik: editForm.nik,
        kk_number: editForm.kk_number,
        address: editForm.address,
        village_id: editForm.village_id,
        group_id: editForm.group_id,
        store_id: editForm.store_id,
        latitude: Number(editForm.latitude),
        longitude: Number(editForm.longitude),
        operator_id: operatorId
      };

      const res = await fetch(`/api/recipients/${recipientId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const responseData = await res.json();
      if (!res.ok) {
        throw new Error(responseData.error || "Gagal mengubah data PB.");
      }

      showToast("berhasil disimpan", "success");
      setIsEditingPB(false);
      fetchPBDetails();
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  // Distribution Form fields (Files as Base64 strings for direct post uploads) - now fully memory-based, no browser storage saving
  const [distForm, setDistForm] = useState({
    drpb_item_id: '',
    distribution_date: new Date().toISOString().split('T')[0],
    volume: '',
    notes: '',
    shortage_reason: '' as ShortageReason | '',
    shortage_notes: '',
    photo_before: '',
    photo_during: '',
    photo_after: '',
    video_base64: '',
    video_duration: '15',
    receipt_base64: ''
  });

  // Finding Form fields
  const [findingForm, setFindingForm] = useState({ category: 'material_shortage' as any, description: '' });

  // Static material presets
  const MATERIAL_PRESETS = [
    'Batu', 'Pasir', 'Semen', 'Kayu', 'Seng', 'Besi', 
    'Bata', 'Kerikil', 'Cat', 'Paku', 'Genteng', 'Kawat', 
    'Pipa', 'Keramik', 'Lainnya'
  ];

  // Load detailed PB information from our APIs
  const fetchPBDetails = async () => {
    try {
      const res = await fetch(`/api/recipients/${recipientId}`);
      if (!res.ok) throw new Error("Gagal mengambil data PB.");
      const data = await res.json();
      
      setRecipient(data.recipient);
      setDrpb(data.drpb || []);
      setDistributions(data.distributions || []);
      setMedia(data.distribution_media || []);
      setPhotos(data.recipient_photos || []);
      setFindings(data.findings || []);
      
      setLoading(false);
    } catch (e: any) {
      showToast("gagal memuat data", "error");
      onBack();
    }
  };

  useEffect(() => {
    fetchPBDetails();
  }, [recipientId]);

  // Convert uploaded files safely to base64 strings
  const triggerImageBase64 = (e: React.ChangeEvent<HTMLInputElement>, key: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setDistForm(prev => ({
        ...prev,
        [key]: reader.result as string
      }));
    };
    reader.readAsDataURL(file);
  };

  // Handle DRPB item submit
  const handleDRPBSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!drpbForm.required_qty) return;

    await onAddDRPBItem(recipientId, {
      ...drpbForm,
      required_qty: Number(drpbForm.required_qty)
    });
    setDrpbForm({ material_type: 'Semen', unit: 'sak', required_qty: '' });
    setShowAddDRPB(false);
    fetchPBDetails();
  };

  // Handle distribution submission
  const handleDistributionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!distForm.drpb_item_id || !distForm.volume) {
      showToast("lengkapi form", "error");
      return;
    }

    // Media valid check - only require at least one photo/media
    const hasMedia = distForm.photo_before || distForm.photo_during || distForm.photo_after || distForm.video_base64 || distForm.receipt_base64;
    if (!hasMedia) {
      showToast("lampirkan bukti", "error");
      return;
    }

    const item = drpb.find(d => d.id === distForm.drpb_item_id);
    if (!item) return;

    // Check for material shortages to trigger shortage reasons
    const sumDelivered = distributions
      .filter(d => d.drpb_item_id === distForm.drpb_item_id)
      .reduce((sum, curr) => sum + Number(curr.volume), 0);
    const futureDelivered = sumDelivered + Number(distForm.volume);

    if (futureDelivered < item.required_qty && !distForm.shortage_reason) {
      showToast("isi alasan kurang", "error");
      return;
    }

    const payload = {
      ...distForm,
      recipient_id: recipientId,
      volume: Number(distForm.volume),
      video_duration: Number(distForm.video_duration) || 15,
      operator_id: operatorId
    };

    try {
      await onAddDistribution(payload);
      // Clean
      setDistForm({
        drpb_item_id: '', distribution_date: new Date().toISOString().split('T')[0],
        volume: '', notes: '', shortage_reason: '', shortage_notes: '',
        photo_before: '', photo_during: '', photo_after: '',
        video_base64: '', video_duration: '15', receipt_base64: ''
      });
      setShowAddDist(false);
      fetchPBDetails();
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  // Handle manual finding submit
  const handleFindingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!findingForm.description) return;

    await onAddFinding(recipientId, findingForm);
    setFindingForm({ category: 'material_shortage', description: '' });
    setShowAddFinding(false);
    fetchPBDetails();
  };

  if (loading || !recipient) {
    return (
      <div className="p-8 text-center space-y-3">
        <div className="w-8 h-8 rounded-full border-t-2 border-slate-900 animate-spin mx-auto" />
        <p className="text-xs text-slate-500 font-mono">Memuat database detail Penerima Bantuan...</p>
      </div>
    );
  }

  const pbVillageName = villages.find(v => v.id === recipient.village_id)?.name || "-";
  const pbGroupName = groups.find(g => g.id === recipient.group_id)?.name || "-";
  const pbStore = stores.find(s => s.id === recipient.store_id);

  // Timeline events generation
  const timelineEvents: { title: string; desc: string; date: string; tag: string }[] = [];
  
  // 1. Created
  timelineEvents.push({
    title: "Akun PB Diaktifkan",
    desc: `Penerima Bantuan terdaftar dengan status awal. Toko penyedia material: ${pbStore?.name || "-"}`,
    date: recipient.created_at,
    tag: "created"
  });

  // 2. Distributions
  distributions.forEach(d => {
    const item = drpb.find(db => db.id === d.drpb_item_id);
    timelineEvents.push({
      title: "Material Disalurkan",
      desc: `Pengiriman bahan ${item?.material_type || "Bahan"} sebanyak ${d.volume} ${item?.unit || "unit"} oleh TFL. Jarak GPS pengiriman: ${d.gps_distance_from_home || 0}m.`,
      date: d.created_at,
      tag: "dist"
    });
  });

  // 3. Findings
  findings.forEach(f => {
    timelineEvents.push({
      title: f.resolved ? "Temuan Diselesaikan" : "Temuan Dilaporkan",
      desc: `Kendala kategori [${f.category}] dicatat: "${f.description}"`,
      date: f.created_at,
      tag: f.resolved ? "resolved" : "finding"
    });
  });

  // Sort timeline latest first
  const sortedTimeline = timelineEvents.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6">
      
      {/* Back button and profile panel */}
      <div className="flex items-center gap-3" id="pb-detail-header shadow-xs">
        <button
          onClick={onBack}
          className="p-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 rounded-xl cursor-pointer transition active:scale-90"
        >
          <ArrowLeft size={16} />
        </button>
        <div>
          <span className="text-[10px] font-bold font-mono text-slate-450 block uppercase">BSPS 2026 / DETIL PEMANTAUAN</span>
          <h2 className="text-lg font-extrabold text-slate-900 font-sans tracking-tight">{recipient.full_name}</h2>
        </div>
      </div>

      {/* Recipient Profile Summary Card / Edit Form */}
      {isEditingPB ? (
        <form onSubmit={handleEditSubmit} className="bg-white border-2 border-indigo-150 rounded-2xl p-5 sm:p-6 shadow-md space-y-5 animate-fadeIn">
          {/* Header / Title */}
          <div className="border-b border-indigo-50 pb-3 flex justify-between items-center bg-gradient-to-r from-indigo-50/20 via-transparent to-transparent">
            <div className="flex items-center gap-2.5 text-indigo-700">
              <span className="text-xl">✍️</span>
              <div>
                <h3 className="text-xs font-black font-sans uppercase tracking-wider text-slate-900">Ubah Data Detil Penerima Bantuan</h3>
                <p className="text-[10px] text-slate-500 font-mono">ID PB: {recipientId}</p>
              </div>
            </div>
            <button 
              type="button" 
              onClick={() => setIsEditingPB(false)}
              className="text-xs font-bold text-slate-600 hover:text-slate-800 transition px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              Batalkan
            </button>
          </div>

          {/* Form Fields: Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Name */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">Nama Lengkap PB:</label>
              <input 
                type="text" 
                required
                value={editForm.full_name} 
                onChange={e => setEditForm(prev => ({ ...prev, full_name: e.target.value }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-2xs font-sans text-slate-900"
              />
            </div>

            {/* NIK */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">NIK (16 Digit):</label>
              <input 
                type="text" 
                required
                maxLength={16}
                value={editForm.nik} 
                onChange={e => setEditForm(prev => ({ ...prev, nik: e.target.value.replace(/\D/g, '') }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-2xs font-mono text-slate-900"
              />
            </div>

            {/* KK */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">Nomor KK (16 Digit):</label>
              <input 
                type="text" 
                required
                maxLength={16}
                value={editForm.kk_number} 
                onChange={e => setEditForm(prev => ({ ...prev, kk_number: e.target.value.replace(/\D/g, '') }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-2xs font-mono text-slate-900"
              />
            </div>

            {/* Address */}
            <div className="space-y-1 md:col-span-2 lg:col-span-3">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">Alamat Rumah Lengkap:</label>
              <textarea 
                rows={2}
                value={editForm.address} 
                onChange={e => setEditForm(prev => ({ ...prev, address: e.target.value }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-2xs font-sans text-slate-900"
                placeholder="Tulis alamat rumah realitas PB..."
              />
            </div>

            {/* Village Dropdown */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">Wilayah Desa:</label>
              <select 
                value={editForm.village_id} 
                onChange={e => setEditForm(prev => ({ ...prev, village_id: e.target.value }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white text-slate-900"
              >
                <option value="">-- Pilih Desa --</option>
                {villages.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
              </select>
            </div>

            {/* Group Dropdown */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">Kelompok TFL (KMP):</label>
              <select 
                value={editForm.group_id} 
                onChange={e => setEditForm(prev => ({ ...prev, group_id: e.target.value }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white text-slate-900"
              >
                <option value="">-- Pilih Kelompok --</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>

            {/* Store Dropdown */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-extrabold font-mono text-slate-500 uppercase block">Toko Rekanan Ditunjuk:</label>
              <select 
                value={editForm.store_id} 
                onChange={e => setEditForm(prev => ({ ...prev, store_id: e.target.value }))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white text-slate-900"
              >
                <option value="">-- Pilih Toko Supplier --</option>
                {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>

          {/* Section 2: Coordinates Maps selection & Inputs */}
          <div className="border-t border-slate-100 pt-4 space-y-4">
            <div>
              <h4 className="text-xs font-extrabold text-indigo-900 font-sans tracking-tight uppercase">📌 KOORDINAT RUMAH PB (LOKASI RUMAH & SEBARAN GPS)</h4>
              <p className="text-[10px] text-slate-500 leading-normal">
                Ubah koordinat dengan mengetik manual, mendeteksi lokasi HP Anda secara offline, atau klik/drag pin secara interaktif lewat peta sebaran di bawah.
              </p>
            </div>

            {/* Manual Inputs + GPS detector row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <div className="space-y-1">
                <label className="text-[9.5px] font-bold font-mono text-slate-500 block">LATITUDE (GARIS LINTANG):</label>
                <input 
                  type="number" 
                  step="any"
                  required
                  value={editForm.latitude} 
                  onChange={e => setEditForm(prev => ({ ...prev, latitude: e.target.value }))}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-slate-900 bg-slate-50"
                  placeholder="Contoh: -6.914744"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9.5px] font-bold font-mono text-slate-500 block">LONGITUDE (GARIS BUJUR):</label>
                <input 
                  type="number" 
                  step="any"
                  required
                  value={editForm.longitude} 
                  onChange={e => setEditForm(prev => ({ ...prev, longitude: e.target.value }))}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-slate-900 bg-slate-50"
                  placeholder="Contoh: 107.609810"
                />
              </div>

              {/* Action Controls for Map syncing / Auto Location */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={syncMapMarkerWithInputs}
                  className="flex-1 py-2.5 px-3 border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold rounded-xl text-xs flex items-center justify-center gap-1 cursor-pointer transition select-none active:scale-95"
                  title="Posisikan penanda peta sesuai koordinat ketikan manual di samping"
                >
                  🗺️ Sinkron Pin
                </button>

                <button
                  type="button"
                  onClick={handleAutoGPS}
                  className="flex-1 py-2.5 px-3 bg-slate-900 text-white hover:bg-slate-800 font-medium rounded-xl text-xs flex items-center justify-center gap-1 cursor-pointer transition select-none active:scale-95 shadow-sm"
                  title="Dapatkan koordinat lokasi GPS perangkat Anda saat ini secara otomatis"
                >
                  🧭 GPS HP
                </button>
              </div>
            </div>

            {/* Interactive Map Canvas */}
            <div className="space-y-1">
              <label className="text-[9.5px] font-semibold font-mono text-slate-450 block uppercase">PILIH VIA PETA INTERAKTIF SEBARAN (KLIK ATAU DRAG PIN):</label>
              <div 
                ref={editMapContainerRef}
                className="h-64 sm:h-72 w-full rounded-2xl border-2 border-slate-100 shadow-inner z-10 overflow-hidden relative"
                id="leaflet-edit-canvas"
              />
              <span className="text-[9.5px] text-slate-450 italic font-medium block">
                *Tips: Klik di mana saja pada peta atau seret (drag) pin biru ke titik atap rumah bapak/ibu PB untuk ketepatan.
              </span>
            </div>
          </div>

          {/* Form Actions Footer */}
          <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsEditingPB(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition"
            >
              Batalkan
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl cursor-pointer transition active:scale-95 shadow-md flex items-center gap-1.5"
            >
              💾 Simpan Perubahan PB
            </button>
          </div>
        </form>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs grid grid-cols-1 md:grid-cols-3 gap-6 relative overflow-hidden" id="pb-profile-flyout">
          
          {/* Info Col 1 */}
          <div className="space-y-3">
            <div>
              <span className="text-[10px] font-bold font-mono text-slate-400 block">NOMOR IDENTITAS NASIONAL</span>
              <span className="text-sm font-bold font-mono text-slate-800">{recipient.nik}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold font-mono text-slate-400 block">NOMOR KARTU KELUARGA</span>
              <span className="text-sm font-bold font-mono text-slate-800">{obfuscateID(recipient.kk_number)}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold font-mono text-slate-400 block">ALAMAT ASLI PB</span>
              <span className="text-xs text-slate-700 italic">{recipient.address}</span>
            </div>
          </div>

          {/* Info Col 2 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-slate-100 text-slate-700 rounded-lg shrink-0">
                <Landmark size={14} />
              </div>
              <div>
                <span className="text-[9px] font-bold font-mono text-slate-400 block uppercase">Wilayah Desa</span>
                <span className="text-xs font-bold text-slate-800">{pbVillageName}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 bg-slate-100 text-slate-700 rounded-lg shrink-0">
                <Layers size={14} />
              </div>
              <div>
                <span className="text-[9px] font-bold font-mono text-slate-400 block uppercase">Kelompok TFL</span>
                <span className="text-xs font-bold text-slate-800">{pbGroupName}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 bg-slate-100 text-slate-700 rounded-lg shrink-0">
                <Building size={14} />
              </div>
              <div>
                <span className="text-[9px] font-bold font-mono text-slate-400 block uppercase">Toko Rekanan</span>
                <span className="text-xs font-bold text-slate-805 truncate block max-w-[200px]">{pbStore?.name || "-"}</span>
              </div>
            </div>
          </div>

          {/* Info Col 3 Status and Actions */}
          <div className="flex flex-col justify-between items-start md:items-end">
            <div className="space-y-1 text-left md:text-right">
              <span className="text-[10px] font-bold font-mono text-slate-405 block uppercase">KONDISI PENYALURAN</span>
              <span className={`inline-block text-xs font-bold px-3 py-1 rounded border uppercase ${getStatusColor(recipient.status)}`}>
                {getStatusLabel(recipient.status)}
              </span>
            </div>

            <div className="mt-4 md:mt-0 space-y-1 text-left md:text-right">
              <span className="text-[10px] font-bold font-mono text-slate-450 block uppercase">KOORDINAT RUMAH PB</span>
              <span className="text-xs font-mono text-slate-8 w-full block">Lat: {recipient.latitude.toFixed(6)}, Lng: {recipient.longitude.toFixed(6)}</span>
            </div>

            <div className="mt-4 flex flex-wrap gap-2 justify-end">
              <button
                type="button"
                onClick={startEditing}
                className="py-1.5 px-3.5 bg-indigo-600 text-white hover:bg-indigo-705 font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer transition select-none shadow-sm hover:scale-102 active:scale-95"
                title="Surgical Edit PB details, coordinates, or mapping locations"
              >
                ✏️ Edit Data PB
              </button>

              <button
                onClick={() => window.open(`/public/${recipientId}`, '_blank')}
                className="py-1.5 px-3 bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100 font-bold rounded-xl text-xs flex items-center gap-1 cursor-pointer transition"
              >
                <Eye size={13} />
                Buka QR Publik
              </button>
            </div>
          </div>

        </div>
      )}

      {/* SECTION: RINGKASAN PROGRES & BUKTI FISIK PENYALURAN (QR TOKO & LAPANGAN) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4" id="qr-photos-summary-block">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-slate-105 pb-3">
          <div>
            <h3 className="text-sm font-extrabold text-slate-905 tracking-tight flex items-center gap-2">
              <span className="text-base">📸</span>
              Katalog Foto Bukti Penyaluran QR (Toko) & Progres Aktual
            </h3>
            <p className="text-[11px] text-slate-500">
              Dokumentasi fisik real-time hasil kiriman Toko Penyalur via QR-Code dan progres pemenuhan bahan bangunan.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-150 px-2.5 py-1 rounded-full flex items-center gap-1 animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" /> SINKRON QR PORTAL
            </span>
          </div>
        </div>

        {/* AI SMART INSIGHTS PANEL */}
        <div className="bg-gradient-to-br from-indigo-50 to-white border border-indigo-150 rounded-2xl p-4 shadow-sm border-l-4 border-l-indigo-500">
          <div className="flex justify-between items-start mb-3">
            <div className="space-y-0.5">
              <h4 className="text-[11px] font-black text-indigo-900 flex items-center gap-1.5 uppercase font-mono">
                <Sparkles size={14} className="text-indigo-600" />
                AI Smart Analysis & Logistik Monitoring
              </h4>
              <p className="text-[10px] text-indigo-600/80 leading-tight">
                Gunakan kecerdasan Gemini untuk menganalisis progress penyerapan material dan mendeteksi anomali pengiriman.
              </p>
            </div>
            <button
              onClick={handleRunAIAnalysis}
              disabled={isAnalyzing || drpb.length === 0}
              className={`px-4 py-2 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm cursor-pointer ${
                isAnalyzing 
                  ? 'bg-slate-100 text-slate-400' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'
              }`}
            >
              {isAnalyzing ? (
                <>
                  <div className="w-3 h-3 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin" />
                  Menganalisis...
                </>
              ) : (
                <>
                  <Sparkles size={13} />
                  Jalankan Analisis AI
                </>
              )}
            </button>
          </div>

          {!aiAnalysis && !isAnalyzing && (
            <div className="py-2 px-3 bg-white/50 border border-indigo-100 rounded-lg border-dashed">
              <p className="text-[10px] text-slate-500 italic text-center">
                Belum ada analisis yang dijalankan. Klik tombol di atas untuk mendapatkan ringkasan cerdas dari asisten AI.
              </p>
            </div>
          )}

          {aiAnalysis && (
            <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-500">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Analysis Box 1 */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-black text-xs">
                      {aiAnalysis.estimated_percentage}%
                    </div>
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block uppercase">Progress Logistik (Estimasi AI)</span>
                      <p className="text-xs font-bold text-slate-800">{aiAnalysis.progress_summary}</p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[9px] font-bold text-rose-500 block uppercase flex items-center gap-1">
                      <AlertTriangle size={10} /> Problem & Temuan Kritis:
                    </span>
                    <ul className="space-y-1">
                      {aiAnalysis.issues.map((issue, i) => (
                        <li key={i} className="text-[10.5px] text-slate-700 flex gap-1.5">
                          <span className="text-rose-400">•</span>
                          <span>{issue}</span>
                        </li>
                      ))}
                      {aiAnalysis.issues.length === 0 && (
                        <li className="text-[10.5px] text-emerald-600 font-medium italic">Tidak ada masalah kritis terdeteksi.</li>
                      )}
                    </ul>
                  </div>
                </div>

                {/* Analysis Box 2 */}
                <div className="bg-indigo-900/5 p-3 rounded-xl border border-indigo-100 space-y-2">
                  <span className="text-[9px] font-bold text-indigo-600 block uppercase flex items-center gap-1">
                    <ClipboardCheck size={10} /> Rekomendasi Langkah Pengawas:
                  </span>
                  <ul className="space-y-1.5">
                    {aiAnalysis.recommendations.map((rec, i) => (
                      <li key={i} className="text-[10.5px] text-slate-800 font-medium bg-white/60 p-1.5 rounded-lg border border-indigo-50/50 flex gap-2">
                        <span className="text-indigo-500 font-black shrink-0">{i + 1}.</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="text-[9px] text-slate-400 flex items-center gap-1 border-t border-indigo-50 pt-2 italic">
                <Sparkles size={10} /> Analisis ini dihasilkan oleh AI berdasarkan data penyaluran, DRPB, dan temuan lapangan saat ini.
              </div>
            </div>
          )}
        </div>

        {/* Outer Grid: Left Overall Progress, Right Photo Gallery */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          
          {/* Col 1 (4 cols): Detailed progress tracker details */}
          <div className="lg:col-span-4 bg-slate-50 border border-slate-150 rounded-2xl p-4 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <span className="text-[10px] font-bold font-mono text-slate-450 block uppercase tracking-wider">REKAPITULASI PROGRES MATERIAL</span>
              
              {(() => {
                const totalRequired = drpb.reduce((sum, item) => sum + Number(item.required_qty), 0);
                const totalDelivered = drpb.reduce((sum, item) => {
                  const delivered = distributions
                    .filter(d => d.drpb_item_id === item.id)
                    .reduce((s, curr) => s + Number(curr.volume), 0);
                  return sum + Math.min(Number(item.required_qty), delivered);
                }, 0);
                const overallProgressPct = totalRequired > 0 ? Math.round((totalDelivered / totalRequired) * 100) : 0;

                return (
                  <>
                    <div className="flex items-center gap-4">
                      {/* Visual Circular/Dial percentage */}
                      <div className="relative w-16 h-16 rounded-full border-4 border-slate-100 flex items-center justify-center bg-white shadow-xs shrink-0">
                        <div className="absolute inset-0 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin duration-1000 opacity-20" />
                        <span className="font-mono text-base font-black text-slate-900">{overallProgressPct}%</span>
                      </div>

                      <div>
                        <h4 className="text-xs font-black text-slate-800">Progres Penyaluran Total</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5 leading-normal">
                          Terpenuhi <strong className="font-bold text-slate-700">{totalDelivered.toFixed(1)}</strong> dari total <strong className="font-bold text-slate-700">{totalRequired.toFixed(1)}</strong> unit alokasi DRPB.
                        </p>
                      </div>
                    </div>

                    {/* Progress Slider representation */}
                    <div className="space-y-1 pt-1">
                      <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${
                            overallProgressPct === 100 
                              ? 'bg-gradient-to-r from-emerald-500 to-green-600' 
                              : overallProgressPct > 50 
                                ? 'bg-gradient-to-r from-indigo-500 to-indigo-600' 
                                : 'bg-gradient-to-r from-amber-500 to-orange-500'
                          }`} 
                          style={{ width: `${overallProgressPct}%` }}
                        />
                      </div>
                      <div className="flex justify-between items-center text-[9px] font-mono text-slate-400">
                        <span>0% (Mulai)</span>
                        <span className="font-bold text-slate-600">{overallProgressPct}% Realisasi</span>
                        <span>100% (Selesai)</span>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>

            {/* List breakdown of material status */}
            <div className="border-t border-slate-200 pt-3 space-y-2 text-xs">
              <span className="text-[9px] font-bold font-mono text-slate-405 block uppercase tracking-wider">Status Pemenuhan Bahan:</span>
              <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                {drpb.length === 0 ? (
                  <p className="text-[10px] text-slate-400 italic">Belum ada bahan DRPB diinput.</p>
                ) : (
                  drpb.map(item => {
                    const delivered = distributions
                      .filter(d => d.drpb_item_id === item.id)
                      .reduce((s, curr) => s + Number(curr.volume), 0);
                    const isDone = delivered >= item.required_qty;
                    return (
                      <div key={item.id} className="flex justify-between items-center text-[10.5px]">
                        <span className="font-semibold text-slate-800">{item.material_type}</span>
                        <span className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded border ${
                          isDone 
                            ? 'bg-emerald-50 border-emerald-150 text-emerald-700' 
                            : 'bg-amber-50 border-amber-150 text-amber-700'
                        }`}>
                          {delivered}/{item.required_qty} {item.unit}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Col 2 (8 cols): Photo/media collection from QR portal */}
          <div className="lg:col-span-8 bg-white border border-slate-150 rounded-2xl p-4 space-y-3">
            <span className="text-[10px] font-bold font-mono text-slate-450 block uppercase tracking-wider">GALERI BUKTI FISIK PENYALURAN (QR TOKO)</span>
            
            {media.length === 0 ? (
              <div className="p-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 flex flex-col items-center justify-center text-center space-y-1.5">
                <span className="text-xl">📸</span>
                <p className="text-[11px] text-slate-500 font-medium">Belum ada foto/video bukti fisik yang terunggah.</p>
                <p className="text-[9px] text-slate-450 font-mono">Penyalur toko dapat mengunggah bukti penyaluran material secara instan dng menscan QR code.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-72 overflow-y-auto pr-1">
                {media.map((f, idx) => {
                  // Find associated distribution to show info
                  const dist = distributions.find(d => d.id === f.distribution_id);
                  const distItem = dist ? drpb.find(db => db.id === dist.drpb_item_id) : null;
                  
                  // Translate media type label nicely
                  const mediaLabelMap: Record<string, string> = {
                    photo_before: '1. Sebelum Bongkar',
                    photo_during: '2. Proses Bongkar',
                    photo_after: '3. Selesai Diturunkan',
                    receipt: '4. Nota Penerimaan',
                    video: 'Video Bongkar Muat'
                  };
                  
                  const isQR = dist?.operator_id === "TOKO_SUPPLIER_PORTAL";
                  const dateStr = dist ? formatDateOnly(dist.distribution_date) : "Log";

                  return (
                    <div 
                      key={f.id || idx} 
                      className="border border-slate-200 rounded-xl overflow-hidden bg-slate-150 flex flex-col justify-between hover:border-slate-350 transition relative group shadow-2xs"
                    >
                      {/* Top Label Badge */}
                      <div className="p-1 px-2 border-b border-slate-150 bg-slate-50 text-[9px] font-mono flex items-center justify-between text-slate-600 gap-1 select-none">
                        <span className="font-extrabold truncate text-slate-800">{mediaLabelMap[f.media_type] || 'Dokumentasi'}</span>
                        {isQR && (
                          <span className="text-[8.5px] bg-indigo-50 border border-indigo-150 text-indigo-700 px-1 py-0.2 rounded font-black shrink-0 animate-pulse">
                            QR TOKO
                          </span>
                        )}
                      </div>

                      {/* Display Image or Video Thumbnail */}
                      <div className="aspect-16/11 bg-slate-900 overflow-hidden relative flex items-center justify-center">
                        {f.media_type === 'video' ? (
                          <div className="flex flex-col items-center justify-center text-amber-300 p-2 text-center select-none font-sans">
                            <Video size={18} className="text-amber-500 animate-pulse" />
                            <span className="text-[8px] font-bold block mt-1 uppercase font-mono bg-amber-950/60 p-0.5 rounded px-1.5">
                              🎥 Video ({f.duration_seconds || 15} Detik)
                            </span>
                          </div>
                        ) : (
                          <img 
                            src={f.file_url} 
                            className="w-full h-full object-cover group-hover:scale-105 transition" 
                            alt={mediaLabelMap[f.media_type]} 
                            loading="lazy"
                          />
                        )}

                        {/* Hover Overlay Zoom Button */}
                        <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-1.5 p-1 select-none">
                          <button
                            type="button"
                            onClick={() => window.open(f.file_url, '_blank')}
                            className="p-1.5 rounded-lg bg-white/95 text-slate-800 text-[10px] font-extrabold hover:bg-white transition flex items-center gap-1 shadow-md cursor-pointer"
                          >
                            <Eye size={10} /> Zoom Foto
                          </button>
                        </div>
                      </div>

                      {/* Bottom Info Footer */}
                      <div className="p-1.5 px-2 bg-slate-50 border-t border-slate-150 text-[9px] font-mono text-slate-500 space-y-0.5 select-none text-left">
                        <div className="truncate text-slate-700 font-bold block">
                          🚚 {distItem ? `${distItem.material_type} (${dist?.volume} ${distItem.unit})` : 'Log Pengiriman'}
                        </div>
                        <div className="flex justify-between items-center text-[8px] text-slate-400">
                          <span>{dateStr}</span>
                          <span className="truncate max-w-[65px]">By: {dist?.operator_id || 'system'}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* DRPB PLANNERS SECTION */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4" id="drpb-planner-panel">
        
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-extrabold text-slate-905 tracking-tight flex items-center gap-1">
              <ClipboardCheck size={16} />
              Daftar Rencana Penyaluran Bahan (DRPB)
            </h3>
            <p className="text-[11px] text-slate-500">Rencana alokasi volume bahan bangunan yang harus dikirim ke lokasi asli.</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <label className="px-3 py-1.5 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition active:scale-95">
              <Sparkles size={13} className="animate-pulse" />
              Scan DRPB (AI) 🪄
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleAIScanUpload}
                disabled={isScanning}
              />
            </label>

            <button
              onClick={() => setShowAddDRPB(!showAddDRPB)}
              className="px-3 py-1.5 bg-slate-105 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition border border-slate-200"
            >
              <Plus size={13} />
              Input Manual
            </button>
            {drpb.length > 0 && (
              <button
                onClick={() => setShowClearDRPBConfirm(true)}
                className="px-3 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-700 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition border border-rose-200 ml-auto md:ml-0"
              >
                <Trash2 size={13} />
                Hapus Semua DRPB
              </button>
            )}
          </div>
        </div>

        {/* Quick Batch Package Filling Action Buttons */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          <div className="space-y-0.5">
            <span className="text-[10px] font-black font-mono text-indigo-700 block uppercase tracking-wider">⚡ Templet Isi Cepat Paket Bahan DRPB</span>
            <p className="text-slate-500 font-normal leading-normal text-[11px]">
              Klik salah satu paketan di samping untuk memuat seluruh kebutuhan bahan standar sekaligus ke draf koreksi, lalu simpan dengan sekali klik!
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5 shrink-0">
            <button
              onClick={() => loadPresetPackage('bsps_standard')}
              className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-2xs transition hover:scale-102 active:scale-95 cursor-pointer flex items-center gap-1 text-[11px]"
              title="Isi draf dengan semen, besi, kayu, seng, pasir, batu, paku standar BSPS"
            >
              🏠 Paket Standar BSPS
            </button>
            <button
              onClick={() => loadPresetPackage('structural')}
              className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-2xs transition hover:scale-102 active:scale-95 cursor-pointer flex items-center gap-1 text-[11px]"
              title="Isi draf dengan material pondasi cor semen, besi, kawat, batu belah, pasir"
            >
              🧱 Paket Pondasi & Cor
            </button>
            <button
              onClick={() => loadPresetPackage('roof_wall')}
              className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-2xs transition hover:scale-102 active:scale-95 cursor-pointer flex items-center gap-1 text-[11px]"
              title="Isi draf dengan material seng gelombang, kalsiboard dinding, kayu reng, paku seng"
            >
              🪵 Paket Atap & Kusen
            </button>
          </div>
        </div>

        {/* AI SCANNER PROGRESS & INTERACTIVE REVIEW DRAFT PANEL */}
        {isScanning && (
          <div className="p-6 bg-indigo-50/60 border border-indigo-150 rounded-2xl flex flex-col items-center justify-center text-center space-y-4 shadow-sm relative overflow-hidden" id="ai-scanning-progress">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-sky-400 via-indigo-500 to-emerald-400 animate-pulse" />
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 animate-bounce">
                <Sparkles size={20} className="text-indigo-600 animate-pulse" />
              </div>
            </div>

            <div className="space-y-1">
              <h4 className="text-xs font-extrabold text-indigo-950 font-mono uppercase tracking-widest flex items-center justify-center gap-1.5">
                <Loader2 size={13} className="animate-spin text-indigo-600" />
                Mengekstrak Dokumen DRPB (AI Scanner)
              </h4>
              <p className="text-[11px] text-slate-600 max-w-md font-medium leading-relaxed">
                {scanStatus}
              </p>
              {scanAttempt > 1 && (
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-amber-100 border border-amber-200 text-[10px] font-bold font-mono uppercase text-amber-800 rounded-full mt-1">
                  <RefreshCw size={10} className="animate-spin" />
                  Mencoba Kembali: Percobaan ke-{scanAttempt} dari 3
                </div>
              )}
            </div>

            {/* Visual Step-by-Step Progress Track */}
            <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl p-3.5 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 border-b border-slate-100 pb-1 px-1">
                <span>TAHAPAN PROSES SCAN DRPB</span>
                <span className="text-indigo-600 font-mono">Attempt {scanAttempt}/3</span>
              </div>
              
              <div className="space-y-2.5 text-left">
                {(['Mengunggah foto...', 'Menghubungi Gemini AI...', 'Membaca tabel...', 'Memvalidasi hasil...', 'Selesai'] as OcrStep[]).map((phase, idx) => {
                  const phases: OcrStep[] = ['Mengunggah foto...', 'Menghubungi Gemini AI...', 'Membaca tabel...', 'Memvalidasi hasil...', 'Selesai'];
                  const activeIdx = ocrStep ? phases.indexOf(ocrStep) : -1;
                  const phaseIdx = idx;

                  const isDone = activeIdx > phaseIdx || (activeIdx === -1 && scanStep === 'idle');
                  const isActive = activeIdx === phaseIdx;

                  return (
                    <div key={phase} className="flex items-center justify-between text-xs border-b border-slate-50 last:border-none pb-2 last:pb-0">
                      <div className="flex items-center gap-2">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          isDone 
                            ? "bg-emerald-100 text-emerald-700" 
                            : isActive 
                              ? "bg-indigo-100 text-indigo-600 animate-pulse" 
                              : "bg-slate-100 text-slate-400"
                        }`}>
                          {isDone ? <Check size={11} className="stroke-[3]" /> : idx + 1}
                        </div>
                        <span className={`font-semibold ${
                          isActive 
                            ? "text-indigo-600 font-bold" 
                            : isDone 
                              ? "text-emerald-700 font-medium" 
                              : "text-slate-500"
                        }`}>
                          {phase}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 animate-pulse">
                        {isDone ? "Selesai" : isActive ? "Proses..." : "Wait..."}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {scannedFile && (
              <div className="relative w-20 h-20 rounded-lg overflow-hidden border border-slate-200 shadow-xs">
                <img src={scannedFile} className="w-full h-full object-cover opacity-75" alt="draft upload thumbnail" />
                <div className="absolute inset-0 bg-indigo-900/10 flex items-center justify-center">
                  <div className="w-4 h-4 rounded-full border-2 border-t-transparent border-white animate-spin" />
                </div>
              </div>
            )}
          </div>
        )}

        {scannerError && (
          <div className="p-5 bg-rose-50 border border-rose-150 rounded-2xl text-xs text-rose-800 space-y-3.5 shadow-sm" id="ai-scan-error">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="text-rose-600 shrink-0 mt-0.5" size={17} />
              <div className="space-y-1">
                <span className="font-extrabold font-mono text-[10px] uppercase tracking-wider block text-rose-900 leading-none">
                  Gagal Melakukan AI Extraction
                </span>
                <p className="text-rose-700/90 leading-relaxed font-medium">{scannerError}</p>
              </div>
            </div>

            {scannedFile && (
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-white border border-rose-200 rounded-xl p-3 mt-1.5">
                <div className="flex items-center gap-2.5">
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-slate-200 shadow-2xs shrink-0 bg-slate-50">
                    <img src={scannedFile} className="w-full h-full object-cover" alt="stale upload preview" />
                  </div>
                  <div className="space-y-0.5 grow min-w-0">
                    <h5 className="font-bold text-slate-800 text-[11px] leading-tight">Coba kembali dengan gambar yang sama?</h5>
                    <p className="text-[10px] text-slate-500 leading-normal">
                      Terkadang kendala jaringan/timeout dari API eksternal menyebabkan proses scanning terputus.
                  </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => performAIScan(scannedFile)}
                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-[11px] cursor-pointer flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95 shrink-0"
                >
                  <RefreshCw size={11} className="mr-0.5 animate-spin-hover" />
                  Coba Lagi Sekarang
                </button>
              </div>
            )}
          </div>
        )}

        {/* AI Draft Items Review Section */}
        {aiDraftItems && (
          <div className="p-5 bg-gradient-to-br from-indigo-50/40 via-sky-50/30 to-indigo-50/40 border border-indigo-150 rounded-2xl space-y-4 shadow-sm" id="ai-draft-container">
            <div className="flex justify-between items-start border-b border-indigo-100 pb-3">
              <div className="space-y-0.5">
                <h4 className="text-xs font-extrabold text-indigo-950 font-mono uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles size={14} className="text-indigo-600" />
                  🪄 AI Draft Review Hasil Photo Scan (Fitur Review TFL)
                </h4>
                <p className="text-[10px] text-indigo-800/85">
                  Silakan periksa, sesuaikan, atau koreksi barang/satuan/kebutuhan yang tersaring agar sama persis dengan foto lembar DRPB sebelum disimpan.
                </p>
              </div>
              <button 
                type="button"
                onClick={() => { setAiDraftItems(null); setScannedFile(null); }}
                className="text-[10px] font-bold text-slate-500 hover:text-slate-800 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
              >
                Batalkan Draft
              </button>
            </div>

            {/* Mode Switcher: DRPB Target vs Auto-Fill Penyaluran */}
            <div className="flex border-b border-indigo-100 gap-4">
              <button
                type="button"
                onClick={() => setDraftMode('drpb')}
                className={`pb-1.5 text-[11px] font-black uppercase tracking-wider font-mono border-b-2 transition ${
                  draftMode === 'drpb' ? 'text-indigo-750 border-indigo-600' : 'text-slate-400 border-transparent hover:text-slate-600'
                }`}
              >
                🗂️ Rencana DRPB Kebutuhan
              </button>
              <button
                type="button"
                onClick={() => setDraftMode('distribution')}
                className={`pb-1.5 text-[11px] font-black uppercase tracking-wider font-mono border-b-2 transition ${
                  draftMode === 'distribution' ? 'text-indigo-750 border-indigo-600' : 'text-slate-400 border-transparent hover:text-slate-600'
                }`}
              >
                📦 Auto-Fill Penyaluran Lapangan (Simpan Kilat)
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
              {/* Photo View Thumbnail */}
              {scannedFile && (
                <div className="md:col-span-3 space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-550 block uppercase">Lembar Asli DRPB</span>
                  <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-100 aspect-3/4 max-h-56 relative group">
                    <img src={scannedFile} className="w-full h-full object-contain" alt="Original Scanned DRPB File" />
                    <button 
                      type="button" 
                      onClick={() => window.open(scannedFile, '_blank')}
                      className="absolute bottom-2 right-2 p-1.5 bg-slate-900/80 text-white rounded-lg text-[9px] font-bold hover:bg-slate-900 flex items-center gap-1"
                    >
                      <Eye size={10} /> Perbesar Foto
                    </button>
                    <button 
                      type="button" 
                      onClick={saveDRPBPhoto}
                      className="absolute bottom-2 left-2 p-1.5 bg-emerald-600/90 text-white rounded-lg text-[9px] font-bold hover:bg-emerald-700 flex items-center gap-1"
                    >
                      <Upload size={10} /> Simpan Foto DRPB
                    </button>
                  </div>
                </div>
              )}

              {/* Action Modality Form View */}
              <div className={scannedFile ? "md:col-span-9 space-y-3" : "md:col-span-12 space-y-3"}>
                {draftMode === 'drpb' ? (
                  <div className="space-y-3">
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {aiDraftItems.length === 0 ? (
                        <div className="p-6 text-center text-slate-500 italic text-xs bg-white rounded-xl border border-slate-150">
                          Tidak ada material yang berhasil disaring oleh AI. Silakan tambahkan material manual di bawah atau unggah foto yang lebih jelas.
                        </div>
                      ) : (
                        aiDraftItems.map((item, idx) => (
                          <div key={idx} className="flex flex-wrap sm:flex-nowrap items-center gap-2 bg-white/70 p-2.5 rounded-lg border border-indigo-100/60 shadow-xs">
                            <div className="flex-1 min-w-[140px] space-y-0.5">
                              <span className="text-[8px] font-mono font-bold text-indigo-400 uppercase block">Material {idx + 1}</span>
                              <input 
                                type="text"
                                value={item.material_type}
                                onChange={(e) => {
                                  const updated = [...aiDraftItems];
                                  updated[idx].material_type = e.target.value;
                                  setAiDraftItems(updated);
                                }}
                                placeholder="Semen, Besi, dll..."
                                className="w-full p-1 border border-slate-200 rounded text-xs text-slate-850 focus:ring-1 focus:ring-indigo-500 font-medium"
                              />
                            </div>

                            <div className="w-24 space-y-0.5">
                              <span className="text-[8px] font-mono font-bold text-indigo-400 uppercase block">Satuan (Unit)</span>
                              <input 
                                type="text"
                                value={item.unit}
                                onChange={(e) => {
                                  const updated = [...aiDraftItems];
                                  updated[idx].unit = e.target.value;
                                  setAiDraftItems(updated);
                                }}
                                placeholder="sak, btg..."
                                className="w-full p-1 border border-slate-200 rounded text-xs text-slate-850 focus:ring-1 focus:ring-indigo-500"
                              />
                            </div>

                            <div className="w-24 space-y-0.5">
                              <span className="text-[8px] font-mono font-bold text-indigo-400 uppercase block">Volume Kebutuhan</span>
                              <input 
                                type="number"
                                value={item.required_qty}
                                onChange={(e) => {
                                  const updated = [...aiDraftItems];
                                  updated[idx].required_qty = Number(e.target.value) || 0;
                                  setAiDraftItems(updated);
                                }}
                                className="w-full p-1 border border-slate-200 rounded text-xs text-slate-850 font-mono text-right focus:ring-1 focus:ring-indigo-500"
                              />
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                const updated = aiDraftItems.filter((_, i) => i !== idx);
                                setAiDraftItems(updated);
                              }}
                              className="p-1.5 border border-slate-200 hover:border-rose-300 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50/50 mt-4 transition cursor-pointer"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))
                      )}
                    </div>

                    <div className="flex justify-between items-center bg-white/40 p-2 rounded-xl border border-dashed border-indigo-200">
                      <button
                        type="button"
                        onClick={() => {
                          setAiDraftItems([...(aiDraftItems || []), { material_type: "Material Baru", unit: "sak", required_qty: 10 }]);
                        }}
                        className="px-2.5 py-1 border border-dashed border-indigo-300 hover:bg-indigo-50 font-bold text-[10px] text-indigo-700 rounded-lg flex items-center gap-1 transition"
                      >
                        <Plus size={10} /> Tambah Item Ke Draft
                      </button>

                      <button
                        type="button"
                        onClick={handleApplyAIDraft}
                        className="px-4 py-1.5 bg-gradient-to-r from-indigo-600 to-indigo-850 hover:from-indigo-750 hover:to-indigo-900 text-white font-extrabold text-xs rounded-lg flex items-center gap-1 shadow-md hover:shadow-indigo-250 transition cursor-pointer"
                      >
                        <CheckCircle2 size={13} />
                        Simpan Hasil AI ke DRPB Warga
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Auto-Fill Penyaluran Mode UI */
                  <div className="space-y-4">
                    <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                      {mappedDraftItems.map((item, idx) => {
                        const isMapped = !!item.matched_id;
                        return (
                          <div key={idx} className={`flex items-center justify-between p-2.5 rounded-lg border text-xs ${
                            isMapped ? 'bg-emerald-50/50 border-emerald-150' : 'bg-amber-50/50 border-amber-150'
                          }`}>
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-slate-800">{item.material_type}</span>
                                <span className="px-1.5 py-0.5 bg-indigo-100 text-indigo-800 rounded font-mono font-bold text-[9px]">
                                  {item.required_qty} {item.unit} (Scanned)
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-500">
                                {isMapped ? (
                                  <span className="text-emerald-750 font-medium font-mono">
                                    ✓ Terpetakan ke: {item.matched_type} (Kebutuhan: {item.matched_qty} {item.unit})
                                  </span>
                                ) : (
                                  <span className="text-amber-700 font-medium font-mono">
                                    ⚠️ Material tidak terdaftar di DRPB PB saat ini.
                                  </span>
                                )}
                              </p>
                            </div>

                            <div className="flex items-center gap-2">
                              {/* Volume editor inside scan list */}
                              <div className="flex items-center gap-1">
                                <span className="text-[9px] text-slate-400 font-mono">Qty Kirim:</span>
                                <input
                                  type="number"
                                  value={item.required_qty}
                                  onChange={(e) => {
                                    const updated = [...aiDraftItems];
                                    updated[idx].required_qty = Number(e.target.value) || 0;
                                    setAiDraftItems(updated);
                                  }}
                                  className="w-16 p-1 border border-slate-200 rounded text-right font-mono"
                                />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Proof Attachment Form */}
                    <div className="p-3 bg-white/80 border border-indigo-100/60 rounded-xl grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-mono font-bold text-indigo-700 uppercase block">Tanggal Kirim</label>
                        <input
                          type="date"
                          value={bulkProofs.date}
                          onChange={(e) => setBulkProofs(prev => ({ ...prev, date: e.target.value }))}
                          className="w-full text-xs p-1.5 bg-white border border-slate-200 rounded-lg text-slate-800"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-mono font-bold text-indigo-700 uppercase block">Catatan Operasional (Penyaluran)</label>
                        <input
                          type="text"
                          placeholder="Misal: Dikirim via truk Engkel toko..."
                          value={bulkProofs.notes}
                          onChange={(e) => setBulkProofs(prev => ({ ...prev, notes: e.target.value }))}
                          className="w-full text-xs p-1.5 bg-white border border-slate-200 rounded-lg text-slate-800"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-mono font-bold text-indigo-700 uppercase block flex items-center gap-1">
                          <Camera size={11} className="text-emerald-600" />
                          Foto Lapangan/Bukti Kirim <span className="text-rose-500 font-bold">*Wajib</span>
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="file"
                            accept="image/*"
                            id="bulk-photo-upload"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  setBulkProofs(prev => ({ ...prev, photo_during: reader.result as string }));
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                            className="hidden"
                          />
                          <label
                            htmlFor="bulk-photo-upload"
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-lg text-[10px] font-extrabold cursor-pointer transition uppercase tracking-wider block"
                          >
                            {bulkProofs.photo_during ? '✓ Terpilih (Ganti)' : 'Pilih Foto Bukti'}
                          </label>
                          {bulkProofs.photo_during && (
                            <div className="relative w-7 h-7 rounded border border-emerald-250 overflow-hidden bg-slate-50 shrink-0">
                              <img src={bulkProofs.photo_during} className="w-full h-full object-cover" alt="Proof preview" />
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-mono font-bold text-indigo-700 uppercase block flex items-center gap-1">
                          <FileText size={11} className="text-indigo-600" />
                          Foto Tanda Terima Fisik (Optional)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="file"
                            accept="image/*"
                            id="bulk-receipt-upload"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  setBulkProofs(prev => ({ ...prev, receipt_base64: reader.result as string }));
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                            className="hidden"
                          />
                          <label
                            htmlFor="bulk-receipt-upload"
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-lg text-[10px] font-extrabold cursor-pointer transition uppercase tracking-wider block"
                          >
                            {bulkProofs.receipt_base64 ? '✓ Terpilih (Ganti)' : 'Pilih Foto Receipt'}
                          </label>
                          {bulkProofs.receipt_base64 && (
                            <div className="relative w-7 h-7 rounded border border-indigo-250 overflow-hidden bg-slate-50 shrink-0">
                              <img src={bulkProofs.receipt_base64} className="w-full h-full object-cover" alt="Receipt preview" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={handleApplyBulkDistribution}
                        className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-650 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-md hover:shadow-emerald-250 transition cursor-pointer"
                      >
                        <CheckCircle2 size={14} />
                        Simpan Penyaluran Kilat ({mappedDraftItems.filter(i => i.matched_id).length} Material Terpetakan)
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Form add DRPB item */}
        {showAddDRPB && (
          <form onSubmit={handleDRPBSubmit} className="p-3 bg-slate-50 border border-slate-200 rounded-xl max-w-xl space-y-3 shadow-inner">
            <h4 className="text-[11px] font-bold font-mono text-slate-705 uppercase">Input Aliran Material Baru</h4>
            
            {/* Quick Prefill Pills */}
            <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-white rounded-xl border border-slate-200">
              <span className="text-[9px] font-black font-mono text-indigo-700 block mr-1 uppercase">Prefill Form:</span>
              {[
                { label: 'Semen (30 sak)', m: 'Semen', u: 'sak', q: '30' },
                { label: 'Besi Beton (15 btg)', m: 'Besi', u: 'btg', q: '15' },
                { label: 'Pasir Cor (8 m3)', m: 'Pasir', u: 'm3', q: '8' },
                { label: 'Kayu Usuk (25 btg)', m: 'Kayu', u: 'btg', q: '25' },
                { label: 'Seng Atap (20 lbr)', m: 'Seng', u: 'lbr', q: '20' },
                { label: 'Batu Kali (5 m3)', m: 'Batu', u: 'm3', q: '5' }
              ].map(preset => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setDrpbForm({ material_type: preset.m, unit: preset.u, required_qty: preset.q })}
                  className="px-2 py-0.5 bg-slate-50 hover:bg-indigo-50 hover:text-indigo-705 hover:border-indigo-200 text-[9.5px] font-bold text-slate-650 rounded-lg border border-slate-200 transition cursor-pointer select-none active:scale-95"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <span className="text-[9px] font-mono font-bold text-slate-500 uppercase block">Material</span>
                <input
                  required
                  type="text"
                  placeholder="Pilih atau tulis bahan..."
                  list="material-presets-list"
                  value={drpbForm.material_type}
                  onChange={(e) => setDrpbForm(prev => ({ ...prev, material_type: e.target.value }))}
                  className="w-full p-1.5 text-xs bg-white border border-slate-250 rounded-lg text-slate-800"
                />
                <datalist id="material-presets-list">
                  {MATERIAL_PRESETS.map(m => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </datalist>
              </div>

              <div className="space-y-1">
                <span className="text-[9px] font-mono font-bold text-slate-500 uppercase block">Satuan</span>
                <input
                  required
                  type="text"
                  placeholder="sak, m3, btg..."
                  value={drpbForm.unit}
                  onChange={(e) => setDrpbForm(prev => ({ ...prev, unit: e.target.value }))}
                  className="w-full p-1.5 text-xs bg-white border border-slate-250 rounded-lg text-slate-800"
                />
              </div>

              <div className="space-y-1">
                <span className="text-[9px] font-mono font-bold text-slate-500 uppercase block">Kebutuhan</span>
                <input
                  required
                  type="number"
                  placeholder="30"
                  value={drpbForm.required_qty}
                  onChange={(e) => setDrpbForm(prev => ({ ...prev, required_qty: e.target.value }))}
                  className="w-full p-1.5 text-xs bg-white border border-slate-250 rounded-lg text-slate-800 font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-1.5">
              <button
                type="button"
                onClick={() => setShowAddDRPB(false)}
                className="px-2.5 py-1 text-xs border border-slate-200 hover:bg-slate-100 rounded-lg text-slate-600"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-3 py-1 text-xs bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg"
              >
                Tambah Rencana
              </button>
            </div>
          </form>
        )}

        {/* DRPB table list comparison */}
        <div className="overflow-x-auto border border-slate-150 rounded-xl">
          <table className="w-full border-collapse text-left text-xs bg-white">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-150 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-4 font-bold">Jenis Material</th>
                <th className="py-2.5 px-3 font-bold">Kebutuhan</th>
                <th className="py-2.5 px-3 font-bold">Realisasi (Terkirim)</th>
                <th className="py-2.5 px-3 font-bold">Kekurangan</th>
                <th className="py-2.5 px-3 font-bold text-center">Progress</th>
                <th className="py-2.5 px-4 font-bold w-12 text-center">Hapus</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150">
              {drpb.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-400 italic text-[11px]">
                    Belum ada material yang terdaftar di DRPB PB ini. Silakan klik "Alokasi Bahan" di atas.
                  </td>
                </tr>
              ) : (
                drpb.map(item => {
                  const delivered = distributions
                    .filter(d => d.drpb_item_id === item.id)
                    .reduce((sum, curr) => sum + Number(curr.volume), 0);
                  const shortage = Math.max(0, item.required_qty - delivered);
                  const progressPct = Math.min(100, Math.round((delivered / item.required_qty) * 100)) || 0;

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4 font-bold text-slate-900 text-sm">{item.material_type}</td>
                      <td className="py-3 px-3 font-mono">{item.required_qty} {item.unit}</td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-800">
                        {delivered} {item.unit}
                      </td>
                      <td className="py-3 px-3">
                        {shortage > 0 ? (
                          <span className="font-mono text-rose-500 font-bold bg-rose-50 px-2 py-0.5 rounded border border-rose-100">
                            Kurang {shortage} {item.unit}
                          </span>
                        ) : (
                          <span className="text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 flex items-center gap-0.5 max-w-fit">
                            <Check size={12} />
                            Terpenuhi
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 align-middle text-center">
                        <div className="flex items-center justify-center gap-2 max-w-[120px] mx-auto">
                          <div className="w-full bg-slate-100 rounded-full h-1.5">
                            <div 
                              className={`h-1.5 rounded-full ${progressPct === 100 ? 'bg-emerald-500' : 'bg-amber-500'}`} 
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                          <span className="font-mono font-bold text-[10px] text-slate-600 shrink-0">{progressPct}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          id={`delete-drpb-${item.id}`}
                          onClick={() => setDrpbItemToDelete(item)}
                          className="p-1 border border-slate-150 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 text-slate-500 rounded cursor-pointer transition"
                        >
                          <Trash2 size={12} />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* INPUT PENYALURAN MATERIAL & HISTORY */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4" id="distribution-tracker-panel">
        
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-extrabold text-slate-905 tracking-tight flex items-center gap-1">
              <Calendar size={16} />
              Riwayat Penyaluran Material Lapangan
            </h3>
            <p className="text-[11px] text-slate-500">Log bukti fisik pengiriman bahan bangunan dari toko yang terverifikasi TFL.</p>
          </div>

          <button
            onClick={() => {
              if (drpb.length === 0) {
                showToast("tambah DRPB dulu", "error");
                return;
              }
              setShowAddDist(!showAddDist);
              // Set initial item
              setDistForm(prev => ({ ...prev, drpb_item_id: drpb[0]?.id || '' }));
            }}
            className="px-3 py-1.5 bg-slate-950 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <PlusCircle size={13} />
            Tambah Penyaluran
          </button>
        </div>

        {/* INPUT PENYALURAN FORM & VALIDATION MODULE */}
        {showAddDist && (
          <form onSubmit={handleDistributionSubmit} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-4 shadow-sm animate-fadeIn">
            <h4 className="text-xs font-bold font-mono text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-1.5">
              Formulir Penyaluran Baru (Wajib Lampiran Dokumen Lapangan)
            </h4>

            {/* Part 1: Date, Material, Volume Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">Tanggal Kirim</span>
                <input
                  required
                  type="date"
                  value={distForm.distribution_date}
                  onChange={(e) => setDistForm(prev => ({ ...prev, distribution_date: e.target.value }))}
                  className="w-full text-xs p-2 bg-white border border-slate-250 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">Item Bahan (Filter DRPB)</span>
                <select
                  required
                  value={distForm.drpb_item_id}
                  onChange={(e) => setDistForm(prev => ({ ...prev, drpb_item_id: e.target.value }))}
                  className="w-full text-xs p-2 bg-white border border-slate-250 rounded-xl"
                >
                  <option value="">Pilih Material</option>
                  {drpb.map(d => (
                    <option key={d.id} value={d.id}>{d.material_type} (Kebutuhan: {d.required_qty} {d.unit})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">Volume Realisasi</span>
                <input
                  required
                  type="number"
                  placeholder="Jumlah dikirim..."
                  value={distForm.volume}
                  onChange={(e) => setDistForm(prev => ({ ...prev, volume: e.target.value }))}
                  className="w-full text-xs p-2 bg-white border border-slate-250 rounded-xl font-mono"
                />
              </div>
            </div>

            {/* Part 2: Shortage notes if total delivered is less than required */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-white border border-slate-200 rounded-xl">
              <div className="space-y-1">
                <span className="text-[10px] font-bold font-mono text-slate-500 uppercase block">Mengalami Kekurangan Stok? (Otomatis)</span>
                <select
                  value={distForm.shortage_reason}
                  onChange={(e) => setDistForm(prev => ({ ...prev, shortage_reason: e.target.value as ShortageReason }))}
                  className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-250 rounded-lg"
                >
                  <option value="">Tidak ada kekurangan (Penuh)</option>
                  <option value="not_available">Material belum tersedia</option>
                  <option value="waiting_delivery">Menunggu pengiriman supplier</option>
                  <option value="store_empty">Bahan toko kosong</option>
                  <option value="weather">Cuaca ekstrem</option>
                  <option value="other">Lainnya (Tulis alasan di samping)</option>
                </select>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-bold font-mono text-slate-500 uppercase block font-sans">Keterangan Tambahan Masalah</span>
                <input
                  type="text"
                  placeholder="Contoh: Stok semen di dump truck tidak muat semuanya"
                  value={distForm.shortage_notes}
                  onChange={(e) => setDistForm(prev => ({ ...prev, shortage_notes: e.target.value }))}
                  className="w-full text-xs p-1.5 bg-slate-50 border border-slate-250 rounded-lg"
                />
              </div>
            </div>

            {/* Part 3: attachments Before, During, After, Video and receipt */}
            <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-3">
              <span className="text-[10px] font-bold font-mono text-slate-500 uppercase block">Lampiran Bukti Fisik (Minimal Lampirkan 1 Foto)</span>
              
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                {/* Photo Before */}
                <div className="space-y-1 border border-slate-100 p-2 rounded-lg bg-slate-50/50 relative">
                  <span className="text-[9px] font-bold block uppercase font-mono text-slate-600">1. Foto Sebelum</span>
                  <label className="flex flex-col items-center justify-center h-16 border border-dashed border-slate-300 rounded-md cursor-pointer hover:bg-slate-100">
                    <Camera size={14} className="text-slate-400" />
                    <span className="text-[8px] text-slate-500 mt-1">Pilih File</span>
                    <input type="file" accept="image/*" onChange={(e) => triggerImageBase64(e, 'photo_before')} className="hidden" />
                  </label>
                  {distForm.photo_before && <span className="text-[8px] text-emerald-600 block mt-1 font-bold">✓ Terisi</span>}
                </div>

                {/* Photo During */}
                <div className="space-y-1 border border-slate-100 p-2 rounded-lg bg-slate-50/50">
                  <span className="text-[9px] font-bold block uppercase font-mono text-slate-600">2. Foto Proses</span>
                  <label className="flex flex-col items-center justify-center h-16 border border-dashed border-slate-300 rounded-md cursor-pointer hover:bg-slate-100">
                    <Camera size={14} className="text-slate-400" />
                    <span className="text-[8px] text-slate-500 mt-1">Pilih File</span>
                    <input type="file" accept="image/*" onChange={(e) => triggerImageBase64(e, 'photo_during')} className="hidden" />
                  </label>
                  {distForm.photo_during && <span className="text-[8px] text-emerald-600 block mt-1 font-bold">✓ Terisi</span>}
                </div>

                {/* Photo After */}
                <div className="space-y-1 border border-slate-100 p-2 rounded-lg bg-slate-50/50">
                  <span className="text-[9px] font-bold block uppercase font-mono text-slate-600">3. Foto Selesai</span>
                  <label className="flex flex-col items-center justify-center h-16 border border-dashed border-slate-300 rounded-md cursor-pointer hover:bg-slate-100">
                    <Camera size={14} className="text-slate-400" />
                    <span className="text-[8px] text-slate-500 mt-1">Pilih File</span>
                    <input type="file" accept="image/*" onChange={(e) => triggerImageBase64(e, 'photo_after')} className="hidden" />
                  </label>
                  {distForm.photo_after && <span className="text-[8px] text-emerald-600 block mt-1 font-bold">✓ Terisi</span>}
                </div>

                {/* Video >= 15s */}
                <div className="space-y-1 border border-slate-100 p-2 rounded-lg bg-slate-50/50">
                  <span className="text-[9px] font-bold block uppercase font-mono text-[#d97706]">4. Video (&ge;15s)</span>
                  <label className="flex flex-col items-center justify-center h-16 border border-dashed border-slate-300 rounded-md cursor-pointer hover:bg-slate-100">
                    <Video size={14} className="text-[#d97706]" />
                    <span className="text-[8px] text-slate-500 mt-1">Pilih File</span>
                    <input type="file" accept="video/*,image/*" onChange={(e) => triggerImageBase64(e, 'video_base64')} className="hidden" />
                  </label>
                  {distForm.video_base64 && (
                    <div className="flex flex-col gap-0.5 mt-1">
                      <span className="text-[8px] text-emerald-600 font-bold">✓ Terisi</span>
                      <input 
                        type="number" 
                        value={distForm.video_duration} 
                        onChange={(e) => setDistForm(p => ({ ...p, video_duration: e.target.value }))}
                        placeholder="Secs" 
                        className="p-1 border border-slate-200 text-[8px] w-12 font-mono h-4 rounded text-slate-800 bg-white"
                      />
                    </div>
                  )}
                </div>

                {/* Receipt/Nota */}
                <div className="space-y-1 border border-slate-100 p-2 rounded-lg bg-slate-50/50">
                  <span className="text-[9px] font-bold block uppercase font-mono text-slate-600">5. Kuintansi/Nota</span>
                  <label className="flex flex-col items-center justify-center h-16 border border-dashed border-slate-300 rounded-md cursor-pointer hover:bg-slate-100">
                    <FileText size={14} className="text-slate-400" />
                    <span className="text-[8px] text-slate-500 mt-1">Pilih File</span>
                    <input type="file" accept="image/*,application/pdf" onChange={(e) => triggerImageBase64(e, 'receipt_base64')} className="hidden" />
                  </label>
                  {distForm.receipt_base64 && <span className="text-[8px] text-emerald-600 block mt-1 font-bold">✓ Terisi</span>}
                </div>
              </div>

            </div>

            {/* Note fields */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold font-mono text-slate-500 uppercase block">Keterangan Catatan Tambahan (Bebas)</span>
              <input
                type="text"
                placeholder="Detail supir, nomor plat mobil pengereman logistik..."
                value={distForm.notes}
                onChange={(e) => setDistForm(prev => ({ ...prev, notes: e.target.value }))}
                className="w-full text-xs p-2 bg-white border border-slate-250 rounded-xl"
              />
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end gap-1.5">
              <button
                type="button"
                onClick={() => setShowAddDist(false)}
                className="px-3 py-1.5 text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl cursor-pointer"
              >
                Batalkan
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl cursor-pointer"
              >
                Kirim & Sinkronkan
              </button>
            </div>
          </form>
        )}

        {/* History Delivery Cards List */}
        <div className="space-y-4">
          {distributions.length === 0 ? (
            <div className="p-8 border border-dashed border-slate-200 rounded-xl text-center text-slate-450 text-xs">
              Belum ada riwayat pengiriman tercatat di lapangan. Klik "Tambah Penyaluran" untuk merekam.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {distributions.map(dist => {
                const item = drpb.find(db => db.id === dist.drpb_item_id);
                const distFiles = media.filter(m => m.distribution_id === dist.id);
                
                return (
                  <div key={dist.id} className="border border-slate-200 rounded-2xl p-4 bg-white space-y-3 shadow-xs">
                    
                    {/* Header line */}
                    <div className="flex justify-between items-start gap-2 border-b border-slate-100 pb-2">
                      <div>
                        <span className="text-[10px] font-bold font-mono text-slate-400 block uppercase">PENGIRIMAN LOGISTIK</span>
                        <h4 className="text-sm font-extrabold text-slate-900">{item?.material_type || "Bahan Bangunan"}</h4>
                      </div>
                      <span className="text-[10px] font-bold font-mono text-slate-650 bg-slate-100 px-2 py-0.5 rounded">
                        {formatFullDateTime(dist.distribution_date)}
                      </span>
                    </div>

                    {/* Stats rows */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-[9px] font-mono text-slate-400 block">VOLUME</span>
                        <span className="font-bold text-slate-800">{dist.volume} {item?.unit}</span>
                      </div>
                      <div>
                        <span className="text-[9px] font-mono text-slate-400 block">Jarak GPS</span>
                        <span className={`font-semibold ${dist.gps_distance_from_home && dist.gps_distance_from_home > 500 ? 'text-red-500 font-bold' : 'text-slate-700'}`}>
                          {dist.gps_distance_from_home || 0} meter
                        </span>
                      </div>
                    </div>

                    {/* Shortage reasons if any */}
                    {dist.shortage_reason && (
                      <div className="p-2 bg-rose-50 border border-rose-100 rounded-lg text-[10px] text-rose-800">
                        <strong>⚠️ PENUNDAAN STOK:</strong> {dist.shortage_reason === 'store_empty' ? 'Stok Toko Kosong' : dist.shortage_reason === 'weather' ? 'Kendala Cuaca' : 'Menunggu delivery'}. {dist.shortage_notes}
                      </div>
                    )}

                    {/* Media Attachments thumbnails */}
                    <div className="space-y-1.5">
                      <span className="text-[9px] font-bold font-mono text-slate-400 uppercase block">Lampiran File Verifikasi TFL</span>
                      <div className="flex flex-wrap gap-1.5">
                        {distFiles.map(f => (
                          <div 
                            key={f.id} 
                            onClick={() => window.open(f.file_url, '_blank')}
                            className="w-10 h-10 rounded-md border border-slate-200 overflow-hidden cursor-pointer hover:opacity-85 bg-slate-100 flex flex-col items-center justify-center relative"
                          >
                            {f.media_type === 'video' ? (
                              <>
                                <Video size={12} className="text-amber-600" />
                                <span className="absolute bottom-0.2 right-0.5 text-[6px] text-amber-700 bg-amber-50 font-mono font-bold leading-none px-0.5 rounded">{f.duration_seconds || 15}s</span>
                              </>
                            ) : f.file_url.startsWith('https://images.unsplash.com') || f.file_url.includes('house') || f.file_url.includes('before') || f.file_url.includes('during') || f.file_url.includes('after') || f.file_url.includes('receipt') ? (
                              <img src={f.file_url} className="w-full h-full object-cover" alt="attachment" />
                            ) : (
                              <FileText size={12} className="text-slate-500" />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Operator signature */}
                    <div className="text-[10px] text-slate-505 font-mono pt-2 border-t border-slate-100 flex justify-between items-center bg-slate-50/50 p-1 rounded">
                      <span className="italic truncate max-w-xs">{dist.notes || "Supir: logs terkirim"}</span>
                      <span className="font-bold">By: {dist.operator_id}</span>
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>

      {/* ACTIVE FINDINGS MODULE */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4" id="findings-registry-panel">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-extrabold text-slate-905 tracking-tight flex items-center gap-1">
              <AlertTriangle size={16} />
              Daftar Temuan Penyaluran Lapangan
            </h3>
            <p className="text-[11px] text-slate-500">Pelaporan ketidaksesuaian volume, kualitas barang, atau kelalaian administratif.</p>
          </div>

          <button
            onClick={() => setShowAddFinding(!showAddFinding)}
            className="px-3 py-1.5 bg-slate-950 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <Plus size={13} />
            Laporkan Kendala
          </button>
        </div>

        {/* Add finding Form */}
        {showAddFinding && (
          <form onSubmit={handleFindingSubmit} className="p-3 bg-red-50 border border-red-150 rounded-xl space-y-3 shadow-inner">
            <h4 className="text-[11px] font-bold font-mono text-red-900 uppercase">Input Masalah Lapangan Baru</h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <span className="text-[9px] font-bold text-red-800 font-mono uppercase block">Kategori</span>
                <select
                  value={findingForm.category}
                  onChange={(e) => setFindingForm(prev => ({ ...prev, category: e.target.value as any }))}
                  className="w-full p-2 bg-white border border-red-200 rounded-lg text-xs"
                >
                  <option value="material_shortage">Kendala Pengiriman Kurang</option>
                  <option value="material_quality">Kualitas Material Menurun / Rusak</option>
                  <option value="material_discrepancy">Selisih material toko vs lapangan</option>
                  <option value="gps_mismatch">GPS Mismatch diluar radius</option>
                  <option value="no_receipt">Nota / Dokumentasi fisik nihil</option>
                </select>
              </div>

              <div className="space-y-1">
                <span className="text-[9px] font-bold text-red-800 font-mono uppercase block">Detail Deskripsi Temuan</span>
                <input
                  required
                  type="text"
                  placeholder="Deskripsikan kronologi dan bukti visual..."
                  value={findingForm.description}
                  onChange={(e) => setFindingForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full p-2 bg-white border border-red-200 rounded-lg text-xs text-slate-800"
                />
              </div>
            </div>

            <div className="flex justify-end gap-1.5 pt-1">
              <button
                type="button"
                onClick={() => setShowAddFinding(false)}
                className="px-2.5 py-1 text-xs border border-red-250 text-slate-650 hover:bg-white rounded-lg"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-3.5 py-1 bg-red-700 hover:bg-red-850 text-white font-bold rounded-lg text-xs"
              >
                Daftarkan Laporan
              </button>
            </div>
          </form>
        )}

        {/* Findings lists */}
        <div className="divide-y divide-slate-100">
          {findings.length === 0 ? (
            <div className="p-6 text-center text-slate-400 italic text-[11px] border border-dashed border-slate-150 rounded-xl bg-slate-50/20">
              Sempurna! Tidak ada laporan temuan aktif di lokasi ini.
            </div>
          ) : (
            findings.map(f => (
              <div key={f.id} className="py-3 flex justify-between items-center gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded uppercase ${f.resolved ? 'bg-emerald-100 text-emerald-800 border-emerald-200' : 'bg-red-100 text-red-800 border-red-200 animate-pulse'}`}>
                      {f.resolved ? '✓ SELESAI' : '🚨 AKTIF'}
                    </span>
                    <span className="text-xs font-bold text-slate-900 font-mono">[{f.category}]</span>
                  </div>
                  <p className="text-xs text-slate-600 font-sans leading-relaxed">{f.description}</p>
                  <p className="text-[9px] text-slate-450 font-mono">Reporter: {f.reported_by} &bull; Tanggal: {formatDateOnly(f.created_at)}</p>
                </div>

                {!f.resolved && (
                  <button
                    onClick={async () => {
                      if (confirm("Tandai temuan ini telah diselesaikan dan material diposisikan layak?")) {
                        await onResolveFinding(f.id);
                        fetchPBDetails();
                      }
                    }}
                    className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition active:scale-95 shrink-0"
                  >
                    Tandai Selesai
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* CHRONOLOGICAL TIMELINE */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4" id="chronological-pb-timeline">
        <h3 className="text-sm font-extrabold text-slate-905 tracking-tight flex items-center gap-1 border-b border-slate-100 pb-3">
          <Clock size={16} />
          Aliran Histori Timeline PB (Paling Baru ke Terlama)
        </h3>

        <div className="relative border-l border-slate-200 pl-4 py-1 space-y-6">
          {sortedTimeline.map((ev, index) => {
            let tagColor = "bg-slate-200 text-slate-800";
            if (ev.tag === "created") tagColor = "bg-indigo-100 text-indigo-800";
            if (ev.tag === "dist") tagColor = "bg-sky-100 text-sky-800";
            if (ev.tag === "finding") tagColor = "bg-red-150 text-red-900";
            if (ev.tag === "resolved") tagColor = "bg-emerald-150 text-emerald-900";

            return (
              <div key={index} className="relative">
                {/* Timeline dot */}
                <span className="absolute -left-[20.5px] top-1.5 w-3 h-3 rounded-full bg-slate-900 ring-4 ring-white" />
                
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[8px] font-bold font-mono px-1.5 py-0.2 rounded uppercase ${tagColor}`}>
                      {ev.tag}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900">{ev.title}</h4>
                    <span className="text-[9px] font-mono text-slate-500 ml-auto">{formatDateOnly(ev.date)}</span>
                  </div>
                  <p className="text-xs text-slate-500 font-sans tracking-tight leading-relaxed">{ev.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      {/* MODAL BATALKAN/HAPUS SELURUH DRPB */}
      {showClearDRPBConfirm && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="clear-drpb-modal">
          <div className="bg-white rounded-3xl border border-rose-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn">
            <div className="flex items-center gap-3 border-b border-rose-50 pb-3 text-rose-600">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                ⚠️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Seluruh DRPB</h3>
                <p className="text-[10px] text-slate-505 font-mono">Tindakan ini menghapus {drpb.length} item material</p>
              </div>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>Apakah Anda yakin ingin menghapus <strong>seluruh data DRPB</strong> untuk PB ini?</p>
              <div className="bg-amber-50 border border-amber-200 text-amber-900 p-3 rounded-2xl text-[10.5px] space-y-1">
                <span className="font-bold font-mono tracking-wider text-[9px] text-amber-800">PERINGATAN:</span>
                <p>Aksi ini akan menghapus semua target material beserta riwayat penyaluran terkait. Lanjutkan?</p>
              </div>
            </div>

            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={() => setShowClearDRPBConfirm(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                onClick={async () => {
                  try {
                    await onClearAllDRPB(recipientId);
                    fetchPBDetails();
                    setShowClearDRPBConfirm(false);
                  } catch (err) {
                    showToast("Gagal menghapus", "error");
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-sm"
              >
                Ya, Hapus Semua
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL HAPUS 1 ITEM DRPB */}
      {drpbItemToDelete && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="delete-drpb-item-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-rose-600">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                🗑️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Item DRPB</h3>
                <p className="text-[10px] text-slate-505 font-mono">Menyeleksi {drpbItemToDelete.material_type}</p>
              </div>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>Hapus item rencana <strong>{drpbItemToDelete.material_type}</strong> dari DRPB?</p>
              <p className="text-[10px] text-slate-500 italic">Riwayat penyaluran yang bertaut dengan item ini juga akan ikut terhapus.</p>
            </div>

            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={() => setDrpbItemToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                id="confirm-delete-drpb-item-btn"
                onClick={async () => {
                  try {
                    await onDeleteDRPBItem(drpbItemToDelete.id);
                    fetchPBDetails();
                    setDrpbItemToDelete(null);
                  } catch (err) {
                    showToast("Gagal menghapus item", "error");
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-sm"
              >
                Hapus Item
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
