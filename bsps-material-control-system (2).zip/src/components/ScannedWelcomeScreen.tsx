import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ClipboardCheck, CheckSquare, Camera, 
  Landmark, MapPin, Home, User, ShieldCheck, ArrowRight, HelpCircle
} from 'lucide-react';
import { Recipient, DRPBItem, RecipientPhoto } from '../types';

interface ScannedWelcomeScreenProps {
  recipient: Recipient;
  photos: RecipientPhoto[];
  pbVillageName: string;
  pbGroupName: string;
  computedProgress: number;
  drpb: DRPBItem[];
  countdown: number;
  onEnterPortal: () => void;
  onSkip: () => void;
  currentStageText: string;
}

export const ScannedWelcomeScreen: React.FC<ScannedWelcomeScreenProps> = ({
  recipient,
  photos,
  pbVillageName,
  pbGroupName,
  computedProgress,
  drpb,
  countdown,
  onEnterPortal,
  onSkip,
  currentStageText,
}) => {
  const [showRecipientProfile, setShowRecipientProfile] = useState<boolean>(false);

  return (
    <div className="flex-1 bg-slate-50 min-h-screen flex flex-col justify-between select-none text-slate-800 font-sans">
      
      {/* GOVERNMENT STYLE MAIN HEADER */}
      <header className="w-full bg-white border-b border-slate-200 py-4 shadow-3xs px-6 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <img 
              src="/logo.png" 
              className="h-11 w-auto object-contain drop-shadow-3xs" 
              alt="Logo PKP" 
              referrerPolicy="no-referrer" 
            />
            <div className="text-left leading-tight">
              <span className="text-[11px] font-black tracking-widest text-amber-600 block uppercase font-mono">
                KEMENTERIAN RUSP / PKP RI
              </span>
              <h1 className="text-sm font-black text-slate-900 uppercase tracking-tight">
                BSPS &mdash; Bantuan Stimulan Perumahan Swadaya
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full text-[10px] font-mono tracking-wider text-amber-900 font-extrabold">
            <ShieldCheck size={12} className="text-amber-600 animate-pulse" />
            SECURE FIELD VERIFICATION PORTAL
          </div>

        </div>
      </header>

      {/* CORE WELCOME BODY AREA */}
      <main className="max-w-3xl mx-auto w-full px-6 py-10 flex-1 flex flex-col justify-center items-center space-y-6">
        
        {/* Welcome titles sapaan */}
        <div className="text-center space-y-2.5 max-w-xl">
          <span className="inline-block text-[10px] font-bold tracking-widest bg-amber-100 border border-amber-200 text-amber-900 px-3.5 py-1 rounded-full uppercase leading-none">
            PROG. BSPS MINAHASA 2026
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase tracking-tight leading-none font-display">
            Selamat Datang di Portal Verifikasi Lapangan BSPS
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Gunakan sistem pengawasan terenkripsi kementerian untuk memeriksa status aliran bantuan material bangunan dan melakukan input laporan penyaluran fisik.
          </p>
        </div>

        {/* INTERACTIVE COMPREHENSIVE CARD GRID CONTAINER */}
        <div className="w-full bg-white rounded-2xl border border-slate-205 shadow-xs p-6 space-y-6">
          
          <div className="flex items-start gap-3 border-b border-slate-100 pb-4">
            <div className="p-3 bg-amber-50 text-amber-700 rounded-xl">
              <Landmark size={20} />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-850 uppercase tracking-tight leading-none">
                Sistem Validasi Material & Pelaporan Mandiri
              </h3>
              <p className="text-[11px] text-zinc-400 mt-1">
                Silakan lakukan pelaporan pengiriman material logistik serta validasi profil penerima bantuan di bawah ini.
              </p>
            </div>
          </div>

          {/* Single featured prominent action button */}
          <div className="pb-2">
            <button
              onClick={onEnterPortal}
              className="w-full py-4 px-6 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-sm uppercase tracking-wider transition active:scale-97 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/20 border border-amber-400"
            >
              <span>Lanjut ke Input Data Penyaluran</span>
              <ArrowRight size={16} className="text-slate-950 shrink-0" />
            </button>
          </div>

          {/* DYNAMIC COLLAPSIBLE ACCORDION FOR RECIPIENT PROFILE */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden bg-slate-50/50">
            <button
              type="button"
              onClick={() => setShowRecipientProfile(!showRecipientProfile)}
              className="w-full p-4 flex items-center justify-between text-left font-extrabold text-xs uppercase tracking-wider text-slate-600 hover:bg-slate-100/80 transition cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <User size={14} className="text-amber-600" />
                Informasi Detail Profil PB ({recipient.full_name})
              </span>
              <span className="font-mono text-[10px] bg-slate-200/80 text-slate-700 px-2.5 py-0.5 rounded-full">
                {showRecipientProfile ? "Tutup ✕" : "Buka Detail 👁️"}
              </span>
            </button>

            <AnimatePresence>
              {showRecipientProfile && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="bg-white border-t border-slate-200 p-5 text-left grid grid-cols-1 md:grid-cols-5 gap-5"
                >
                  {/* Visual Image */}
                  <div className="col-span-1 md:col-span-2 h-36 rounded-xl overflow-hidden bg-slate-100 relative border border-slate-200 shadow-3xs">
                    {photos.length > 0 ? (
                      <img 
                        src={photos[photos.length - 1].file_url} 
                        className="w-full h-full object-cover" 
                        alt="Rumah PB" 
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center text-slate-400 text-[10px]">
                        <Home size={26} className="mb-1 text-slate-400" />
                        <span>Dokumentasi belum diupload</span>
                      </div>
                    )}
                    <div className="absolute bottom-1.5 left-1.5 bg-amber-600 px-2 py-0.5 rounded text-[8px] font-mono uppercase text-white font-bold">
                      FOTO KONDISI RILL
                    </div>
                  </div>

                  {/* Info Text */}
                  <div className="col-span-1 md:col-span-3 flex flex-col justify-between space-y-3">
                    <div className="space-y-1">
                      <span className="text-[9.5px] font-mono font-black text-amber-600 block uppercase tracking-wider">
                        PROFIL PENERIMA MANFAAT VERIFIED:
                      </span>
                      <h4 className="text-[17px] font-black text-slate-900 uppercase tracking-wide leading-tight">
                        {recipient.full_name}
                      </h4>
                      <p className="text-[9.5px] text-slate-400 font-mono">
                        REG: #{recipient.id.slice(0, 12).toUpperCase()}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-[10.5px] text-slate-600 pt-1.5 border-t border-slate-200">
                      <div>
                        <span className="text-[8.5px] text-slate-400 block uppercase font-mono">Wilayah Desa</span>
                        <span className="font-black uppercase text-slate-800">{pbVillageName}</span>
                      </div>
                      <div>
                        <span className="text-[8.5px] text-slate-400 block uppercase font-mono">Kelompok Pokman</span>
                        <span className="font-black uppercase text-slate-800">{pbGroupName}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Quick Informative KPIs Section */}
          <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-slate-100 text-left">
            
            <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl">
              <span className="text-[8.5px] font-bold text-slate-450 block uppercase font-mono">PROGRES FISIK</span>
              <span className="text-base font-black text-emerald-600 block mt-1 font-mono">
                {computedProgress}%
              </span>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl">
              <span className="text-[8.5px] font-bold text-slate-450 block uppercase font-mono">ALOKASI BARANG</span>
              <span className="text-xs font-bold text-slate-800 block mt-1.5 truncate">
                {drpb.length} Jenis Bahan
              </span>
            </div>

          </div>

          {/* Auto Direct option widget */}
          <div className="pt-2 text-center">
            <button
              onClick={onSkip}
              className="text-xs text-slate-450 hover:text-slate-600 font-bold transition flex items-center justify-center gap-1 w-full cursor-pointer"
            >
              Atau lewati otomatis ke portal dalam {countdown} detik &rarr;
            </button>
          </div>

        </div>

      </main>

      {/* REGIONAL HOUSING DEPT COPYRIGHT FOOTER */}
      <footer className="w-full bg-white border-t border-slate-205 py-4.5 px-6 select-none shrink-0 text-center">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-400">
          <p className="font-medium">
            &copy; {new Date().getFullYear()} Kementerian PKP RI &bull; Dinas Perumahan Rakyat Kawasan Permukiman.
          </p>
          <div className="flex gap-4 font-mono font-bold uppercase text-[9.5px]">
            <span>VERIFIED DIGITAL PORTAL</span>
            <span className="text-amber-600">&bull; BSPS-M22</span>
          </div>
        </div>
      </footer>

    </div>
  );
};
