/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Cloud, Download, Upload, Database, RefreshCw, 
  CheckCircle2, AlertTriangle, Info, Clock, RefreshCw as SpinIcon,
  Shield, FileJson, Trash2, HelpCircle
} from 'lucide-react';

interface BackupManagerProps {
  onRefresh: () => void;
  showToast: (message: string, type: 'success' | 'error') => void;
  operatorId?: string;
}

export default function BackupManager({
  onRefresh,
  showToast,
  operatorId = "TIM22"
}: BackupManagerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [backupStats, setBackupStats] = useState<{
    exists: boolean;
    backedAt: string | null;
    recipientsCount: number;
    villagesCount: number;
    storesCount: number;
    sizeKb: number;
  }>({
    exists: false,
    backedAt: null,
    recipientsCount: 0,
    villagesCount: 0,
    storesCount: 0,
    sizeKb: 0
  });

  const [syncing, setSyncing] = useState(false);

  // Load status of live database server (No local browser storage saves are allowed)
  const refreshBackupStatus = async () => {
    try {
      const response = await fetch('/api/system/dump');
      if (response.ok) {
        const parsed = await response.json();
        // Calculate dynamic live payload size
        const rawString = JSON.stringify(parsed);
        const bytes = new Blob([rawString]).size;
        setBackupStats({
          exists: true,
          backedAt: new Date().toISOString(),
          recipientsCount: Array.isArray(parsed.recipients) ? parsed.recipients.length : 0,
          villagesCount: Array.isArray(parsed.villages) ? parsed.villages.length : 0,
          storesCount: Array.isArray(parsed.stores) ? parsed.stores.length : 0,
          sizeKb: Math.round((bytes / 1024) * 100) / 100
        });
      }
    } catch (e) {
      console.error("Gagal memuat status database langsung", e);
    }
  };

  useEffect(() => {
    refreshBackupStatus();
  }, []);

  const handleExportBackup = async () => {
    setSyncing(true);
    try {
      const response = await fetch('/api/system/dump');
      if (!response.ok) {
        showToast("Hubungan ke basis data server terganggu.", "error");
        return;
      }
      const parsed = await response.json();
      const rawString = JSON.stringify(parsed, null, 2);
      const blob = new Blob([rawString], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `ekspor-data-bsps-pkp-tim22-${new Date().toISOString().replace(/T/, '_').replace(/:/g, '-').slice(0, 19)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast("Berkas ekspor database .JSON berhasil diunduh murni dari server!", "success");
    } catch (err) {
      showToast("Gagal memproses ekspor data", "error");
    } finally {
      setSyncing(false);
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        
        // Validation check
        if (!parsed.recipients || !Array.isArray(parsed.recipients)) {
          showToast("File JSON tidak dikenali sebagai format cadangan PKP yang valid!", "error");
          return;
        }

        const confirmRestore = window.confirm(
          "PERINGATAN: Mengimpor file backup ini akan menimpa seluruh database server aktif Anda dengan data cadangan ini. Lanjutkan?"
        );
        if (!confirmRestore) return;

        setSyncing(true);
        showToast("Menghubungkan & mentransfer paket data...", "success");
        
        const restoreRes = await fetch('/api/system/restore', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            villages: parsed.villages || [],
            groups: parsed.groups || [],
            stores: parsed.stores || [],
            recipients: parsed.recipients || [],
            drpb_items: parsed.drpbItems || parsed.drpb_items || [],
            distributions: parsed.distributions || [],
            distribution_media: parsed.distributionMedia || parsed.distribution_media || [],
            recipient_photos: parsed.recipientPhotos || parsed.recipient_photos || [],
            findings: parsed.findings || [],
            audit_logs: parsed.auditLogs || parsed.audit_logs || [],
            operator_id: operatorId
          })
        });

        if (restoreRes.ok) {
          showToast("Sinkronisasi tuntas! Basis data dipulihkan ke server.", "success");
          refreshBackupStatus();
          onRefresh();
        } else {
          showToast("Gagal melakukan restorasi data ke server.", "error");
        }
      } catch (err) {
        console.error(err);
        showToast("Gagal mengurai file JSON cadangan. Pastikan berkas tidak rusak.", "error");
      } finally {
        setSyncing(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    };
    reader.readAsText(file);
  };

  const handleForceBackupNow = async () => {
    setSyncing(true);
    try {
      await onRefresh();
      await refreshBackupStatus();
      showToast("Data server berhasil dimuat ulang secara real-time!", "success");
    } catch {
      showToast("Gagal menyinkronkan data", "error");
    } finally {
      setSyncing(false);
    }
  };

  const handleClearCache = () => {
    // There is no persistent browser data anymore, so this operates as empty audit notifier
    showToast("Aman: 0 KB data disisakan di Chrome/situs Anda.", "success");
  };

  return (
    <div className="space-y-6">
      
      {/* Visual Header */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-md border border-indigo-500/20">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center border border-indigo-500/30 shrink-0">
            <Cloud className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] font-black tracking-widest uppercase px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">INTELLIGENT SECURE DATABASE CORE</span>
            <h1 className="text-xl font-extrabold tracking-tight font-display mt-1">
              Sistem Cloud-Sync & Ekspor Mandiri TFL
            </h1>
            <p className="text-[11px] text-slate-350 leading-relaxed mt-0.5 max-w-2xl font-semibold">
              Kementerian PKP TIM 22 Minahasa membekali koordinasi lapangan dengan teknologi ekspor backup aman.
              Penyimpanan lokal di browser (Chrome) dinonaktifkan sepenuhnya demi kerahasiaan data; ekspor data dilakukan murni secara dinamis dari memori aktif server.
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: Info Status vs Actions list */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Local Storage Backup Status Indicator */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs">
          <div>
            <div className="flex justify-between items-center border-b border-slate-100 pb-4 mb-4">
              <h3 className="text-xs font-black font-mono text-slate-800 uppercase tracking-wider flex items-center gap-2">
                <Database className="text-indigo-600" size={16} />
                Situs & Browser Aman
              </h3>
              <span className="text-[10px] uppercase font-black font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-250">
                LOKAL BERSIH (0 KB)
              </span>
            </div>

            {backupStats.exists ? (
              <div className="space-y-4 text-left">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400 font-semibold">Status Piringan:</span>
                    <span className="font-mono font-bold text-slate-800">
                      Aktif Berjalan (Server)
                    </span>
                  </div>
                  <div className="flex justify-between text-xs border-t border-slate-200/50 pt-2">
                    <span className="text-slate-400 font-semibold">Taksiran Ukuran:</span>
                    <span className="font-mono font-bold text-slate-800">{backupStats.sizeKb} KB</span>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <div className="text-[10px] font-black font-mono text-slate-400 uppercase tracking-widest">Matrik Database Server Terbaca</div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <div className="border border-slate-150 rounded-xl p-2.5 text-center">
                      <div className="text-lg font-black font-mono text-slate-800">{backupStats.recipientsCount}</div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase font-sans">PB</div>
                    </div>
                    <div className="border border-slate-150 rounded-xl p-2.5 text-center">
                      <div className="text-lg font-black font-mono text-slate-800">{backupStats.villagesCount}</div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase font-sans">Desa</div>
                    </div>
                    <div className="border border-slate-150 rounded-xl p-2.5 text-center">
                      <div className="text-lg font-black font-mono text-slate-800">{backupStats.storesCount}</div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase font-sans">Toko</div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-slate-400 text-xs">
                <AlertTriangle size={24} className="mx-auto text-amber-500 mb-2.5" />
                Browser tidak menggunakan penyimpanan offline.
              </div>
            )}
          </div>

          {backupStats.exists && (
            <div className="border-t border-slate-100 pt-4 mt-6">
              <button
                onClick={handleClearCache}
                className="w-full py-2 hover:bg-slate-50 text-slate-600 border border-slate-200 hover:border-slate-300 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Trash2 size={13} />
                Cek Penyimpanan Chrome
              </button>
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: Interventions / Sync Controls */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs text-left">
          <h3 className="text-xs font-black font-mono text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-4 mb-4">
            Aksi Penyelamatan &amp; Kontrol Sinkronisasi data
          </h3>

          <div className="space-y-4">
            
            {/* Quick Action Info Alert */}
            <div className="bg-emerald-50/50 border border-emerald-150 rounded-xl p-4 flex items-start gap-3">
              <Shield size={18} className="text-emerald-650 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-900 leading-relaxed font-semibold">
                <span className="font-black uppercase tracking-wider block text-[10px] text-emerald-750 mb-0.5">KEBIJAKAN PRIVASI &amp; PERFORMA</span>
                Untuk melindungi data pribadi dan integritas sistem, aplikasi ini bersih dari caching offline yang menumpuk di penjelajah Chrome Anda. Ekspor basis data dapat Anda lakukan kapan saja murni secara fisik dengan mengklik tombol unduh, yang akan menyatukan seluruh tabel server dalam satu berkas terenkapsulasi secara aman.
              </div>
            </div>

            {/* Form Actions Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              
              {/* Force Backup (Update Local Storage Cache) */}
              <button
                onClick={handleForceBackupNow}
                disabled={syncing}
                className="bg-amber-600 hover:bg-amber-700 text-white p-4 rounded-xl font-bold transition flex flex-col justify-between items-start text-left hover:shadow-md cursor-pointer group disabled:opacity-50"
              >
                <RefreshCw size={22} className={`text-white mb-6 group-hover:rotate-180 transition-transform duration-500 ${syncing ? 'animate-spin' : ''}`} />
                <div>
                  <h4 className="text-sm font-black tracking-tight font-display mb-0.5">Segarkan Data Server</h4>
                  <p className="text-[10px] text-amber-100 leading-normal font-semibold">Muat ulang dan paksa pengetokan ulang data server untuk memastikan sinkronisasi termutakhir.</p>
                </div>
              </button>

              {/* Unduh Berkas JSON Backup */}
              <button
                onClick={handleExportBackup}
                disabled={!backupStats.exists}
                className="bg-slate-900 hover:bg-slate-800 text-white p-4 rounded-xl font-bold transition flex flex-col justify-between items-start text-left hover:shadow-md cursor-pointer group disabled:opacity-40"
              >
                <Download size={22} className="text-white mb-6 group-hover:translate-y-1 transition-transform" />
                <div>
                  <h4 className="text-sm font-black tracking-tight font-display mb-0.5">Unduh Cadangan .JSON</h4>
                  <p className="text-[10px] text-slate-450 leading-normal font-semibold">Ekspor salinan komplit semua tabel Anda ke dalam format file fisik murni ditarik langsung dari server.</p>
                </div>
              </button>

            </div>

            {/* Import Area: Click / Drag */}
            <div className="border-2 border-dashed border-slate-200 hover:border-slate-350 focus-within:border-slate-850 rounded-xl p-5 text-center transition-all bg-slate-50/50">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImportBackup} 
                accept=".json" 
                className="hidden" 
              />
              <FileJson size={24} className="mx-auto text-slate-400 mb-2" />
              <h4 className="text-xs font-bold text-slate-800">Impor & Pulihkan Menggunakan Berkas JSON</h4>
              <p className="text-[10px] text-slate-450 mt-1 max-w-sm mx-auto font-semibold">
                Pilih file JSON cadangan PKP untuk memulihkan seluruh struktur dan data base lapangan ke server secara penuh.
              </p>
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={syncing}
                className="mt-3.5 inline-flex items-center gap-1.5 px-4 py-1.5 bg-white border border-slate-250 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-bold cursor-pointer transition shadow-2xs active:scale-95 disabled:opacity-50"
              >
                <Upload size={12} />
                Pilih Berkas JSON
              </button>
            </div>

          </div>
        </div>

      </div>

      {/* Cloud-sync Architecture FAQs */}
      <div className="bg-slate-50 rounded-2xl border border-slate-200 p-5 text-left">
        <h4 className="text-xs font-black font-mono text-slate-800 uppercase tracking-wider flex items-center gap-1.5 mb-3">
          <HelpCircle size={15} className="text-slate-500" />
          Pertanyaan umum cara kerja Cloud-Sync PKP TIM 22 Minahasa:
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 leading-relaxed font-semibold">
          <div className="space-y-1.5">
            <h5 className="font-bold text-slate-800">1. Di mana data disimpan sekarang?</h5>
            <p className="text-slate-500 leading-normal">
              Seluruh data aman tersimpan secara dinamis di server cloud aktif. Browser Chrome Anda tidak lagi menimbun file atau draft cadangan dalam penyimpanan lokal situs, menjamin nol pelacakan lokal.
            </p>
          </div>
          <div className="space-y-1.5">
            <h5 className="font-bold text-slate-800">2. Bagaimana mengamankan arsip secara fisik?</h5>
            <p className="text-slate-500 leading-normal">
              Anda bisa mendownload berkas .JSON resmi secara mandiri melalui tombol "Unduh Cadangan .JSON" di atas untuk disimpan dengan aman di komputer atau ponsel Anda secara privat.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
