/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Upload, X, Grid, Eye, Trash2, Camera, Compass } from 'lucide-react';

interface PhotoUploadProps {
  onUploadCompleted: (photos: { name: string; base64: string }[]) => void;
  onCancel: () => void;
}

const ARAH_OPTIONS = [
  "Depan", "Kanan Depan", "Kanan", "Kanan Belakang", "Belakang", "Kiri Belakang", "Kiri", "Kiri Depan", "Atas", "Bawah", "Umum"
];

export default function PhotoUpload({ onUploadCompleted, onCancel }: PhotoUploadProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploadedPhotos, setUploadedPhotos] = useState<{ id: string; name: string; base64: string; size: number; angle: string }[]>([]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFiles = async (files: FileList) => {
    const list = Array.from(files);
    const newPhotosState = [...uploadedPhotos];

    for (let i = 0; i < list.length; i++) {
      const file = list[i];
      
      // Limit to 24 photos max total
      if (newPhotosState.length >= 24) {
        alert("Batas maksimum unggah adalah 24 foto per sesi.");
        break;
      }

      // Check format
      const isFormatValid = ['image/jpeg', 'image/png', 'image/webp'].includes(file.type);
      if (!isFormatValid) {
        alert(`File ${file.name} tidak didukung. Harap unggah format JPEG, PNG, atau WEBP.`);
        continue;
      }

      // Check max size: 10MB
      if (file.size > 10 * 1024 * 1024) {
        alert(`File ${file.name} melebihi kapasitas maksimum 10MB.`);
        continue;
      }

      try {
        const base64 = await toBase64(file);
        
        // Select an angle suggestion based on index or default to 'Umum'
        const angleSuggestion = i < ARAH_OPTIONS.length - 1 ? ARAH_OPTIONS[i] : "Umum";

        newPhotosState.push({
          id: Math.random().toString(36).substring(7),
          name: file.name,
          base64,
          size: file.size,
          angle: angleSuggestion
        });
      } catch (err) {
        console.error("Gagal convert file ke base64:", err);
      }
    }

    setUploadedPhotos(newPhotosState);
  };

  const toBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFiles(e.target.files);
    }
  };

  const handleDelete = (id: string) => {
    setUploadedPhotos(uploadedPhotos.filter(p => p.id !== id));
  };

  const handleAngleChange = (id: string, newAngle: string) => {
    setUploadedPhotos(uploadedPhotos.map(p => p.id === id ? { ...p, angle: newAngle } : p));
  };

  const handleTriggerFileSelect = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleSave = () => {
    if (uploadedPhotos.length < 3) {
      alert("Harap unggah minimal 3 foto untuk diproses.");
      return;
    }
    // Map to simple shape: array of {name: AngleTag, base64: base64}
    const finalPhotos = uploadedPhotos.map(p => ({
      name: p.angle,
      base64: p.base64
    }));
    onUploadCompleted(finalPhotos);
  };

  return (
    <div className="space-y-4">
      {/* Drag and Drop Zone */}
      <div 
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={handleTriggerFileSelect}
        className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center space-y-3 ${
          dragActive 
            ? 'border-amber-500 bg-amber-50 shadow-inner' 
            : 'border-slate-300 hover:border-slate-400 bg-slate-50 hover:bg-slate-100'
        }`}
      >
        <input 
          ref={fileInputRef}
          type="file" 
          multiple 
          accept="image/jpeg,image/png,image/webp" 
          onChange={handleChange}
          className="hidden" 
        />
        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border border-slate-205 shadow-sm text-slate-500">
          <Upload size={22} className="text-slate-400 group-hover:text-amber-500 animate-bounce" />
        </div>
        <div>
          <p className="text-xs font-bold text-slate-800">Tarik & Letakkan Foto Anda di Sini</p>
          <p className="text-[10px] text-slate-500 mt-1">Atau klik untuk menelusuri file komputer (Maks 24 file)</p>
          <p className="text-[9px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md font-mono font-bold mt-2 inline-block">
            Maks 10MB per foto • Format: JPEG, PNG, WEBP
          </p>
        </div>
      </div>

      {uploadedPhotos.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider font-mono flex items-center gap-1">
              <Grid size={13} />
              Daftar Foto Terunggah ({uploadedPhotos.length}/24)
            </h4>
            <span className="text-[10px] text-slate-500">
              Ubah tag arah untuk presisi stitching AI
            </span>
          </div>

          {/* Grid display */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {uploadedPhotos.map((photo) => (
              <div 
                key={photo.id} 
                className="bg-white border border-slate-200 rounded-2xl p-2.5 flex gap-3 shadow-sm hover:shadow-md transition relative group"
              >
                {/* Thumb */}
                <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0 relative bg-slate-100">
                  <img 
                    src={photo.base64} 
                    alt={photo.name} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Info & Tag */}
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div className="text-[11px]">
                    <p className="font-bold text-slate-800 truncate" title={photo.name}>
                      {photo.name}
                    </p>
                    <p className="text-[9px] text-slate-400 font-mono">
                      {(photo.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>

                  {/* Dropdown to tag angle */}
                  <div className="flex items-center gap-1 mt-1">
                    <Compass size={11} className="text-slate-400 shrink-0" />
                    <select
                      value={photo.angle}
                      onChange={(e) => handleAngleChange(photo.id, e.target.value)}
                      className="bg-slate-100 outline-none border-t border-b border-l border-r border-slate-200 text-[10px] py-0.5 px-1.5 rounded-lg font-bold text-slate-700 w-full"
                    >
                      {ARAH_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Delete overlay button */}
                <button
                  type="button"
                  onClick={() => handleDelete(photo.id)}
                  className="absolute top-2 right-2 bg-rose-50 border border-rose-200 text-rose-500 hover:bg-rose-100 hover:text-rose-700 p-1 rounded-lg transition"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onCancel}
              className="border border-slate-300 text-slate-700 font-bold px-4 py-2 rounded-xl text-xs hover:bg-slate-100 transition"
            >
              Batalkan
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="bg-amber-600 text-white font-extrabold px-6 py-2 rounded-xl text-xs hover:bg-amber-700 shadow-md transition"
            >
              Simpan & Review {uploadedPhotos.length} Foto
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
