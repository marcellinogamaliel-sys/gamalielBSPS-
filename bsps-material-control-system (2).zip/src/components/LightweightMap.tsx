import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Recipient, Village, Store } from '../types';
import { Map, MapPin, Grid, Layers, Search, Eye, Filter, CheckCircle2, AlertTriangle, HelpCircle, Activity } from 'lucide-react';

interface LightweightMapProps {
  recipients: Recipient[];
  villages: Village[];
  stores: Store[];
  onNavigate?: (tab: string) => void;
}

export default function LightweightMap({
  recipients,
  villages,
  stores,
  onNavigate
}: LightweightMapProps) {
  const [isLeafletReady, setIsLeafletReady] = useState(() => typeof window !== 'undefined' && !!(window as any).L);
  const [mapStyle, setMapStyle] = useState<'satellite' | 'terrain'>('satellite');
  const [villageFilter, setVillageFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const mapRef = useRef<any>(null);
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  const markersGroupRef = useRef<any>(null);
  const tileLayerRef = useRef<any>(null);

  const TILE_LAYERS = {
    satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    terrain: 'https://tile.opentopomap.org/{z}/{x}/{y}.png'
  };

  const TILE_ATTRIBUTIONS = {
    satellite: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
    terrain: 'Map data &copy; OpenTopoMap contributors'
  };

  // Safe Leaflet dynamic loader
  useEffect(() => {
    if (isLeafletReady) return;

    const loadCss = (href: string) => {
      if (document.querySelector(`link[href="${href}"]`)) return;
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;
      document.head.appendChild(link);
    };

    const loadScript = (src: string) => {
      return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) {
          resolve(true);
          return;
        }
        const script = document.createElement("script");
        script.src = src;
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
    };

    async function loadLeaflet() {
      try {
        loadCss("https://unpkg.com/leaflet@1.9.4/dist/leaflet.css");
        await loadScript("https://unpkg.com/leaflet@1.9.4/dist/leaflet.js");
        setIsLeafletReady(true);
      } catch (err) {
        console.error("Failed to dynamically compile Leaflet assets:", err);
      }
    }

    loadLeaflet();
  }, [isLeafletReady]);

  // Valid coordinate filter
  const validPBs = recipients.filter(pb => {
    const lat = Number(pb.latitude);
    const lng = Number(pb.longitude);
    return !isNaN(lat) && !isNaN(lng) && lat !== 0 && lng !== 0 && lat >= -11 && lat <= 6 && lng >= 95 && lng <= 141; // Indonesia bounds check
  });

  // Filter processes
  const filteredPBs = validPBs.filter(pb => {
    const matchVillage = villageFilter === 'all' || pb.village_id === villageFilter;
    const matchStatus = statusFilter === 'all' || pb.status === statusFilter;
    const matchSearch = searchQuery === '' || 
      pb.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (pb.address && pb.address.toLowerCase().includes(searchQuery.toLowerCase())) ||
      pb.nik.includes(searchQuery);
    return matchVillage && matchStatus && matchSearch;
  });

  // Map Initializer
  useEffect(() => {
    const L = (window as any).L;
    if (!L || !container) return;

    if (mapRef.current) {
      mapRef.current.remove();
      mapRef.current = null;
    }

    let centerLat = -2.5489;
    let centerLng = 118.0149;
    let initialZoom = 5;

    if (filteredPBs.length > 0) {
      centerLat = filteredPBs.reduce((sum, p) => sum + Number(p.latitude), 0) / filteredPBs.length;
      centerLng = filteredPBs.reduce((sum, p) => sum + Number(p.longitude), 0) / filteredPBs.length;
      initialZoom = filteredPBs.length === 1 ? 15 : 12;
    }

    const map = L.map(container, { 
      zoomControl: false,
      maxZoom: 18,
      minZoom: 3
    }).setView([centerLat, centerLng], initialZoom);
    
    mapRef.current = map;

    L.control.zoom({ position: 'topright' }).addTo(map);

    tileLayerRef.current = L.tileLayer(TILE_LAYERS[mapStyle], {
      attribution: TILE_ATTRIBUTIONS[mapStyle],
      maxZoom: 18
    }).addTo(map);

    markersGroupRef.current = L.layerGroup().addTo(map);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [isLeafletReady, container]);

  // Adjust tile layer dynamically on style switch
  useEffect(() => {
    const L = (window as any).L;
    if (!L || !mapRef.current || !tileLayerRef.current) return;

    mapRef.current.removeLayer(tileLayerRef.current);
    tileLayerRef.current = L.tileLayer(TILE_LAYERS[mapStyle], {
      attribution: TILE_ATTRIBUTIONS[mapStyle],
      maxZoom: 18
    }).addTo(mapRef.current);
  }, [mapStyle]);

  // Update Markers dynamically when filters or data change
  useEffect(() => {
    const L = (window as any).L;
    if (!L || !mapRef.current || !markersGroupRef.current) return;

    markersGroupRef.current.clearLayers();

    filteredPBs.forEach(pb => {
      // Color markers based on status
      let color = '#3b82f6'; // in_progress (blue)
      if (pb.status === 'complete') color = '#22c55e'; // complete (green)
      if (pb.status === 'has_finding') color = '#ef4444'; // has_finding (red)
      if (pb.status === 'not_started') color = '#94a3b8'; // not_started (slate)

      const statusLabels: Record<string, string> = {
        not_started: 'Belum Mulai',
        in_progress: 'Sedang Berjalan',
        complete: 'Selesai',
        has_finding: 'Ada Temuan'
      };

      const villageObj = villages.find(v => v.id === pb.village_id);
      const storeObj = stores.find(s => s.id === pb.store_id);

      const marker = L.circleMarker([Number(pb.latitude), Number(pb.longitude)], {
        radius: 7,
        fillColor: color,
        color: '#ffffff',
        weight: 1.5,
        opacity: 1,
        fillOpacity: 0.95
      });

      const popupContent = `
        <div class="p-2 font-sans select-none text-slate-800" style="min-width: 200px;">
          <h4 class="font-bold text-sm text-slate-900 border-b border-slate-100 pb-1 mb-1.5 uppercase">${pb.full_name}</h4>
          <div class="space-y-1 text-xs">
            <p><strong>NIK:</strong> <code class="bg-slate-100 px-1 rounded text-[11px]">${pb.nik}</code></p>
            <p><strong>Desa:</strong> ${villageObj ? villageObj.name : '-'}</p>
            <p><strong>Alamat:</strong> ${pb.address || '-'}</p>
            <p><strong>Toko Penyuplai:</strong> ${storeObj ? storeObj.name : '-'}</p>
            <div class="mt-2 pt-1">
              <span class="inline-block px-2 py-0.5 rounded text-[10px] font-bold text-white uppercase" style="background-color: ${color}">
                ${statusLabels[pb.status] || pb.status}
              </span>
            </div>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);
      markersGroupRef.current.addLayer(marker);
    });

    // Fit bounds only if we have filtered elements
    if (filteredPBs.length > 0 && mapRef.current) {
      const group = L.featureGroup(Object.values(markersGroupRef.current._layers));
      mapRef.current.fitBounds(group.getBounds().pad(0.1));
    }
  }, [filteredPBs, isLeafletReady, villages, stores]);

  const statsTotal = recipients.length;
  const statsMapped = validPBs.length;
  const statsUnmapped = statsTotal - statsMapped;
  const statsComplete = filteredPBs.filter(p => p.status === 'complete').length;
  const statsInProgress = filteredPBs.filter(p => p.status === 'in_progress').length;
  const statsNotStarted = filteredPBs.filter(p => p.status === 'not_started').length;
  const statsFindings = filteredPBs.filter(p => p.status === 'has_finding').length;

  const handleFlyTo = (pb: Recipient) => {
    const L = (window as any).L;
    if (!L || !mapRef.current) return;
    mapRef.current.setView([Number(pb.latitude), Number(pb.longitude)], 16);
    
    // Find the specific layer to open popup
    const layers = markersGroupRef.current.getLayers();
    const matchedLayer = layers.find((layer: any) => {
      const latlng = layer.getLatLng();
      return latlng.lat === Number(pb.latitude) && latlng.lng === Number(pb.longitude);
    });
    if (matchedLayer) {
      matchedLayer.openPopup();
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-[720px] bg-slate-50 rounded-2xl overflow-hidden border border-slate-200 shadow-sm" id="lightweight-map-container">
      {/* Sidebar Controls & Stats */}
      <div className="w-full lg:w-96 flex flex-col bg-white border-b lg:border-b-0 lg:border-r border-slate-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <Activity className="w-4 h-4" />
            </span>
            <h3 className="font-bold text-slate-800 text-sm">Peta Sebaran Ringan (Instan)</h3>
          </div>
          <p className="text-[11px] text-slate-500">
            Versi super ringan berkinerja tinggi. Menampilkan sebaran titik lokasi Penerima Bantuan (PB) secara instan.
          </p>
        </div>

        {/* Quick Quality Stats */}
        <div className="px-4 py-3 bg-indigo-50/40 border-b border-indigo-100 grid grid-cols-3 gap-2 text-center text-xs">
          <div>
            <span className="block text-[10px] text-slate-500 font-medium">Total PB</span>
            <span className="font-extrabold text-slate-800 text-sm">{statsTotal}</span>
          </div>
          <div>
            <span className="block text-[10px] text-emerald-600 font-medium">Terpetakan</span>
            <span className="font-extrabold text-emerald-600 text-sm">{statsMapped}</span>
          </div>
          <div>
            <span className="block text-[10px] text-amber-600 font-medium font-mono">No GPS</span>
            <span className="font-extrabold text-amber-600 text-sm">{statsUnmapped}</span>
          </div>
        </div>

        {/* Filters Panel */}
        <div className="p-4 space-y-3 border-b border-slate-100">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama PB atau NIK..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Village selector */}
            <div>
              <label className="text-[10px] font-black text-slate-400 block mb-1 uppercase tracking-wider">Desa</label>
              <select
                value={villageFilter}
                onChange={(e) => setVillageFilter(e.target.value)}
                className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none"
              >
                <option value="all">Semua Desa</option>
                {villages.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>

            {/* Status selector */}
            <div>
              <label className="text-[10px] font-black text-slate-400 block mb-1 uppercase tracking-wider">Status</label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none"
              >
                <option value="all">Semua Status</option>
                <option value="not_started">Belum Mulai</option>
                <option value="in_progress">Dalam Proses</option>
                <option value="complete">Selesai</option>
                <option value="has_finding">Ada Temuan</option>
              </select>
            </div>
          </div>
        </div>

        {/* Dynamic List */}
        <div className="flex-1 overflow-y-auto min-h-[180px] divide-y divide-slate-100">
          {filteredPBs.length === 0 ? (
            <div className="p-8 text-center text-slate-400 space-y-2">
              <MapPin className="w-8 h-8 mx-auto stroke-1" />
              <p className="text-xs">Tidak ada data titik lokasi yang cocok.</p>
            </div>
          ) : (
            filteredPBs.map(pb => {
              const villageObj = villages.find(v => v.id === pb.village_id);
              let statusColor = 'bg-slate-400';
              if (pb.status === 'complete') statusColor = 'bg-emerald-500';
              if (pb.status === 'in_progress') statusColor = 'bg-blue-500';
              if (pb.status === 'has_finding') statusColor = 'bg-red-500';

              return (
                <div 
                  key={pb.id}
                  onClick={() => handleFlyTo(pb)}
                  className="p-3 text-left hover:bg-slate-50 transition cursor-pointer flex justify-between items-start select-none"
                >
                  <div className="space-y-0.5 pr-2">
                    <h5 className="font-bold text-slate-800 text-xs uppercase tracking-tight">{pb.full_name}</h5>
                    <p className="text-[10px] text-slate-400">NIK {pb.nik}</p>
                    <p className="text-[10px] text-slate-500 truncate max-w-[210px]">{villageObj ? villageObj.name : 'Desa Lain'} &bull; {pb.address || '-'}</p>
                  </div>
                  <span className={`w-2.5 h-2.5 rounded-full ${statusColor} mt-1`} />
                </div>
              );
            })
          )}
        </div>
        
        {/* Style selection footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex justify-between items-center text-xs">
          <span className="text-[10px] font-bold text-slate-500">Corak:</span>
          <div className="flex gap-1.5">
            <button
              onClick={() => setMapStyle('satellite')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition flex items-center gap-1 ${mapStyle === 'satellite' ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'}`}
            >
              🛰️ Satelit
            </button>
            <button
              onClick={() => setMapStyle('terrain')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition flex items-center gap-1 ${mapStyle === 'terrain' ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'}`}
            >
              🏔️ Relief
            </button>
          </div>
        </div>

      </div>

      {/* Map Element */}
      <div className="flex-1 h-[420px] lg:h-full relative bg-slate-900 flex items-center justify-center">
        {!isLeafletReady && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm z-30 flex flex-col items-center justify-center text-slate-300 gap-3">
            <div className="w-8 h-8 rounded-full border-2 border-indigo-400 border-t-transparent animate-spin" />
            <p className="text-xs font-mono">Memuat Peta Sebaran Ringan...</p>
          </div>
        )}
        
        <div ref={setContainer} className="w-full h-full z-10" />

        {/* Floating Legends */}
        <div className="absolute bottom-4 left-4 z-20 bg-slate-950/85 backdrop-blur border border-slate-800 rounded-xl p-3 text-[10px] text-slate-300 space-y-1.5 shadow-xl select-none">
          <span className="font-bold text-slate-400 block tracking-wider uppercase mb-1">Status Lapangan</span>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>Selesai ({statsComplete})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
            <span>Sedang Berjalan ({statsInProgress})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span>Temuan Audit ({statsFindings})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
            <span>Belum Mulai ({statsNotStarted})</span>
          </div>
        </div>
      </div>
    </div>
  );
}
