/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
// xlsx is lazy-loaded inside generateTemplate and handleExcelFileChange to keep it out of the main bundle
import { 
  Users, Plus, Search, Filter, Layers, 
  MapPin, CheckCircle2, AlertTriangle, Building, 
  Compass, Eye, Trash2, Camera, X, ClipboardList, Download, Upload
} from 'lucide-react';
import { Recipient, Village, Group, Store, DRPBItem } from '../types';
import { getStatusColor, getStatusLabel } from '../utils';

interface RecipientListProps {
  recipients: Recipient[];
  villages: Village[];
  groups: Group[];
  stores: Store[];
  drpbItems: DRPBItem[];
  onNavigate: (path: string, id?: string) => void;
  onAddRecipient: (data: any) => Promise<void>;
  onDeleteRecipient: (id: string) => Promise<void>;
  onBulkDeleteRecipients: (ids: string[]) => Promise<void>;
  onBulkDeleteDRPB: (ids: string[]) => Promise<void>;
  onClearAllRecipients: () => Promise<void>;
  onResetDRPB: () => Promise<void>;
  onRefresh: (silent?: boolean) => Promise<void>;
  showToast: (message: string, type: 'success' | 'error') => void;
}

export default function RecipientList({
  recipients,
  villages,
  groups,
  stores,
  drpbItems,
  onNavigate,
  onAddRecipient,
  onDeleteRecipient,
  onBulkDeleteRecipients,
  onBulkDeleteDRPB,
  onClearAllRecipients,
  onResetDRPB,
  onRefresh,
  showToast
}: RecipientListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [villageFilter, setVillageFilter] = useState('all');
  const [groupFilter, setGroupFilter] = useState('all');
  const [storeFilter, setStoreFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Custom delete confirmation modal state
  const [recipientToDelete, setRecipientToDelete] = useState<Recipient | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Form active state
  const [showAddForm, setShowAddForm] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  
  // Bulk selection state
  const [selectedPBIds, setSelectedPBIds] = useState<string[]>([]);
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [showBulkDeleteDRPBConfirm, setShowBulkDeleteDRPBConfirm] = useState(false);
  const [showClearAllConfirm, setShowClearAllConfirm] = useState(false);
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  const [parsedRecipients, setParsedRecipients] = useState<any[]>([]);
  const [skippedRows, setSkippedRows] = useState<any[]>([]);
  const [importReport, setImportReport] = useState<{
    success: boolean;
    count: number;
    duplicates: number;
    skipped: any[];
  } | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState<number>(0);
  const [importStatusMessage, setImportStatusMessage] = useState<string>("");
  const [importDebugInfo, setImportDebugInfo] = useState<{
    fileName: string;
    totalRows: number;
    colMapping: { [key: string]: string };
    errors: { row: number; name: string; reason: string }[];
    successCount: number;
    failCount: number;
  } | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);

  // Form Fields
  const [formData, setFormData] = useState({
    full_name: '',
    nik: '',
    kk_number: '',
    address: '',
    village_id: '',
    group_id: '',
    store_id: '',
    latitude: '',
    longitude: '',
    initial_photo: ''
  });

  // Filtered Groups for form dropdown selection
  const formGroups = formData.village_id 
    ? groups.filter(g => g.village_id === formData.village_id)
    : [];

  // Filtered Recipients list
  const filteredRecipients = recipients.filter(r => {
    const matchesSearch = r.full_name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          r.nik.includes(searchTerm);
    const matchesVillage = villageFilter === 'all' || r.village_id === villageFilter;
    const matchesGroup = groupFilter === 'all' || r.group_id === groupFilter;
    const matchesStore = storeFilter === 'all' || r.store_id === storeFilter;
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    
    return matchesSearch && matchesVillage && matchesGroup && matchesStore && matchesStatus;
  });

  // GPS trigger for form
  const getFormCurrentGPS = () => {
    setGpsLoading(true);
    if (!navigator.geolocation) {
      showToast("GPS tidak didukung", "error");
      setGpsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setFormData(prev => ({
          ...prev,
          latitude: pos.coords.latitude.toFixed(6),
          longitude: pos.coords.longitude.toFixed(6)
        }));
        setGpsLoading(false);
      },
      (err) => {
        showToast("gagal mengambil GPS", "error");
        setGpsLoading(false);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // Image reader to base64 helper
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({
        ...prev,
        initial_photo: reader.result as string
      }));
    };
    reader.readAsDataURL(file);
  };

  const generateTemplate = async () => {
    try {
      const XLSX = await import('xlsx');
      const ws = XLSX.utils.aoa_to_sheet([
        ['Nama PB', 'NIK', 'No. KK', 'Alamat Rumah', 'Nama Desa', 'Kelompok / Pokmas', 'Nama Toko', 'Lat & Long'],
        ['DANTJE SUMAYOUW', '7102061234567890', '7102061234567890', 'JAGA 1', 'SIMBEL', 'WOKA', 'RIDSWA', '1.234567,124.567890']
      ]);
      
      // Format NIK and KK columns as text ('@')
      ['B', 'C'].forEach(col => {
        for (let r = 2; r <= 100; r++) {
          const cellRef = `${col}${r}`;
          if (!ws[cellRef]) ws[cellRef] = { t: 's', v: '' };
          ws[cellRef].z = '@';
        }
      });
      
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Data PB');
      XLSX.writeFile(wb, 'template-import-pb-bsps.xlsx');
      showToast("Template Excel diunduh!", "success");
    } catch (err: any) {
      showToast("Gagal membuat template", "error");
    }
  };

  const handleExcelFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    console.log("[Excel Import Engine] File selected:", file.name, "size:", file.size, "bytes");
    setImportReport(null);
    setImportDebugInfo(null);
    setImportProgress(0);
    setImportStatusMessage("");

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        console.log("[Excel Import Engine] Starting FileReader compilation...");
        const XLSX = await import('xlsx');
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { 
          type: 'array',
          cellText: false,
          cellDates: true,
          raw: false
        });
        
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        const rawData = XLSX.utils.sheet_to_json<any[]>(worksheet, { 
          header: 1, 
          defval: '',
          raw: false 
        });
        
        if (rawData.length === 0) {
          showToast("Berkas kosong atau tidak berisi baris data", "error");
          return;
        }

        const firstRow = rawData[0].map((h: any) => String(h || "").trim());
        
        let mappedHeaders: { [key: string]: number } = {};
        firstRow.forEach((hdr: string, idx: number) => {
          const key = mapHeader(hdr);
          if (key) {
            mappedHeaders[key] = idx;
          }
        });

        const standardKeys = [
          { key: 'full_name', label: 'Nama PB' },
          { key: 'nik', label: 'NIK' },
          { key: 'kk_number', label: 'No. KK' },
          { key: 'address', label: 'Alamat Rumah' },
          { key: 'village_name', label: 'Nama Desa' },
          { key: 'group_name', label: 'Kelompok / Pokmas' },
          { key: 'store_name', label: 'Nama Toko' },
          { key: 'lat_lng', label: 'Lat & Long' }
        ];

        const activeMappingLog: { [key: string]: string } = {};
        standardKeys.forEach(std => {
          const actualIdx = mappedHeaders[std.key];
          if (actualIdx !== undefined) {
            const colLetter = String.fromCharCode(65 + actualIdx);
            const colName = firstRow[actualIdx] || `Kolom ke-${actualIdx + 1}`;
            activeMappingLog[std.label] = `${colLetter} (Membaca: "${colName}")`;
          } else {
            activeMappingLog[std.label] = "Tidak Ditemukan";
          }
        });

        const actualStartIndex = 1; // Assuming first row is always header

        const list: any[] = [];
        const skipped: any[] = [];

        for (let i = actualStartIndex; i < rawData.length; i++) {
          const row = rawData[i];
          if (!row || row.length === 0 || row.every(val => String(val).trim() === "")) {
            continue;
          }

          const getVal = (key: string) => {
            const idx = mappedHeaders[key];
            if (idx === undefined || idx < 0 || idx >= row.length) return "";
            return String(row[idx] ?? "").trim();
          };

          const full_name = getVal('full_name');
          const nikRaw = getVal('nik');
          const kkRaw = getVal('kk_number');
          const address = getVal('address');
          const village_name = getVal('village_name');
          const group_name = getVal('group_name');
          const store_name = getVal('store_name');
          
          let latitude: number | undefined;
          let longitude: number | undefined;
          
          const latLngRaw = getVal('lat_lng');
          if (latLngRaw) {
            const cleaned = latLngRaw.replace(/[,;|]/g, '|').replace(/\s+/g, '');
            const parts = cleaned.split('|');
            if (parts.length >= 2) {
              const parsedLat = Number(parts[0]);
              const parsedLng = Number(parts[1]);
              if (!isNaN(parsedLat) && !isNaN(parsedLng)) {
                latitude = parsedLat;
                longitude = parsedLng;
              }
            }
          } else {
            const rawLat = getVal('latitude');
            const rawLng = getVal('longitude');
            if (rawLat && !isNaN(Number(rawLat))) latitude = Number(rawLat);
            if (rawLng && !isNaN(Number(rawLng))) longitude = Number(rawLng);
          }
          
          if (!full_name) {
            skipped.push({ row: i + 1, name: "-", reason: "Nama PB kosong" });
            continue;
          }
          if (full_name.length < 3) {
            skipped.push({ row: i + 1, name: full_name, reason: "Nama PB minimal 3 karakter" });
            continue;
          }
          if (/^\d+$/.test(full_name)) {
            skipped.push({ row: i + 1, name: full_name, reason: "Nama PB tidak boleh hanya angka" });
            continue;
          }

          const cleanDigits = (val: string) => {
            let str = String(val).trim();
            if (str.toLowerCase().includes('e')) {
              const num = Number(str);
              if (!isNaN(num)) str = num.toLocaleString('fullwide', { useGrouping: false });
            }
            if (/\.0+$/.test(str)) str = str.split('.')[0];
            return str.replace(/\D/g, "");
          };

          const cleaned_nik = cleanDigits(nikRaw);
          const cleaned_kk = cleanDigits(kkRaw);

          if (!cleaned_nik || cleaned_nik.length !== 16) {
            skipped.push({ row: i + 1, name: full_name, reason: "NIK tidak valid. Harus 16 digit angka." });
            continue;
          }
          
          // Temporary validation against empty values.
          if (!cleaned_kk || cleaned_kk.length !== 16) {
            skipped.push({ row: i + 1, name: full_name, reason: "No. KK tidak valid. Harus 16 digit angka." });
            continue;
          }
          if (!village_name) {
            skipped.push({ row: i + 1, name: full_name, reason: "Nama Desa kosong" });
            continue;
          }
          if (!group_name) {
            skipped.push({ row: i + 1, name: full_name, reason: "Kelompok / Pokmas kosong" });
            continue;
          }
          if (!store_name) {
            skipped.push({ row: i + 1, name: full_name, reason: "Nama Toko kosong" });
            continue;
          }
          if (!address) {
            skipped.push({ row: i + 1, name: full_name, reason: "Alamat Rumah kosong" });
            continue;
          }

          list.push({
            full_name,
            nik: cleaned_nik,
            kk_number: cleaned_kk,
            address,
            village_name,
            group_name,
            store_name,
            latitude,
            longitude,
            rowNum: i + 1
          });
        }

        setParsedRecipients(list);
        setSkippedRows(skipped);
        setImportDebugInfo({
          fileName: file.name,
          totalRows: rawData.length,
          colMapping: activeMappingLog,
          errors: skipped.map(s => ({ row: s.row, name: s.name, reason: s.reason })),
          successCount: list.length,
          failCount: skipped.length
        });
        showToast(`Berhasil membaca ${list.length} data. ${skipped.length} baris dilewati.`, "success");
      } catch (err: any) {
        showToast("Gagal membaca berkas Excel: " + (err.message || "kesalahan format"), "error");
      }
    };
    reader.onerror = () => {
      showToast("Gagal memuat berkas dari disk lokal", "error");
    };
    reader.readAsArrayBuffer(file);
  };

  const handleImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedRecipients.length === 0) {
      showToast("Belum ada data valid untuk diimpor", "error");
      return;
    }

    setIsImporting(true);
    setImportProgress(10);
    setImportStatusMessage("Menyiapkan payload transmisi data massal...");

    try {
      setImportProgress(35);
      setImportStatusMessage("Mengirim payload ke API server gateway (/api/pb/import)...");

      const response = await fetch("/api/pb/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipients: parsedRecipients,
          operator_id: "TFL_WEB_IMPORT"
        })
      });

      setImportProgress(85);
      setImportStatusMessage("Membaca respons server...");

      const resData = await response.json();

      if (response.ok) {
        setImportProgress(100);
        setImportStatusMessage("Integrasi Selesai!");
        
        setImportReport({
          success: true,
          count: resData.count || 0,
          duplicates: resData.duplicates || 0,
          skipped: resData.skipped || []
        });

        showToast(`Import rampung! Berhasil: ${resData.count}`, "success");
        await onRefresh(true);
        setParsedRecipients([]);
        setSkippedRows([]);
      } else {
        throw new Error(resData.error || "Gagal mengimpor data server");
      }
    } catch (err: any) {
      showToast("Gagal memproses import: " + (err.message || "koneksi terputus"), "error");
    } finally {
      setIsImporting(false);
      setImportProgress(0);
      setImportStatusMessage("");
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // NIK / KK length checks
    if (formData.nik.length !== 16 || isNaN(Number(formData.nik))) {
      showToast("NIK harus 16 digit", "error");
      return;
    }
    if (formData.kk_number.length !== 16 || isNaN(Number(formData.kk_number))) {
      showToast("KK harus 16 digit", "error");
      return;
    }

    try {
      await onAddRecipient(formData);
      // Reset
      setFormData({
        full_name: '', nik: '', kk_number: '', address: '',
        village_id: '', group_id: '', store_id: '',
        latitude: '', longitude: '', initial_photo: ''
      });
      setShowAddForm(false);
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  const mapHeader = (hdr: string): string | null => {
    const h = hdr.toLowerCase().trim();
    if (['nama pb', 'nama lengkap', 'nama penerima', 'nama cpb', 'nama_pb'].includes(h)) return 'full_name';
    if (['nik'].includes(h)) return 'nik';
    if (['no. kk', 'kk', 'no kk', 'nomor kk'].includes(h)) return 'kk_number';
    if (['alamat rumah', 'alamat'].includes(h)) return 'address';
    if (['nama desa', 'desa'].includes(h)) return 'village_name';
    if (['kelompok / pokmas', 'kelompok', 'pokmas', 'nama kelompok'].includes(h)) return 'group_name';
    if (['nama toko', 'toko', 'nama toko rekanan'].includes(h)) return 'store_name';
    if (['lat & long', 'lat long', 'koordinat', 'latitude longitude'].includes(h)) return 'lat_lng';
    if (['latitude', 'lat'].includes(h)) return 'latitude';
    if (['longitude', 'long', 'lng'].includes(h)) return 'longitude';
    return null;
  };


  // Image reader to base64 helper


  return (
    <div className="space-y-6">
      
      {/* Header and Add Button Actions */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 tracking-tight flex items-center gap-1.5 font-sans">
            <Users size={20} className="text-slate-800" />
            Registry Penerima Bantuan (PB)
          </h2>
          <p className="text-xs text-slate-500">
            Daftar seluruh warga penerima stimulasi bedah rumah swadaya BSPS 2026.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setShowImportDialog(!showImportDialog);
              setShowAddForm(false);
            }}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 transition active:scale-95 border border-slate-200"
          >
            {showImportDialog ? <X size={15} /> : <Upload size={15} />}
            {showImportDialog ? 'Tutup Import' : 'Import Massal Data PB'}
          </button>

          <button
            onClick={() => {
              setShowAddForm(!showAddForm);
              setShowImportDialog(false);
            }}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 transition active:scale-95 shadow-sm"
          >
            {showAddForm ? <X size={15} /> : <Plus size={15} />}
            {showAddForm ? 'Tutup Formulir' : 'Tambah Penerima Baru'}
          </button>
        </div>
      </div>

      {/* FORM: IMPORT MASSAL DATA PB */}
      {showImportDialog && (
        <form onSubmit={handleImportSubmit} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm animate-fadeIn space-y-4">
          <div className="border-b border-slate-150 pb-2 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
            <div>
              <h3 className="text-xs font-bold text-slate-800 font-mono uppercase tracking-wider flex items-center gap-1">
                <Upload size={14} className="text-emerald-600 animate-pulse" />
                INTEGRASI IMPORT EXCEL / SPREADSHEET DATA PB BSPS
              </h3>
            </div>
            
            <button
              type="button"
              onClick={generateTemplate}
              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-[10px] font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              <Download size={13} />
              📥 Download Template
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            <div className="md:col-span-4 space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">UNGGAH BERKAS:</label>
                <div 
                  className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/10 hover:bg-emerald-50/30 p-5 rounded-xl transition text-center relative cursor-pointer"
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                      const pseudoEvent = { target: { files: e.dataTransfer.files } } as any;
                      handleExcelFileChange(pseudoEvent);
                    }
                  }}
                >
                  <input
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleExcelFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-750">Pilih Berkas atau Seret ke Sini</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:col-span-8 flex flex-col justify-between">
              <div className="max-h-64 overflow-y-auto space-y-4 pr-1">
                {importDebugInfo && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl">
                        <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500 mb-2 block">HEADER TERDETEKSI</label>
                        <ul className="text-[10px] space-y-1 text-slate-700 font-mono">
                          {Object.entries(importDebugInfo.colMapping).map(([key, val]) => (
                            <li key={key} className={val === "Tidak Ditemukan" ? "text-rose-600" : ""}>
                              <span className="font-bold">{key}</span>: {val as string}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl flex flex-col justify-center">
                         <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500 mb-2 block">STATUS PARSING</label>
                         <div className="space-y-1">
                           <p className="text-xs">Total Data: <span className="font-bold">{importDebugInfo.totalRows - 1}</span></p>
                           <p className="text-xs text-emerald-600">Valid: <span className="font-bold">{importDebugInfo.successCount}</span></p>
                           <p className="text-xs text-rose-600">Gagal: <span className="font-bold">{importDebugInfo.failCount}</span></p>
                         </div>
                      </div>
                    </div>

                    {importDebugInfo.errors.length > 0 && (
                      <div className="bg-rose-50 border border-rose-200 p-3 rounded-xl">
                        <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-rose-600 mb-2 block">DETAIL ERROR</label>
                        <div className="max-h-32 overflow-y-auto pr-2">
                          <table className="w-full text-left text-[10px]">
                            <thead className="bg-rose-100 text-rose-800">
                              <tr>
                                <th className="p-1 px-2 rounded-l">Baris</th>
                                <th className="p-1 px-2">Nama PB</th>
                                <th className="p-1 px-2 rounded-r">Error</th>
                              </tr>
                            </thead>
                            <tbody>
                              {importDebugInfo.errors.map((err: any, i: number) => (
                                <tr key={i} className="border-b border-rose-100 last:border-0 text-rose-700">
                                  <td className="p-1 px-2 font-mono">{err.row}</td>
                                  <td className="p-1 px-2">{err.name}</td>
                                  <td className="p-1 px-2">{err.reason}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                    
                    {parsedRecipients.length > 0 && (
                       <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl">
                        <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-emerald-700 mb-2 block">PREVIEW DATA (1 BARIS PERTAMA)</label>
                          <div className="text-[10px] grid grid-cols-2 gap-y-1 text-slate-700">
                             <p>Nama PB: <span className="font-bold">{parsedRecipients[0].full_name}</span></p>
                             <p>NIK: <span className="font-bold">{parsedRecipients[0].nik}</span></p>
                             <p>No. KK: <span className="font-bold">{parsedRecipients[0].kk_number}</span></p>
                             <p>Desa: <span className="font-bold">{parsedRecipients[0].village_name}</span></p>
                             <p>Kelompok: <span className="font-bold">{parsedRecipients[0].group_name}</span></p>
                             <p>Toko: <span className="font-bold">{parsedRecipients[0].store_name}</span></p>
                             <p className="col-span-2">Alamat: <span className="font-bold">{parsedRecipients[0].address}</span></p>
                             <p className="col-span-2">Koordinat: <span className="font-bold">{parsedRecipients[0].latitude}, {parsedRecipients[0].longitude}</span></p>
                          </div>
                       </div>
                    )}
                  </div>
                )}
              </div>

              {isImporting && (
                <div className="bg-emerald-50 border border-emerald-150 rounded-xl p-3.5 space-y-2 animate-fadeIn mt-3 text-left">
                  <div className="flex justify-between items-center text-xs font-bold text-emerald-800">
                    <span className="flex items-center gap-1.5 font-sans">
                      {importStatusMessage}
                    </span>
                    <span className="font-mono text-[11px] bg-white border border-emerald-200 px-1.5 py-0.5 rounded text-emerald-700 leading-none">{importProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-200/60 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-teal-600 h-full transition-all duration-300 rounded-full" 
                      style={{ width: `${importProgress}%` }}
                    />
                  </div>
                </div>
              )}
              
              {importReport && (
                <div className="bg-white border text-left border-emerald-200 rounded-xl p-4 space-y-3 animate-fadeIn mt-3 text-slate-800">
                  <h4 className="text-sm font-bold text-emerald-700 border-b border-emerald-100 pb-2 flex items-center gap-2 font-mono uppercase">
                    <CheckCircle2 size={16} /> Hasil Import
                  </h4>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs pb-2 border-b border-slate-100">
                    <div className="bg-slate-50 p-2 rounded-lg">
                      <p className="text-slate-500 mb-1 lg:font-bold">Total PB</p>
                      <p className="text-lg font-black text-slate-800">{importReport.count + importReport.duplicates + importReport.skipped.length}</p>
                    </div>
                    <div className="bg-emerald-50 p-2 rounded-lg">
                      <p className="text-emerald-600 mb-1 font-bold">Berhasil</p>
                      <p className="text-lg font-black text-emerald-700">{importReport.count}</p>
                    </div>
                    <div className="bg-rose-50 p-2 rounded-lg">
                      <p className="text-rose-600 mb-1 font-bold">Gagal/Skip</p>
                      <p className="text-lg font-black text-rose-700">{importReport.duplicates + importReport.skipped.length}</p>
                    </div>
                  </div>
                  
                  {importReport.skipped.length > 0 && (
                     <div className="max-h-32 overflow-y-auto">
                        <table className="w-full text-left text-[10px]">
                          <thead className="bg-slate-100 text-slate-700 sticky top-0">
                            <tr>
                              <th className="p-1.5 px-2 rounded-l">Nama PB</th>
                              <th className="p-1.5 px-2">NIK</th>
                              <th className="p-1.5 px-2 rounded-r">Alasan</th>
                            </tr>
                          </thead>
                          <tbody>
                            {importReport.skipped.map((skip: any, i: number) => (
                              <tr key={i} className="border-b border-slate-100 last:border-0">
                                <td className="p-1 px-2 text-slate-800">{skip.name}</td>
                                <td className="p-1 px-2 font-mono text-slate-600">{skip.nik}</td>
                                <td className="p-1 px-2 text-rose-600">{skip.reason}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                     </div>
                  )}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-105 mt-4">
                <button
                  type="button"
                  onClick={() => setShowImportDialog(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="submit"
                  disabled={isImporting || parsedRecipients.length === 0}
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs font-black cursor-pointer shadow-sm transition disabled:opacity-55"
                >
                  {isImporting ? 'Sedang Mengimpor...' : `Mulai Integrasikan ${parsedRecipients.length} Data PB`}
                </button>
              </div>
            </div>
          </div>
        </form>
      )}

      {/* FORM: TAMBAH PENERIMA BANTUAN */}
      {showAddForm && (
        <form onSubmit={handleFormSubmit} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm animate-fadeIn space-y-4">
          <h3 className="text-xs font-bold text-slate-800 font-mono uppercase tracking-wider border-b border-slate-150 pb-2 flex items-center gap-1">
            <ClipboardList size={14} />
            Formulir Pendaftaran Warga PB
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Nama Lengkap */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Nama Lengkap PB</label>
              <input
                required
                type="text"
                placeholder="Contoh: Ahmad Subardjo"
                value={formData.full_name}
                onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            {/* NIK */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">NIK (16 Digit)</label>
              <input
                required
                maxLength={16}
                type="text"
                placeholder="3201xxxxxxxxxxxx"
                value={formData.nik}
                onChange={(e) => setFormData(prev => ({ ...prev, nik: e.target.value.replace(/\D/g, '') }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
              />
            </div>

            {/* KK */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Nomor Kartu Keluarga (16 Digit)</label>
              <input
                required
                maxLength={16}
                type="text"
                placeholder="3201xxxxxxxxxxxx"
                value={formData.kk_number}
                onChange={(e) => setFormData(prev => ({ ...prev, kk_number: e.target.value.replace(/\D/g, '') }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
              />
            </div>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Desa Dropdown */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Wilayah Desa</label>
              <select
                required
                value={formData.village_id}
                onChange={(e) => setFormData(prev => ({ ...prev, village_id: e.target.value, group_id: '' }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
              >
                <option value="">Pilih Desa</option>
                {villages.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>

            {/* Kelompok Dropdown */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Kelompok PB (Sesuai Desa)</label>
              <select
                required
                disabled={!formData.village_id}
                value={formData.group_id}
                onChange={(e) => setFormData(prev => ({ ...prev, group_id: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-250 focus:outline-none disabled:opacity-40"
              >
                <option value="">Pilih Kelompok</option>
                {formGroups.map(g => (
                  <option key={g.id} value={g.id}>{g.name}</option>
                ))}
              </select>
            </div>

            {/* Toko Rekanan */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Toko Penyedia Material</label>
              <select
                required
                value={formData.store_id}
                onChange={(e) => setFormData(prev => ({ ...prev, store_id: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
              >
                <option value="">Pilih Toko Penyedia</option>
                {stores.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.owner_name})</option>
                ))}
              </select>
            </div>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Latitude & Longitude with GPS capture */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Latitude Rumah PB</label>
              <input
                required
                type="number"
                step="any"
                placeholder="-6.913000"
                value={formData.latitude}
                onChange={(e) => setFormData(prev => ({ ...prev, latitude: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Longitude Rumah PB</label>
              <input
                required
                type="number"
                step="any"
                placeholder="107.605000"
                value={formData.longitude}
                onChange={(e) => setFormData(prev => ({ ...prev, longitude: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Koordinat GPS Lapangan</label>
              <button
                type="button"
                onClick={getFormCurrentGPS}
                disabled={gpsLoading}
                className="w-full py-2 bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-xl text-xs font-semibold cursor-pointer text-slate-700 flex items-center justify-center gap-1 transition active:scale-95 disabled:opacity-40"
              >
                <Compass size={13} className={gpsLoading ? 'animate-spin' : ''} />
                {gpsLoading ? 'Membaca Satelit GPS...' : 'Ambil Koordinat Rumah'}
              </button>
            </div>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Alamat Lengkap */}
            <div className="md:col-span-8 space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Alamat Lengkap Rumah</label>
              <textarea
                required
                placeholder="Kp. Cigoler RT 03/RW 04, Belakang Mushola Al-Khoir"
                value={formData.address}
                rows={2}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50/50 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            {/* Foto Rumah Awal */}
            <div className="md:col-span-4 space-y-1.5">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Foto Fisik Rumah Awal (0%)</label>
              <div className="flex items-center gap-2">
                <label className="flex-1 py-4 border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 transition">
                  <Camera size={18} className="text-slate-400" />
                  <span className="text-[10px] text-slate-500 font-bold mt-1">Ubah / Upload Foto</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
                
                {formData.initial_photo && (
                  <div className="w-14 h-14 rounded-lg overflow-hidden border border-slate-250 shrink-0 relative">
                    <img src={formData.initial_photo} alt="Initial" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, initial_photo: '' }))}
                      className="absolute top-0.5 right-0.5 bg-red-500 text-white p-0.5 rounded-full"
                    >
                      <X size={8} />
                    </button>
                  </div>
                )}
              </div>
            </div>

          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-xs border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl cursor-pointer"
            >
              Batalkan
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold cursor-pointer transition"
            >
              Simpan PB & Tambah DRPB
            </button>
          </div>

        </form>
      )}

      {/* FILTER PANEL */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs grid grid-cols-1 sm:grid-cols-5 gap-3" id="recipient-filters">
        
        {/* Search */}
        <div className="relative col-span-1 sm:col-span-1">
          <Search size={14} className="absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Cari PB (Nama/NIK)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8 pr-3 py-2 w-full text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          />
        </div>

        {/* Desa Filter */}
        <div>
          <select
            value={villageFilter}
            onChange={(e) => {
              setVillageFilter(e.target.value);
              setGroupFilter('all');
            }}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          >
            <option value="all">Saring Desa (Semua)</option>
            {villages.map(v => (
              <option key={v.id} value={v.id}>{v.name}</option>
            ))}
          </select>
        </div>

        {/* Kelompok Filter */}
        <div>
          <select
            disabled={villageFilter === 'all'}
            value={groupFilter}
            onChange={(e) => setGroupFilter(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50 disabled:opacity-50"
          >
            <option value="all">Saring Kelompok (Semua)</option>
            {groups
              .filter(g => villageFilter === 'all' || g.village_id === villageFilter)
              .map(g => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
          </select>
        </div>

        {/* Toko Filter */}
        <div>
          <select
            value={storeFilter}
            onChange={(e) => setStoreFilter(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          >
            <option value="all">Saring Toko (Semua)</option>
            {stores.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          >
            <option value="all">Saring Status (Semua)</option>
            <option value="complete">Lengkap (Hijau)</option>
            <option value="in_progress">Dalam Proses (Kuning)</option>
            <option value="not_started">Belum Penyaluran (Merah)</option>
            <option value="has_finding">Ada Temuan (Hitam)</option>
          </select>
        </div>

      </div>

      {/* EXPORT AND PRINT REPORT BUTTONS */}
      <div className="flex flex-col sm:flex-row justify-between items-center bg-slate-100 border border-slate-200/80 px-4 py-3 rounded-xl gap-3 text-xs mt-1 print:hidden" id="export-report-controls">
        <span className="text-[11px] text-slate-500 font-mono font-medium">
          Ditemukan <span className="font-bold text-slate-800">{filteredRecipients.length} keluarga PB</span> berdasarkan saringan filter Anda.
        </span>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
          {/* Print/Cetak report */}
          <button
            type="button"
            onClick={() => window.print()}
            className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-xs"
          >
            🖨️ Cetak Laporan Desa (PDF)
          </button>

          {/* Export to Excel link */}
          <a
            href={`/api/reports/recipients/excel?village_id=${villageFilter === 'all' ? '' : villageFilter}&status=${statusFilter === 'all' ? '' : statusFilter}`}
            download="Laporan_Penyaluran_BSPS.csv"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black cursor-pointer transition select-none flex items-center justify-center gap-1.5 active:scale-95 shadow-sm"
          >
            <Download size={13} />
            Ekspor Hasil Filter (.CSV)
          </a>
          
          {/* Kosongkan DRPB Seluruh PB */}
          <button
            onClick={async () => {
              if (onResetDRPB) {
                await onResetDRPB();
              }
            }}
            className="px-3.5 py-2 border border-amber-200 text-amber-600 bg-white hover:bg-amber-50 rounded-xl text-xs font-bold cursor-pointer transition whitespace-nowrap hidden sm:flex items-center gap-1.5 shadow-sm ml-auto"
          >
            <Trash2 size={13} />
            Reset DRPB Semua PB (Massal)
          </button>

          {/* Hapus Semua Data (Kosongkan) */}
          <button
            onClick={() => setShowClearAllConfirm(true)}
            className="px-3.5 py-2 border border-rose-200 text-rose-600 bg-white hover:bg-rose-50 rounded-xl text-xs font-bold cursor-pointer transition whitespace-nowrap hidden sm:flex items-center gap-1.5 shadow-sm"
          >
            <Trash2 size={13} />
            Kosongkan Semua Data PB & DRPB
          </button>
        </div>
      </div>

      {/* BULK ACTIONS TOOLBAR */}
      {selectedPBIds.length > 0 && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-3 mb-4 flex flex-col sm:flex-row items-center justify-between text-indigo-900 animate-fadeIn gap-3">
          <div className="flex items-center gap-2 font-medium text-xs">
             <CheckCircle2 size={15} className="text-indigo-600" />
             Terpilih <span className="font-bold text-lg leading-none">{selectedPBIds.length}</span> PB
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
               onClick={() => setShowBulkDeleteDRPBConfirm(true)}
               className="px-3 md:px-4 py-2 uppercase bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-[10px] md:text-xs font-black cursor-pointer transition flex items-center gap-1.5 shadow-md active:scale-95 whitespace-nowrap"
            >
               <Trash2 size={14} /> Hapus DRPB Terpilih
            </button>
            <button
               onClick={() => setShowBulkDeleteConfirm(true)}
               className="px-3 md:px-4 py-2 uppercase bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-[10px] md:text-xs font-black cursor-pointer transition flex items-center gap-1.5 shadow-md active:scale-95 whitespace-nowrap"
            >
               <Trash2 size={14} /> Hapus PB Terpilih
            </button>
          </div>
        </div>
      )}

      {/* RECIPIENTS RESULTS BOX GRID */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex items-center justify-between">
           <label className="flex items-center gap-2 cursor-pointer group">
             <input 
               type="checkbox" 
               checked={selectedPBIds.length > 0 && selectedPBIds.length === filteredRecipients.length && filteredRecipients.length > 0}
               onChange={(e) => {
                 if (e.target.checked) setSelectedPBIds(filteredRecipients.map(r => r.id));
                 else setSelectedPBIds([]);
               }}
               className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 bg-white cursor-pointer shadow-sm disabled:opacity-50"
               disabled={filteredRecipients.length === 0}
             />
             <span className="text-xs font-bold text-slate-600 uppercase tracking-widest group-hover:text-slate-900">Pilih Semua ({filteredRecipients.length})</span>
           </label>
        </div>
        <div className="divide-y divide-slate-100 flex flex-col">
          <AnimatePresence mode="popLayout">
            {filteredRecipients.length === 0 ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-12 text-center text-slate-400 text-xs w-full"
              >
                Tidak ada data Penerima Bantuan (PB) yang sesuai saringan filter.
              </motion.div>
            ) : (
              filteredRecipients.map(pb => {
                const pbVillage = villages.find(v => v.id === pb.village_id)?.name || "-";
                const pbGroup = groups.find(g => g.id === pb.group_id)?.name || "-";
                const pbStore = stores.find(s => s.id === pb.store_id);
                
                const pbDRPB = drpbItems.filter(d => d.recipient_id === pb.id);
                const isChecked = selectedPBIds.includes(pb.id);

                return (
                  <motion.div 
                    key={pb.id}
                    layout
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ 
                      opacity: 1, 
                      y: 0,
                      backgroundColor: isChecked ? 'rgba(238, 242, 255, 0.35)' : 'rgba(255, 255, 255, 1)'
                    }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    whileHover={{ 
                      scale: 1.008, 
                      backgroundColor: isChecked ? 'rgba(238, 242, 255, 0.55)' : 'rgba(248, 250, 252, 0.9)',
                      boxShadow: '0 10px 20px -10px rgba(15, 23, 42, 0.08)'
                    }}
                    transition={{ type: "spring", stiffness: 350, damping: 28 }}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row justify-between sm:items-center gap-4 transition-all duration-200 border-b border-slate-100 last:border-b-0"
                  >
                    <div className="flex gap-4 min-w-0 flex-1">
                      <div className="pt-1 select-none">
                        <input 
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) setSelectedPBIds(prev => [...prev, pb.id]);
                            else setSelectedPBIds(prev => prev.filter(id => id !== pb.id));
                          }}
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 shadow-sm bg-white cursor-pointer"
                        />
                      </div>
                      <div className="space-y-1.5 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 
                            onClick={() => onNavigate('recipient_detail', pb.id)}
                            className="text-sm font-extrabold text-slate-905 hover:text-indigo-600 transition truncate flex items-center gap-1.5 cursor-pointer"
                            title="Klik untuk membuka Halaman Detail PB ini"
                          >
                            <Eye size={15} className="text-indigo-500 hover:text-indigo-750 hover:scale-115 transition shrink-0" />
                            {pb.full_name}
                          </h4>
                          <span className={`text-[10px] font-bold px-2.5 py-0.2 rounded border uppercase ${getStatusColor(pb.status)}`}>
                            {getStatusLabel(pb.status)}
                          </span>
                        </div>

                        <p className="text-xs text-slate-500 font-mono">
                          NIK: <span className="font-semibold text-slate-700">{pb.nik}</span> 
                          &bull; KK: <span className="font-semibold text-slate-700">{pb.kk_number}</span>
                        </p>

                        <div className="flex flex-wrap items-center gap-y-1 gap-x-2.5 text-[10px] text-slate-500 font-mono">
                          <span className="flex items-center gap-0.5 text-slate-800 font-semibold">
                            <Layers size={11} className="text-slate-400 shrink-0" />
                            {pbVillage}, {pbGroup}
                          </span>
                          <span>&bull;</span>
                          <span className="flex items-center gap-0.5 text-slate-700">
                            <Building size={11} className="text-slate-400 shrink-0" />
                            {pbStore ? pbStore.name : "Toko tidak terdaftar"}
                          </span>
                          <span>&bull;</span>
                          <span className="flex items-center gap-0.2 text-blue-600 font-medium">
                            <MapPin size={11} className="shrink-0" />
                            Lat: {pb.latitude.toFixed(4)}, Lng: {pb.longitude.toFixed(4)}
                          </span>
                        </div>

                        <p className="text-xs text-slate-500 italic truncate max-w-xl">Alamat: {pb.address}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <div className="text-right mr-2 hidden md:block">
                        <span className="text-[10px] font-bold font-mono text-slate-450 block">STATUS DRPB</span>
                        <span className="text-xs font-bold text-slate-700">{pbDRPB.length} Rencana Bahan</span>
                      </div>

                      <button
                        onClick={() => onNavigate('recipient_detail', pb.id)}
                        className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-705 text-white rounded-xl cursor-pointer transition flex items-center gap-1.5 text-xs font-black tracking-wide"
                        title="Lihat Rencana / Input Penyaluran & Progress"
                      >
                        <Eye size={13} />
                        Detail PB
                      </button>

                      <button
                        onClick={() => setRecipientToDelete(pb)}
                        className="p-2 border border-rose-200 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer transition"
                        title="Hapus Penerima Bantuan"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </motion.div>
                );
              })
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* CUSTOM MODERN DELETE CONFIRMATION MODAL */}
      {recipientToDelete && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="custom-delete-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-rose-605">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                ⚠️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Konfirmasi Hapus PB</h3>
                <p className="text-[10px] text-slate-505 font-mono">Tindakan ini permanen & terekam di audit trail</p>
              </div>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>
                Apakah Anda yakin ingin menghapus penerima bantuan (PB) bernama <strong>{recipientToDelete.full_name}</strong> (NIK: {recipientToDelete.nik})?
              </p>
              <div className="bg-amber-50 border border-amber-200 text-amber-900 p-3 rounded-2xl text-[10.5px] space-y-1">
                <span className="font-bold font-mono tracking-wider text-[9px] text-amber-800">PERINGATAN KERAS:</span>
                <p>Tindakan ini juga akan menghapus secara bersih:</p>
                <ul className="list-disc list-inside mt-1 space-y-0.5">
                  <li>Seluruh item rencana alokasi DRPB.</li>
                  <li>Seluruh bukti & foto riwayat penyaluran lapangan terkait.</li>
                </ul>
              </div>
            </div>

            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setRecipientToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={async () => {
                  setIsDeleting(true);
                  try {
                    await onDeleteRecipient(recipientToDelete.id);
                    setRecipientToDelete(null);
                  } catch (err: any) {
                    showToast("gagal menghapus", "error");
                  } finally {
                    setIsDeleting(false);
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 active:scale-95 shadow-sm disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <span className="w-3 h-3 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    Menghapus...
                  </>
                ) : (
                  <>Ya, Hapus Permanen</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BULK DELETE CONFIRMATION MODAL */}
      {showBulkDeleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="bulk-delete-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-rose-605">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-150 flex items-center justify-center text-lg font-bold">
                ⚠️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Massal PB</h3>
                <p className="text-[10px] text-slate-505 font-mono">Menghapus {selectedPBIds.length} PB beserta datanya</p>
              </div>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>
                Apakah Anda yakin ingin menghapus <strong>{selectedPBIds.length} penerima bantuan</strong> yang dipilih?
              </p>
              <div className="bg-amber-50 border border-amber-200 text-amber-900 p-3 rounded-2xl text-[10.5px] space-y-1">
                <span className="font-bold font-mono tracking-wider text-[9px] text-amber-800">PERINGATAN KERAS:</span>
                <p>Seluruh DRPB, penyaluran, dan bukti foto terkait data terpilih juga akan terhapus. Tindakan ini permanen.</p>
              </div>
            </div>

            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={() => setShowBulkDeleteConfirm(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={async () => {
                  setIsBulkProcessing(true);
                  try {
                    await onBulkDeleteRecipients(selectedPBIds);
                    setSelectedPBIds([]);
                    setShowBulkDeleteConfirm(false);
                  } catch (err: any) {
                    showToast("Gagal menghapus PB massal", "error");
                  } finally {
                    setIsBulkProcessing(false);
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 shadow-sm disabled:opacity-50"
              >
                {isBulkProcessing ? 'Menghapus...' : 'Hapus Terpilih'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BULK DELETE DRPB CONFIRMATION MODAL */}
      {showBulkDeleteDRPBConfirm && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="bulk-delete-drpb-modal">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn">
            <div className="flex items-center gap-3 border-b border-indigo-50 pb-3 text-amber-600">
              <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-150 flex items-center justify-center text-lg font-bold">
                ⚠️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Hapus Massal DRPB</h3>
                <p className="text-[10px] text-slate-500 font-mono">Menyeleksi {selectedPBIds.length} PB terpilih</p>
              </div>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>
                Apakah Anda yakin ingin menghapus <strong>seluruh data rencana material (DRPB)</strong> untuk <strong>{selectedPBIds.length} penerima bantuan</strong> yang dipilih?
              </p>
              <div className="bg-amber-50 border border-amber-200 text-amber-900 p-3 rounded-2xl text-[10.5px] space-y-1">
                <span className="font-bold font-mono tracking-wider text-[9px] text-amber-800">PERINGATAN:</span>
                <p>Seluruh riwayat realisasi penyaluran serta foto bukti yang terkait dengan DRPB PB terpilih akan ikut terhapus secara permanen.</p>
              </div>
            </div>

            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={() => setShowBulkDeleteDRPBConfirm(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={async () => {
                  setIsBulkProcessing(true);
                  try {
                    await onBulkDeleteDRPB(selectedPBIds);
                    setSelectedPBIds([]);
                    setShowBulkDeleteDRPBConfirm(false);
                  } catch (err: any) {
                    showToast("Gagal menghapus DRPB massal", "error");
                  } finally {
                    setIsBulkProcessing(false);
                  }
                }}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 shadow-sm disabled:opacity-50"
              >
                {isBulkProcessing ? 'Menghapus...' : 'Ya, Hapus DRPB'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CLEAR ALL CONFIRMATION MODAL */}
      {showClearAllConfirm && (
        <div className="fixed inset-0 bg-rose-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn" id="clear-all-modal">
          <div className="bg-white rounded-3xl border border-rose-200 max-w-md w-full p-6 shadow-2xl space-y-6 animate-scaleIn">
            <div className="flex items-center gap-3 border-b border-rose-100 pb-3 text-rose-600">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 flex items-center justify-center text-lg font-bold">
                🗑️
              </div>
              <div>
                <h3 className="text-sm font-black font-sans uppercase tracking-tight text-slate-900">Kosongkan Semua Data</h3>
                <p className="text-[10px] text-rose-500 font-mono">PERINGATAN: PENGHAPUSAN SELURUH DATA</p>
              </div>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <p>
                Tindakan ini akan <strong className="text-rose-600">MENGHAPUS SELURUH PENERIMA BANTUAN (PB)</strong> di dalam sistem.
              </p>
              <div className="bg-rose-50 border border-rose-200 text-rose-900 p-3 rounded-2xl text-[10.5px] space-y-1">
                <span className="font-bold font-mono tracking-wider text-[9px] text-rose-800">TIDAK BISA DIKEMBALIKAN:</span>
                <p>Selain seluruh PB, sistem juga akan menghapus secara keseluruhan:</p>
                <ul className="list-disc list-inside mt-1 space-y-0.5">
                  <li>Semua Rencana Bahan (DRPB)</li>
                  <li>Semua Catatan Penyaluran & Titik GPS</li>
                  <li>Semua Bukti Foto & Video Lapangan</li>
                  <li>Semua Catatan Temuan Lapangan</li>
                </ul>
              </div>
              <p className="font-bold">Apakah Anda benar-benar yakin ingin melanjutkan?</p>
            </div>

            <div className="flex gap-2.5 pt-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={() => setShowClearAllConfirm(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition select-none disabled:opacity-50"
              >
                Batalkan
              </button>
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={async () => {
                  setIsBulkProcessing(true);
                  try {
                    await onClearAllRecipients();
                    setSelectedPBIds([]);
                    setShowClearAllConfirm(false);
                  } catch (err: any) {
                    showToast("Gagal mengosongkan data", "error");
                  } finally {
                    setIsBulkProcessing(false);
                  }
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl cursor-pointer transition select-none flex items-center gap-1.5 shadow-sm disabled:opacity-50 shadow-rose-600/30 ring-2 ring-transparent focus:ring-rose-200"
              >
                {isBulkProcessing ? 'Menghapus Keseluruhan...' : 'Ya, Kosongkan Semua!'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
