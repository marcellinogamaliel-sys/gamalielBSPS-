import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, Clock, Calendar, CheckSquare, Upload, 
  Send, ShieldAlert, ArrowRight, X, Sparkles, Check, CheckCircle2, History 
} from 'lucide-react';
import { Arahan, ArahanComment, ArahanProof } from '../types';

interface TFLArahanManagerProps {
  arahanList: Arahan[];
  onRefresh: () => void;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

export default function TFLArahanManager({ arahanList, onRefresh, showToast }: TFLArahanManagerProps) {
  const [selectedArahanId, setSelectedArahanId] = useState<string | null>(null);
  
  // Create comment states
  const [commentText, setCommentText] = useState('');
  
  // Submit Proof States
  const [proofDesc, setProofDesc] = useState('');
  const [proofPhoto, setProofPhoto] = useState<string>('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [submittingProof, setSubmittingProof] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedArahan = arahanList.find(a => a.id === selectedArahanId);

  // Automatically update status to 'dibaca' when TFL clicks on a 'belum_dibaca' task
  const handleSelectArahan = async (item: Arahan) => {
    setSelectedArahanId(item.id);
    
    // Reset proof inputs
    setProofDesc('');
    setProofPhoto('');
    setPreviewUrl(null);

    if (item.status === 'belum_dibaca') {
      try {
        const res = await fetch(`/api/arahan/${item.id}/status`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            status: 'dibaca',
            operator_id: 'TFL_USER'
          })
        });
        if (res.ok) {
          onRefresh();
        }
      } catch (e) {
        console.error("Gagal memperbarui status baca", e);
      }
    }
  };

  // Submit chat reply
  const handlePostComment = async () => {
    if (!selectedArahanId || !commentText.trim()) return;
    try {
      const res = await fetch(`/api/arahan/${selectedArahanId}/comment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender_role: 'tfl',
          sender_name: 'Fasilitator Lapangan TFL',
          message: commentText.trim()
        })
      });

      if (res.ok) {
        setCommentText('');
        onRefresh();
        showToast("Balasan dikirim!", "success");
      }
    } catch (e) {
      showToast("Gagal mengirim balasan", "error");
    }
  };

  // Drag and Drop & file upload handling to Base64
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        showToast("Maksimal ukuran foto adalah 10MB.", "error");
        return;
      }
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setProofPhoto(base64);
      setPreviewUrl(base64);
    };
    reader.readAsDataURL(file);
  };

  // Submit proof of completion back to Korkab
  const handleSubmitProofFinish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedArahanId) return;

    setSubmittingProof(true);
    try {
      const res = await fetch(`/api/arahan/${selectedArahanId}/complete`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          photo: proofPhoto,
          description: proofDesc,
          operator_id: 'TFL'
        })
      });

      if (res.ok) {
        showToast("Bukti penyelesaian berhasil dikirim! Menunggu persetujuan KORKAB.", "success");
        setProofDesc('');
        setProofPhoto('');
        setPreviewUrl(null);
        onRefresh();
      } else {
        showToast("Gagal mengirim bukti penyelesaian", "error");
      }
    } catch (err) {
      showToast("Kesalahan sistem", "error");
    } finally {
      setSubmittingProof(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start font-sans">
      
      {/* LEFT SIDE: LIST OF DIRECTIVES */}
      <div className="md:col-span-5 space-y-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold font-mono tracking-wider text-slate-400 block uppercase">Daftar Penugasan</span>
          <h2 className="text-base font-black text-slate-900 mt-0.5">Tugas & Instruksi dari KORKAB</h2>
        </div>

        <div className="space-y-3.5">
          {arahanList.length === 0 ? (
            <div className="p-12 text-center text-slate-400 italic bg-white rounded-2xl border border-slate-100">
              Belum ada arahan / tugas yang masuk dari Koordinator Kabupaten.
            </div>
          ) : (
            arahanList.map((item) => {
              const isSelected = selectedArahanId === item.id;
              
              let statusLabel = 'Belum Dibaca';
              let statusColor = 'bg-red-100 text-red-650';
              if (item.status === 'dibaca') {
                statusLabel = 'Dibaca';
                statusColor = 'bg-yellow-100 text-yellow-805';
              } else if (item.status === 'selesai') {
                statusLabel = 'Selesai';
                statusColor = 'bg-green-100 text-green-700';
              }

              let priorityText = '🔴 Kritis';
              if (item.priority === 'sedang') priorityText = '🟡 Sedang';
              else if (item.priority === 'rendah') priorityText = '🟢 Rendah';

              return (
                <div 
                  key={item.id}
                  onClick={() => handleSelectArahan(item)}
                  className={`p-4 bg-white rounded-2xl border hover:border-amber-500 transition cursor-pointer relative overflow-hidden shadow-xs hover:shadow ${
                    isSelected ? 'ring-2 ring-amber-500 border-amber-500 bg-amber-50/10' : 'border-slate-150'
                  }`}
                >
                  <div className="flex justify-between items-start gap-4">
                    <div className="space-y-1">
                      <span className="text-[9px] font-bold font-mono tracking-wide text-indigo-705 bg-indigo-50 px-2 py-0.5 rounded-full uppercase">
                        {item.category.replace('_', ' ')}
                      </span>
                      <h3 className="text-xs font-black text-slate-900 leading-tight uppercase pt-1">{item.title}</h3>
                      <p className="text-[11px] text-zinc-500 line-clamp-2 pt-0.5">{item.description}</p>
                    </div>
                    
                    <div className="text-right shrink-0 space-y-1">
                      <span className={`text-[8px] font-black uppercase font-mono px-1.5 py-0.5 rounded leading-none block ${statusColor}`}>
                        {statusLabel}
                      </span>
                      <span className="text-[8px] text-zinc-400 font-mono block pt-1">
                        Sisa Hari: {Math.max(0, Math.round((new Date(item.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))} Hari
                      </span>
                    </div>
                  </div>

                  <div className="mt-3.5 pt-2 border-t border-slate-50 flex justify-between items-center text-[10px] text-slate-400 font-mono">
                    <span>Deadline: {new Date(item.deadline).toLocaleDateString('id-ID')}</span>
                    <span className="font-bold text-slate-650">{priorityText}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* RIGHT SIDE: SELECTED DIRECTIVE CHAT & PROOF SUBMIT */}
      <div className="md:col-span-7">
        <AnimatePresence mode="wait">
          {selectedArahan ? (
            <motion.div
              key={selectedArahan.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="p-6 bg-white rounded-3xl border border-slate-105 shadow-sm space-y-6"
            >
              
              {/* Header Box */}
              <div className="border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-black uppercase font-mono px-2 py-0.5 bg-indigo-50 text-[#0B4F8C] border border-indigo-100 rounded-full">
                    {selectedArahan.category.replace('_', ' ').toUpperCase()}
                  </span>
                  <span className="text-[9px] font-bold font-mono px-2 py-0.5 bg-slate-50 border border-slate-200 rounded-full uppercase">
                    Prioritas {selectedArahan.priority}
                  </span>
                </div>
                <h2 className="text-[15px] font-black text-slate-900 uppercase mt-2.5">{selectedArahan.title}</h2>
              </div>

              {/* Instructions Detail */}
              <div className="space-y-1.5 text-xs leading-relaxed text-slate-700">
                <span className="text-[9px] font-bold font-mono uppercase text-slate-400 block tracking-wider">Instruksi KORKAB</span>
                <p className="font-medium whitespace-pre-wrap select-text">{selectedArahan.description}</p>
                
                {selectedArahan.attachment && (
                  <div className="pt-2">
                    <a 
                      href={selectedArahan.attachment} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="inline-flex items-center gap-1.5 font-bold text-[#0B4F8C] hover:underline"
                    >
                      <span>🔗 Buka Tautan Lampiran Pendukung</span>
                    </a>
                  </div>
                )}
              </div>

              {/* FORUM CHAT SECTION */}
              <div className="space-y-3.5 border-t border-b border-slate-100 py-4">
                <span className="text-[9px] font-bold font-mono uppercase text-slate-400 block tracking-wider">Forum Balasan KORKAB & TFL</span>
                
                {/* Chat items scroll */}
                <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                  {!selectedArahan.comments || selectedArahan.comments.length === 0 ? (
                    <p className="text-[11px] text-slate-450 italic py-2 text-center text-slate-400">Belum ada tanggapan obrolan.</p>
                  ) : (
                    selectedArahan.comments.map(c => {
                      const isKorkab = c.sender_role === 'korkab';
                      return (
                        <div key={c.id} className={`p-2.5 rounded-xl flex flex-col gap-1 text-[11px] leading-normal ${isKorkab ? 'bg-indigo-50 border border-indigo-150 pl-3 border-l-4 border-l-indigo-600' : 'bg-slate-50 border border-slate-150'}`}>
                          <div className="flex justify-between font-bold text-slate-800">
                            <span className="uppercase text-[10px]">{c.sender_name}</span>
                            <span className="text-[8px] opacity-60 font-mono">{new Date(c.created_at).toLocaleTimeString('id-id', { hour:'2-digit', minute:'2-digit' })}</span>
                          </div>
                          <p className="text-slate-700">{c.message}</p>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Send reply bar */}
                <div className="flex gap-2.5">
                  <input 
                    type="text" 
                    placeholder="Tulis balasan koordinasi lapangan..."
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handlePostComment();
                    }}
                    className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none"
                  />
                  <button
                    onClick={handlePostComment}
                    className="p-2.5 px-4 bg-slate-900 text-white hover:bg-slate-800 rounded-xl font-bold flex items-center justify-center active:scale-95 transition cursor-pointer"
                  >
                    <Send size={13} />
                  </button>
                </div>
              </div>

              {/* PROOF OF COMPLETION SUBMISSION */}
              {selectedArahan.proof ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 space-y-3">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="font-extrabold text-emerald-800">BUKTI PENYELESAIAN TERKIRIM</span>
                    <span className="text-slate-400">{new Date(selectedArahan.proof.submitted_at || '').toLocaleDateString('id-ID')}</span>
                  </div>

                  {selectedArahan.proof.photo && (
                    <div className="rounded-xl overflow-hidden h-36 bg-white border border-emerald-150">
                      <img 
                        src={selectedArahan.proof.photo} 
                        alt="Bukti upload" 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}

                  {selectedArahan.proof.description && (
                    <p className="text-[11px] leading-relaxed text-slate-700 bg-white p-2.5 rounded-xl border border-emerald-55">
                      <strong>Keterangan TFL:</strong> {selectedArahan.proof.description}
                    </p>
                  )}

                  <div className="p-2.5 text-center text-[11px] font-mono text-emerald-700 font-bold bg-white/70 rounded-xl flex items-center justify-center gap-1">
                    <Check size={14} />
                    <span>Laporan kemajuan tuntas terkonfirmasi.</span>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmitProofFinish} className="space-y-4">
                  <div className="flex items-center gap-1.5 text-[11px] font-black font-mono text-amber-600 uppercase">
                    <CheckSquare size={13} />
                    <span>Kirim Bukti Penyelesaian Tugas</span>
                  </div>

                  {/* Drag and drop image upload area */}
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-5 rounded-2xl border-2 border-dashed border-slate-205 bg-slate-50 hover:bg-slate-100/50 hover:border-[#0B4F8C]/40 transition text-center cursor-pointer space-y-2 select-none relative"
                  >
                    <input 
                      type="file" 
                      accept="image/*" 
                      ref={fileInputRef} 
                      onChange={handleFileChange} 
                      className="hidden" 
                    />
                    
                    {previewUrl ? (
                      <div className="relative h-40 w-full rounded-xl overflow-hidden shadow-inner border border-slate-150">
                        <img 
                          src={previewUrl} 
                          alt="preview" 
                          className="w-full h-full object-cover" 
                          referrerPolicy="no-referrer"
                        />
                        <button 
                          type="button" 
                          onClick={(e) => {
                            e.stopPropagation();
                            setPreviewUrl(null);
                            setProofPhoto('');
                          }}
                          className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 rounded-full text-white cursor-pointer"
                        >
                          <X size={13} />
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Upload className="mx-auto text-slate-400 w-7 h-7" />
                        <p className="text-xs font-bold text-slate-705">Ketuk/Unggah Foto Hasil Progres Lapangan</p>
                        <p className="text-[10px] text-slate-400 font-mono">Format JPG/PNG s/d 10 Megabytes</p>
                      </div>
                    )}
                  </div>

                  {/* Text statement description */}
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold font-mono uppercase text-slate-400">Statement Laporan Hasil Lapangan</label>
                    <textarea 
                      required
                      placeholder="Tulis ringkasan kemajuan atau hambatan lapangan di sini..."
                      value={proofDesc}
                      onChange={(e) => setProofDesc(e.target.value)}
                      rows={2}
                      className="w-full p-2.5 text-xs text-slate-800 bg-white border border-slate-200 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C]/40 rounded-xl"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingProof || !proofPhoto}
                    className="w-full py-3 bg-[#0B4F8C] hover:bg-[#0B4F8C]/90 text-white font-extrabold text-xs rounded-xl cursor-pointer active:scale-95 transition disabled:opacity-40 text-center"
                  >
                    {submittingProof ? 'Mengirim data...' : 'Kirim Laporan & Foto Tuntas'}
                  </button>
                </form>
              )}

            </motion.div>
          ) : (
            <div className="p-20 text-center text-slate-400 font-mono italic bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-center items-center gap-2">
              <span>👈</span>
              <span>Klik salah satu arahan / tugas KORKAB di daftar kiri untuk memulai koordinasi dan mengunggah foto progres.</span>
            </div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
