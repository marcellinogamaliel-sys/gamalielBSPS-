/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AlertTriangle, CheckCircle2, ShieldAlert, Filter, 
  Search, Plus, ClipboardList, Eye, Trash2 
} from 'lucide-react';
import { Finding, Recipient, Village, Store } from '../types';
import { formatDateOnly } from '../utils';

interface FindingsManagerProps {
  findings: Finding[];
  recipients: Recipient[];
  villages: Village[];
  stores: Store[];
  operatorId: string;
  onAddFinding: (recipientId: string, data: any) => Promise<void>;
  onResolveFinding: (findingId: string) => Promise<void>;
  onNavigate: (path: string, recipientId?: string) => void;
  showToast: (message: string, type: 'success' | 'error') => void;
}

export default function FindingsManager({
  findings,
  recipients,
  villages,
  stores,
  operatorId,
  onAddFinding,
  onResolveFinding,
  onNavigate,
  showToast
}: FindingsManagerProps) {
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'resolved'>('active');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Local state to keep track of findings that are currently animating their resolve transition
  const [resolvingIds, setResolvingIds] = useState<Record<string, boolean>>({});

  // Form toggle
  const [showForm, setShowForm] = useState(false);
  
  // New Finding fields
  const [newFinding, setNewFinding] = useState({
    recipient_id: '',
    category: 'material_shortage',
    description: ''
  });

  const handleResolve = async (findingId: string) => {
    setResolvingIds(prev => ({ ...prev, [findingId]: true }));
    // Wait for the gorgeous celebration and color transition to play
    await new Promise(resolve => setTimeout(resolve, 1100));
    try {
      await onResolveFinding(findingId);
    } catch (err: any) {
      setResolvingIds(prev => {
        const updated = { ...prev };
        delete updated[findingId];
        return updated;
      });
      showToast("Gagal menyelesaikan temuan", "error");
    }
  };

  const CATEGORIES = [
    { value: 'material_discrepancy', label: 'Selisih Volume Material' },
    { value: 'material_shortage', label: 'Pengiriman Kurang' },
    { value: 'no_receipt', label: 'Berkas Nota/Kuintansi Nihil' },
    { value: 'no_photo', label: 'Lampiran Foto Tidak Lengkap' },
    { value: 'no_video', label: 'Lampiran Video Tidak Valid' },
    { value: 'gps_mismatch', label: 'GPS Mismatch diluar radius' },
    { value: 'material_quality', label: 'Kualitas Bahan Buruk / Rusak' }
  ];

  // Filter reported issues list
  const filteredFindings = findings.filter(f => {
    const r = recipients.find(pb => pb.id === f.recipient_id);
    const pbName = r?.full_name.toLowerCase() || '';

    const matchesSearch = pbName.includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || 
                          (statusFilter === 'active' && !f.resolved) ||
                          (statusFilter === 'resolved' && f.resolved);
    const matchesCategory = categoryFilter === 'all' || f.category === categoryFilter;

    return matchesSearch && matchesStatus && matchesCategory;
  });

  const getCategoryLabel = (val: string) => {
    return CATEGORIES.find(c => c.value === val)?.label || val;
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFinding.recipient_id || !newFinding.description.trim()) {
      showToast("lengkapi data", "error");
      return;
    }

    try {
      await onAddFinding(newFinding.recipient_id, {
        category: newFinding.category,
        description: newFinding.description
      });
      setNewFinding({ recipient_id: '', category: 'material_shortage', description: '' });
      setShowForm(false);
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner and Add Action */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 flex items-center gap-1.5 font-sans">
            <ShieldAlert size={20} className="text-red-600 animate-pulse" />
            Pengendalian Temuan & Kendala Lapangan
          </h2>
          <p className="text-xs text-slate-500">Mencatat, memverifikasi, dan melacak penyelesaian masalah material program BSPS 2026.</p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition active:scale-95 shadow-xs"
        >
          {showForm ? 'Tutup Formulir' : 'Laporkan Temuan Baru'}
        </button>
      </div>

      {/* FORM: INPUT TEMUAN BARU */}
      {showForm && (
        <form onSubmit={handleFormSubmit} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4 animate-fadeIn">
          <h3 className="text-xs font-bold font-mono text-slate-800 uppercase tracking-wider border-b border-slate-150 pb-2">
            Formulir Pengaduan Kendala Material Lapangan
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Choose Resident */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Pilih Penerima Bantuan (PB)</label>
              <select
                required
                value={newFinding.recipient_id}
                onChange={(e) => setNewFinding(prev => ({ ...prev, recipient_id: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none"
              >
                <option value="">-- Cari Nama Warga PB --</option>
                {recipients.map(pb => (
                  <option key={pb.id} value={pb.id}>{pb.full_name} ({pb.nik})</option>
                ))}
              </select>
            </div>

            {/* Choose Category */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Kategori Masalah</label>
              <select
                required
                value={newFinding.category}
                onChange={(e) => setNewFinding(prev => ({ ...prev, category: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat.value} value={cat.value}>{cat.label}</option>
                ))}
              </select>
            </div>

            {/* Description field */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Deskripsi Kendala/Bukti Penyimpangan</label>
              <input
                required
                type="text"
                placeholder="Contoh: Semen merk X rusak kena air / Pasir bercampur tanah liat"
                value={newFinding.description}
                onChange={(e) => setNewFinding(prev => ({ ...prev, description: e.target.value }))}
                className="w-full py-2 px-3 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 text-xs border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl"
            >
              Batalkan
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl cursor-pointer"
            >
              Laporkan Laporan Temuan
            </button>
          </div>
        </form>
      )}

      {/* FILTER SEARCH PANEL */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="relative col-span-1 sm:col-span-2">
          <Search size={14} className="absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Cari PB berdasarkan Nama..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8 pr-3 py-2 w-full text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          >
            <option value="active">Lihat Temuan Aktif (Belum Selesai)</option>
            <option value="resolved">Lihat Temuan Selesai (Diselesaikan)</option>
            <option value="all">Melihat Seluruh Temuan</option>
          </select>
        </div>

        <div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full py-2 px-3 text-xs rounded-xl border border-slate-200 focus:outline-none bg-slate-50/50"
          >
            <option value="all">Seluruh Kategori Kendala</option>
            {CATEGORIES.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* RESULTS LIST FOR FINDINGS */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="divide-y divide-slate-100 flex flex-col">
          <AnimatePresence mode="popLayout">
            {filteredFindings.length === 0 ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-12 text-center text-slate-400 text-xs"
              >
                Tidak ada data laporan temuan pengendali yang sesuai filter pilihan.
              </motion.div>
            ) : (
              filteredFindings.map(f => {
                const r = recipients.find(pb => pb.id === f.recipient_id);
                const villageName = r ? villages.find(v => v.id === r.village_id)?.name : '-';
                const storeName = r ? stores.find(s => s.id === r.store_id)?.name : '-';
                const isResolved = f.resolved || !!resolvingIds[f.id];

                return (
                  <motion.div 
                    key={f.id} 
                    layout
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ 
                      opacity: 1, 
                      y: 0,
                      backgroundColor: isResolved ? "rgba(240, 253, 244, 0.4)" : "rgba(255, 255, 255, 1)",
                      borderColor: isResolved ? "rgb(187, 247, 208)" : "rgb(243, 244, 246)"
                    }}
                    exit={{ opacity: 0, x: -50, scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 350, damping: 28 }}
                    className="p-4 sm:p-5 flex flex-col md:flex-row justify-between md:items-center gap-4 hover:bg-slate-50/50 transition-all leading-relaxed relative border-b border-slate-150 last:border-b-0"
                  >
                    
                    <div className="space-y-1.5 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <motion.span 
                          layout
                          animate={{
                            scale: isResolved ? [1, 1.15, 1] : 1,
                            backgroundColor: isResolved ? "#ecfdf5" : "#fef2f2",
                            color: isResolved ? "#047857" : "#dc2626",
                            borderColor: isResolved ? "#a7f3d0" : "#fecaca"
                          }}
                          transition={{ type: "spring", stiffness: 500, damping: 25 }}
                          className="text-[9px] font-bold font-mono px-2 py-0.5 rounded border uppercase flex items-center gap-1.5"
                        >
                          {isResolved ? (
                            <motion.span
                              initial={{ scale: 0, rotate: -45 }}
                              animate={{ scale: 1, rotate: 0 }}
                              className="font-black text-emerald-600 block text-[10px]"
                            >
                              ✓
                            </motion.span>
                          ) : (
                            <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping inline-block shrink-0" />
                          )}
                          {isResolved ? 'Terselesaikan' : 'Masalah Aktif'}
                        </motion.span>
                        <span className="text-xs font-bold text-slate-800 font-mono">
                          [{getCategoryLabel(f.category)}]
                        </span>
                      </div>

                      <p className="text-sm font-semibold text-slate-900">
                        Warga PB: <span className="text-slate-800 font-extrabold">{r?.full_name || "PB tidak ditemukan"}</span>
                      </p>

                      <p className="text-xs text-slate-600 font-sans italic p-2 bg-slate-50 border border-slate-150 rounded-lg max-w-2xl">
                        "{f.description}"
                      </p>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-500 font-mono">
                        <span>Desa: {villageName}</span>
                        <span>&bull;</span>
                        <span>Penyedia: {storeName}</span>
                        <span>&bull;</span>
                        <span>Tgl Laporan: {formatDateOnly(f.created_at)}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      <button
                        onClick={() => onNavigate('recipient_detail', f.recipient_id)}
                        className="p-1 px-2.5 border border-slate-200 hover:bg-slate-105 rounded-xl text-[11px] font-bold text-slate-700 flex items-center gap-1 cursor-pointer transition bg-white"
                      >
                        <Eye size={12} />
                        Detail DRPB Warga
                      </button>

                      {!isResolved && (
                        <button
                          onClick={async () => {
                            if (confirm("Nyatakan laporan temuan ini diselesaikan dan material diposisikan sudah sesuai standard?")) {
                              await handleResolve(f.id);
                            }
                          }}
                          className="py-1 px-3 bg-emerald-600 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs cursor-pointer active:scale-95 transition"
                        >
                          Selesaikan Temuan
                        </button>
                      )}
                      {isResolved && (
                        <motion.span
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="text-[11px] font-extrabold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-xl flex items-center gap-1 select-none"
                        >
                          🎉 Sukses
                        </motion.span>
                      )}
                    </div>

                  </motion.div>
                );
              })
            )}
          </AnimatePresence>
        </div>
      </div>

    </div>
  );
}
