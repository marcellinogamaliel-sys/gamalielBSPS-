/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface MapControlsProps {
  mapStyle: 'dark' | 'satellite' | 'terrain' | 'light';
  setMapStyle: (style: 'dark' | 'satellite' | 'terrain' | 'light') => void;
  showMarkers: boolean;
  setShowMarkers: (val: boolean) => void;
  showClusters: boolean;
  setShowClusters: (val: boolean) => void;
  showHeatmap: boolean;
  setShowHeatmap: (val: boolean) => void;
  showRadius: boolean;
  setShowRadius: (val: boolean) => void;
  isHeatmapSupported: boolean;
}

export default function MapControls({
  mapStyle,
  setMapStyle,
  showMarkers,
  setShowMarkers,
  showClusters,
  setShowClusters,
  showHeatmap,
  setShowHeatmap,
  showRadius,
  setShowRadius,
  isHeatmapSupported
}: MapControlsProps) {
  return (
    <div className="space-y-3.5">
      {/* Boxed Corak Peta */}
      <div className="space-y-1">
        <span className="text-[8.5px] font-black font-mono tracking-widest text-slate-400 block uppercase">🎨 Corak Peta</span>
        <div className="grid grid-cols-2 gap-1.5 text-[9px]">
          <button 
            id="map-style-satellite-btn"
            onClick={() => setMapStyle('satellite')} 
            className={`py-2 rounded font-bold border transition cursor-pointer ${mapStyle === 'satellite' ? 'bg-indigo-600 border-indigo-500 text-white shadow-md font-extrabold' : 'bg-slate-800/60 border-slate-750 text-slate-350 hover:bg-slate-700'}`}
          >
            🛰️ Satelit
          </button>
          <button 
            id="map-style-terrain-btn"
            onClick={() => setMapStyle('terrain')} 
            className={`py-2 rounded font-bold border transition cursor-pointer ${mapStyle === 'terrain' ? 'bg-indigo-600 border-indigo-500 text-white shadow-md font-extrabold' : 'bg-slate-800/60 border-slate-750 text-slate-350 hover:bg-slate-700'}`}
          >
            🏔️ Relief
          </button>
        </div>
      </div>

      {/* Layaring toggling switches */}
      <div className="space-y-1.5 border-t border-slate-750 pt-2 text-[10.5px]">
        <span className="text-[8.5px] font-black font-mono tracking-widest text-slate-400 block uppercase">👁️ TAMPILAN ELEMEN</span>
        
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input 
            id="map-element-markers-checkbox"
            type="checkbox" 
            checked={showMarkers} 
            onChange={(e) => setShowMarkers(e.target.checked)} 
            className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0 w-3.5 h-3.5 cursor-pointer"
          />
          <span className="text-slate-200">Individu (Pins)</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input 
            id="map-element-clusters-checkbox"
            type="checkbox" 
            checked={showClusters} 
            onChange={(e) => setShowClusters(e.target.checked)} 
            className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0 w-3.5 h-3.5 cursor-pointer"
          />
          <span className="text-slate-200">Kelompokan (Clustering)</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input 
            id="map-element-heatmap-checkbox"
            type="checkbox" 
            checked={showHeatmap} 
            onChange={(e) => setShowHeatmap(e.target.checked)} 
            className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0 w-3.5 h-3.5 cursor-pointer"
          />
          <span className={`text-slate-250 font-bold ${showHeatmap ? 'text-orange-400' : ''}`}>
            🔥 Peta Panas (Heatmap)
            {!isHeatmapSupported && <span className="text-[7.5px] font-normal text-slate-500 block"> (tidak dimuat)</span>}
          </span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input 
            id="map-element-radius-checkbox"
            type="checkbox" 
            checked={showRadius} 
            onChange={(e) => setShowRadius(e.target.checked)} 
            className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0 w-3.5 h-3.5 cursor-pointer"
          />
          <span className="text-slate-200">Radius Distribusi Desa</span>
        </label>
      </div>
    </div>
  );
}
