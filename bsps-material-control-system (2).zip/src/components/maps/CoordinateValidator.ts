/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Validates whether coordinates are valid, non-zero, and not empty
export function isValidCoordinate(lat: any, lng: any): boolean {
  if (lat === null || lat === undefined || lat === '' || lat === 0) return false;
  if (lng === null || lng === undefined || lng === '' || lng === 0) return false;
  
  const nLat = Number(lat);
  const nLng = Number(lng);
  
  if (isNaN(nLat) || isNaN(nLng)) return false;
  
  // Checking boundary margins to prevent coordinate corruption
  if (nLat === 0 && nLng === 0) return false;
  if (nLat < -90 || nLat > 90) return false;
  if (nLng < -180 || nLng > 180) return false;
  
  return true;
}
