/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Village } from '../../types';

interface MapFiltersProps {
  villages: Village[];
  selectedVillageFilter: string;
  setSelectedVillageFilter: (val: string) => void;
  selectedProgressFilter: string;
  setSelectedProgressFilter: (val: string) => void;
  selectedStatusFilter: string;
  setSelectedStatusFilter: (val: string) => void;
}

export default function MapFilters({
  villages,
  selectedVillageFilter,
  setSelectedVillageFilter,
  selectedProgressFilter,
  setSelectedProgressFilter,
  selectedStatusFilter,
  setSelectedStatusFilter
}: MapFiltersProps) {
  return (
    <div className="space-y-1.5 border-t border-slate-750 pt-2">
      <span className="text-[8.5px] font-black font-mono tracking-widest text-slate-400 block uppercase">🎛️ PENYARING DATA</span>
      
      <div className="space-y-1.5 text-[10px]">
        {/* Desa Filter */}
        <select 
          id="map-filter-desa-selector"
          value={selectedVillageFilter} 
          onChange={(e) => setSelectedVillageFilter(e.target.value)}
          className="w-full bg-slate-800/80 border border-slate-700 rounded-lg py-1 px-1.5 text-white outline-none text-[10.5px] focus:ring-1 focus:ring-indigo-500 cursor-pointer"
        >
          <option value="all">📍 Semua Desa</option>
          {villages.map(v => (
            <option key={v.id} value={v.id}>🏘️ {v.name}</option>
          ))}
        </select>

        {/* Progress Filter */}
        <select 
          id="map-filter-progress-selector"
          value={selectedProgressFilter} 
          onChange={(e) => setSelectedProgressFilter(e.target.value)}
          className="w-full bg-slate-800/80 border border-slate-700 rounded-lg py-1 px-1.5 text-white outline-none text-[10.5px] focus:ring-1 focus:ring-indigo-500 cursor-pointer"
        >
          <option value="all">📈 Semua Tingkat Progres</option>
          <option value="complete">✅ Selesai (100%)</option>
          <option value="process">🏗️ Konstruksi (1-99%)</option>
          <option value="unstarted">❗ Belum Mulai (0%)</option>
        </select>

        {/* Technical status */}
        <select 
          id="map-filter-status-selector"
          value={selectedStatusFilter} 
          onChange={(e) => setSelectedStatusFilter(e.target.value)}
          className="w-full bg-slate-800/80 border border-slate-700 rounded-lg py-1 px-1.5 text-white outline-none text-[10.5px] focus:ring-1 focus:ring-indigo-500 cursor-pointer"
        >
          <option value="all">🔍 Semua Status Sistem</option>
          <option value="complete">Lengkap & Diterima</option>
          <option value="in_progress">Sedang Distribusi</option>
          <option value="not_started">Dalam Antrean</option>
          <option value="has_finding">⚠️ Temuan Audit</option>
        </select>
      </div>
    </div>
  );
}
