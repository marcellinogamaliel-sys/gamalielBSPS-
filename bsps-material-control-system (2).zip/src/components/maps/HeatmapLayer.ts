/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { isValidCoordinate } from './CoordinateValidator';

export function isHeatmapAvailable(L: any): boolean {
  if (!L) return false;
  return typeof L.heatLayer === 'function';
}

export function drawHeatmap(
  L: any, 
  map: any, 
  filteredPBs: any[], 
  onWarning?: (msg: string) => void
): any {
  if (!L || !map) return null;
  
  // Verify heatmap plugin availability
  if (!isHeatmapAvailable(L)) {
    console.warn("Leaflet Heatmap plugin (L.heatLayer) is not available. Falling back to normal marker pins.");
    if (onWarning) {
      onWarning("Plugin heatmap tidak tersedia. Menggunakan penanda normal.");
    }
    return null;
  }
  
  const heatData: [number, number, number][] = [];
  
  filteredPBs.forEach(pb => {
    const lat = Number(pb.latitude);
    const lng = Number(pb.longitude);
    
    if (isValidCoordinate(lat, lng)) {
      // Progress inverse: those with 0% progress represent immediate urgency, thus high heatmap weight
      const intensity = (100 - pb.progress) / 100;
      heatData.push([lat, lng, intensity]);
    }
  });

  try {
    const heatmapLayer = L.heatLayer(heatData, {
      radius: 40,
      blur: 25,
      maxZoom: 17,
      gradient: {
        0.0: '#22c55e', // Green
        0.3: '#3b82f6', // Blue
        0.6: '#eab308', // Yellow
        0.8: '#f97316', // Orange
        1.0: '#ef4444'  // Red (Needs Urgent supply)
      }
    }).addTo(map);
    
    return heatmapLayer;
  } catch (err) {
    console.error("Error drawing heatmap: ", err);
    return null;
  }
}
