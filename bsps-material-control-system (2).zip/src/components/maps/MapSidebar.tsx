/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Target, ShieldAlert, Check, Clock, AlertTriangle } from 'lucide-react';
import { Recipient, Store, DRPBItem, Distribution } from '../../types';

interface MapSidebarProps {
  activePin: any | null;
  setActivePin: (val: any | null) => void;
  filteredPBs: any[];
  mappedPBs: any[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  flyToPB: (pbId: string) => void;
  onNavigate: (path: string, recipientId?: string) => void;
  isFullscreen: boolean;
}

export default function MapSidebar({
  activePin,
  setActivePin,
  filteredPBs,
  mappedPBs,
  drpbItems,
  distributions,
  flyToPB,
  onNavigate,
  isFullscreen
}: MapSidebarProps) {
  
  // Safe computation of materials progress for active recipient
  const activePinChecklist = React.useMemo(() => {
    if (!activePin || 'owner_name' in activePin) return [];
    
    const rChecklist = drpbItems.filter(item => item.recipient_id === activePin.id);
    return rChecklist.map(item => {
      const deliveredVol = distributions
        .filter(dist => dist.recipient_id === activePin.id && dist.drpb_item_id === item.id)
        .reduce((sum, curr) => sum + Number(curr.volume), 0);
      return {
        ...item,
        deliveredVol,
        isCompleted: deliveredVol >= item.required_qty
      };
    });
  }, [activePin, drpbItems, distributions]);

  return (
    <div className={`flex flex-col gap-4 ${isFullscreen ? 'h-full shrink-0' : 'flex-1'}`}>
      {activePin ? (
        'owner_name' in activePin ? (
          // Partner Store Card (simplified focus on material delivery source)
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white shadow-lg flex-1 flex flex-col justify-between bg-gradient-to-br from-slate-900 to-indigo-950/20 max-h-full overflow-y-auto">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-black font-mono tracking-widest text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2 py-0.5 rounded uppercase">Mitra Dropping Bahan</span>
                <button 
                  onClick={() => setActivePin(null)} 
                  className="p-1 hover:bg-slate-800 rounded-full text-slate-400 transition cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/15 flex items-center justify-center text-lg border border-sky-500/10">🏪</div>
                <div>
                  <h4 className="text-sm font-bold text-white tracking-tight leading-none">{activePin.name}</h4>
                  <p className="text-[11px] text-slate-400 mt-1">Pemilik: {activePin.owner_name}</p>
                </div>
              </div>

              {/* Served Recipients Material Drop List */}
              <div className="border-t border-slate-800 pt-4">
                <span className="text-slate-400 text-[9px] font-extrabold font-mono tracking-widest block uppercase mb-2">
                  PB YANG DILAYANI BELANJA:
                </span>
                {mappedPBs.filter(p => p.store_id === activePin.id).length === 0 ? (
                  <span className="text-[10px] text-slate-500 italic block">Tidak ada PB terdaftar di toko ini.</span>
                ) : (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {mappedPBs.filter(p => p.store_id === activePin.id).map(sp => (
                      <div 
                        key={sp.id} 
                        onClick={() => flyToPB(sp.id)}
                        className="p-2 rounded-xl bg-slate-800/40 border border-slate-800/50 hover:bg-slate-800 transition cursor-pointer flex items-center justify-between"
                      >
                        <div className="truncate pr-2">
                          <p className="text-[11px] font-bold text-white truncate leading-none">{sp.nama}</p>
                          <p className="text-[9.5px] text-slate-400 font-mono mt-1">NIK {sp.nik}</p>
                        </div>
                        <span className="text-[8px] font-black text-indigo-400 px-1.5 py-0.5 rounded bg-indigo-950/40">{sp.progress}%</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <button 
              onClick={() => onNavigate('stores', activePin.id)}
              className="w-full mt-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
            >
              Portal Stok Toko
            </button>
          </div>
        ) : (
          // Simplified Recipient PB card focusing purely on Names, Materials, and volume metrics
          <div className="bg-white border-2 border-slate-200 rounded-3xl p-5 shadow-lg flex-1 flex flex-col justify-between max-h-full overflow-y-auto text-slate-850">
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <span className={`text-[10px] font-black uppercase px-2 py-0.5 tracking-wider rounded border ${
                  activePin.status === 'complete' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                  'bg-amber-50 text-amber-600 border-amber-200'
                }`}>
                  PB: {activePin.status === 'complete' ? 'Lunas' : 'Konstruksi'}
                </span>
                <button 
                  onClick={() => setActivePin(null)} 
                  className="p-1 hover:bg-slate-100 rounded-full text-slate-400 cursor-pointer text-slate-450 transition"
                >
                  <X size={14} />
                </button>
              </div>

              <div>
                <h4 className="text-sm font-extrabold text-slate-900 leading-tight tracking-tight">{activePin.nama}</h4>
                <p className="text-[10px] text-indigo-700 font-bold mt-1"> Desa: {activePin.desa}</p>
              </div>

              {/* Material Items Checker checklist layout */}
              <div className="space-y-2 border-t border-slate-100 pt-3">
                <span className="text-[9.5px] font-black text-slate-400 font-mono tracking-wider uppercase block">DAFTAR MATERIAL &amp; VOLUME:</span>
                <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                  {activePinChecklist.length === 0 ? (
                    <span className="text-xs text-slate-400 italic">Daftar material tidak tersedia.</span>
                  ) : (
                    activePinChecklist.map((it: any) => (
                      <div 
                        key={it.id} 
                        className={`p-2.5 rounded-xl border text-[11px] flex items-center justify-between ${
                          it.isCompleted 
                            ? 'bg-emerald-50/70 border-emerald-200/60 text-slate-800' 
                            : 'bg-slate-50 border-slate-150 text-slate-500'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          {it.isCompleted ? (
                            <span className="text-emerald-600 font-bold shrink-0">✓</span>
                          ) : (
                            <Clock size={11} className="text-slate-400 shrink-0" />
                          )}
                          <span className="font-semibold truncate">{it.material_type}</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold shrink-0">
                          {it.deliveredVol} / {it.required_qty} <small className="text-[8px] font-normal">{it.unit}</small>
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Simple Actions */}
            <div className="pt-3 border-t border-slate-100 flex flex-col gap-1.5 mt-4">
              <button 
                onClick={() => onNavigate('recipient_detail', activePin.id)}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition flex items-center justify-center gap-1"
              >
                Tinjau Rencana DRPB
              </button>
            </div>
          </div>
        )
      ) : (
        // Standard Active List Section (Empty active state)
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white shadow-lg flex-1 flex flex-col justify-between max-h-[480px] overflow-y-auto">
          <div className="space-y-3.5 flex-1 flex flex-col min-h-0">
            <div className="flex items-center gap-2">
              <Target size={14} className="text-indigo-400" />
              <span className="text-[10.5px] font-black font-mono tracking-widest text-slate-300 uppercase">
                DAFTAR PENERIMA BANTUAN ({filteredPBs.length})
              </span>
            </div>

            {filteredPBs.length === 0 ? (
              <div className="text-center py-10 space-y-2 text-slate-500 my-auto flex flex-col items-center">
                <AlertTriangle size={32} className="text-slate-600" />
                <span className="text-xs font-bold uppercase block">Data Kosong</span>
                <p className="text-[11.5px] text-slate-400 leading-relaxed max-w-[200px]">Penerima bantuan tidak ditemukan.</p>
              </div>
            ) : (
              <div className="space-y-2 overflow-y-auto max-h-[380px] pr-1.5 flex-1 select-none text-slate-100">
                {filteredPBs.map(pb => (
                  <div 
                    key={pb.id}
                    onClick={() => flyToPB(pb.id)}
                    className="p-3 bg-slate-800/50 border border-slate-805 hover:border-slate-700 rounded-2xl hover:bg-slate-800 transition cursor-pointer flex items-center justify-between"
                  >
                    <div className="truncate pr-3 w-full">
                      <p className="text-xs font-extrabold text-white truncate">{pb.nama}</p>
                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">NIK {pb.nik}</p>
                      <span className="text-[9.5px] text-indigo-400 font-medium mt-1 inline-block">🏘️ {pb.desa}</span>
                    </div>
                    <div className="text-right shrink-0 flex flex-col items-end gap-1">
                      <span className="text-xs font-extrabold font-mono text-slate-200">{pb.progress}%</span>
                      <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${
                        pb.status === 'complete' ? 'bg-emerald-500/20 text-emerald-400' :
                        'bg-amber-500/20 text-amber-400'
                      }`}>
                        {pb.status === 'complete' ? 'LKP' : 'PRG'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-3 bg-slate-800/60 border border-slate-800/50 rounded-2xl text-[10px] text-slate-400 mt-4 leading-normal flex gap-2">
            <ShieldAlert size={14} className="text-amber-500 shrink-0" />
            <p>
              Sistem memantau kesesuaian dropping barang di lapangan dari Toko penyedia ke koordinat lokasi BSPS.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
