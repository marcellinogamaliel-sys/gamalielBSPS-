/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function getColorByProgress(progress: number): string {
  if (progress >= 100) return '#22c55e'; // Green
  if (progress >= 75) return '#3b82f6';  // Blue
  if (progress >= 50) return '#eab308';  // Yellow
  if (progress >= 25) return '#f97316';  // Orange
  return '#ef4444';                      // Red
}

export function getMarkerConfig(progress: number) {
  if (progress >= 100) {
    return { color: '#22c55e', icon: '✅', animation: 'markerSparkle 2s infinite ease-in-out' };
  } else if (progress >= 75) {
    return { color: '#3b82f6', icon: '⚡', animation: 'markerGlow 2.5s infinite ease-in-out' };
  } else if (progress >= 50) {
    return { color: '#eab308', icon: '🔨', animation: 'markerRotate 5s infinite linear' };
  } else if (progress >= 25) {
    return { color: '#f97316', icon: '🏗️', animation: 'markerBounce 2.5s infinite ease-in-out' };
  } else {
    return { color: '#ef4444', icon: '❗', animation: 'markerPulse 1.8s infinite ease-in-out' };
  }
}

export function createAnimatedMarker(L: any, pb: any) {
  if (!L) return null;
  const config = getMarkerConfig(pb.progress);
  const markerHtml = `
    <div class="marker-wrapper" data-id="${pb.id}">
      <div class="radar-ring ring-1" style="border-color: ${config.color}; color: ${config.color}"></div>
      <div class="radar-ring ring-2" style="border-color: ${config.color}; color: ${config.color}"></div>
      <div class="marker-body" style="
        background: ${config.color};
        animation: ${config.animation};
        box-shadow: 0 4px 15px ${config.color}80;
      ">
        <span class="marker-icon">${config.icon}</span>
      </div>
      <div class="marker-tail" style="border-top-color: ${config.color}"></div>
      <div class="marker-badge">${pb.progress}%</div>
    </div>
  `;
  return L.divIcon({
    html: markerHtml,
    className: 'custom-marker',
    iconSize: [44, 54],
    iconAnchor: [22, 54],
    popupAnchor: [0, -54]
  });
}

export function createClusterIcon(L: any, cluster: any) {
  if (!L) return null;
  const count = cluster.getChildCount();
  const markers = cluster.getAllChildMarkers();
  
  // Safe computation of average progress from markers
  const progressValues = markers.map((m: any) => {
    if (m && m.options) {
      // Look under custom parameter, options property, or fallback
      return m.options.progress || 0;
    }
    return 0;
  });
  
  const avgProgress = progressValues.length > 0 
    ? progressValues.reduce((sum: number, p: number) => sum + p, 0) / progressValues.length
    : 0;
  const dominantColor = getColorByProgress(avgProgress);
  
  return L.divIcon({
    html: `
      <div class="cluster-wrapper">
        <div class="cluster-ring outer" style="border-color: ${dominantColor}50"></div>
        <div class="cluster-ring middle" style="border-color: ${dominantColor}80"></div>
        <div class="cluster-body" style="background: ${dominantColor}">
          <span class="cluster-count">${count}</span>
          <span class="cluster-label">PB</span>
        </div>
        <div class="cluster-mini-bar">
          <div style="width:${avgProgress}%; background: white; height: 3.5px; border-radius: 2px;"></div>
        </div>
      </div>
    `,
    className: 'custom-cluster',
    iconSize: [60, 60],
    iconAnchor: [30, 30]
  });
}
