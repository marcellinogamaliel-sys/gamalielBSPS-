/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Search, X } from 'lucide-react';

interface MapSearchProps {
  searchTerm: string;
  setSearchTerm: (val: string) => void;
}

export default function MapSearch({ searchTerm, setSearchTerm }: MapSearchProps) {
  return (
    <div className="absolute top-4 left-4 right-4 z-[1000] flex gap-2 max-w-sm pointer-events-auto">
      <div className="relative w-full shadow-2xl rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-700/60 p-1 flex items-center">
        <Search size={15} className="text-slate-400 ml-3" />
        <input
          id="map-recipient-search-input"
          type="text"
          placeholder="Cari penerima bantuan, desa, nik..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full text-xs text-white bg-transparent h-10 border-none outline-none pl-2 pr-2 placeholder:text-slate-500 focus:outline-none focus:ring-0"
        />
        {searchTerm && (
          <button 
            onClick={() => setSearchTerm('')} 
            className="p-1.5 text-slate-400 hover:text-white rounded-full cursor-pointer transition"
          >
            <X size={13} />
          </button>
        )}
      </div>
    </div>
  );
}
