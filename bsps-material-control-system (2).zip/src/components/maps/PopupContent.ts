/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { getMarkerConfig } from './RecipientMarker';

// Simple XSS security sanitize helper to avoid injecting dangerous html
export function sanitizeHTML(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

export function buildPopup(pb: any): string {
  const config = getMarkerConfig(pb.progress);
  const pbId = sanitizeHTML(pb.id.toString());
  const pbNama = sanitizeHTML(pb.nama || '');
  const pbDesa = sanitizeHTML(pb.desa || '');
  const pbStatus = sanitizeHTML(pb.status_material || '');
  
  return `
    <div class="pb-popup text-slate-100 p-2 font-sans space-y-2.5 min-w-[200px]" style="background: #0b0f19; border-radius: 12px;">
      <div class="flex items-center gap-2 border-b border-slate-800 pb-1.5" style="border-left: 3px solid ${config.color}; padding-left: 6px;">
        <div class="popup-identity">
          <div class="popup-name text-xs font-black tracking-tight text-white leading-tight">${pbNama}</div>
          <div class="popup-location text-[10px] text-slate-400 font-medium mt-0.5">🏘️ ${pbDesa}</div>
        </div>
      </div>
      
      <div class="space-y-1 text-[11px] text-slate-350">
        <div class="flex justify-between items-center bg-white/5 px-2 py-1 rounded">
          <span class="text-slate-400 font-medium">Status:</span>
          <span class="font-bold text-slate-200">${pbStatus}</span>
        </div>
        <div class="flex justify-between items-center bg-white/5 px-2 py-1 rounded">
          <span class="text-slate-400 font-medium">Progress Fisik:</span>
          <span class="font-black" style="color: ${config.color}">${pb.progress}%</span>
        </div>
      </div>
      
      <div class="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-slate-800">
        <button onclick="openPBDetail('${pbId}')" class="py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[10px] text-center shadow-sm cursor-pointer transition">
          Detail PB
        </button>
        <a href="https://www.google.com/maps/search/?api=1&query=${pb.latitude},${pb.longitude}" target="_blank" rel="noreferrer" class="py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold rounded text-[10px] text-center flex items-center justify-center cursor-pointer transition">
          Google Maps
        </a>
      </div>
    </div>
  `;
}
