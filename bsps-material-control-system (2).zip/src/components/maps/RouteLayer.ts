/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Store } from '../../types';
import { isValidCoordinate } from './CoordinateValidator';

export function drawRoutes(L: any, routeGroup: any, filteredPBs: any[], stores: Store[]) {
  if (!L || !routeGroup) return;
  
  routeGroup.clearLayers();
  
  filteredPBs.forEach(pb => {
    const pbLat = Number(pb.latitude);
    const pbLng = Number(pb.longitude);
    
    // Validate recipient coordinate first
    if (!isValidCoordinate(pbLat, pbLng)) return;
    
    const st = stores.find(s => s.id === pb.store_id);
    if (st) {
      const stLat = Number(st.latitude);
      const stLng = Number(st.longitude);
      
      // Validate store coordinate
      if (!isValidCoordinate(stLat, stLng)) return;
      
      const isComp = pb.status === 'complete';
      L.polyline([[pbLat, pbLng], [stLat, stLng]], {
        color: isComp ? '#22c55e' : '#eab308',
        weight: 1.5,
        dashArray: '5, 6',
        opacity: isComp ? 0.25 : 0.6
      }).addTo(routeGroup);
    }
  });
}
