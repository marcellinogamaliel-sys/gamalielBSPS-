/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Village } from '../../types';
import { isValidCoordinate } from './CoordinateValidator';

export function drawRadiusCircles(L: any, radiusGroup: any, mappedPBs: any[], villages: Village[]) {
  if (!L || !radiusGroup) return;
  
  radiusGroup.clearLayers();
  
  const desaColors: { [key: string]: string } = {
    'Desa A': '#7c83ff',
    'Desa B': '#4ade80',
    'Desa C': '#fbbf24',
    'Desa D': '#f87171'
  };

  villages.forEach(v => {
    // Only aggregate recipients with valid, clean coordinates
    const villagePBs = mappedPBs.filter(p => {
      const lat = Number(p.latitude);
      const lng = Number(p.longitude);
      return p.village_id === v.id && isValidCoordinate(lat, lng);
    });
    
    if (villagePBs.length === 0) return;

    const lats = villagePBs.map(p => Number(p.latitude));
    const lngs = villagePBs.map(p => Number(p.longitude));
    const avgLat = lats.reduce((a, b) => a + b, 0) / lats.length;
    const avgLng = lngs.reduce((a, b) => a + b, 0) / lngs.length;

    // Validate generated average center coordinate before laying down overlay
    if (!isValidCoordinate(avgLat, avgLng)) return;

    L.circle([avgLat, avgLng], {
      radius: 650,
      color: desaColors[v.name] || '#7c83ff',
      fillColor: desaColors[v.name] || '#7c83ff',
      fillOpacity: 0.08,
      weight: 2,
      dashArray: '8, 6'
    }).addTo(radiusGroup);

    L.marker([avgLat, avgLng], {
      icon: L.divIcon({
        html: `
          <div class="desa-label-text bg-slate-900/90 py-1 px-2.5 rounded-lg border border-slate-700/60 text-[10px] text-white font-bold whitespace-nowrap text-center">
            🏘️ ${v.name}<br>
            <small class="text-indigo-350 font-mono text-[8px] font-black">${villagePBs.length} PB AKTIF</small>
          </div>
        `,
        className: 'desa-label-icon',
        iconSize: [120, 42],
        iconAnchor: [60, 21]
      })
    }).addTo(radiusGroup);
  });
}
