/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Store } from '../../types';
import { sanitizeHTML } from './PopupContent';

export function createStoreIcon(L: any) {
  if (!L) return null;
  return L.divIcon({
    className: 'custom-store-pin-wrapper',
    html: `
      <div class="store-triangle-pulsing" style="position: relative; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
        <svg style="width: 32px; height: 32px;" viewBox="0 0 24 24" fill="#0ea5e9">
          <polygon points="12,2 2,20 22,20" stroke="#ffffff" stroke-width="2" stroke-linejoin="round" />
        </svg>
        <span style="position: absolute; font-size: 11px; top: 12px; left: 50%; transform: translateX(-50%);">🏪</span>
      </div>
    `,
    iconSize: [34, 34],
    iconAnchor: [17, 17]
  });
}

export function buildStorePopup(st: Store): string {
  const storeId = sanitizeHTML(st.id);
  const name = sanitizeHTML(st.name);
  const owner = sanitizeHTML(st.owner_name);
  const address = sanitizeHTML(st.address);
  
  return `
    <div class="p-2.5 space-y-2 text-xs font-sans min-w-[200px]" style="background: #0b0f19; color: #f1f5f9; border-radius: 12px;">
      <div class="font-extrabold flex items-center gap-1.5 text-sky-400 text-xs">
        <span>🏪</span> TOKO REKANAN
      </div>
      <div class="font-bold border-b border-slate-800 pb-1.5 text-white text-[12px]">${name}</div>
      <div class="space-y-1 text-slate-300 text-[10.5px]">
        <div>Pemilik: <span class="font-bold text-slate-100">${owner}</span></div>
        <div class="text-slate-400 mt-1 leading-normal">${address}</div>
      </div>
      <button onclick="focusOnMap(${Number(st.latitude)}, ${Number(st.longitude)})" class="w-full mt-1.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded font-bold text-[10px] transition cursor-pointer">
        📍 Fokus Jarak
      </button>
    </div>
  `;
}
