import React from 'react';
import { Recipient, Store, Village, Group, DRPBItem, Distribution, DistributionMedia, Finding } from '../types';

interface PublicViewerMapProps {
  recipients: Recipient[];
  stores: Store[];
  villages: Village[];
  groups: Group[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  distributionMedia: DistributionMedia[];
  findings: Finding[];
  onExit: () => void;
}

export default function PublicViewerMap({ onExit, recipients, stores, villages, groups, drpbItems, distributions, distributionMedia, findings }: PublicViewerMapProps) {
  return (
    <div className="p-10 text-white bg-slate-900 min-h-screen">
      <h1 className="text-2xl">Public Viewer Map</h1>
      <pre className="text-xs">{recipients.length} recipients loaded</pre>
      <button onClick={onExit} className="bg-slate-700 p-2 mt-4">Exit</button>
    </div>
  );
}
