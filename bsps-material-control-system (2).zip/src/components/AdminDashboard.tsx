import React, { useEffect, useState } from 'react';

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetch('/api/admin/stats', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('adminToken')}` }
    })
      .then(res => res.json())
      .then(data => setStats(data.stats));
  }, []);

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      {stats ? (
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4 bg-gray-100 rounded">Users: {stats.totalUsers}</div>
          <div className="p-4 bg-gray-100 rounded">Teams: {stats.totalTeams}</div>
          <div className="p-4 bg-gray-100 rounded">Recipients: {stats.totalRecipients}</div>
        </div>
      ) : <p>Loading...</p>}
    </div>
  );
};
