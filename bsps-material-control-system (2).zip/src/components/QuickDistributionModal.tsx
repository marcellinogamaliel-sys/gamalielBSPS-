import React, { useState, useMemo } from 'react';
import { 
  X, Search, Landmark, User, CheckCircle2, 
  ArrowRight, Calendar, FileText, ChevronRight, Check
} from 'lucide-react';
import { Recipient, Village, DRPBItem, Distribution } from '../types';

interface QuickDistributionModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipients: Recipient[];
  villages: Village[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  operatorId: string;
  onSave: (payload: any) => Promise<boolean>;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

// Draw transparent Slate HUD over image overlay with real GPS + Timestamp
const applyTimestampAndGps = (
  base64Str: string,
  pbName: string,
  gps: { latitude: number; longitude: number } | null
): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve(base64Str);
        return;
      }
      
      // Draw original image
      ctx.drawImage(img, 0, 0);
      
      const bannerHeight = Math.max(45, Math.round(canvas.height * 0.12));
      const fontSize = Math.max(12, Math.round(bannerHeight * 0.18));
      
      // 85% translucent Slate banner at the bottom
      ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
      ctx.fillRect(0, canvas.height - bannerHeight, canvas.width, bannerHeight);
      
      // Golden Amber accent bar at LHS
      ctx.fillStyle = "#f59e0b";
      ctx.fillRect(0, canvas.height - bannerHeight, Math.max(6, Math.round(canvas.width * 0.015)), bannerHeight);
      
      // Text configuration
      ctx.fillStyle = "#ffffff";
      ctx.font = `bold ${fontSize}px sans-serif`;
      ctx.textBaseline = "middle";
      
      const nowStr = new Date().toLocaleString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        timeZoneName: 'short'
      });
      
      const gpsStr = gps && gps.latitude && gps.longitude 
        ? `GPS: ${gps.latitude.toFixed(6)}°, ${gps.longitude.toFixed(6)}°` 
        : "GPS: Kordinat tidak terdeteksi (Aktifkan GPS perangkat)";
        
      const textX = Math.max(15, Math.round(canvas.width * 0.03));
      let textY = canvas.height - bannerHeight + (bannerHeight / 4);
      
      // Line 1: Recipient Fullname
      ctx.fillText(`Penerima: ${pbName.toUpperCase()}`, textX, textY);
      
      // Line 2: GPS coordinate
      ctx.font = `${fontSize - 2}px monospace`;
      ctx.fillStyle = "#cbd5e1";
      textY = canvas.height - bannerHeight + (bannerHeight / 1.7);
      ctx.fillText(gpsStr, textX, textY);
      
      // Line 3: System Timestamp & Program Stamp
      ctx.font = `${fontSize - 3}px monospace`;
      ctx.fillStyle = "#94a3b8";
      textY = canvas.height - bannerHeight + (bannerHeight / 1.15);
      ctx.fillText(`WAKTU VERIFIKASI: ${nowStr} | TFL SYSTEM BSPS`, textX, textY);
      
      resolve(canvas.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => {
      resolve(base64Str);
    };
    img.src = base64Str;
  });
};

export default function QuickDistributionModal({
  isOpen,
  onClose,
  recipients,
  villages,
  drpbItems,
  distributions,
  operatorId,
  onSave,
  showToast
}: QuickDistributionModalProps) {
  // Wizard States
  const [step, setStep] = useState<number>(1);
  const [searchTerm, setSearchTerm] = useState<string>('');
  
  // Selection States
  const [selectedPB, setSelectedPB] = useState<Recipient | null>(null);
  const [selectedStage, setSelectedStage] = useState<string>('0%');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('');
  const [volume, setVolume] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState<string>('');

  // Camera & Location Verification States
  const videoRef = React.useRef<HTMLVideoElement | null>(null);
  const [photoBase64, setPhotoBase64] = useState<string>('');
  const [gpsCoords, setGpsCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);

  // Fetch Geolocation automatically on Step 4
  React.useEffect(() => {
    if (step === 4 && !gpsCoords) {
      setIsLocating(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGpsCoords({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
          setIsLocating(false);
        },
        (error) => {
          console.warn("Unable to fetch GPS from geolocation API:", error);
          setIsLocating(false);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    }
  }, [step, gpsCoords]);

  // Clean stream on unmount
  React.useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  const startLiveStream = async () => {
    try {
      setIsCapturing(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      setCameraStream(stream);
      // Wait minor frame to let ref establish
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch (err) {
      console.warn("Live webcam stream access error, fallback to file capture:", err);
      showToast("Gagal mengakses kamera langsung. Silakan gunakan tombol Kamera Ponsel.", "error");
      setIsCapturing(false);
    }
  };

  const stopLiveStream = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
    }
    setCameraStream(null);
    setIsCapturing(false);
  };

  const handleCaptureFromStream = async () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      // Draw frame
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const rawBase64 = canvas.toDataURL("image/jpeg");
      
      // Stop webcam stream
      stopLiveStream();
      
      // Stamp the image
      const constStamped = await applyTimestampAndGps(rawBase64, selectedPB?.full_name || "BSPS", gpsCoords);
      setPhotoBase64(constStamped);
    }
  };

  const handleNativeImageChosen = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        const constStamped = await applyTimestampAndGps(base64, selectedPB?.full_name || "BSPS", gpsCoords);
        setPhotoBase64(constStamped);
      }
    };
    reader.readAsDataURL(file);
  };

  // Filtering Recipient List for Step 1
  const searchedPBList = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return recipients.filter(pb => 
      pb.full_name.toLowerCase().includes(term) ||
      pb.nik.includes(term) ||
      pb.id.toLowerCase().includes(term)
    );
  }, [recipients, searchTerm]);

  // Compute what DRPB materials are available and incomplete for selected PB
  const availableMaterials = useMemo(() => {
    if (!selectedPB) return [];
    
    const pbItems = drpbItems.filter(item => item.recipient_id === selectedPB.id);
    return pbItems.map(item => {
      const delivered = distributions
        .filter(d => d.drpb_item_id === item.id)
        .reduce((sum, curr) => sum + Number(curr.volume), 0);
      const remainingShortage = Math.max(0, item.required_qty - delivered);

      return {
        ...item,
        delivered,
        remainingShortage
      };
    }).filter(item => item.remainingShortage > 0);
  }, [selectedPB, drpbItems, distributions]);

  if (!isOpen) return null;

  // Navigation validations
  const handleNextStep = () => {
    if (step === 1) {
      if (!selectedPB) {
        showToast("Silakan tentukan Penerima Bantuan (PB) dahulu!", "error");
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!selectedStage) {
        showToast("Silakan pilih tahapan distribusi!", "error");
        return;
      }
      // Automap material option if materials exist
      if (availableMaterials.length > 0) {
        setSelectedMaterialId(availableMaterials[0].id);
        setVolume(availableMaterials[0].remainingShortage.toString());
      } else {
        showToast("Semua rencana alokasi DRPB untuk PB ini sudah terpenuhi lunas!", "error");
        return;
      }
      setStep(3);
    } else if (step === 3) {
      const volNum = Number(volume);
      if (isNaN(volNum) || volNum <= 0) {
        showToast("Masukkan volume pengiriman material yang valid dan > 0!", "error");
        return;
      }

      // Find selected item limit
      const selectedItemObj = availableMaterials.find(m => m.id === selectedMaterialId);
      if (selectedItemObj && volNum > selectedItemObj.remainingShortage) {
        showToast(`Volume input (${volNum}) melebihi sisa kekurangan DRPB (${selectedItemObj.remainingShortage})!`, "error");
        return;
      }

      setStep(4);
    }
  };

  const handlePrevStep = () => {
    setStep(prev => Math.max(1, prev - 1));
  };

  // Quick dispatch submission
  const handleSubmitFast = async () => {
    if (!selectedPB || !selectedMaterialId) return;

    if (!photoBase64) {
      showToast("Bukti foto serah terima wajib diambil terlebih dahulu sebelum menyimpan!", "error");
      return;
    }

    const payload = {
      recipient_id: selectedPB.id,
      drpb_item_id: selectedMaterialId,
      volume: Number(volume),
      distribution_date: date,
      shortage_reason: "",
      shortage_notes: "Dicatat melalui modul Penyaluran Cepat",
      notes: notes,
      photo_during: photoBase64,
      gps_latitude: gpsCoords?.latitude,
      gps_longitude: gpsCoords?.longitude,
      operator_id: operatorId
    };

    const success = await onSave(payload);
    if (success) {
      // Clear variables on success
      setSelectedPB(null);
      setVolume('');
      setPhotoBase64('');
      setStep(1);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-xl overflow-hidden animate-scaleUp border border-slate-200 flex flex-col max-h-[85vh]">
        
        {/* Header bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex justify-between items-center select-none shrink-0">
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-amber-500 animate-ping mr-1" />
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-100 font-mono">
              Tambah Penyaluran Cepat (Step {step}/4)
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"
          >
            <X size={16} />
          </button>
        </div>

        {/* Dynamic step bar visualizer */}
        <div className="bg-slate-50 border-b border-slate-150 p-2.5 px-6 grid grid-cols-4 gap-2 text-center text-[10px] font-bold shrink-0">
          {[
            { tag: "1", title: "Pilih PB" },
            { tag: "2", title: "Pilih Tahap" },
            { tag: "3", title: "Detail Bahan" },
            { tag: "4", title: "Konfirmasi" }
          ].map((s, idx) => (
            <div 
              key={idx} 
              className={`pb-1 flex items-center justify-center gap-1 border-b-2 transition ${
                step === (idx + 1) 
                  ? 'border-indigo-600 text-indigo-700 font-extrabold' 
                  : (step > (idx + 1) ? 'border-emerald-500 text-emerald-600' : 'border-slate-200 text-slate-400')
              }`}
            >
              <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] ${
                step >= (idx + 1) ? 'bg-indigo-650 text-white' : 'bg-slate-100 text-slate-400'
              }`}>
                {s.tag}
              </span>
              <span className="hidden sm:inline">{s.title}</span>
            </div>
          ))}
        </div>

        {/* Step Container */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">

          {/* STEP 1: SELECT PB WHATEVER SEARCHING IN REALTIME */}
          {step === 1 && (
            <div className="space-y-3.5">
              <span className="text-[10px] font-black font-mono text-zinc-550 block uppercase tracking-wide">
                LANGKAH 1: CARI &amp; TENTUKAN PENERIMA BANTUAN (PB)
              </span>
              
              <div className="relative">
                <Search className="absolute left-3 top-2.5 text-slate-400" size={13} />
                <input 
                  type="text"
                  placeholder="Ketik nama lengkap warga, NIK, atau ID PB..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full text-xs pl-8 pr-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-indigo-650"
                  autoFocus
                />
              </div>

              {/* Scrollable searchable PB lists */}
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {searchedPBList.slice(0, 15).map(pb => {
                  const isSelected = selectedPB?.id === pb.id;
                  const vName = villages.find(v => v.id === pb.village_id)?.name || "Desa";
                  return (
                    <div 
                      key={pb.id}
                      onClick={() => setSelectedPB(pb)}
                      className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between text-xs active:scale-98 select-none ${
                        isSelected 
                          ? 'bg-indigo-50 border-indigo-350 text-indigo-900 shadow-sm' 
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      <div>
                        <span className="font-extrabold text-sm block uppercase text-slate-850">{pb.full_name}</span>
                        <span className="text-[10px] text-slate-450 font-mono">Desa {vName} &bull; NIK: {pb.nik}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-indigo-600 shadow-xs shadow-indigo-400" />}
                        <span className="text-[10.5px] uppercase font-bold text-slate-500 font-mono bg-slate-100 px-1.8 py-0.5 rounded">
                          {pb.status === 'complete' ? 'SELESAI' : 'PROSES'}
                        </span>
                      </div>
                    </div>
                  );
                })}
                {searchedPBList.length === 0 && (
                  <div className="p-8 text-center text-slate-400 italic text-xs">
                    Warga tidak ditemukan. Coba keyword pencarian yang lain.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 2: CHOOSE DISTRIBUTION STAGE COMPLIANT TO SYSTEM ENUM */}
          {step === 2 && selectedPB && (
            <div className="space-y-4">
              <span className="text-[10px] font-black font-mono text-zinc-550 block uppercase tracking-wide">
                LANGKAH 2: TENTUKAN TAHAP REALISASI FISIK
              </span>

              <div className="p-4 bg-slate-10/50 border border-slate-200 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-500 font-mono block uppercase">Warga Terpilih:</span>
                  <span className="text-sm font-black text-slate-900 uppercase">{selectedPB.full_name}</span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] text-slate-550 block uppercase font-mono">Status Saat Ini:</span>
                  <span className="text-xs font-bold text-amber-600 uppercase bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    {selectedPB.status === 'in_progress' ? 'KONS. FISIK' : (selectedPB.status === 'complete' ? '100% LAYAK' : 'PERSIAPAN')}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3.5 text-xs">
                {[
                  { id: '0%', title: "Tahap 0% (Sebelum Konstruksi)", desc: "Pengiriman material pondasi awal, batu kali, pasir pasang, semen." },
                  { id: '50%', title: "Tahap 50% (Tengah Pembangunan)", desc: "Pengiriman batu bata, material kayu balok, splay tiang, kawat." },
                  { id: '100%', title: "Tahap 100% (Finishing)", desc: "Pengiriman seng atap seng, cat, ubin lantai, pintu toilet." }
                ].map((stg) => {
                  const isCurSelected = selectedStage === stg.id;
                  return (
                    <div
                      key={stg.id}
                      onClick={() => setSelectedStage(stg.id)}
                      className={`p-3.5 rounded-2xl border transition cursor-pointer select-none active:scale-98 ${
                        isCurSelected 
                          ? 'bg-indigo-50 border-indigo-350 text-indigo-900 shadow-sm' 
                          : 'bg-white hover:bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-extrabold text-[12.5px] text-slate-800">{stg.title}</span>
                        {isCurSelected && <div className="text-indigo-650 bg-indigo-150 p-1 rounded-full"><Check size={11} strokeWidth={3} /></div>}
                      </div>
                      <p className="text-[10.5px] text-slate-500 mt-1 leading-normal">{stg.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: FILL DELIVERY VOLUME & MATERIAL */}
          {step === 3 && selectedPB && (
            <div className="space-y-4 text-xs">
              <span className="text-[10px] font-black font-mono text-zinc-550 block uppercase tracking-wide">
                LANGKAH 3: RINCIAN MATERIAL YANG DIKIRIMKAN (DRPB)
              </span>

              {/* Material Dropdown filtered from PB remaining alocations */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase font-mono">Pilih Jenis Material:</label>
                <select
                  value={selectedMaterialId}
                  onChange={(e) => {
                    setSelectedMaterialId(e.target.value);
                    const matching = availableMaterials.find(m => m.id === e.target.value);
                    if (matching) {
                      setVolume(matching.remainingShortage.toString());
                    }
                  }}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-850"
                >
                  {availableMaterials.map(mat => (
                    <option key={mat.id} value={mat.id}>
                      {mat.material_type} (Sisa: {mat.remainingShortage} {mat.unit})
                    </option>
                  ))}
                </select>
              </div>

              {/* Volume text field with recommended volume shortage check */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase font-mono">Volume Rill Pengiriman:</label>
                <div className="flex gap-2">
                  <input 
                    type="number"
                    value={volume}
                    onChange={(e) => setVolume(e.target.value)}
                    className="flex-1 p-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold"
                    placeholder="Masukkan jumlah rill..."
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const mat = availableMaterials.find(m => m.id === selectedMaterialId);
                      if (mat) setVolume(mat.remainingShortage.toString());
                    }}
                    className="px-3.5 py-2 hover:bg-slate-150 border border-slate-200 rounded-xl font-bold font-mono"
                  >
                    Selesaikan sisa
                  </button>
                </div>
              </div>

              {/* Date Input default to today */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase font-mono">Tanggal Pengiriman:</label>
                <input 
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                />
              </div>

              {/* Action Notes */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase font-mono">Catatan Pengantaran (Opsional):</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                  placeholder="Isi detail pengiriman, supir truk, dsb..."
                />
              </div>
            </div>
          )}

          {/* STEP 4: FINAL RECAP CONFIRM AND SAVE */}
          {step === 4 && selectedPB && (
            <div className="space-y-4">
              <span className="text-[10px] font-black font-mono text-zinc-550 block uppercase tracking-wide">
                LANGKAH 4: KONFIRMASI PENYALURAN MATERIAL CEPAT
              </span>

              <div className="p-4 bg-slate-50/50 border border-slate-200 rounded-2xl text-xs space-y-3.5">
                <div>
                  <span className="text-[9.5px] text-slate-400 uppercase block font-mono">Penerima Bantuan BSPS:</span>
                  <span className="text-[14.5px] font-extrabold text-slate-850 uppercase">{selectedPB.full_name}</span>
                </div>

                <div className="grid grid-cols-2 gap-3 pb-2 border-b border-slate-150">
                  <div>
                    <span className="text-[9.5px] text-slate-400 uppercase block font-mono">Tahapan Fisik:</span>
                    <span className="font-extrabold text-indigo-700">{selectedStage} Stage</span>
                  </div>
                  <div>
                    <span className="text-[9.5px] text-slate-400 uppercase block font-mono">Tanggal Logistik:</span>
                    <span className="font-mono font-bold text-slate-700">{date}</span>
                  </div>
                </div>

                <div className="p-3 bg-indigo-50 border border-indigo-150 rounded-xl flex justify-between items-center">
                  <div>
                    <span className="text-[9px] text-indigo-600 font-mono block uppercase">Bahan Yang Dikirim:</span>
                    <span className="text-[13.5px] font-black uppercase text-indigo-950">
                      {availableMaterials.find(m => m.id === selectedMaterialId)?.material_type || "Material"}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-indigo-600 font-mono block uppercase">Volume Kiriman:</span>
                    <span className="text-base font-mono font-black text-indigo-950">
                      {volume} {availableMaterials.find(m => m.id === selectedMaterialId)?.unit || ""}
                    </span>
                  </div>
                </div>

                {notes && (
                  <div>
                    <span className="text-[9.5px] text-slate-400 uppercase block font-mono">Catatan Tambahan:</span>
                    <p className="text-slate-600 text-xs italic">"{notes}"</p>
                  </div>
                )}
              </div>

              {/* Photo Verification Panel */}
              <div className="bg-slate-50 p-4 border border-indigo-100 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-extrabold text-indigo-700 uppercase font-mono flex items-center gap-1.5">
                    📷 Bukti Foto Serah Terima (Wajib)
                  </span>
                  {gpsCoords ? (
                    <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded flex items-center gap-1 font-mono">
                      📍 GPS Koordinat Tersemat
                    </span>
                  ) : (
                    <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded flex items-center gap-1 font-mono">
                      {isLocating ? "⏳ Melacak GPS..." : "⚠️ GPS Tidak Aktif"}
                    </span>
                  )}
                </div>

                {photoBase64 ? (
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 shadow-3xs max-h-48 aspect-video">
                    <img src={photoBase64} alt="Bukti Penyaluran" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotoBase64('')}
                      className="absolute top-2 right-2 bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-lg shadow-md cursor-pointer transition active:scale-90"
                      title="Hapus foto"
                    >
                      Hapus & Ulangi 🗑️
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {/* Live webcam capture if activated */}
                    {isCapturing ? (
                      <div className="relative rounded-xl overflow-hidden border border-slate-350 bg-black aspect-video flex flex-col justify-end min-h-[180px]">
                        <video ref={videoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover transform -scale-x-100" />
                        <div className="relative z-10 p-3 bg-gradient-to-t from-black/80 to-transparent flex justify-center gap-2">
                          <button
                            type="button"
                            onClick={handleCaptureFromStream}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold rounded-lg cursor-pointer active:scale-95 transition"
                          >
                            Ambil Foto 📸
                          </button>
                          <button
                            type="button"
                            onClick={stopLiveStream}
                            className="px-3.5 py-1.5 bg-slate-700 hover:bg-slate-800 text-white text-[10px] font-bold rounded-lg cursor-pointer active:scale-95 transition"
                          >
                            Batal
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-2">
                        {/* Native File Input Trigger for environment capture */}
                        <label className="flex flex-col items-center justify-center p-4 bg-white border border-dashed border-slate-300 hover:border-indigo-400 rounded-xl cursor-pointer hover:bg-indigo-50/10 transition text-center space-y-1 select-none active:scale-98">
                          <span className="text-xl">📱</span>
                          <span className="text-[10px] font-extrabold text-slate-700 uppercase leading-none mt-1">Kamera Ponsel</span>
                          <span className="text-[9px] text-slate-400">Gunakan Kamera HP</span>
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            className="hidden"
                            onChange={handleNativeImageChosen}
                          />
                        </label>
                        
                        {/* Live Web Camera */}
                        <button
                          type="button"
                          onClick={startLiveStream}
                          className="flex flex-col items-center justify-center p-4 bg-white border border-dashed border-slate-300 hover:border-indigo-400 rounded-xl cursor-pointer hover:bg-indigo-50/10 transition text-center space-y-1 select-none active:scale-98"
                        >
                          <span className="text-xl">💻</span>
                          <span className="text-[10px] font-extrabold text-slate-700 uppercase leading-none mt-1">Live Webcam</span>
                          <span className="text-[9px] text-slate-400">Stream Langsung Browser</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="p-3 bg-amber-50 text-amber-850 rounded-xl border border-amber-200 text-[10.5px] leading-relaxed flex gap-2">
                <CheckCircle2 size={16} className="text-amber-500 shrink-0 mt-0.5" />
                <span>Dengan mengklik "Simpan Penyaluran Cepat", logistik akan langsung memotong sisa kekurangan bahan dan tersinkron ke dashboard korwil beserta data foto serah terima fisik.</span>
              </div>
            </div>
          )}

        </div>

        {/* Modal Buttons Footer bar */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex justify-between shrink-0 select-none">
          {step > 1 ? (
            <button
              onClick={handlePrevStep}
              className="px-5 py-2.5 text-xs font-bold text-slate-600 bg-white hover:bg-slate-100 border border-slate-250 rounded-xl transition cursor-pointer"
            >
              Kembali
            </button>
          ) : (
            <button 
              onClick={onClose}
              className="px-5 py-2.5 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl transition cursor-pointer"
            >
              Batal
            </button>
          )}

          {step < 4 ? (
            <button
              onClick={handleNextStep}
              className="px-5 py-2.5 bg-indigo-650 hover:bg-indigo-700 active:scale-95 text-white text-xs font-bold rounded-xl flex items-center gap-1 cursor-pointer transition select-none"
            >
              <span>Lanjut</span>
              <ArrowRight size={13} />
            </button>
          ) : (
            <button
              onClick={handleSubmitFast}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl transition cursor-pointer select-none"
            >
              Simpan Penyaluran Cepat 🚀
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
