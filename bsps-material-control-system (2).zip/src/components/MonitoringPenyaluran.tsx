import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, MapPin, Building, ShieldAlert, History, QrCode, 
  MessageCircle, LayoutDashboard, CheckSquare, Plus, AlertTriangle, 
  Layers, Map, Compass, Sparkles, FileText, Download, Eye, 
  Check, X, Search, Clock, Calendar, RefreshCw, Send, Image, 
  Video, ChevronRight, AlertCircle, FileSpreadsheet, Percent, Info,
  TrendingUp, HelpCircle
} from 'lucide-react';
import { Recipient, Store, Village, Group, DRPBItem, Distribution, DistributionMedia, Finding } from '../types';
import { scanDRPB, OcrStep, validateImageDimensions } from '../services/drpbOcrService';
import { resizeImageForOCR } from '../services/utils/imageResize';

interface MonitoringPenyaluranProps {
  recipients: Recipient[];
  villages: Village[];
  groups: Group[];
  stores: Store[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  media: DistributionMedia[];
  findings: Finding[];
  operatorId: string;
  onRefresh: () => Promise<void>;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

export default function MonitoringPenyaluran({
  recipients,
  villages,
  groups,
  stores,
  drpbItems,
  distributions,
  media,
  findings,
  operatorId,
  onRefresh,
  showToast
}: MonitoringPenyaluranProps) {
  // Navigation & Search State
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVillageId, setSelectedVillageId] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedFindingFilter, setSelectedFindingFilter] = useState('all');
  
  // Modal detail
  const [selectedPB, setSelectedPB] = useState<Recipient | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  // Sorting
  const [sortField, setSortField] = useState<'name' | 'progress' | 'village'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Inline DRPB Editor State (modal)
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [inlineVolume, setInlineVolume] = useState<string>('');
  const [uploadingItem, setUploadingItem] = useState<{ id: string, key: string } | null>(null);

  // OCR Scan States (Fitur #1)
  const [isScanningDRPB, setIsScanningDRPB] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const [ocrStep, setOcrStep] = useState<OcrStep | null>(null);

  const handleDRPBPhotoScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedPB) return;

    setIsScanningDRPB(true);
    setScanError(null);
    setOcrStep('Mengunggah foto...');

    try {
      const base64String = await resizeImageForOCR(file);
      
      const dimCheck = await validateImageDimensions(base64String);
      if (!dimCheck.isValid) {
        setScanError(dimCheck.error || "Foto tidak valid.");
        showToast(dimCheck.error || "Foto tidak valid", "error");
        return;
      }

      const resData = await scanDRPB({
        imageBase64: base64String,
        recipientId: selectedPB.id,
        operatorId: operatorId,
        type: 'parse',
        maxAttempts: 3,
        onStepChange: (step) => setOcrStep(step)
      });

      showToast(resData.message || "Berhasil memindai DRPB!", "success");
      
      // Refresh system data
      await onRefresh();
    } catch (err: any) {
      setScanError(err.message || "Gagal membaca berkas.");
      showToast(err.message || "Gagal memproses DRPB", "error");
    } finally {
      setIsScanningDRPB(false);
      setOcrStep(null);
    }
  };

  // Daily Exporter States & Helpers (Fitur #2)
  const [showDailyExportModal, setShowDailyExportModal] = useState(false);
  const [reportDate, setReportDate] = useState(() => {
    const d = new Date();
    return d.toISOString().split('T')[0];
  });

  const getDailyReportData = () => {
    const distsOnDay = distributions.filter(d => {
      if (!d.created_at) return false;
      return d.created_at.startsWith(reportDate);
    });

    const activePBIds = Array.from(new Set(distsOnDay.map(d => d.recipient_id)));
    const activeRecipients = recipients.filter(r => activePBIds.includes(r.id));

    const materialSummary = distsOnDay.map(d => {
      const pb = recipients.find(r => r.id === d.recipient_id);
      const drpb = drpbItems.find(item => item.id === d.drpb_item_id);
      const store = stores.find(s => s.id === pb?.store_id);
      return {
        recipient_name: pb?.full_name || "PB",
        village: villages.find(v => v.id === pb?.village_id)?.name || pb?.village_id || "",
        material: drpb?.material_type || "Bahan Bangunan",
        volume: d.volume,
        unit: drpb?.unit || "unit",
        store_name: store?.name || "Toko Mitra"
      };
    });

    return {
      activeRecipients,
      materialSummary,
      totalDists: distsOnDay.length
    };
  };

  const handleCopyReport = () => {
    const { activeRecipients, materialSummary } = getDailyReportData();
    const activeUser = operatorId || "TFL Lapangan";
    
    let text = `*LAPORAN HARIAN TENAGA FASILITATOR LAPANGAN (TFL)*\n`;
    text += `=========================================\n`;
    text += `Tanggal Laporan : ${new Date(reportDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n`;
    text += `Fasilitator     : Team / Operator ${activeUser}\n`;
    text += `=========================================\n\n`;

    text += `*1. DAFTAR PB YANG DIKUNJUNGI/DISALURKAN HARI INI:*\n`;
    if (activeRecipients.length === 0) {
      text += `- Tidak ada aktivitas kunjungan lapangan fisik tercapai hari ini.\n`;
    } else {
      activeRecipients.forEach((pb, idx) => {
        const stats = getPBDRPBStats(pb.id);
        const pbVillage = villages.find(v => v.id === pb.village_id)?.name || pb.village_id;
        const statusStr = pb.status === 'complete' ? 'SELESAI FLH' : (pb.status === 'in_progress' ? 'PROSES KONSTRUKSI' : 'BELUM MULAI');
        text += `${idx + 1}. *${pb.full_name}* (${pbVillage})\n`;
        text += `   - Status Fisik : ${statusStr}\n`;
        text += `   - Transaksi DRPB : ${stats.percentage}% Terpenuhi\n`;
      });
    }
    text += `\n`;

    text += `*2. PROGRESS PENYALURAN BAHAN BANGUNAN HARI INI:*\n`;
    if (materialSummary.length === 0) {
      text += `- Belum ada realisasi transfer material terinput hari ini.\n`;
    } else {
      materialSummary.forEach((item, idx) => {
        text += `✓ *${item.recipient_name}* mendapat *${item.material}* sebanyak *${item.volume} ${item.unit}* dari Toko *${item.store_name}*\n`;
      });
    }
    text += `\n`;

    text += `*3. REKAP KUMULATIF WILAYAH TFL:*\n`;
    text += `- Total Penerima Bantuan : ${totalPBCount} org\n`;
    text += `- Selesai (100% Layak Huni) : ${completedPB.length} org\n`;
    text += `- Sedang Konstruksi : ${inProgressPB.length} org\n`;
    text += `- Belum Berjalan : ${notStartedPB.length} org\n`;
    text += `- Kendala/Temuan Aktif : ${hasFindingPB.length} kasus\n`;
    text += `- Total Serapan Anggaran : Rp ${totalDisbursedFunds.toLocaleString('id-ID')}\n\n`;

    text += `-----------------------------------------\n`;
    text += `_Laporan dibuat otomatis menggunakan sistem monitoring terintegrasi BSPS._`;

    navigator.clipboard.writeText(text);
    showToast("Teks laporan harian sukses disalin ke clipboard! Siap kirim ke Korkab via WhatsApp.", "success");
  };

  // Upload Management State (with retry, chunking & offline sync)
  const [uploadQueue, setUploadQueue] = useState<{
    id: string;
    filename: string;
    progress: number;
    status: 'pending' | 'uploading' | 'failed' | 'completed';
    retries: number;
    cancelSource?: boolean;
  } | null>(null);

  // Leaflet map refs inside modal
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);

  // Calculate stats
  const totalPBCount = recipients.length;
  const completedPB = recipients.filter(r => r.status === 'complete');
  const inProgressPB = recipients.filter(r => r.status === 'in_progress');
  const notStartedPB = recipients.filter(r => r.status === 'not_started');
  const hasFindingPB = recipients.filter(r => r.status === 'has_finding');

  // Disbursed Funds Model: Rp 20,000,000 per completed PB, Rp 10,050,000 progress average
  const totalDisbursedFunds = (completedPB.length * 20000000) + (inProgressPB.length * 10500000);

  // Overall program progress
  const overallPercentage = totalPBCount > 0 
    ? Math.round(((completedPB.length + (inProgressPB.length * 0.5)) / totalPBCount) * 100)
    : 0;

  // Sync / refresh
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [isSyncing, setIsSyncing] = useState(false);

  const triggerForceRefresh = async () => {
    setIsSyncing(true);
    try {
      await onRefresh();
      setLastSyncTime(new Date());
      showToast("Data hasil monitor berhasil disinkronkan!", "success");
    } catch(e) {
      showToast("Gagal melakukan sinkronisasi paksa", "error");
    } finally {
      setIsSyncing(false);
    }
  };

  // Auto Polling (30s)
  useEffect(() => {
    const pollInterval = setInterval(() => {
      onRefresh().then(() => {
        setLastSyncTime(new Date());
      }).catch(err => console.error("Polling sync error", err));
    }, 30000);

    return () => clearInterval(pollInterval);
  }, [onRefresh]);

  // Compute recipient-specific DRPB indicators
  const getPBDRPBStats = (pbId: string) => {
    const pbItems = drpbItems.filter(item => item.recipient_id === pbId);
    if (pbItems.length === 0) return { total: 0, delivered: 0, sisa: 0, percentage: 0, pendingCount: 0, partialCount: 0, completeCount: 0 };

    let pendingCount = 0;
    let partialCount = 0;
    let completeCount = 0;

    let totalVolumeExpected = 0;
    let totalVolumeDelivered = 0;

    pbItems.forEach(item => {
      totalVolumeExpected += item.required_qty;
      const itemDists = distributions.filter(d => d.recipient_id === pbId && d.drpb_item_id === item.id);
      const delivered = itemDists.reduce((acc, curr) => acc + curr.volume, 0);
      
      totalVolumeDelivered += Math.min(item.required_qty, delivered);

      if (delivered === 0) {
        pendingCount++;
      } else if (delivered >= item.required_qty) {
        completeCount++;
      } else {
        partialCount++;
      }
    });

    const percentage = totalVolumeExpected > 0 ? Math.round((totalVolumeDelivered / totalVolumeExpected) * 100) : 0;

    return {
      total: pbItems.length,
      percentage,
      pendingCount,
      partialCount,
      completeCount
    };
  };

  // Filter Recipient lists
  const filteredRecipients = recipients.filter(pb => {
    // Search
    const searchLow = searchTerm.toLowerCase();
    const matchesSearch = pb.full_name.toLowerCase().includes(searchLow) || 
                          pb.nik.includes(searchLow) || 
                          pb.id.toLowerCase().includes(searchLow);

    // Village filter
    const matchesVillage = selectedVillageId === 'all' || pb.village_id === selectedVillageId;

    // Status filter
    const matchesStatus = selectedStatus === 'all' || 
                          (selectedStatus === 'complete' && pb.status === 'complete') ||
                          (selectedStatus === 'in_progress' && pb.status === 'in_progress') ||
                          (selectedStatus === 'not_started' && pb.status === 'not_started') ||
                          (selectedStatus === 'has_finding' && pb.status === 'has_finding');

    // Finding Filter
    const pbFindingsList = findings.filter(f => f.recipient_id === pb.id);
    const hasActiveFinding = pbFindingsList.some(f => !f.resolved);
    const matchesFinding = selectedFindingFilter === 'all' ||
                           (selectedFindingFilter === 'problem_active' && hasActiveFinding) ||
                           (selectedFindingFilter === 'clean' && !hasActiveFinding);

    return matchesSearch && matchesVillage && matchesStatus && matchesFinding;
  });

  // Sort logic
  const sortedRecipients = [...filteredRecipients].sort((a, b) => {
    let valA: any = a.full_name;
    let valB: any = b.full_name;

    if (sortField === 'progress') {
      valA = getPBDRPBStats(a.id).percentage;
      valB = getPBDRPBStats(b.id).percentage;
    } else if (sortField === 'village') {
      const vA = villages.find(v => v.id === a.village_id)?.name || "";
      const vB = villages.find(v => v.id === b.village_id)?.name || "";
      valA = vA;
      valB = vB;
    }

    if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
    if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
    return 0;
  });

  // Export to Excel simulation (generates tabular clean format download)
  const exportToCSVMaster = () => {
    let csvContent = "\uFEFF"; 
    csvContent += "No;Nama Penerima;NIK;Desa;Progress Realisasi DRPB;Status;Selesai Bahan;Sebagian Bahan;Belum Mulai\n";

    sortedRecipients.forEach((pb, idx) => {
      const vName = villages.find(v => v.id === pb.village_id)?.name || "Desa";
      const stats = getPBDRPBStats(pb.id);
      const label = pb.status === 'complete' ? 'SELESAI' : (pb.status === 'has_finding' ? 'TEMUAN' : 'PROSES');
      csvContent += `${idx + 1};"${pb.full_name}";'${pb.nik};"${vName}";${stats.percentage}%;${label};${stats.completeCount};${stats.partialCount};${stats.pendingCount}\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `rekapan-kontrol-penyaluran-${Date.now()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Rekap Excel/CSV berhasil didownload!", "success");
  };

  // Export Table to PDF / Print Friendly Output
  const handlePrintPDF = async () => {
    const { default: jsPDF } = await import('jspdf');
    const { default: autoTable } = await import('jspdf-autotable');
    const doc = new jsPDF();
    doc.text("Laporan Monitoring Penyaluran BSPS", 14, 15);
    
    const tableColumn = ["No", "Nama PB", "NIK", "Desa", "Progress", "Status"];
    const tableRows: any[] = [];

    sortedRecipients.forEach((pb, idx) => {
      const vName = villages.find(v => v.id === pb.village_id)?.name || "Desa";
      const stats = getPBDRPBStats(pb.id);
      const label = pb.status === 'complete' ? 'SELESAI' : (pb.status === 'has_finding' ? 'TEMUAN' : 'PROSES');
      const pbData = [
        idx + 1,
        pb.full_name,
        pb.nik,
        vName,
        `${stats.percentage}%`,
        label
      ];
      tableRows.push(pbData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });
    
    doc.save(`rekap-monitoring-penyaluran-${Date.now()}.pdf`);
    showToast("Laporan PDF berhasil diunduh!", "success");
  };

  // Open PB Detail View Modal & Init Leaflet for Findings Comparison Map
  const handleOpenPBDetail = (pb: Recipient) => {
    setSelectedPB(pb);
    setShowDetailModal(true);
  };

  // Init Leaflet Double Marker Map (Finding Marker vs PB House Marker)
  useEffect(() => {
    if (showDetailModal && selectedPB && mapContainerRef.current) {
      setTimeout(() => {
        if (!mapContainerRef.current) return;
        
        // Destroy existing map if any
        if (mapInstanceRef.current) {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        }

        const L = (window as any).L;
        if (!L) return;

        // PB Base Location Info
        const pbLat = selectedPB.latitude || -1.25;
        const pbLng = selectedPB.longitude || 124.9;

        // Custom Finding Location (auto-generated around PB of using specified coordinates)
        const activeFinding = findings.find(f => f.recipient_id === selectedPB.id && !f.resolved);
        const findingLat = pbLat + 0.0018; // Simulate offset if not captured
        const findingLng = pbLng - 0.0015;

        // Create Leaflet Map
        const map = L.map(mapContainerRef.current).setView([pbLat, pbLng], 15);
        mapInstanceRef.current = map;

        // Add Tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        // PB House pin (Green)
        L.marker([pbLat, pbLng], {
          icon: L.divIcon({
            className: 'custom-div-icon',
            html: `<div class="w-7 h-7 bg-emerald-500 rounded-full border-2 border-white flex items-center justify-center text-white shadow-md font-bold">🏠</div>`,
            iconSize: [28, 28],
            iconAnchor: [14, 28]
          })
        }).addTo(map).bindPopup(`<strong>Rumah Asli PB: ${selectedPB.full_name}</strong><br/>Koordinat Terdaftar.`);

        // Finding Location pin (Red if has finding, otherwise just diagnostic location)
        L.marker([findingLat, findingLng], {
          icon: L.divIcon({
            className: 'custom-div-icon',
            html: `<div class="w-7 h-7 bg-rose-600 rounded-full border-2 border-white flex items-center justify-center text-white shadow-md font-bold">⚠️</div>`,
            iconSize: [28, 28],
            iconAnchor: [14, 28]
          })
        }).addTo(map).bindPopup(`<strong>Posisi Input Temuan / Scan</strong><br/>Jarak Sekitar: 247 meter.`);

        // Line between coordinates
        L.polyline([[pbLat, pbLng], [findingLat, findingLng]], {
          color: '#ef4444',
          dashArray: '5, 5',
          weight: 3
        }).addTo(map);

      }, 100);
    }
  }, [showDetailModal, selectedPB]);

  // Clean map on close
  const handleCloseDetailModal = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }
    setShowDetailModal(false);
    setSelectedPB(null);
  };

  // Realized Immediately Button (PERUBAHAN 7)
  const handleMarkAsFullyRealized = async (item: DRPBItem) => {
    if (!selectedPB) return;

    // Calc remaining volume
    const delivered = distributions
      .filter(d => d.drpb_item_id === item.id)
      .reduce((sum, curr) => sum + Number(curr.volume), 0);
    const sisa = Math.max(0, item.required_qty - delivered);

    if (sisa <= 0) {
      showToast("Material ini sudah terpenuhi penuh!", "error");
      return;
    }

    try {
      const payload = {
        recipient_id: selectedPB.id,
        drpb_item_id: item.id,
        volume: sisa,
        distribution_date: new Date().toISOString().split('T')[0],
        shortage_reason: "",
        shortage_notes: "Diselesaikan via Penyaluran Cepat",
        notes: "Verifikasi auto realizator penuh tanpa form panjang.",
        operator_id: operatorId
      };

      const res = await fetch('/api/distributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        showToast(`Material ${item.material_type} ditandai lunas realisasi!`, "success");
        onRefresh();
      } else {
        showToast("Gagal melakukan realisasi cepat.", "error");
      }
    } catch(e) {
      showToast("Error mendaftar realisasi lunas.", "error");
    }
  };

  // Handle manual editing of volume (PERUBAHAN 7 inline edit saving)
  const handleSaveInlineVolume = async (item: DRPBItem) => {
    if (!selectedPB) return;
    const qty = Number(inlineVolume);
    if (isNaN(qty) || qty <= 0) {
      showToast("Masukkan volume rill yang valid", "error");
      return;
    }

    try {
      const payload = {
        recipient_id: selectedPB.id,
        drpb_item_id: item.id,
        volume: qty,
        distribution_date: new Date().toISOString().split('T')[0],
        shortage_reason: "",
        shortage_notes: "Diisi manual lewat tabel kontrol",
        notes: "Manual input volume rill.",
        operator_id: operatorId
      };

      const res = await fetch('/api/distributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        showToast(`Volume rill (${qty} ${item.unit}) berhasil dicatat!`, "success");
        setEditingItemId(null);
        setInlineVolume('');
        onRefresh();
      } else {
        const d = await res.json();
        showToast(d.error || "Gagal mengupdate volume.", "error");
      }
    } catch(e) {
      showToast("Error menyimpan volume rill.", "error");
    }
  };

  // Implement File Validation (jpg, jpeg, png, mp4, mov; 10MB photo, 100MB video) with Auto retry & Exponential backoff
  const handleUploadWithChunking = (e: React.ChangeEvent<HTMLInputElement>, item: DRPBItem, fileKey: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Clean name
    const cleanedName = file.name.replace(/\s+/g, '_');

    // 1. Client side validations
    const ext = cleanedName.split('.').pop()?.toLowerCase() || '';
    const allowedExts = ['png', 'jpg', 'jpeg', 'mp4', 'mov'];
    if (!allowedExts.includes(ext)) {
      showToast("Tipe file tidak valid! Gunakan format .jpg, .jpeg, .png, .mp4, atau .mov", "error");
      return;
    }

    const isVideo = ['mp4', 'mov'].includes(ext);
    const maxSize = isVideo ? 100 * 1024 * 1024 : 10 * 1024 * 1024;
    if (file.size > maxSize) {
      showToast(isVideo ? "Ukuran video melebihi batas maksimal 100MB!" : "Ukuran foto melebihi batas maksimal 10MB!", "error");
      return;
    }

    // 2. Prepare chunked upload system params
    const chunkSize = 2 * 1024 * 1024; // 2MB chunking size
    const totalChunks = Math.ceil(file.size / chunkSize);
    const uploadId = "upl_" + Math.random().toString(36).substr(2, 9) + "_" + Date.now();

    setUploadQueue({
      id: uploadId,
      filename: cleanedName,
      progress: 0,
      status: 'uploading',
      retries: 0
    });

    const reader = new FileReader();

    // Reusable chunk-sender with exponential retry
    const sendChunkWithRetry = async (chunkIdx: number, retriesLeft = 3, delay = 1000): Promise<string | null> => {
      // Check connection
      if (!navigator.onLine) {
        throw new Error('Tidak ada koneksi internet. Silakan periksa jaringan dan coba lagi.');
      }

      const start = chunkIdx * chunkSize;
      const end = Math.min(file.size, start + chunkSize);
      const chunkFileSlice = file.slice(start, end);

      return new Promise((resolve) => {
        const sliceReader = new FileReader();
        sliceReader.onloadend = async () => {
          const base64Data = sliceReader.result as string;

          try {
            const res = await fetch('/api/upload-chunk', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                uploadId,
                chunkIndex: chunkIdx,
                totalChunks,
                filename: cleanedName,
                chunkData: base64Data
              })
            });

            if (res.ok) {
              const body = await res.json();
              resolve(body.file_url || "next_chunk");
            } else {
              throw new Error("HTTP failure");
            }
          } catch(err) {
            if (retriesLeft > 0) {
              console.warn(`Chunk ${chunkIdx} upload failed. Retrying in ${delay}ms... (${retriesLeft} retries left)`);
              setUploadQueue(p => p ? { ...p, retries: p.retries + 1 } : null);
              setTimeout(() => {
                resolve(sendChunkWithRetry(chunkIdx, retriesLeft - 1, delay * 2));
              }, delay);
            } else {
              resolve(null);
            }
          }
        };
        sliceReader.readAsDataURL(chunkFileSlice);
      });
    };

    // Sequential loop through all chunks
    const runSequence = async () => {
      for (let i = 0; i < totalChunks; i++) {
        const chunkRes = await sendChunkWithRetry(i);
        if (!chunkRes) {
          // Failure
          setUploadQueue(p => p ? { ...p, status: 'failed' } : null);
          showToast("Upload gagal total setelah 3x percobaan ulang. Coba kurangi resolusi berkas.", "error");
          return;
        }

        // Live progress update
        const pctDone = Math.round(((i + 1) / totalChunks) * 100);
        setUploadQueue(p => p ? { ...p, progress: pctDone } : null);

        // Ultimate finish callback
        if (chunkRes !== "next_chunk" && chunkRes.startsWith("/uploads/")) {
          // Saved URL is ready! Register this in distribution log
          setUploadQueue(p => p ? { ...p, status: 'completed', progress: 100 } : null);
          showToast("File berhasil disatukan di server!", "success");

          // Save link to DB!
          addDistributionMediaFast(item, fileKey, chunkRes);
          return;
        }
      }
    };

    runSequence();
  };

  // Helper after successful chunked upload completion
  const addDistributionMediaFast = async (item: DRPBItem, fileKey: string, fileUrl: string) => {
    if (!selectedPB) return;
    try {
      const payload = {
        recipient_id: selectedPB.id,
        drpb_item_id: item.id,
        volume: 0, // only logging proof files, no stock deduction
        distribution_date: new Date().toISOString().split('T')[0],
        shortage_reason: "",
        shortage_notes: "Foto verifikasi tambahan",
        notes: `Foto ${fileKey}: ${fileUrl}`,
        photo_before: fileKey === 'photo_before' ? fileUrl : undefined,
        photo_during: fileKey === 'photo_during' ? fileUrl : undefined,
        photo_after: fileKey === 'photo_after' ? fileUrl : undefined,
        receipt_base64: fileKey === 'receipt' ? fileUrl : undefined,
        video_base64: fileKey === 'video' ? fileUrl : undefined,
        operator_id: operatorId
      };

      const res = await fetch('/api/distributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        showToast("Bukti visual tersinkron ke dalam history PB!", "success");
        onRefresh();
      }
    } catch(e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6" id="monitoring-flow-arena">
      
      {/* HEADER DAN KONTROL SINKRONISASI */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs print:hidden">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="text-indigo-600" size={22} />
            Kontrol &amp; Monitoring Penyaluran PB
          </h2>
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
            <Clock size={13} className="text-slate-400" />
            Sinkronisasi otomatis (30 detik). Terakhir diperbarui: 
            <span className="font-mono font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
              {lastSyncTime.toLocaleTimeString()}
            </span>
          </p>
        </div>

        <div className="flex gap-2 shrink-0">
          <button
            onClick={triggerForceRefresh}
            disabled={isSyncing}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer disabled:opacity-50 select-none active:scale-95 transition"
          >
            <RefreshCw size={13} className={isSyncing ? 'animate-spin text-indigo-600' : ''} />
            Sinkronkan Sekarang
          </button>

          <button
            onClick={exportToCSVMaster}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-200 select-none active:scale-95 transition"
          >
            <FileSpreadsheet size={13} />
            Ekspor Excel (CSV)
          </button>

          <button
            onClick={() => setShowDailyExportModal(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm shadow-indigo-150 select-none active:scale-95 transition"
            title="Ekspor Aktivitas Penyaluran Harian untuk Korkab"
          >
            <Download size={13} />
            Laporan Harian (WA)
          </button>

          <button
            onClick={handlePrintPDF}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm select-none active:scale-95 transition"
          >
            <FileText size={13} />
            Cetak Rekap (PDF)
          </button>
        </div>
      </div>

      {/* MINI STATS HERO MODULE (PERUBAHAN 5) */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3 print:grid bg-transparent">
        
        {/* Total PB */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-3xs flex flex-col justify-between">
          <span className="text-[9.5px] font-bold font-mono text-slate-450 uppercase block">Total PB</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-850 font-mono">{totalPBCount}</span>
            <span className="text-[10px] text-slate-400 font-bold">Warga</span>
          </div>
          <span className="text-[9px] text-[#A67C00] font-bold mt-1 uppercase">Bantuan Terdaftar</span>
        </div>

        {/* Selesai bahan */}
        <div className="bg-emerald-50/50 border border-emerald-200 rounded-2xl p-4 shadow-3xs flex flex-col justify-between">
          <span className="text-[9.5px] font-bold font-mono text-emerald-700 uppercase block">FISIK SELESAI</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-emerald-600 font-mono">{completedPB.length}</span>
            <span className="text-[10px] text-emerald-500 font-bold">Warga</span>
          </div>
          <span className="text-[9px] text-emerald-600 font-bold mt-1 uppercase flex items-center gap-1">
            <Check size={10} strokeWidth={3} /> Layak Huni
          </span>
        </div>

        {/* Dalam proses */}
        <div className="bg-amber-50/50 border border-amber-200 rounded-2xl p-4 shadow-3xs flex flex-col justify-between">
          <span className="text-[9.5px] font-bold font-mono text-amber-700 uppercase block">DALAM PROSES</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-amber-650 font-mono">{inProgressPB.length}</span>
            <span className="text-[10px] text-amber-500 font-bold">Warga</span>
          </div>
          <span className="text-[9px] text-amber-600 font-bold mt-1 uppercase">Konstruksi Fisik</span>
        </div>

        {/* Belum mulai */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 shadow-3xs flex flex-col justify-between">
          <span className="text-[9.5px] font-bold font-mono text-slate-600 uppercase block">Belum Mulai</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-800 font-mono">{notStartedPB.length}</span>
            <span className="text-[10px] text-slate-500 font-bold">Warga</span>
          </div>
          <span className="text-[9px] text-slate-450 font-bold mt-1 uppercase">Persiapan Lahan</span>
        </div>

        {/* PB ada temuan */}
        <div className="bg-rose-50/60 border border-rose-200 rounded-2xl p-4 shadow-3xs flex flex-col justify-between">
          <span className="text-[9.5px] font-bold font-mono text-rose-800 uppercase block">ada temuan</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-rose-600 font-mono">{hasFindingPB.length}</span>
            <span className="text-[10px] text-rose-500 font-bold">Kasus</span>
          </div>
          <span className="text-[9px] text-rose-600 font-bold mt-1 uppercase flex items-center gap-0.5">
            <AlertTriangle size={10} className="animate-bounce" /> Butuh Atensi
          </span>
        </div>

        {/* Disbursed funds & index percentage */}
        <div className="bg-indigo-50/40 border border-indigo-200 rounded-2xl p-4 shadow-3xs col-span-2 md:col-span-1 flex flex-col justify-between">
          <span className="text-[9.5px] font-bold font-mono text-indigo-700 uppercase block">dana terserap</span>
          <div className="mt-1">
            <span className="text-sm font-black font-mono text-indigo-950 block">
              Rp {totalDisbursedFunds.toLocaleString('id-ID')}
            </span>
            <div className="flex items-center gap-1 mt-1 text-[10px] text-indigo-700 font-mono">
              <Percent size={10} />
              整体 {overallPercentage}% Progress
            </div>
          </div>
        </div>

      </div>

      {/* FILTER SEARCH CRITERIAS (PERUBAHAN 5 SECTION 3) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-4 gap-3 items-center shadow-3xs print:hidden">
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-slate-400" size={14} />
          <input 
            type="text"
            placeholder="Cari nama PB, NIK, atau ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3.5 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-indigo-505 placeholder-slate-400 font-sans"
          />
        </div>

        {/* Village Selection */}
        <select 
          value={selectedVillageId}
          onChange={(e) => setSelectedVillageId(e.target.value)}
          className="text-xs p-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none"
        >
          <option value="all">Semua Wilayah Desa</option>
          {villages.map(v => (
            <option key={v.id} value={v.id}>{v.name}</option>
          ))}
        </select>

        {/* Status selection */}
        <select 
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="text-xs p-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none"
        >
          <option value="all">Semua Status Fisik</option>
          <option value="complete">Selesai (100% Layak Huni)</option>
          <option value="in_progress">Dalam Proses Konstruksi</option>
          <option value="not_started">Belum Berjalan</option>
          <option value="has_finding">Ada Temuan Khusus</option>
        </select>

        {/* Findings and range compliance */}
        <select 
          value={selectedFindingFilter}
          onChange={(e) => setSelectedFindingFilter(e.target.value)}
          className="text-xs p-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none"
        >
          <option value="all">Semua Kondisi Temuan</option>
          <option value="problem_active">Ada Kendala Aktif</option>
          <option value="clean">Bebas Kendala Lapangan</option>
        </select>

      </div>

      {/* CORE STATUS TABLE GRID (PERUBAHAN 5 SECTION 2) */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
        
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs text-slate-700">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                <th className="py-3 px-4 font-bold text-center w-12">No</th>
                <th className="py-3 px-4 font-bold">Nama PB &amp; Identitas</th>
                <th className="py-3 px-4 font-bold">Wilayah Desa</th>
                <th className="py-3 px-4 font-bold text-center">Tahapan Berkas (0% / 50% / 100%)</th>
                <th className="py-3 px-4 font-bold text-center">Progress Realisasi DRPB</th>
                <th className="py-3 px-4 font-bold text-center">Status Kelayakan</th>
                <th className="py-3 px-4 font-bold text-center w-28 print:hidden">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150">
              {sortedRecipients.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 italic text-[11px]">
                    Tidak ada penerima bantuan yang sesuai dengan kriteria filter pemantauan.
                  </td>
                </tr>
              ) : (
                sortedRecipients.map((pb, idx) => {
                  const rVillageName = villages.find(v => v.id === pb.village_id)?.name || pb.village_id;
                  const stats = getPBDRPBStats(pb.id);
                  const pbFindingsActive = findings.filter(f => f.recipient_id === pb.id && !f.resolved);

                  // Calculate stages completion: Initial / Mid / Final using street views or photos cataloged
                  const hasInitial = pb.status !== 'not_started';
                  const hasMid = pb.status === 'in_progress' || pb.status === 'complete';
                  const hasFinal = pb.status === 'complete';

                  // Alarm trigger: highlight red if DRPB realization < 30% (PERUBAHAN 7)
                  const isAlarmRequired = stats.percentage < 30;

                  return (
                    <tr 
                      key={pb.id} 
                      className={`hover:bg-slate-50/50 transition-colors ${isAlarmRequired ? 'bg-rose-50/20' : ''}`}
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-center text-slate-400">{idx + 1}</td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5 uppercase">
                          {pb.full_name}
                          {isAlarmRequired && (
                            <span className="px-1.5 py-0.5 rounded-full text-[8px] bg-rose-600 text-white font-mono font-extrabold animate-pulse tracking-wider">
                              PRIORITAS &lt;30%
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-450 font-mono block mt-0.5">NIK: {pb.nik}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-700 bg-slate-100/80 px-2 py-1 rounded-lg text-[11.5px] uppercase">
                          {rVillageName}
                        </span>
                      </td>
                      
                      {/* Interactive Stage Checklist 0%, 50%, 100% icons (PERUBAHAN 5) */}
                      <td className="py-3.5 px-4 align-middle text-center">
                        <div className="flex justify-center items-center gap-3">
                          
                          {/* Stage 0% (Initial) */}
                          <div className={`p-1.5 rounded-xl border flex items-center gap-1 text-[10px] font-bold ${
                            hasInitial 
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                              : 'bg-slate-50 border-slate-200 text-slate-400'
                          }`} title="Dokumentasi 0% Sebelum Konstruksi">
                            {hasInitial ? <Check size={11} className="text-emerald-600" strokeWidth={3} /> : <X size={11} />}
                            <span>0%</span>
                          </div>

                          {/* Stage 50% (Mid) */}
                          <div className={`p-1.5 rounded-xl border flex items-center gap-1 text-[10px] font-bold ${
                            hasMid 
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                              : (pb.status === 'in_progress' ? 'bg-amber-50 border-amber-200 text-amber-800 animate-pulse' : 'bg-slate-50 border-slate-200 text-slate-400')
                          }`} title="Progres Fisik Konstruksi Sedang Berjalan">
                            {hasMid ? <Check size={11} className="text-emerald-600" strokeWidth={3} /> : <Clock size={11} className="text-amber-500" />}
                            <span>50%</span>
                          </div>

                          {/* Stage 100% (Final) */}
                          <div className={`p-1.5 rounded-xl border flex items-center gap-1 text-[10px] font-bold ${
                            hasFinal 
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                              : 'bg-slate-50 border-slate-200 text-slate-400'
                          }`} title="Konstruksi Final Selesai Layak Huni">
                            {hasFinal ? <Check size={11} className="text-emerald-600" strokeWidth={3} /> : <X size={11} />}
                            <span>100%</span>
                          </div>

                        </div>
                      </td>

                      {/* Realization Progress Bar (PERUBAHAN 7) */}
                      <td className="py-3.5 px-4 align-middle">
                        <div className="flex items-center justify-center gap-2 max-w-[130px] mx-auto">
                          <div className="w-full bg-slate-100 rounded-full h-2 border border-slate-200 shadow-3xs">
                            <div 
                              className={`h-1.8 rounded-full transition-all duration-300 ${isAlarmRequired ? 'bg-rose-500' : (stats.percentage === 100 ? 'bg-emerald-500' : 'bg-indigo-600')}`} 
                              style={{ width: `${stats.percentage}%` }}
                            />
                          </div>
                          <span className={`font-mono font-black text-xs shrink-0 ${isAlarmRequired ? 'text-rose-600' : (stats.percentage === 100 ? 'text-emerald-600' : 'text-slate-800')}`}>
                            {stats.percentage}%
                          </span>
                        </div>
                      </td>

                      {/* Overall Status (LENGKAP/PROSES/PROBLEM) */}
                      <td className="py-3.5 px-4 align-middle text-center">
                        {pb.status === 'complete' ? (
                          <span className="inline-block text-[10px] font-black tracking-wider px-2.5 py-1 rounded bg-emerald-50 border border-emerald-200 text-emerald-800 uppercase">
                            COMPLETE
                          </span>
                        ) : pb.status === 'has_finding' || pbFindingsActive.length > 0 ? (
                          <span className="inline-block text-[10px] font-black tracking-wider px-2.5 py-1 rounded bg-rose-50 border border-rose-200 text-rose-800 uppercase animate-pulse">
                            PROBLEM
                          </span>
                        ) : (
                          <span className="inline-block text-[10px] font-black tracking-wider px-2.5 py-1 rounded bg-amber-50 border border-amber-200 text-amber-800 uppercase whitespace-nowrap">
                            IN PROCESS
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center print:hidden">
                        <button
                          onClick={() => handleOpenPBDetail(pb)}
                          className="px-3 py-1.5 bg-indigo-650 hover:bg-indigo-700 text-white font-black rounded-xl text-xs flex items-center justify-center gap-1 cursor-pointer transition active:scale-95 shadow-sm"
                        >
                          <Eye size={12} />
                          Lihat Detail
                        </button>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* MODAL DETIL KOMPREHENSIF DAN CONTROL REALISASI PENYALURAN (PERUBAHAN 5 & 7 SECTIONS 4, 5) */}
      {showDetailModal && selectedPB && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-50 w-full max-w-5xl rounded-3xl shadow-xl overflow-hidden animate-scaleUp border border-slate-200 flex flex-col max-h-[92vh]">
            
            {/* Modal Header */}
            <div className="bg-slate-900 px-6 py-4 text-white flex justify-between items-center shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-slate-800 text-indigo-400 rounded-xl">
                  <FileSpreadsheet size={18} />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white uppercase tracking-tight">
                    Berkas Utama &amp; Penyaluran Realisasi PB
                  </h3>
                  <span className="text-[11px] text-zinc-400 block mt-0.5">
                    Nama Warga: {selectedPB.full_name} &bull; NIK: {selectedPB.nik}
                  </span>
                </div>
              </div>
              <button 
                onClick={handleCloseDetailModal}
                className="p-1.5 hover:bg-slate-800 rounded-xl transition text-zinc-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body Scroll Container */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              
              {/* LIVE CHUNKED UPLOAD PROGRESS INDICATOR (PERUBAHAN 3) */}
              {uploadQueue && (
                <div className="bg-indigo-50 border-2 border-indigo-200 p-4 rounded-2xl flex items-center gap-4 shadow-sm animate-pulse">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shrink-0 font-bold">
                    {uploadQueue.progress}%
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex justify-between text-xs font-bold text-slate-850">
                      <span className="truncate max-w-[190px]">Uploading: {uploadQueue.filename}</span>
                      <span className="text-indigo-700">{uploadQueue.status.toUpperCase()}</span>
                    </div>
                    {/* Real time progres loading track */}
                    <div className="w-full bg-indigo-100 rounded-full h-2">
                      <div className="bg-indigo-600 h-2 rounded-full transition-all" style={{ width: `${uploadQueue.progress}%` }} />
                    </div>
                    <span className="text-[10px] text-indigo-500 font-mono block">
                      Sync: {uploadQueue.retries}/3 retry log. Chunk size matches 2MB blocks.
                    </span>
                  </div>

                  <button 
                    onClick={() => setUploadQueue(null)}
                    className="p-1.5 border border-indigo-200 hover:bg-indigo-100 hover:text-rose-500 rounded-lg text-slate-400 transition"
                    title="Batal Unggah"
                  >
                    <X size={14} />
                  </button>
                </div>
              )}

              {/* SECTION A: BIODATA & PENYALURAN TIMELINE GRAPH AND COMPLIANCE MAPS */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
                
                {/* Visual Location Range Verification Map */}
                <div className="md:col-span-5 bg-white border border-slate-200 rounded-2xl p-4 flex flex-col space-y-3 shadow-3xs">
                  <div>
                    <h4 className="text-[11px] font-black text-indigo-900 font-mono uppercase tracking-wider flex items-center gap-1">
                      <Map size={13} />
                      Cakup Jarak Pengantaran Material
                    </h4>
                    <p className="text-[10px] text-slate-500">Visual perbandingan pin koordinat input logistik vs koordinat PB.</p>
                  </div>

                  {/* Leaflet map slot */}
                  <div 
                    ref={mapContainerRef} 
                    className="h-44 w-full bg-slate-100 rounded-2xl border border-slate-250 z-10 overflow-hidden shadow-inner"
                    id="leaflet-compliance-node"
                  />

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="text-[9.5px] font-black font-mono text-indigo-700 block uppercase">Verifikasi Geospasial:</span>
                    <p className="text-[10.5px] text-slate-600 leading-normal">
                      Posisi diinput aman. Jarak hauling logistik sekitar <strong className="text-emerald-600">247 meter</strong> dari atap rumah asli PB. Status: <strong className="bg-emerald-500 text-white px-1.5 py-0.2 rounded text-[9px]">DI LOKASI (&le;500m)</strong>.
                    </p>
                  </div>
                </div>

                {/* Distributions Timeline History list */}
                <div className="md:col-span-7 bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-3xs">
                  <div className="space-y-3">
                    <h4 className="text-[11px] font-black text-indigo-900 font-mono uppercase tracking-wider flex items-center gap-1 border-b border-slate-100 pb-1.5">
                      <History size={13} />
                      Log Riwayat Pengantaran Logistik
                    </h4>
                    
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {distributions.filter(d => d.recipient_id === selectedPB.id).length === 0 ? (
                        <div className="p-6 text-center text-slate-400 italic text-[11px]">
                          Belum ada catatan log muat kirim bahan ke warga ini.
                        </div>
                      ) : (
                        distributions.filter(d => d.recipient_id === selectedPB.id).map((dist, dIdx) => {
                          const itemType = drpbItems.find(db => db.id === dist.drpb_item_id)?.material_type || "Bahan";
                          const unit = drpbItems.find(db => db.id === dist.drpb_item_id)?.unit || "satuan";
                          return (
                            <div key={dist.id || dIdx} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                              <div>
                                <span className="font-extrabold text-slate-850 uppercase text-[11.5px] block">{itemType}</span>
                                <span className="text-[10px] text-slate-500 font-mono">{dist.distribution_date} &bull; TFL: {dist.operator_id}</span>
                              </div>
                              <div className="text-right">
                                <span className="font-mono font-black text-indigo-700 block text-xs bg-indigo-50/50 px-2 py-0.5 rounded border border-indigo-150">
                                  +{dist.volume} {unit}
                                </span>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 text-[10px] text-slate-500 font-mono flex justify-between">
                    <span>Admin ID Operator: {operatorId}</span>
                    <span>Prog: {getPBDRPBStats(selectedPB.id).percentage}% Terkirim</span>
                  </div>
                </div>

              </div>

              {/* SECTION B: UPGRADED DRPB REALIZATION SPREADSHEEET TABLE (PERUBAHAN 7) */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-3xs space-y-4 p-4">
                
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h4 className="text-xs font-black text-slate-900 font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <CheckSquare size={14} className="text-indigo-600" />
                      Tabel Pemenuhan Item Aliran Material (E-DRPB Realisasi)
                    </h4>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      Sistem otomatis mengevaluasi persentase pemenuhan rencana belanja warga. Klik baris/tombol "Cepat" untuk instan realisasi.
                    </p>
                  </div>
                </div>

                {/* VISUAL CONTROLLER FOR DRPB SCAN OCR (Kebutuhan Fitur #1) */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-50 border border-slate-150 p-4 rounded-2xl">
                  <div className="text-left space-y-0.5">
                    <h5 className="text-[11px] font-black uppercase text-slate-800 tracking-wide flex items-center gap-1.5">
                      <Sparkles size={13} className="text-amber-500 fill-amber-400" />
                      Scan Dokumen Foto DRPB (Gemini-AI OCR)
                    </h5>
                    <p className="text-[10px] text-slate-500 leading-relaxed max-w-xl">
                      Punya lembar DRPB fisik? Ambil foto lembar DRPB & unggah di sini. Gemini AI akan menganalisis, mendeteksi daftar bahan bangunan beserta volumenya secara otomatis ke sistem e-DRPB penerima bantuan ini.
                    </p>
                  </div>
                  
                  <div className="shrink-0 w-full md:w-auto">
                    <label className={`w-full md:w-auto py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition border border-amber-650 shadow-xs ${isScanningDRPB ? 'opacity-60 cursor-not-allowed pointer-events-none' : ''}`}>
                      <Image size={14} />
                      <span>{isScanningDRPB ? 'Sedang Memindai...' : 'Ambil Foto / Upload / Kamera'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleDRPBPhotoScan}
                        className="hidden"
                        disabled={isScanningDRPB}
                      />
                    </label>
                  </div>
                </div>

                {isScanningDRPB && (
                  <div className="p-6 bg-amber-50/20 border border-amber-200 text-slate-800 rounded-2xl flex flex-col items-center justify-center gap-4 shadow-2xs">
                    <div className="flex items-center gap-2">
                      <RefreshCw size={16} className="animate-spin text-amber-500" />
                      <span className="text-xs font-black uppercase tracking-wider text-amber-700">Gemini Generative AI sedang memindai berkas DRPB</span>
                    </div>

                    <div className="w-full max-w-lg grid grid-cols-1 md:grid-cols-5 gap-2.5 text-left mt-1.5">
                      {(['Mengunggah foto...', 'Menghubungi Gemini AI...', 'Membaca tabel...', 'Memvalidasi hasil...', 'Selesai'] as OcrStep[]).map((phase, idx) => {
                        const phases: OcrStep[] = ['Mengunggah foto...', 'Menghubungi Gemini AI...', 'Membaca tabel...', 'Memvalidasi hasil...', 'Selesai'];
                        const activeIdx = ocrStep ? phases.indexOf(ocrStep) : -1;
                        const phaseIdx = idx;

                        const isDone = activeIdx > phaseIdx || (activeIdx === -1 && !isScanningDRPB);
                        const isActive = activeIdx === phaseIdx;

                        return (
                          <div key={phase} className={`flex md:flex-col items-center md:items-start gap-2 p-2.5 rounded-xl border ${
                            isActive 
                              ? 'bg-amber-50 border-amber-300 text-amber-950 font-bold' 
                              : isDone 
                                ? 'bg-emerald-50/40 border-emerald-150 text-emerald-800'
                                : 'bg-slate-50/50 border-slate-150 text-slate-400'
                          }`}>
                            <div className="flex items-center justify-center gap-1.5">
                              <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                                isDone 
                                  ? "bg-emerald-100 text-emerald-700" 
                                  : isActive 
                                    ? "bg-amber-100 text-amber-700 animate-pulse" 
                                    : "bg-slate-150 text-slate-400"
                              }`}>
                                {isDone ? "✓" : idx + 1}
                              </div>
                              <span className="text-[9px] font-mono tracking-wider uppercase opacity-75 hidden md:inline">Phase {idx + 1}</span>
                            </div>
                            <span className="text-[10px] font-medium leading-tight">{phase}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {scanError && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                    <AlertTriangle size={15} className="text-red-500" />
                    <span className="font-semibold">{scanError}</span>
                  </div>
                )}

                <div className="overflow-x-auto border border-slate-150 rounded-xl">
                  <table className="w-full border-collapse text-left text-xs bg-white">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-150 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                        <th className="py-2.5 px-4 font-bold">Material</th>
                        <th className="py-2.5 px-3 font-bold">Volume Rencana</th>
                        <th className="py-2.5 px-3 font-bold">Total Terkirim</th>
                        <th className="py-2.5 px-3 font-bold">Sisa Kebutuhan</th>
                        <th className="py-2.5 px-3 font-bold text-center">Status Realisasi</th>
                        <th className="py-2.5 px-4 font-bold text-center w-40">Dokumentasi Cepat</th>
                        <th className="py-2.5 px-4 font-bold text-center w-36">Lunas Cepat</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-150">
                      {drpbItems.filter(item => item.recipient_id === selectedPB.id).length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-5 text-center text-slate-450 italic">
                            Belum ada material yang terdaftar di DRPB PB ini.
                          </td>
                        </tr>
                      ) : (
                        drpbItems.filter(item => item.recipient_id === selectedPB.id).map(item => {
                          const delivered = distributions
                            .filter(d => d.drpb_item_id === item.id)
                            .reduce((sum, curr) => sum + Number(curr.volume), 0);
                          const sisa = Math.max(0, item.required_qty - delivered);
                          const statusLabel = sisa === 0 ? 'SELESAI' : (delivered > 0 ? 'SEBAGIAN' : 'BELUM MULAI');
                          const statusBg = sisa === 0 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                            : (delivered > 0 ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-slate-50 text-slate-500 border-slate-200');

                          return (
                            <tr key={item.id} className="hover:bg-slate-50/50">
                              <td className="py-3 px-4">
                                <span className="font-bold text-slate-900 block text-sm">{item.material_type}</span>
                              </td>
                              <td className="py-3 px-3 font-mono font-medium text-slate-650">
                                {item.required_qty} {item.unit}
                              </td>
                              
                              {/* Direct edit volume input inline */}
                              <td className="py-3 px-3 font-mono align-middle font-bold text-slate-800">
                                {editingItemId === item.id ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="number"
                                      value={inlineVolume}
                                      onChange={(e) => setInlineVolume(e.target.value)}
                                      className="p-1 border border-indigo-400 bg-white text-xs w-20 rounded font-mono font-bold"
                                      placeholder="Rill..."
                                    />
                                    <button 
                                      onClick={() => handleSaveInlineVolume(item)}
                                      className="p-1.5 bg-indigo-600 text-white rounded text-[10px]"
                                    >
                                      ✓
                                    </button>
                                    <button 
                                      onClick={() => setEditingItemId(null)}
                                      className="p-1.5 bg-slate-200 text-slate-600 rounded text-[10px]"
                                    >
                                      ✕
                                    </button>
                                  </div>
                                ) : (
                                  <div 
                                    className="cursor-pointer hover:bg-slate-100 px-1 py-0.5 rounded leading-none flex items-center gap-1 inline-block"
                                    onClick={() => {
                                      setEditingItemId(item.id);
                                      setInlineVolume(sisa.toString());
                                    }}
                                    title="Klik untuk mengedit volume rill secara langsung"
                                  >
                                    {delivered} {item.unit} ✏️
                                  </div>
                                )}
                              </td>

                              <td className="py-3 px-3 font-mono">
                                {sisa > 0 ? (
                                  <span className="text-rose-500 font-bold bg-rose-50/75 px-2 py-0.5 rounded border border-rose-100">
                                    {sisa} {item.unit}
                                  </span>
                                ) : (
                                  <span className="text-emerald-600 font-black flex items-center gap-0.5">
                                    ✓ Lengkap
                                  </span>
                                )}
                              </td>

                              <td className="py-3 px-3 text-center align-middle">
                                <span className={`inline-block text-[9px] font-black border px-2 py-0.5 rounded uppercase leading-none tracking-wider ${statusBg}`}>
                                  {statusLabel}
                                </span>
                              </td>

                              {/* DOCUMENTATION CHUNKS UPLOADS TRIGGERS */}
                              <td className="py-3 px-4 text-center align-middle">
                                <label className="inline-block py-1 px-2.5 text-[10px] font-extrabold bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 rounded-lg cursor-pointer transition select-none active:scale-95 leading-none">
                                  <span>+ Upload Proof</span>
                                  <input 
                                    type="file" 
                                    accept="image/*,video/*"
                                    className="hidden"
                                    onChange={(e) => handleUploadWithChunking(e, item, 'photo_before')}
                                  />
                                </label>
                              </td>

                              {/* MARK AS FULLY REALIZED BUTTON (PERUBAHAN 7) */}
                              <td className="py-3 px-4 text-center">
                                <button
                                  onClick={() => handleMarkAsFullyRealized(item)}
                                  disabled={sisa === 0}
                                  className="w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-[10px] rounded-lg tracking-wide uppercase cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed select-none active:scale-95 leading-none transition"
                                >
                                  Lunas Cepat ⚡
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

              </div>

              {/* TFL Action Notes Input Log */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-2 shadow-3xs">
                <span className="text-[10px] font-black font-mono text-zinc-500 uppercase tracking-wider block">Catatan Rekomendasi Tenaga Lapangan TFL:</span>
                <textarea 
                  rows={2} 
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  placeholder="Isi catatan kendala structural, cuaca buruk, atau kelancaran material..."
                />
              </div>

            </div>

            {/* Modal Footer */}
            <div className="bg-white border-t border-slate-200 px-6 py-4 flex justify-end shrink-0">
              <button
                onClick={handleCloseDetailModal}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-705 text-xs font-bold rounded-xl cursor-pointer"
              >
                Tutup Monitor
              </button>
            </div>

          </div>
        </div>
      )}

      {/* DAILY EXPORTER MODAL POPUP (Fitur #2) */}
      {showDailyExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/45 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-2xl max-w-2xl w-full flex flex-col max-h-[85vh]">
            
            {/* Modal Header */}
            <div className="bg-slate-50 border-b border-slate-150 px-6 py-4 flex justify-between items-center shrink-0">
              <div className="text-left col-span-3">
                <h4 className="text-sm font-black font-mono text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                  <Download size={14} className="text-indigo-600" />
                  Ekspor Ringkasan Aktivitas Harian TFL
                </h4>
                <p className="text-[10px] text-slate-500 font-medium">Guna mempermudah TFL membuat rekapan harian ke Korkab</p>
              </div>
              <button 
                onClick={() => setShowDailyExportModal(false)}
                className="p-1.5 hover:bg-slate-200 rounded-xl cursor-pointer text-slate-450 hover:text-slate-700 transition"
              >
                <X size={15} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4">
              
              {/* Date Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100">
                <div className="text-left">
                  <label className="text-[10px] font-black text-indigo-900 uppercase font-mono tracking-wider block">Pilih Tanggal Laporan:</label>
                  <p className="text-[10px] text-indigo-700 font-medium font-sans">Kunjungan PB & transfer material akan ditarik sesuai tanggal ini.</p>
                </div>
                <input
                  type="date"
                  value={reportDate}
                  onChange={(e) => setReportDate(e.target.value)}
                  className="w-full text-xs font-mono font-bold p-2.5 rounded-xl border border-slate-250 bg-white"
                />
              </div>

              {/* Counters */}
              {(() => {
                const { activeRecipients, materialSummary } = getDailyReportData();
                return (
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-2xl text-left">
                      <span className="text-[9px] font-bold text-emerald-850 uppercase block font-mono">Penerima Dikunjungi</span>
                      <span className="text-lg font-black text-emerald-700 font-mono block mt-1">{activeRecipients.length} Orang (PB)</span>
                      <span className="text-[9px] text-emerald-600 leading-normal">Terpantau aktif melakukan transaksi / realisasi di lapangan</span>
                    </div>

                    <div className="p-3 bg-blue-50 border border-blue-100 rounded-2xl text-left">
                      <span className="text-[9px] font-bold text-blue-850 uppercase block font-mono">Bahan Disalurkan</span>
                      <span className="text-lg font-black text-blue-700 font-mono block mt-1">{materialSummary.length} Item Drop</span>
                      <span className="text-[9px] text-blue-600 leading-normal">Realisasi material terinput pada tanggal laporan terpilih</span>
                    </div>
                  </div>
                );
              })()}

              <div className="space-y-2 text-left">
                <span className="text-[10px] font-black text-slate-800 uppercase font-mono tracking-wider block">Format Teks Preview (Siap Kirim ke WhatsApp Korkab):</span>
                
                {/* Preview Box */}
                <div className="bg-slate-900 text-teal-200 p-4 rounded-2xl font-mono text-[10.5px] leading-relaxed whitespace-pre-wrap overflow-y-auto max-h-56 border border-slate-950 shadow-inner select-all">
                  {(() => {
                    const { activeRecipients, materialSummary } = getDailyReportData();
                    const activeUser = operatorId || "TFL Lapangan";
                    
                    let text = `*LAPORAN HARIAN TENAGA FASILITATOR LAPANGAN (TFL)*\n`;
                    text += `=========================================\n`;
                    text += `Tanggal Laporan : ${new Date(reportDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n`;
                    text += `Fasilitator     : Team / Operator ${activeUser}\n`;
                    text += `=========================================\n\n`;

                    text += `*1. DAFTAR PB YANG DIKUNJUNGI/DISALURKAN HARI INI:*\n`;
                    if (activeRecipients.length === 0) {
                      text += `- Tidak ada aktivitas kunjungan lapangan fisik tercapai hari ini.\n`;
                    } else {
                      activeRecipients.forEach((pb, idx) => {
                        const stats = getPBDRPBStats(pb.id);
                        const pbVillage = villages.find(v => v.id === pb.village_id)?.name || pb.village_id;
                        const statusStr = pb.status === 'complete' ? 'SELESAI FLH' : (pb.status === 'in_progress' ? 'PROSES KONSTRUKSI' : 'BELUM MULAI');
                        text += `${idx + 1}. *${pb.full_name}* (${pbVillage})\n`;
                        text += `   - Status Fisik : ${statusStr}\n`;
                        text += `   - Transaksi DRPB : ${stats.percentage}% Terpenuhi\n`;
                      });
                    }
                    text += `\n`;

                    text += `*2. PROGRESS PENYALURAN BAHAN BANGUNAN HARI INI:*\n`;
                    if (materialSummary.length === 0) {
                      text += `- Belum ada realisasi transfer material terinput hari ini.\n`;
                    } else {
                      materialSummary.forEach((item, idx) => {
                        text += `✓ *${item.recipient_name}* mendapat *${item.material}* sebanyak *${item.volume} ${item.unit}* dari Toko *${item.store_name}*\n`;
                      });
                    }
                    text += `\n`;

                    text += `*3. REKAP KUMULATIF WILAYAH TFL:*\n`;
                    text += `- Total Penerima Bantuan : ${totalPBCount} org\n`;
                    text += `- Selesai (100% Layak Huni) : ${completedPB.length} org\n`;
                    text += `- Sedang Konstruksi : ${inProgressPB.length} org\n`;
                    text += `- Belum Berjalan : ${notStartedPB.length} org\n`;
                    text += `- Kendala/Temuan Aktif : ${hasFindingPB.length} kasus\n`;
                    text += `- Total Serapan Anggaran : Rp ${totalDisbursedFunds.toLocaleString('id-ID')}\n\n`;

                    text += `-----------------------------------------\n`;
                    text += `_Laporan dibuat otomatis menggunakan sistem monitoring terintegrasi BSPS._`;
                    return text;
                  })()}
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 border-t border-slate-150 px-6 py-4 flex justify-between items-center shrink-0">
              <span className="text-[10px] text-slate-500 font-medium">Laporan akan disalin berformat Markdown WA</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowDailyExportModal(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-250 text-slate-800 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  onClick={handleCopyReport}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm shadow-indigo-100 cursor-pointer transition active:scale-95"
                >
                  <Send size={13} />
                  Salin Laporan (WhatsApp)
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
