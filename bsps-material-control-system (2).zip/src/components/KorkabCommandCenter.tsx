import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import MapTracker from './MapTracker';
import { 
  Users, MapPin, Building, ShieldAlert, History, QrCode, 
  MessageCircle, LayoutDashboard, LogOut, CheckCircle2, 
  Plus, AlertTriangle, Layers, Map, Compass, Sparkles, FileText, 
  Download, Settings, Eye, Check, X, ArrowUpRight, Search, Clock, 
  Calendar, RefreshCw, Send, Image, ZoomIn, FileSpreadsheet, ChevronRight, HelpCircle
} from 'lucide-react';
import { Village, Group, Store, Recipient, DRPBItem, Distribution, DistributionMedia, Finding, AuditLog, Arahan, ArahanComment, ArahanProof, User } from '../types';

interface KorkabCommandCenterProps {
  villages: Village[];
  groups: Group[];
  stores: Store[];
  recipients: Recipient[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  distributionMedia: DistributionMedia[];
  findings: Finding[];
  auditLogs: AuditLog[];
  arahan: Arahan[];
  users: User[];
  onRefresh: () => Promise<void>;
  onLogout: () => void;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

export default function KorkabCommandCenter({
  villages,
  groups,
  stores,
  recipients: rawRecipients,
  drpbItems: rawDrpbItems,
  distributions: rawDistributions,
  distributionMedia: rawDistributionMedia,
  findings: rawFindings,
  auditLogs: rawAuditLogs,
  arahan: initialArahan,
  users,
  onRefresh,
  onLogout,
  showToast
}: KorkabCommandCenterProps) {
  // Navigation
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedRecipientId, setSelectedRecipientId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // --- TEAM FILTERING ENGINE ---
  const [selectedTeamFilter, setSelectedTeamFilter] = useState<string>('all');
  
  const registeredTeams = useMemo(() => {
    const teams = (users || []).map(u => u.team_id).filter(Boolean);
    // Include principal seed/demo team "Tim 22" if missing
    if (!teams.some(t => t?.toLowerCase() === 'tim 22' || t?.toLowerCase() === 'tim22')) {
      teams.push("Tim 22");
    }
    return Array.from(new Set(teams));
  }, [users]);

  const recipients = useMemo(() => {
    if (selectedTeamFilter === 'all') return rawRecipients;
    return rawRecipients.filter(r => {
      const t = r.tfl_team || "Tim 22"; // default old seeds to principal team
      return t.toLowerCase().trim() === selectedTeamFilter.toLowerCase().trim();
    });
  }, [rawRecipients, selectedTeamFilter]);

  const activeRecipientIds = useMemo(() => recipients.map(r => r.id), [recipients]);

  const drpbItems = useMemo(() => {
    return rawDrpbItems.filter(item => activeRecipientIds.includes(item.recipient_id));
  }, [rawDrpbItems, activeRecipientIds]);

  const distributions = useMemo(() => {
    return rawDistributions.filter(d => activeRecipientIds.includes(d.recipient_id));
  }, [rawDistributions, activeRecipientIds]);

  const distributionMedia = useMemo(() => {
    return rawDistributionMedia.filter(m => {
      const dist = rawDistributions.find(d => d.id === m.distribution_id);
      return dist && activeRecipientIds.includes(dist.recipient_id);
    });
  }, [rawDistributionMedia, rawDistributions, activeRecipientIds]);

  const findings = useMemo(() => {
    return rawFindings.filter(f => activeRecipientIds.includes(f.recipient_id));
  }, [rawFindings, activeRecipientIds]);

  const auditLogs = useMemo(() => {
    return rawAuditLogs.filter(a => a.entity_type === 'recipient' && activeRecipientIds.includes(a.entity_id || ''));
  }, [rawAuditLogs, activeRecipientIds]);

  const handleMapNavigate = (page: string, id?: string) => {
    if (page === 'recipient_detail' && id) {
      setSelectedRecipientId(id);
      setCurrentTab('pb');
    } else if (page === 'stores' && id) {
      setCurrentTab('material');
    }
  };

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVillageFilter, setSelectedVillageFilter] = useState('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('all');

  // Interactive Map State
  const [selectedMapPB, setSelectedMapPB] = useState<Recipient | null>(null);

  // Gallery view and Zoom modal
  const [galleryFilter, setGalleryFilter] = useState('all');
  const [activePhoto, setActivePhoto] = useState<string | null>(null);

  // Arahan state
  const [arahanList, setArahanList] = useState<Arahan[]>(initialArahan);
  const [showCreateArahanModal, setShowCreateArahanModal] = useState(false);
  const [newArahanTitle, setNewArahanTitle] = useState('');
  const [newArahanCategory, setNewArahanCategory] = useState<'tugas_lapangan' | 'koreksi_data' | 'monitoring_material' | 'progress_fisik' | 'dokumentasi' | 'informasi_umum'>('tugas_lapangan');
  const [newArahanDesc, setNewArahanDesc] = useState('');
  const [newArahanPriority, setNewArahanPriority] = useState<'tinggi' | 'sedang' | 'rendah'>('tinggi');
  const [newArahanDeadline, setNewArahanDeadline] = useState('');
  const [newArahanAttachment, setNewArahanAttachment] = useState('');
  const [submittingArahan, setSubmittingArahan] = useState(false);

  // Active Directives Comment threads
  const [commentInputs, setCommentInputs] = useState<{ [id: string]: string }>({});
  const [weather] = useState(() => {
    const list = ['Cerah Berawan', 'Hujan Sedang', 'Hujan Ringan', 'Berawan Tebal'];
    return {
      temp: '27°C',
      condition: list[Math.floor(Math.random() * list.length)],
      location: 'Minahasa, Sulut'
    };
  });

  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Realtime Time and Date update
  useEffect(() => {
    const clock = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(clock);
  }, []);

  // Sync initial arahan from props
  useEffect(() => {
    setArahanList(initialArahan);
  }, [initialArahan]);

  // Load custom arahan list dynamically
  const fetchArahan = async () => {
    try {
      const res = await fetch('/api/arahan');
      if (res.ok) {
        const data = await res.json();
        setArahanList(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchArahan();
    const interval = setInterval(fetchArahan, 6000); // refresh every 6s for realtime feel
    return () => clearInterval(interval);
  }, []);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await onRefresh();
    await fetchArahan();
    setIsRefreshing(false);
    showToast("Database disinkronkan secara realtime!", "success");
  };

  // Helper inside loop to compute progress percent for a single PB
  const getRecipientProgress = (pbId: string) => {
    const pbDRPB = drpbItems.filter(d => d.recipient_id === pbId);
    if (pbDRPB.length === 0) return 0;
    
    let totalRequired = 0;
    let totalDelivered = 0;

    pbDRPB.forEach(item => {
      totalRequired += item.required_qty;
      const itemDists = distributions.filter(d => d.recipient_id === pbId && d.drpb_item_id === item.id);
      const delivered = itemDists.reduce((acc, curr) => acc + curr.volume, 0);
      totalDelivered += Math.min(item.required_qty, delivered);
    });

    return totalRequired > 0 ? Math.round((totalDelivered / totalRequired) * 100) : 0;
  };

  // Check if Recipient needs attention (stale >7 days, no progress photo, no street view, material incomplete)
  const isRecipientNeedsAttention = (pb: Recipient) => {
    const lastUpdate = pb.updated_at ? new Date(pb.updated_at).getTime() : 0;
    const isStale = (Date.now() - lastUpdate) > 7 * 24 * 60 * 60 * 1000;

    // No Distribution Photos
    const pbPhotos = distributionMedia.filter(m => {
      const dist = distributions.find(d => d.id === m.distribution_id);
      return dist && dist.recipient_id === pb.id && m.media_type.startsWith('photo_');
    });
    const noPhotos = pbPhotos.length === 0;

    // Progress incomplete
    const progress = getRecipientProgress(pb.id);
    const isIncomplete = progress < 100;

    // Findings unremedied
    const hasUnresolvedFinding = findings.some(f => f.recipient_id === pb.id && !f.resolved);

    return isStale || noPhotos || isIncomplete || hasUnresolvedFinding;
  };

  // Dynamic KPI Aggregations
  const stats = useMemo(() => {
    const pbCount = recipients.length;
    const activeDesas = villages.filter(v => recipients.some(r => r.village_id === v.id)).length;
    
    let totalProgressSum = 0;
    let completedCount = 0;
    let inProgressCount = 0;
    let needsAttentionCount = 0;

    recipients.forEach(pb => {
      const prog = getRecipientProgress(pb.id);
      totalProgressSum += prog;
      if (prog === 100) completedCount++;
      else if (prog > 0) inProgressCount++;
      
      if (isRecipientNeedsAttention(pb)) {
        needsAttentionCount++;
      }
    });

    const averageProgress = pbCount > 0 ? Math.round(totalProgressSum / pbCount) : 0;

    // Computes Material Status Distribution
    let completeMats = 0;
    let partialMats = 0;
    let notStartedMats = 0;
    let problematicMats = 0;

    recipients.forEach(pb => {
      const prog = getRecipientProgress(pb.id);
      const hasFinding = findings.some(f => f.recipient_id === pb.id && !f.resolved);
      if (hasFinding) problematicMats++;
      else if (prog === 100) completeMats++;
      else if (prog > 0) partialMats++;
      else notStartedMats++;
    });

    // Arahan/Tugas indicators
    const totalArahan = arahanList.length;
    const pendingArahan = arahanList.filter(a => a.status === 'belum_dibaca' || a.status === 'dibaca').length;
    const waitingVerification = arahanList.filter(a => a.status === 'selesai' && a.proof).length;
    const resolvedArahan = arahanList.filter(a => a.status === 'selesai' && !a.proof).length; // or completed verified
    
    // Deadline This Week
    const oneWeekMs = 7 * 24 * 60 * 60 * 1000;
    const deadlineThisWeek = arahanList.filter(a => {
      const diff = new Date(a.deadline).getTime() - Date.now();
      return diff > 0 && diff <= oneWeekMs && a.status !== 'selesai';
    }).length;

    return {
      pbCount,
      activeDesas,
      averageProgress,
      completedCount,
      inProgressCount,
      needsAttentionCount,
      completeMats,
      partialMats,
      notStartedMats,
      problematicMats,
      totalArahan,
      pendingArahan,
      waitingVerification,
      deadlineThisWeek
    };
  }, [recipients, villages, drpbItems, distributions, findings, arahanList, distributionMedia]);

  // Village Ranking Reports
  const villageRankings = useMemo(() => {
    return villages.map(v => {
      const villagePBs = recipients.filter(r => r.village_id === v.id);
      if (villagePBs.length === 0) return { ...v, pbCount: 0, avgProgress: 0 };
      
      const totalProg = villagePBs.reduce((sum, pb) => sum + getRecipientProgress(pb.id), 0);
      const avgProg = Math.round(totalProg / villagePBs.length);
      return {
        ...v,
        pbCount: villagePBs.length,
        avgProgress: avgProg
      };
    }).sort((a, b) => b.avgProgress - a.avgProgress);
  }, [villages, recipients, drpbItems, distributions]);

  // 🧠 MEMOIZED AI ADVICE & COGNITIVE SERVICES SUITE CALCULATIONS
  const [aiAnalysisResults, setAiAnalysisResults] = useState<{
    insights: string[];
    recommendations: string[];
    anomalies: string[];
    team: string;
    analyzedAt: string;
  } | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const performAnalysis = (teamFilter: string) => {
    setAnalyzing(true);
    // Simulate AI analysis delay
    setTimeout(() => {
      // Logic from pre-existing useMemos, now dynamic based on teamFilter
      const filteredForAnalysis = (teamFilter === 'all' ) ? recipients : recipients.filter(r => (r.tfl_team || "Tim 22").toLowerCase().trim() === teamFilter.toLowerCase().trim());
      
      // Re-calculate stats for this specific team/filter
      const pbCount = filteredForAnalysis.length;
      const statsForTeam = { pbCount };
      
      const insights: string[] = [];
      if (pbCount === 0) {
        insights.push("Tidak ada data penyerapan swadaya untuk tim ini.");
      } else {
         insights.push(`Analisis aktif untuk ${pbCount} PB dalam tim ${teamFilter}.`);
      }

      setAiAnalysisResults({
        insights,
        recommendations: ["Monitoring material secara rutin.", "Pastikan koordinat lokasi sesuai."],
        anomalies: ["Tidak ada anomali terdeteksi."],
        team: teamFilter,
        analyzedAt: new Date().toLocaleTimeString()
      });
      setAnalyzing(false);
    }, 800);
  };

  const fastestVillage = villageRankings[0] || null;
  const needAttentionVillage = [...villageRankings].reverse().find(v => v.pbCount > 0) || null;

  // Recent Activity Feed calculated from Audit Logs + Recent distributions
  const activities = useMemo(() => {
    return [...auditLogs]
      .filter(l => l.action !== 'login')
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 10);
  }, [auditLogs]);

  // Photo gallery filter
  const galleryPhotos = useMemo(() => {
    const list: { id: string; pbName: string; villageName: string; url: string; date: string; type: string }[] = [];
    
    distributionMedia.forEach(m => {
      const dist = distributions.find(d => d.id === m.distribution_id);
      if (!dist) return;
      const pb = recipients.find(r => r.id === dist.recipient_id);
      if (!pb) return;
      const v = villages.find(vl => vl.id === pb.village_id);
      
      // Match active village inside gallery filter
      if (galleryFilter !== 'all' && pb.village_id !== galleryFilter) return;

      list.push({
        id: m.id,
        pbName: pb.full_name,
        villageName: v ? v.name : 'Desa Lain',
        url: m.file_url,
        date: m.uploaded_at,
        type: m.media_type
      });
    });

    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [distributionMedia, distributions, recipients, villages, galleryFilter]);

  // Export handlers
  const handleExport = (type: 'recipients' | 'stores' | 'villages') => {
    showToast(`Mengekspor data ${type}...`, 'success');
    window.open(`/api/reports/${type}/excel`, '_blank');
  };

  // Submit new arahan
  const handleCreateArahan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArahanTitle || !newArahanDesc || !newArahanDeadline) {
      showToast("Sila lengkapi semua field", "error");
      return;
    }
    setSubmittingArahan(true);
    try {
      const res = await fetch('/api/arahan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newArahanTitle,
          category: newArahanCategory,
          description: newArahanDesc,
          priority: newArahanPriority,
          deadline: newArahanDeadline,
          attachment: newArahanAttachment
        })
      });

      if (res.ok) {
        showToast("Arahan KORKAB berhasil disebarkan ke TFL!", "success");
        setShowCreateArahanModal(false);
        setNewArahanTitle('');
        setNewArahanDesc('');
        setNewArahanDeadline('');
        setNewArahanAttachment('');
        fetchArahan();
        onRefresh();
      } else {
        showToast("Gagal menyimpan arahan", "error");
      }
    } catch (err) {
      showToast("Kesalahan jaringan", "error");
    } finally {
      setSubmittingArahan(false);
    }
  };

  // Submit comment reply
  const handlePostComment = async (arahanId: string) => {
    const text = commentInputs[arahanId]?.trim();
    if (!text) return;

    try {
      const res = await fetch(`/api/arahan/${arahanId}/comment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender_role: 'korkab',
          sender_name: 'ADRI MENGKO, ST',
          message: text
        })
      });
      if (res.ok) {
        setCommentInputs(prev => ({ ...prev, [arahanId]: '' }));
        fetchArahan();
        showToast("Komentar terkirim!", "success");
      }
    } catch (e) {
      showToast("Gagal mengirim balasan", "error");
    }
  };

  // Complete arahan verification from Korkab side
  const handleVerifyArahanComplete = async (arahanId: string) => {
    if (!confirm("Tandai tugas ini telah tuntas diverifikasi?")) return;
    try {
      const res = await fetch(`/api/arahan/${arahanId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'selesai',
          operator_id: 'KORKAB_ADRI'
        })
      });
      if (res.ok) {
        fetchArahan();
        showToast("Tugas diverifikasi selesai!", "success");
      }
    } catch (e) {
      showToast("Kesalahan sistem", "error");
    }
  };

  // Filtering Recipients for table view
  const filteredRecipients = useMemo(() => {
    return recipients.filter(pb => {
      const matchesSearch = pb.full_name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            pb.nik.includes(searchTerm) || 
                            pb.address.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesVillage = selectedVillageFilter === 'all' || pb.village_id === selectedVillageFilter;
      
      const progress = getRecipientProgress(pb.id);
      let matchesStatus = true;
      if (selectedStatusFilter === 'complete') matchesStatus = progress === 100;
      else if (selectedStatusFilter === 'in_progress') matchesStatus = progress > 0 && progress < 100;
      else if (selectedStatusFilter === 'not_started') matchesStatus = progress === 0;
      else if (selectedStatusFilter === 'needs_attention') matchesStatus = isRecipientNeedsAttention(pb);

      return matchesSearch && matchesVillage && matchesStatus;
    });
  }, [recipients, searchTerm, selectedVillageFilter, selectedStatusFilter, drpbItems, distributions]);

  return (
    <div className="min-h-screen bg-[#F5F7FA] text-slate-800 flex flex-col font-sans relative">
      
      {/* 1. TOP PREMIUM EXECUTIVE BANNER */}
      <header className="bg-gradient-to-r from-[#041E42] to-[#012169] text-white py-4 px-6 md:px-8 border-b-4 border-amber-500 flex flex-col md:flex-row justify-between items-center gap-4 shadow-md">
        <div className="flex items-center gap-4">
          <img src="/logo.png" alt="Logo PKP" className="h-14 w-auto drop-shadow-md" />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-amber-500 text-slate-950 font-black font-mono tracking-widest px-2 py-0.5 rounded-full">KORKAB</span>
              <span className="text-xs text-slate-300 font-bold font-mono tracking-wide">EXECUTIVE COMMAND CENTER</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black tracking-tight text-white mt-1">SISTEM MONITORING BSPS DIGITAL</h1>
            <p className="text-[11px] text-slate-300 font-medium">Kabupaten Minahasa &bull; Kementerian Perumahan dan Kawasan Permukiman RI</p>
          </div>
        </div>

        {/* Realtime clock and action buttons */}
        <div className="flex items-center gap-4">
          <div className="bg-white/5 backdrop-blur-md px-4 py-2 rounded-xl text-center md:text-right hidden sm:block border border-white/5 font-mono text-xs">
            <div className="text-slate-300 flex items-center gap-1.5 justify-end">
              <Calendar size={13} className="text-amber-400" />
              <span>{currentTime.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
            </div>
            <div className="font-extrabold text-[#F4A300] mt-0.5 flex items-center gap-1.5">
              <Clock size={13} />
              <span>{currentTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })} WITA</span>
            </div>
          </div>

          <button 
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="p-3 bg-white/10 hover:bg-white/15 text-white rounded-xl transition-all duration-200 active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center border border-white/10"
            title="Sinkronisasi Data Realtime"
          >
            <RefreshCw size={15} className={isRefreshing ? 'animate-spin text-amber-400' : ''} />
          </button>

          <button 
            onClick={onLogout}
            className="p-3 bg-red-650/85 hover:bg-red-700 text-white rounded-xl transition-all duration-200 active:scale-95 cursor-pointer flex items-center justify-center border border-red-500/10"
            title="Keluar Sesi KORKAB"
          >
            <LogOut size={15} />
          </button>
        </div>
      </header>

      {/* 2. BODY SHELL WITH SIDEBAR & DESKTOP MAIN WINDOW */}
      <div className="flex-1 flex flex-col md:flex-row">
        
        {/* EXECUTIVE LEFT SIDEBAR NAVIGATION */}
        <aside className="w-full md:w-64 bg-[#0B4F8C] text-white shrink-0 shadow-lg flex flex-col justify-between">
          <div className="p-4 space-y-6">
            
            {/* User Profile widget */}
            <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 space-y-1 text-center sm:text-left relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 bg-amber-400/10 rounded-full blur-xl" />
              <p className="text-[10px] font-black uppercase text-amber-400 tracking-wider font-mono">Penanggung Jawab</p>
              <h3 className="font-black text-sm text-white">ADRI MENGKO, ST</h3>
              <p className="text-[9px] text-slate-300 font-mono mt-0.5">KORKAB TIM 22 MINAHASA</p>
              <div className="pt-2 text-[9px] font-mono text-amber-300 flex items-center justify-center sm:justify-start gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                <span>ONLINE &bull; {weather.temp} {weather.condition}</span>
              </div>
            </div>

            {/* Menu List */}
            <nav className="space-y-1">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
                { id: 'pb', label: 'Monitoring PB', icon: Users },
                { id: 'map', label: 'Peta Sebaran', icon: Map },
                { id: 'progress', label: 'Progress Rumah', icon: Layers },
                { id: 'material', label: 'Material Logistik', icon: Building },
                { id: 'gallery', label: 'Galeri Lapangan', icon: Image },
                { id: 'arahan', label: 'Arahan KORKAB', icon: MessageCircle, badge: stats.pendingArahan },
                { id: 'reports', label: 'Laporan Mandat', icon: FileText },
                { id: 'exports', label: 'Export Excel/CSV', icon: FileSpreadsheet },
              ].map((item) => {
                const IconComp = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentTab(item.id);
                      setSelectedRecipientId(null);
                    }}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer ${
                      isActive 
                        ? 'bg-amber-500 text-slate-950 font-black shadow-md' 
                        : 'text-slate-100 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <IconComp size={15} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge && item.badge > 0 ? (
                      <span className="px-2 py-0.5 text-[9px] font-black bg-red-500 text-white rounded-full font-mono animate-bounce">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar decorative footer */}
          <div className="p-4 border-t border-white/10 hidden md:block">
            <span className="text-[9px] font-mono font-bold text-slate-350 block uppercase text-center">EXECUTIVE SUITE v2.26</span>
          </div>
        </aside>

        {/* MAIN EXECUTIVE PANEL VIEWPORT */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
          
          {/* TEAM ADJUSTMENT CONTROL PANEL (Kebutuhan Fitur #3) */}
          <div className="bg-white border border-slate-100 rounded-2xl p-4 mb-6 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-500/10 text-amber-650 rounded-xl">
                <Users size={18} />
              </div>
              <div className="text-left">
                <h4 className="text-xs font-black uppercase text-slate-800 tracking-wide">Adjust KORKAB Control Dashboard</h4>
                <p className="text-[10px] text-slate-500">Sesuaikan dashboard KORKAB berdasarkan tim TFL terdaftar lapangan.</p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <label className="text-[10px] font-bold font-mono text-slate-400 shrink-0 uppercase">PILIH TIM TFL:</label>
              <select
                value={selectedTeamFilter}
                onChange={(e) => {
                  setSelectedTeamFilter(e.target.value);
                  showToast(`Dashboard disesuaikan untuk: ${e.target.value === 'all' ? 'Semua Tim' : e.target.value.toUpperCase()}`, "success");
                }}
                className="p-2 text-xs rounded-lg border border-slate-200 focus:ring-1 focus:ring-amber-500 bg-slate-50 font-bold text-slate-800 cursor-pointer w-full sm:w-48"
              >
                <option value="all">🌐 Semua Tim (Utuh)</option>
                {registeredTeams.map(t => (
                  <option key={t} value={t}>👥 {t.toUpperCase()}</option>
                ))}
              </select>
            </div>
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={currentTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >

              {/* TAB 1: EXECUTIVE COMMAND CENTER DASHBOARD */}
              {currentTab === 'dashboard' && (
                <div className="space-y-8">
                  
                  {/* Executive Header Banner */}
                  <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-amber-400/5 rounded-full blur-2xl" />
                    <div>
                      <h2 className="text-xl font-bold tracking-tight text-slate-900">Selamat Datang Kepemimpinan, Bapak ADRI MENGKO, ST</h2>
                      <p className="text-xs text-slate-500 mt-1">Status real-time kemajuan dropping stimulan & progress fisik BSPS 2026 Kabupaten Minahasa.</p>
                    </div>
                    
                    {/* Running banner for highest directive */}
                    <div className="shrink-0">
                      <button 
                        onClick={() => setCurrentTab('arahan')}
                        className="py-2.5 px-4 rounded-xl bg-amber-500 text-slate-950 text-xs font-black flex items-center gap-2 cursor-pointer transition active:scale-95 shadow-sm hover:bg-amber-600"
                      >
                        <Plus size={14} />
                        <span>Kirim Arahan Lapangan</span>
                      </button>
                    </div>
                  </div>

                  {/* 6 EXECUTIVE KPI CARDS */}
                  <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
                    {[
                      { label: 'TOTAL PB', val: stats.pbCount, color: 'border-l-indigo-500 text-indigo-700', sub: 'Penerima Bantuan' },
                      { label: 'DESA AKTIF', val: stats.activeDesas, color: 'border-l-sky-500 text-sky-700', sub: 'Kec. Wilayah' },
                      { label: 'RATA PROGRES', val: `${stats.averageProgress}%`, color: 'border-l-emerald-500 text-emerald-700', sub: 'Realisasi Fisik' },
                      { label: 'RUMAH SELESAI', val: stats.completedCount, color: 'border-l-green-500 text-green-700', sub: 'Taraf Progres 100%' },
                      { label: 'RUMAH DALAM PROSES', val: stats.inProgressCount, color: 'border-l-amber-500 text-amber-700', sub: 'Dropping Aktif' },
                      { label: 'PERLU ATTENTION', val: stats.needsAttentionCount, color: 'border-l-red-500 text-red-700 text-red-600 font-extrabold', sub: 'Batas Alert Tinggi' },
                    ].map((card, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ scale: 0.95, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: idx * 0.05 }}
                        className={`p-4 bg-white rounded-2xl border-l-4 border-slate-200/80 hover:border-l-amber-500 border border-slate-150 shadow-sm transition hover:shadow-md ${card.color}`}
                      >
                        <span className="text-[10px] font-bold font-mono tracking-wider block text-slate-400">{card.label}</span>
                        <h2 className="text-2xl font-black font-sans tracking-tight mt-1 mb-0.5">{card.val}</h2>
                        <span className="text-[9px] text-zinc-500 block leading-none font-medium">{card.sub}</span>
                      </motion.div>
                    ))}
                  </div>

                  {/* 🧠 SMART ADVISOR & COGNITIVE PREDUCTION SUITE */}
                  <div className="bg-[#022a5e]/5 rounded-2xl p-6 border border-amber-500/10 shadow-3xs space-y-4 relative overflow-hidden" id="korkab-ai-cognitive-suite">
                    {/* Decorative backdrop mesh */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" />
                    
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-slate-900 text-amber-400 rounded-xl shadow-xs">
                          <Sparkles className="w-5 h-5 animate-pulse" />
                        </div>
                        <div>
                          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider font-display flex items-center gap-2">
                            Asisten Eksekutif Wilayah AIBSPS
                          </h3>
                          <p className="text-[10px] text-slate-500 font-medium">Informasi prognostik &amp; rekomendasi taktis kepemimpinan KORKAB.</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1.5 self-start sm:self-auto bg-amber-100 border border-amber-205 px-3 py-1 rounded-full text-[9px] font-mono font-black text-amber-800 uppercase tracking-widest">
                        🤖 EXECUTIVE COGNITION ACTIVE
                      </div>
                    </div>

                    {/* 3-Column Responsive Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5 relative z-10">
                      
                      {/* 1. PREDICTIVE INSIGHTS */}
                      <div className="bg-white border border-slate-200/85 rounded-2xl p-4.5 space-y-3.5 shadow-3xs flex flex-col justify-between">
                        <div className="space-y-2.5">
                          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                            <span className="text-xs">📈</span>
                            <span className="text-[10px] font-black text-slate-505 uppercase tracking-wider font-mono">Prognosis &amp; Trend Wilayah</span>
                          </div>
                          <ul className="space-y-2.5 text-[10.5px] text-slate-600 leading-relaxed list-none pl-0">
                            {analyzing ? (
                              Array.from({ length: 3 }).map((_, i) => (
                                <li key={i} className="flex items-start gap-2 animate-pulse">
                                  <div className="w-2 h-2 bg-slate-200 rounded-full mt-1 shrink-0" />
                                  <div className="h-3 bg-slate-200 rounded-full w-full" />
                                </li>
                              ))
                            ) : aiAnalysisResults?.insights.map((insight, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <span className="text-amber-500 font-black mt-0.5 shrink-0">•</span>
                                <span>{insight}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* 2. TREND ALERTS / ANOMALIES */}
                      <div className="bg-white border border-slate-200/85 rounded-2xl p-4.5 space-y-3.5 shadow-3xs flex flex-col justify-between">
                        <div className="space-y-2.5">
                          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                            <span className="text-xs">🚨</span>
                            <span className="text-[10px] font-black text-slate-505 uppercase tracking-wider font-mono">Deteksi Botol Leher Lapangan</span>
                          </div>
                          <ul className="space-y-2.5 text-[10.5px] text-slate-650 leading-relaxed list-none pl-0">
                            {analyzing ? (
                              Array.from({ length: 2 }).map((_, i) => (
                                <li key={i} className="flex items-start gap-2 bg-rose-50/15 border border-rose-100/40 p-2.5 rounded-xl animate-pulse">
                                  <div className="w-4 h-4 bg-rose-200 rounded-full shrink-0" />
                                  <div className="h-3 bg-rose-200 rounded-full w-full" />
                                </li>
                              ))
                            ) : aiAnalysisResults?.anomalies.map((anomaly, idx) => (
                              <li key={idx} className="flex items-start gap-2 bg-rose-50/15 border border-rose-100/40 p-2.5 rounded-xl text-slate-700">
                                <span className="text-rose-500 font-extrabold mt-0.5 shrink-0">⚠️</span>
                                <span className="font-semibold text-rose-950/80">{anomaly}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* 3. RECOMMENDATION CARDS */}
                      <div className="bg-white border border-slate-200/85 rounded-2xl p-4.5 space-y-3.5 shadow-3xs flex flex-col justify-between">
                        <div className="space-y-2.5">
                          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                            <span className="text-xs">💡</span>
                            <span className="text-[10px] font-black text-slate-550 uppercase tracking-wider font-mono">Rekomendasi Taktis</span>
                          </div>
                          <div className="space-y-2.5">
                            {analyzing ? (
                              Array.from({ length: 3 }).map((_, i) => (
                                <div key={i} className="p-2.5 border border-slate-100 bg-slate-50/50 rounded-xl animate-pulse flex items-center gap-2">
                                  <div className="w-3 h-3 bg-slate-200 rounded-full shrink-0" />
                                  <div className="h-3 bg-slate-200 rounded-full w-full" />
                                </div>
                              ))
                            ) : aiAnalysisResults?.recommendations.map((rec, idx) => (
                              <div key={idx} className="p-2.5 border border-slate-100 bg-slate-50/50 rounded-xl text-slate-700 font-medium text-[10.5px] flex items-center gap-2">
                                <span className="w-1.5 h-1.5 bg-sky-500 rounded-full shrink-0" />
                                <span>{rec}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* MIDDLE GRID: MAP + VILLAGE ANALYSIS WIDGETS */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* Col 1 & 2: Large Map Sebaran Shortcut */}
                    <div className="lg:col-span-2 p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <Map className="text-indigo-600 w-5 h-5" />
                          <h3 className="font-bold text-sm uppercase text-slate-900 tracking-tight">Status Peta GPS Sebaran Penerima</h3>
                        </div>
                        <button 
                          onClick={() => setCurrentTab('map')}
                          className="text-xs font-bold text-[#0B4F8C] flex items-center gap-1 hover:underline"
                        >
                          <span>Buka Peta Komprehensif</span>
                          <ArrowUpRight size={13} />
                        </button>
                      </div>

                      {/* Map Area Mock / Embedded view representation */}
                      <div className="relative h-96 w-full rounded-2xl bg-slate-900 overflow-hidden text-white flex flex-col justify-end p-4 border border-slate-200/40 shadow-inner">
                        <div className="absolute inset-0 bg-[radial-gradient(#1A365D_1px,transparent_1px)] [background-size:16px_16px] opacity-25" />
                        
                        {/* Interactive Markers overlay simulator with responsive clicks */}
                        <div className="absolute inset-0 flex items-center justify-center p-6">
                          <div className="relative w-full h-full">
                            {recipients.slice(0, 10).map((r, i) => {
                              const prog = getRecipientProgress(r.id);
                              let col = 'bg-emerald-500 ring-emerald-500/30';
                              if (prog === 0) col = 'bg-red-500 ring-red-500/30';
                              else if (prog < 100) col = 'bg-yellow-500 ring-yellow-500/30';

                              return (
                                <motion.button
                                  key={r.id}
                                  onClick={() => setSelectedMapPB(r)}
                                  className={`absolute ${col} w-4 h-4 rounded-full ring-4 shadow-lg focus:outline-none cursor-pointer transition transform hover:scale-125`}
                                  style={{
                                    left: `${30 + (i * 7) % 65}%`,
                                    top: `${20 + (i * 9) % 70}%`
                                  }}
                                  animate={{ scale: [1, 1.1, 1] }}
                                  transition={{ repeat: Infinity, duration: 2 + i % 2, delay: i * 0.1 }}
                                />
                              );
                            })}
                          </div>
                        </div>

                        {/* Selected PB Details floating box */}
                        <div className="z-10 w-full">
                          {selectedMapPB ? (
                            <div className="p-4 rounded-xl bg-slate-950/90 text-white backdrop-blur-md border border-white/20 shadow-2xl relative">
                              <button 
                                onClick={() => setSelectedMapPB(null)}
                                className="absolute top-2.5 right-2.5 text-slate-400 hover:text-white p-1 rounded-lg"
                              >
                                <X size={14} />
                              </button>
                              <div className="flex gap-4">
                                <div className="w-14 h-14 bg-white/10 rounded-lg flex items-center justify-center text-xl shrink-0 font-bold border border-white/10">
                                  🏡
                                </div>
                                <div className="space-y-1 select-text">
                                  <span className="text-[9px] font-bold uppercase tracking-wider font-mono text-amber-400">
                                    Progress Fisik: {getRecipientProgress(selectedMapPB.id)}%
                                  </span>
                                  <h3 className="font-bold text-xs">{selectedMapPB.full_name.toUpperCase()}</h3>
                                  <p className="text-[10px] text-slate-300">Desa: {villages.find(v => v.id === selectedMapPB.village_id)?.name || 'Kec. Minahasa'}</p>
                                  <p className="text-[9px] text-slate-400">Status Material: {selectedMapPB.status === 'complete' ? 'Lengkap Terdisitribusi' : 'Penyaluran Bertahap'}</p>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="p-3 bg-black/60 backdrop-blur-md rounded-xl text-center text-xs text-slate-350">
                              💡 Klik penanda koordinat di atas untuk menganalisis material, progress fisik, dan street view setiap rumah PB secara cepat.
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Col 3: Executive Widgets (Villages Performance & SV Status) */}
                    <div className="space-y-4">
                      
                      {/* Desa Tercepat & Memerlukan Perhatian */}
                      <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                        <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase">Analisis Wilayah</h4>
                        
                        {/* Fastest */}
                        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100">
                          <span className="text-[9px] font-black uppercase text-emerald-700 bg-emerald-300/30 px-1.5 py-0.5 rounded-full font-mono">
                            Desa Tercepat
                          </span>
                          <h3 className="text-sm font-extrabold text-emerald-950 mt-1.5 uppercase">
                            {fastestVillage ? fastestVillage.name : 'Memuat data...'}
                          </h3>
                          <p className="text-[10px] text-emerald-800 font-mono mt-0.5">Average Progress: {fastestVillage?.avgProgress}%</p>
                        </div>

                        {/* Slowest / Need Attention */}
                        <div className="p-3 rounded-xl bg-red-50 border border-red-100">
                          <span className="text-[9px] font-black uppercase text-red-700 bg-red-300/30 px-1.5 py-0.5 rounded-full font-mono">
                            Desa Perlu Perhatian
                          </span>
                          <h3 className="text-sm font-extrabold text-red-950 mt-1.5 uppercase">
                            {needAttentionVillage ? needAttentionVillage.name : 'Memuat data...'}
                          </h3>
                          <p className="text-[10px] text-red-800 font-mono mt-0.5">Average Progress: {needAttentionVillage?.avgProgress}%</p>
                        </div>
                      </div>

                      {/* Circular Progress: Rata-rata Progres Fisik */}
                      <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                        <div className="flex justify-between items-center">
                          <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase">Rata-rata Fisik Tuntas</h4>
                          <span className="text-xs font-mono font-bold text-indigo-700">{stats.averageProgress}%</span>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          {/* Pure SVG Animated Circular indicator */}
                          <div className="relative w-16 h-16 shrink-0">
                            <svg className="w-16 h-16 transform -rotate-90">
                              <circle cx="32" cy="32" r="28" stroke="#E2E8F0" strokeWidth="6" fill="transparent" />
                              <circle 
                                cx="32" cy="32" r="28" 
                                stroke="#3B82F6" strokeWidth="6" fill="transparent" 
                                strokeDasharray={2 * Math.PI * 28}
                                strokeDashoffset={2 * Math.PI * 28 * (1 - stats.averageProgress / 100)}
                                strokeLinecap="round"
                              />
                            </svg>
                            <span className="absolute inset-0 flex items-center justify-center font-mono font-bold text-[10px]">
                              {stats.completedCount}/{recipients.length}
                            </span>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-slate-800">Progres Konstruksi Penerima Bantuan</p>
                            <p className="text-[9px] text-slate-500 mt-1 leading-normal">Status fisik tuntas dikalkulasi dari dropping logistik lengkap dan penyelesaian audit.</p>
                          </div>
                        </div>
                      </div>

                      {/* Doughnut Progress: Material Delivery Status */}
                      <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                        <div className="flex justify-between items-center">
                          <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase">Monitoring Material</h4>
                        </div>
                        <div className="space-y-2">
                          {[
                            { name: 'Material Lengkap (100%)', count: stats.completeMats, color: 'bg-green-500' },
                            { name: 'Penyaluran Sebagian', count: stats.partialMats, color: 'bg-amber-500' },
                            { name: 'Belum Ada Distribusi', count: stats.notStartedMats, color: 'bg-indigo-500' },
                            { name: 'Sengketa/Bermasalah', count: stats.problematicMats, color: 'bg-red-500' },
                          ].map((cat, i) => (
                            <div key={i} className="flex justify-between items-center text-xs">
                              <div className="flex items-center gap-2 text-[11px] font-medium text-slate-600">
                                <span className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                                <span>{cat.name}</span>
                              </div>
                              <span className="font-mono font-bold">{cat.count} PB</span>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* BOTTOM ROW GRID: FIELD ACTIVITY TFL + RECENT FEED */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    
                    {/* TFL Field Output Metrics */}
                    <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <Users className="text-amber-500 w-5 h-5" />
                          <h3 className="font-bold text-sm uppercase text-slate-900 tracking-tight">Kinerja Harian Fasilitator (TFL)</h3>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">SINKRON</span>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="p-3 bg-slate-50 rounded-xl relative overflow-hidden">
                          <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">Upload Foto</span>
                          <h3 className="text-xl font-bold mt-1 text-slate-800">{distributionMedia.length}</h3>
                          <span className="text-[9px] text-slate-500">Berkas Visual</span>
                        </div>
                        <div className="p-3 bg-slate-50 rounded-xl relative overflow-hidden">
                          <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">Kekurangan SMS</span>
                          <h3 className="text-xl font-bold mt-1 text-amber-600">{findings.filter(f => !f.resolved).length}</h3>
                          <span className="text-[9px] text-slate-500">Laporan Kendala</span>
                        </div>
                        <div className="p-3 bg-slate-50 rounded-xl relative overflow-hidden">
                          <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">Tuntutan Progress</span>
                          <h3 className="text-xl font-bold mt-1 text-emerald-600">{distributions.length}</h3>
                          <span className="text-[9px] text-slate-500">Riwayat Dropping</span>
                        </div>
                      </div>
                    </div>

                    {/* Recent audit trails activities Feed */}
                    <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <History className="text-[#0B4F8C] w-5 h-5" />
                          <h3 className="font-bold text-sm uppercase text-slate-900 tracking-tight">Feed Aktivitas Lapangan Terbaru</h3>
                        </div>
                        <button 
                          onClick={() => setCurrentTab('reports')}
                          className="text-xs font-bold text-[#0B4F8C] hover:underline"
                        >
                          Semua Log
                        </button>
                      </div>

                      <div className="space-y-3.5 max-h-60 overflow-y-auto pr-1">
                        {activities.length === 0 ? (
                          <div className="p-8 text-center text-xs text-slate-400 italic">
                            Belum ada riwayat aktivitas terbaru hari ini.
                          </div>
                        ) : (
                          activities.map((act) => (
                            <div key={act.id} className="flex gap-3 text-xs border-b border-slate-50 pb-2.5 last:border-0 pl-1">
                              <span className="text-sm shrink-0 mt-0.5">📝</span>
                              <div className="space-y-0.5 select-text">
                                <p className="font-medium text-slate-700">{act.description}</p>
                                <div className="flex items-center gap-2 text-[9px] text-slate-400 font-mono">
                                  <span>{act.user_id.toUpperCase()}</span>
                                  <span>&bull;</span>
                                  <span>{new Date(act.created_at).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit' })} ({Math.max(1, Math.round((Date.now() - new Date(act.created_at).getTime()) / 60000))} menit lalu)</span>
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* TAB 2: MONITORING RECIPIENTS (PB) */}
              {currentTab === 'pb' && (
                <div className="space-y-6">
                  
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">Database Penerima Bantuan (Mata-Mata KORKAB)</h2>
                      <p className="text-xs text-slate-500 mt-1">Status ketersediaan material, kecocokan koordinat GPS, dan bukti pemantauan fisik.</p>
                    </div>
                    <span className="text-xs font-bold bg-[#0B4F8C]/10 text-[#0B4F8C] px-3.5 py-1.5 rounded-xl font-mono uppercase">
                      Read Only Mode
                    </span>
                  </div>

                  {/* Filter Search controls */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="relative">
                      <Search className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
                      <input 
                        type="text" 
                        placeholder="Cari nama PB, NIK, atau alamat..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 text-xs bg-white border border-slate-200 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C] rounded-xl font-mono"
                      />
                    </div>

                    <select
                      value={selectedVillageFilter}
                      onChange={(e) => setSelectedVillageFilter(e.target.value)}
                      className="p-3 text-xs bg-white border border-slate-200 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C] cursor-pointer rounded-xl font-mono"
                    >
                      <option value="all">Semua Desa Wilayah Binaan</option>
                      {villages.map(v => (
                        <option key={v.id} value={v.id}>{v.name.toUpperCase()}</option>
                      ))}
                    </select>

                    <select
                      value={selectedStatusFilter}
                      onChange={(e) => setSelectedStatusFilter(e.target.value)}
                      className="p-3 text-xs bg-white border border-slate-200 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C] cursor-pointer rounded-xl font-mono"
                    >
                      <option value="all">Semua Status Penyaluran</option>
                      <option value="complete">Selesai (Progress 100%)</option>
                      <option value="in_progress">Dalam Penyaluran (1%-99%)</option>
                      <option value="not_started">Belum Mulai (0%)</option>
                      <option value="needs_attention">Perlu Perhatian Khusus</option>
                    </select>
                  </div>

                  {/* Recipients Table */}
                  <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-150 text-slate-500 font-bold uppercase font-mono text-[10px]">
                            <th className="py-4 px-5">Nama PB</th>
                            <th className="py-4 px-5">Identitas NIK</th>
                            <th className="py-4 px-4">Desa Kelompok</th>
                            <th className="py-4 px-4">Koordinat Dropping</th>
                            <th className="py-4 px-4 text-center">Progress Dropping</th>
                            <th className="py-4 px-5 text-right font-sans">Visual & Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredRecipients.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="py-12 text-center text-slate-400 italic">
                                Tidak ada data penerima bantuan yang cocok dengan kriteria filter.
                              </td>
                            </tr>
                          ) : (
                            filteredRecipients.map(pb => {
                              const progressPct = getRecipientProgress(pb.id);
                              const isAttention = isRecipientNeedsAttention(pb);
                              const vName = villages.find(v => v.id === pb.village_id)?.name || 'Desa';
                              const gName = groups.find(g => g.id === pb.group_id)?.name || 'Kelompok';

                              return (
                                <tr key={pb.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition">
                                  <td className="py-4 px-5 font-bold select-text text-slate-800">
                                    <div className="flex flex-col">
                                      <span>{pb.full_name.toUpperCase()}</span>
                                      <span className="text-[10px] text-slate-400 italic font-mono mt-0.5">{pb.address}</span>
                                    </div>
                                  </td>
                                  <td className="py-4 px-5 font-mono text-slate-600">{pb.nik}</td>
                                  <td className="py-4 px-4 text-slate-600 uppercase font-medium">
                                    <div className="flex flex-col gap-0.5">
                                      <span>{vName}</span>
                                      <span className="text-[10px] text-zinc-400">{gName}</span>
                                    </div>
                                  </td>
                                  <td className="py-4 px-4 font-mono text-[10px] text-slate-500">
                                    {pb.latitude ? `${pb.latitude.toFixed(5)}, ${pb.longitude.toFixed(5)}` : 'Belum Terkunci'}
                                  </td>
                                  <td className="py-4 px-4">
                                    <div className="space-y-1 w-32 mx-auto">
                                      <div className="flex justify-between items-center text-[10px] font-mono">
                                        <span className={`font-bold ${progressPct === 100 ? 'text-green-600' : 'text-amber-500'}`}>{progressPct}%</span>
                                        {isAttention ? (
                                          <span className="text-red-500 text-[9px] font-black uppercase text-[8px] tracking-wide animate-pulse bg-red-100 px-1 rounded">Attention</span>
                                        ) : null}
                                      </div>
                                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                        <div 
                                          className={`h-full ${progressPct === 100 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                                          style={{ width: `${progressPct}%` }}
                                        />
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-4 px-5 text-right space-x-1.5">
                                    {/* Launch full read-only modal or display details */}
                                    <button 
                                      onClick={() => {
                                        setSelectedRecipientId(pb.id);
                                        // Render special view
                                      }}
                                      className="py-1.5 px-3 rounded-lg border border-[#0B4F8C]/20 hover:border-[#0B4F8C] bg-white text-[#0B4F8C] font-bold text-[10px] leading-none transition-all duration-200 active:scale-95 cursor-pointer flex items-center gap-1 inline-flex"
                                    >
                                      <Eye size={12} />
                                      <span>Periksa</span>
                                    </button>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

              {/* READ ONLY PB DETAIL WINDOW VIEWPORT (INJECTED ON SELECT) */}
              {selectedRecipientId && (
                <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex justify-end p-4">
                  <motion.div 
                    initial={{ x: 500 }}
                    animate={{ x: 0 }}
                    exit={{ x: 500 }}
                    className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl p-6 overflow-y-auto space-y-6"
                  >
                    
                    {/* Header detail */}
                    <div className="flex justify-between items-center border-b border-slate-100 pb-4">
                      <div>
                        <span className="text-[10px] font-bold font-mono tracking-wider text-amber-500 uppercase">PB DETIL AUDIT TRAIL</span>
                        <h2 className="text-xl font-bold text-slate-900 mt-1">
                          {recipients.find(r => r.id === selectedRecipientId)?.full_name.toUpperCase()}
                        </h2>
                      </div>
                      <button 
                        onClick={() => setSelectedRecipientId(null)}
                        className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-xl cursor-pointer"
                      >
                        <X size={16} />
                      </button>
                    </div>

                    {/* Meta data of Selected PB */}
                    {(() => {
                      const pbItem = recipients.find(r => r.id === selectedRecipientId);
                      if (!pbItem) return null;
                      
                      const dItems = drpbItems.filter(d => d.recipient_id === pbItem.id);
                      const pbDists = distributions.filter(d => d.recipient_id === pbItem.id);
                      const pbFindings = findings.filter(f => f.recipient_id === pbItem.id);
                      const tflName = 'TIM 22';

                      return (
                        <div className="space-y-6">
                          
                          {/* Profile row */}
                          <div className="grid grid-cols-2 gap-4 text-xs">
                            <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-slate-600">
                              <p className="font-mono text-[9px] text-slate-400 font-bold uppercase">NIK Penerima</p>
                              <p className="font-bold text-slate-800 select-all font-mono">{pbItem.nik}</p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-slate-600">
                              <p className="font-mono text-[9px] text-slate-400 font-bold uppercase">No Kartu Keluarga</p>
                              <p className="font-mono font-bold text-slate-800 select-all">{pbItem.kk_number}</p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-slate-600">
                              <p className="font-mono text-[9px] text-slate-400 font-bold uppercase">Jalur Alamat</p>
                              <p className="font-bold text-slate-800">{pbItem.address}</p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-slate-600">
                              <p className="font-mono text-[9px] text-slate-400 font-bold uppercase">Akurasi Dropping GPS</p>
                              <p className="font-mono font-bold text-[#0B4F8C]">
                                {pbItem.latitude ? `${pbItem.latitude.toFixed(6)}, ${pbItem.longitude.toFixed(6)}` : 'Tidak Ada'}
                              </p>
                            </div>
                          </div>

                          {/* Material progress list detail */}
                          <div className="space-y-3">
                            <h3 className="font-bold text-xs uppercase text-slate-900 tracking-tight">Status DRPB (Rencana Material) & Penyaluran</h3>
                            <div className="space-y-2 border border-slate-100 rounded-2xl p-4">
                              {dItems.length === 0 ? (
                                <p className="text-xs text-slate-400 italic text-center py-4">Belum ada item material yang didaftarkan TFL.</p>
                              ) : (
                                dItems.map(item => {
                                  const delivered = pbDists
                                    .filter(d => d.drpb_item_id === item.id)
                                    .reduce((sum, curr) => sum + curr.volume, 0);
                                  const pct = Math.min(100, Math.round((delivered / item.required_qty) * 100)) || 0;

                                  return (
                                    <div key={item.id} className="text-xs flex justify-between items-center border-b border-slate-50 pb-2.5 last:border-0 last:pb-0">
                                      <div>
                                        <p className="font-bold text-slate-800 uppercase">{item.material_type}</p>
                                        <p className="text-[10px] text-slate-400">Dropping: {delivered} dari {item.required_qty} {item.unit}</p>
                                      </div>
                                      <div className="text-right">
                                        <span className={`font-mono font-bold ${pct === 100 ? 'text-green-600' : 'text-amber-500'}`}>{pct}%</span>
                                      </div>
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          </div>

                          {/* Active Findings for this PB */}
                          <div className="space-y-3">
                            <h3 className="font-bold text-xs uppercase text-slate-900 tracking-tight">Audit Temuan Kendala</h3>
                            <div className="space-y-2">
                              {pbFindings.length === 0 ? (
                                <p className="text-xs text-emerald-600 bg-emerald-50 p-3 rounded-xl border border-emerald-100 text-center">
                                  ✅ Bebas temuan kendala material. Dropping aman!
                                </p>
                              ) : (
                                pbFindings.map(f => (
                                  <div key={f.id} className={`p-3 rounded-xl border text-xs flex justify-between gap-3 ${f.resolved ? 'bg-emerald-50/50 border-emerald-100 text-slate-700' : 'bg-red-50 border-red-100 text-red-950'}`}>
                                    <div className="space-y-1">
                                      <p className="font-bold uppercase tracking-wider text-[9px] font-mono">
                                        {f.category.replace('_', ' ').toUpperCase()}
                                      </p>
                                      <p>{f.description}</p>
                                      <p className="text-[9px] text-slate-400">Dilaporkan oleh: {f.reported_by}</p>
                                    </div>
                                    <div className="shrink-0 flex items-center">
                                      <span className={`font-extrabold text-[9px] uppercase px-2 py-0.5 rounded-md ${f.resolved ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white animate-pulse'}`}>
                                        {f.resolved ? 'Tuntas' : 'Terbuka'}
                                      </span>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>



                        </div>
                      );
                    })()}

                  </motion.div>
                </div>
              )}

              {/* TAB 3: FULL SCREEN INTERACTIVE MAP SEBARAN */}
              {currentTab === 'map' && (
                <div className="space-y-6">
                  <MapTracker 
                    recipients={recipients} 
                    stores={stores} 
                    villages={villages}
                    drpbItems={drpbItems}
                    distributions={distributions}
                    onNavigate={handleMapNavigate}
                  />
                </div>
              )}

              {/* TAB 4: PROGRESS RUMAH VILLA-BY-VILLAGE STATISTICS */}
              {currentTab === 'progress' && (
                <div className="space-y-6">
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
                    <h2 className="text-lg font-bold text-slate-900 font-sans">Monitoring Progress Fisik Kabupaten per Desa</h2>
                    <p className="text-xs text-slate-500 mt-1">Ranking otomatis berdasarkan tingkat realisasi fisik material stimulan di lapangan.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Rankings listing */}
                    <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                      <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase">Hierarki Ranking Kemajuan Fisik</h4>
                      <div className="space-y-3.5">
                        {villageRankings.filter(v => v.pbCount > 0).map((vr, i) => (
                          <div key={vr.id} className="space-y-1.5">
                            <div className="flex justify-between items-center text-xs">
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-black text-slate-400 bg-slate-100 w-5 h-5 rounded-md flex items-center justify-center">
                                  #{i+1}
                                </span>
                                <span className="font-bold text-slate-800 uppercase">{vr.name}</span>
                                <span className="text-[10px] text-slate-400">({vr.pbCount} PB)</span>
                              </div>
                              <span className="font-mono font-black text-[#0B4F8C]">{vr.avgProgress}%</span>
                            </div>
                            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full"
                                style={{ width: `${vr.avgProgress}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Explanatory cards */}
                    <div className="space-y-6">
                      <div className="p-6 bg-amber-50 rounded-3xl border border-amber-200/40 text-[#5c4033] space-y-3">
                        <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-amber-800">Catatan Koordinator untuk TFL</h4>
                        <p className="text-xs leading-relaxed text-slate-700">
                          Desa dengan tingkat penyerapan di bawah <strong>40%</strong> harus segera dijadwalkan verifikasi fisik dan audit data. KORKAB merekomendasikan TFL memberikan prioritas pengiriman untuk sisa bahan stimulan.
                        </p>
                      </div>

                      <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-3">
                        <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase">Perbandingan Total Terverifikasi</h4>
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div className="p-3 bg-emerald-50 rounded-xl">
                            <span className="text-[9px] font-bold text-emerald-800 block">FISIK SELESAI (100%)</span>
                            <span className="text-2xl font-black text-emerald-950 block mt-1">{stats.completedCount} Unit</span>
                          </div>
                          <div className="p-3 bg-blue-50 rounded-xl">
                            <span className="text-[9px] font-bold text-blue-800 block">DALAM PROGRES REKONSILIASI</span>
                            <span className="text-2xl font-black text-blue-950 block mt-1">{stats.inProgressCount} Unit</span>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>
              )}



              {/* TAB 6: MATERIAL DISTRIBUTION STATUS */}
              {currentTab === 'material' && (
                <div className="space-y-6">
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
                    <h2 className="text-lg font-bold text-slate-900">Analisis Kepatuhandropping Material PKP</h2>
                    <p className="text-xs text-slate-500 mt-1">Mengawasi jalannya pengiriman bahan bangunan stimulan langsung ke titik dropping.</p>
                  </div>

                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm text-center py-12">
                    <span className="text-4xl">📊</span>
                    <h3 className="font-extrabold text-sm text-slate-800 uppercase mt-4">Statistik Volume Distribusi Material</h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
                      Lengkap: {stats.completeMats} PB | Sebagian: {stats.partialMats} PB | Belum Dropping: {stats.notStartedMats} PB | Masalah/Temuan: {stats.problematicMats} PB.
                    </p>
                  </div>

                </div>
              )}

              {/* TAB 7: FIELD PHOTO GALLERY LOGS */}
              {currentTab === 'gallery' && (
                <div className="space-y-6">
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">Galeri Foto Dropping & Progres Lapangan</h2>
                      <p className="text-xs text-slate-500 mt-1">Grid foto modern seluruh aktivitas TFL untuk pembuktian dropping material fisik yang valid.</p>
                    </div>
                    
                    <select
                      value={galleryFilter}
                      onChange={(e) => setGalleryFilter(e.target.value)}
                      className="p-3 text-xs bg-white border border-slate-200 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C] cursor-pointer rounded-xl font-mono"
                    >
                      <option value="all">Semua Desa Wilayah Binaan</option>
                      {villages.map(v => (
                        <option key={v.id} value={v.id}>{v.name.toUpperCase()}</option>
                      ))}
                    </select>
                  </div>

                  {galleryPhotos.length === 0 ? (
                    <div className="bg-white rounded-3xl border border-slate-100 p-16 text-center text-slate-400 italic">
                      Belum ada foto progres material terunggah untuk kategori desa ini.
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                      {galleryPhotos.map((ph) => (
                        <div 
                          key={ph.id} 
                          onClick={() => setActivePhoto(ph.url)}
                          className="group relative bg-[#041E42]/5 rounded-2xl overflow-hidden h-44 shadow-sm border border-slate-200/50 hover:shadow-lg transition cursor-pointer select-none"
                        >
                          <img 
                            src={ph.url} 
                            alt={`Progres ${ph.pbName}`} 
                            className="w-full h-full object-cover transition transform duration-500 group-hover:scale-110" 
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end space-y-1">
                            <span className="text-[9px] font-black uppercase text-amber-500 font-mono tracking-wider">{ph.villageName}</span>
                            <h4 className="text-[11px] font-black text-white leading-tight uppercase font-sans">{ph.pbName}</h4>
                            <p className="text-[9px] text-slate-350">{new Date(ph.date).toLocaleDateString('id-ID')}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* High Resolution Zoom Photo Modal */}
                  <AnimatePresence>
                    {activePhoto && (
                      <div className="fixed inset-0 z-[10000] bg-slate-950/90 flex flex-col justify-center items-center p-6">
                        <button 
                          onClick={() => setActivePhoto(null)}
                          className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full cursor-pointer z-20 font-bold transition transform duration-200 active:scale-95"
                        >
                          <X size={20} />
                        </button>
                        <motion.div 
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.9, opacity: 0 }}
                          className="max-w-4xl max-h-[80vh] overflow-hidden rounded-3xl shadow-2xl relative border border-white/10"
                        >
                          <img 
                            src={activePhoto} 
                            alt="Resolusi Tinggi" 
                            className="w-full h-auto max-h-[75vh] object-contain" 
                            referrerPolicy="no-referrer"
                          />
                        </motion.div>
                        <p className="text-xs font-mono text-amber-400 font-bold mt-4">SISTEM VALIDASI VISUAL KEMENPKP &bull; SECURE CDN</p>
                      </div>
                    )}
                  </AnimatePresence>

                </div>
              )}

              {/* TAB 8: DIRECTIVES ARAHAN (KORKAB INPUT TASK FORM & LIST) */}
              {currentTab === 'arahan' && (
                <div className="space-y-6">
                  
                  {/* Title and stats summary */}
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">Arahan, Tugas & Pengumuman KORKAB</h2>
                      <p className="text-xs text-slate-500 mt-1">Saluran instruksi langsung dari KORKAB ke Dashboard lapangan Tenaga Fasilitator (TFL).</p>
                    </div>
                    
                    <button
                      onClick={() => setShowCreateArahanModal(true)}
                      className="py-2.5 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs rounded-xl cursor-pointer active:scale-95 transition shadow-sm flex items-center gap-2"
                    >
                      <Plus size={14} />
                      <span>Buat Tugas / Arahan Baru</span>
                    </button>
                  </div>

                  {/* Interactive Status Widgets */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                      <span className="text-[9px] font-bold font-mono tracking-wider text-slate-400 block uppercase">TUGAS AKTIF TFL</span>
                      <h2 className="text-2xl font-black text-slate-900 mt-1">{stats.totalArahan}</h2>
                      <span className="text-[9px] text-slate-500 block">Total Instruksi</span>
                    </div>

                    <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                      <span className="text-[9px] font-bold font-mono tracking-wider text-amber-505 block uppercase text-amber-605 font-bold">MENUNGGU TINDAK LANJUT</span>
                      <h2 className="text-2xl font-black text-amber-655 text-amber-600 mt-1">{stats.pendingArahan}</h2>
                      <span className="text-[9px] text-amber-600 block">Belum Dituntaskan TFL</span>
                    </div>

                    <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                      <span className="text-[9px] font-bold font-mono tracking-wider text-emerald-510 block uppercase text-emerald-600 font-bold">TUNTAS VERIFIKASI</span>
                      <h2 className="text-2xl font-black text-emerald-600 mt-1">{stats.waitingVerification}</h2>
                      <span className="text-[9px] text-slate-500 block">Tugas Diselesaikan</span>
                    </div>

                    <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm font-bold bg-amber-50 border-amber-200">
                      <span className="text-[9px] font-black font-mono tracking-wider text-amber-800 block uppercase">DEADLINE MINGGU INI</span>
                      <h2 className="text-2xl font-black text-amber-900 mt-1">{stats.deadlineThisWeek}</h2>
                      <span className="text-[9px] text-amber-800 block">Urgensi Rentang Waktu</span>
                    </div>
                  </div>

                  {/* Create directive overlay modal */}
                  <AnimatePresence>
                    {showCreateArahanModal && (
                      <div className="fixed inset-0 z-50 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-4">
                        <motion.form 
                          onSubmit={handleCreateArahan}
                          initial={{ scale: 0.95, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.95, opacity: 0 }}
                          className="w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6 relative border border-slate-100"
                        >
                          <div className="flex justify-between items-center border-b border-gray-100 pb-3">
                            <h3 className="text-base font-black uppercase tracking-tight text-[#0B4F8C]">Buat Arahan / Tugas KORKAB</h3>
                            <button 
                              type="button" 
                              onClick={() => setShowCreateArahanModal(false)}
                              className="p-1 cursor-pointer hover:bg-slate-100 rounded-lg text-slate-400"
                            >
                              <X size={16} />
                            </button>
                          </div>

                          <div className="space-y-4">
                            
                            {/* Title */}
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold font-mono uppercase text-slate-500">JUDUL ARAHAN / TUGAS</label>
                              <input 
                                required
                                type="text"
                                placeholder="Contoh: Lengkapi Foto Progres Simbel"
                                value={newArahanTitle}
                                onChange={(e) => setNewArahanTitle(e.target.value)}
                                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C]"
                              />
                            </div>

                            {/* Category & Priority Row */}
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold font-mono uppercase text-slate-500">KATEGORI ARAHAN</label>
                                <select
                                  value={newArahanCategory}
                                  onChange={(e) => setNewArahanCategory(e.target.value as any)}
                                  className="w-full p-2.5 text-xs rounded-xl bg-white border border-slate-200 text-slate-805"
                                >
                                  <option value="tugas_lapangan">Tugas Lapangan</option>
                                  <option value="koreksi_data">Koreksi Data</option>
                                  <option value="monitoring_material">Monitoring Material</option>
                                  <option value="progress_fisik">Progress Fisik</option>
                                  <option value="dokumentasi">Dokumentasi</option>
                                  <option value="informasi_umum">Informasi Umum</option>
                                </select>
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-bold font-mono uppercase text-slate-500">PRIORITAS</label>
                                <select
                                  value={newArahanPriority}
                                  onChange={(e) => setNewArahanPriority(e.target.value as any)}
                                  className="w-full p-2.5 text-xs rounded-xl bg-white border border-slate-200 text-slate-805"
                                >
                                  <option value="tinggi">🔴 Tinggi (Urgensi)</option>
                                  <option value="sedang">🟡 Sedang</option>
                                  <option value="rendah">🟢 Rendah</option>
                                </select>
                              </div>
                            </div>

                            {/* Deadline Row */}
                            <div className="space-y-1 col-span-2">
                              <label className="text-[10px] font-bold font-mono uppercase text-slate-500">BATAS WAKTU (DEADLINE)</label>
                              <input 
                                required
                                type="date"
                                value={newArahanDeadline}
                                onChange={(e) => setNewArahanDeadline(e.target.value)}
                                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C]/40 font-mono"
                              />
                            </div>

                            {/* Description detail */}
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold font-mono uppercase text-slate-500">ISI DETAIL ARAHAN</label>
                              <textarea
                                required
                                rows={3}
                                placeholder="Tulis instruksi lengkap Anda di sini..."
                                value={newArahanDesc}
                                onChange={(e) => setNewArahanDesc(e.target.value)}
                                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 text-slate-850 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C]"
                              />
                            </div>

                            {/* Attachment (optional fake simulated text string/icon mapping or link) */}
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold font-mono uppercase text-slate-500">LAMPIRAN PENDUKUNG (OPSIONAL)</label>
                              <input 
                                type="text"
                                placeholder="Contoh link panduan atau PDF dokumen"
                                value={newArahanAttachment}
                                onChange={(e) => setNewArahanAttachment(e.target.value)}
                                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0B4F8C]"
                              />
                            </div>

                          </div>

                          <div className="pt-2 flex gap-4">
                            <button
                              type="button"
                              onClick={() => setShowCreateArahanModal(false)}
                              className="flex-1 py-3 border border-slate-200 text-slate-500 font-bold text-xs rounded-xl cursor-pointer active:scale-95 transition text-center"
                            >
                              Batal
                            </button>
                            <button
                              type="submit"
                              disabled={submittingArahan}
                              className="flex-1 py-3 bg-[#0B4F8C] hover:bg-[#0B4F8C]/90 text-white font-black text-xs rounded-xl cursor-pointer active:scale-95 transition disabled:opacity-50 text-center"
                            >
                              {submittingArahan ? 'Menyebarkan...' : 'Sebarkan Arahan'}
                            </button>
                          </div>

                        </motion.form>
                      </div>
                    )}
                  </AnimatePresence>

                  {/* Directives Lists */}
                  <div className="space-y-6">
                    {arahanList.length === 0 ? (
                      <div className="p-16 text-center text-slate-400 italic bg-white rounded-3xl border border-slate-100 shadow-sm">
                        Belum ada arahan yang ditugaskan kepada TFL saat ini. Klik "Buat Tugas / Arahan Baru" di sudut kanan atas untuk membuat prioritas pertama.
                      </div>
                    ) : (
                      arahanList.map((item) => {
                        let statusColor = 'bg-red-100 text-red-750 border-red-200 border';
                        if (item.status === 'dibaca') {
                          statusColor = 'bg-yellow-100 text-yellow-850 border-yellow-250 border';
                        } else if (item.status === 'selesai') {
                          statusColor = 'bg-green-150 text-green-900 border-green-300 border font-bold';
                        }

                        let priorityIcon = '🔴';
                        if (item.priority === 'sedang') priorityIcon = '🟡';
                        else if (item.priority === 'rendah') priorityIcon = '🟢';

                        return (
                          <div key={item.id} className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-6">
                            
                            {/* Row 1 Header */}
                            <div className="flex flex-col md:flex-row justify-between gap-4 border-b border-slate-50 pb-4">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[9px] font-black uppercase font-mono px-2 py-0.5 rounded-full bg-indigo-50 border border-indigo-150 text-[#0B4F8C]">
                                    {item.category.replace('_', ' ').toUpperCase()}
                                  </span>
                                  <span className="text-[9px] font-bold font-mono px-2 py-0.5 rounded-full bg-slate-50 border border-slate-200">
                                    {priorityIcon} PRIORITAS {item.priority.toUpperCase()}
                                  </span>
                                  <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded-md ${statusColor}`}>
                                    {item.status.replace('_', ' ').toUpperCase()}
                                  </span>
                                </div>
                                <h3 className="text-base font-extrabold text-slate-900 select-text uppercase mt-2">{item.title}</h3>
                              </div>

                              <div className="md:text-right font-mono text-[10px] text-zinc-500 shrink-0">
                                <p>SINKRONISASI: REALTIME</p>
                                <p className="text-red-650 font-bold text-red-600 mt-1">BATAS: {new Date(item.deadline).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                              </div>
                            </div>

                            {/* Row 2: Desc & Comments thread */}
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                              
                              {/* Left detail info column */}
                              <div className="md:col-span-7 space-y-4 text-xs leading-relaxed border-b md:border-b-0 md:border-r border-slate-50 pb-4 md:pb-0 md:pr-6">
                                <div className="space-y-1">
                                  <p className="font-bold text-slate-450 uppercase text-[9px] tracking-wider font-mono">Detail Arahan Instruksi</p>
                                  <p className="text-slate-700 font-medium whitespace-pre-wrap select-text">{item.description}</p>
                                </div>

                                {item.attachment && (
                                  <div className="p-3 bg-slate-50 rounded-xl flex items-center justify-between text-[11px] font-medium border border-slate-100">
                                    <div className="flex items-center gap-2">
                                      <span>🔗</span>
                                      <span className="font-bold text-slate-705">Lampiran Dokumen Tambahan</span>
                                    </div>
                                    <a href={item.attachment} target="_blank" rel="noreferrer" className="text-amber-600 hover:underline">Buka Link</a>
                                  </div>
                                )}

                                {/* Proof block from TFL if task is selesai */}
                                {item.proof ? (
                                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 space-y-3">
                                    <div className="flex justify-between items-center bg-white/50 backdrop-blur px-2.5 py-1.5 rounded-lg border border-emerald-110">
                                      <span className="text-[10px] font-black text-emerald-800 font-mono tracking-wider">BUKTI PENYELESAIAN TFL</span>
                                      <span className="text-[9px] text-emerald-700 font-mono">{new Date(item.proof.submitted_at || '').toLocaleString('id-ID')}</span>
                                    </div>
                                    
                                    {item.proof.photo && (
                                      <div className="h-32 rounded-xl overflow-hidden border border-emerald-150 bg-white">
                                        <img 
                                          src={item.proof.photo} 
                                          alt="Bukti Kirim" 
                                          className="w-full h-full object-cover cursor-pointer hover:scale-105 transition duration-300" 
                                          onClick={() => setActivePhoto(item.proof?.photo || '')}
                                          referrerPolicy="no-referrer"
                                        />
                                      </div>
                                    )}

                                    {item.proof.description && (
                                      <p className="text-[11px] text-slate-700 whitespace-pre-wrap leading-normal bg-white p-2.5 rounded-xl border border-emerald-100">
                                        <strong>Keterangan TFL:</strong> {item.proof.description}
                                      </p>
                                    )}

                                    {item.status !== 'selesai' ? (
                                      <button
                                        onClick={() => handleVerifyArahanComplete(item.id)}
                                        className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-extrabold rounded-xl width-full text-center cursor-pointer active:scale-95 transition"
                                      >
                                        Verifikasi & Tandai Selesai Tuntas
                                      </button>
                                    ) : (
                                      <div className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                                        <CheckCircle2 size={13} className="text-emerald-500" />
                                        <span>Tugas Diverifikasi Tepat Aturan & Selesai!</span>
                                      </div>
                                    )}
                                  </div>
                                ) : (
                                  <div className="p-3 bg-amber-50/50 rounded-xl border border-dashed border-amber-200 text-[10px] text-slate-500 font-mono flex items-center gap-2">
                                    <span>⏳</span>
                                    <span>Menunggu pengiriman dokumen/foto bukti penyelesaian dari TFL lapangan...</span>
                                  </div>
                                )}

                              </div>

                              {/* Right comments column */}
                              <div className="md:col-span-5 space-y-4 flex flex-col justify-between">
                                <div className="space-y-3">
                                  <span className="font-bold text-slate-450 uppercase text-[9px] tracking-wider font-mono">Forum Respon Realtime</span>
                                  
                                  {/* Thread list scroll */}
                                  <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                                    {!item.comments || item.comments.length === 0 ? (
                                      <p className="text-[11px] text-slate-400 italic py-2 pr-1 text-center">Belum ada obrolan/pesan balasan.</p>
                                    ) : (
                                      item.comments.map(c => {
                                        const isKorkab = c.sender_role === 'korkab';
                                        return (
                                          <div key={c.id} className={`p-2.5 rounded-xl flex flex-col gap-1 text-[11px] leading-normal ${isKorkab ? 'bg-indigo-50 border border-indigo-100 pl-3 border-l-4 border-l-indigo-600' : 'bg-slate-50 border border-slate-150'}`}>
                                            <div className="flex justify-between font-bold text-slate-800">
                                              <span>{c.sender_name.toUpperCase()}</span>
                                              <span className="text-[8px] opacity-60 font-mono">{new Date(c.created_at).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit' })}</span>
                                            </div>
                                            <p className="text-slate-700">{c.message}</p>
                                          </div>
                                        );
                                      })
                                    )}
                                  </div>
                                </div>

                                {/* Write message box */}
                                <div className="flex gap-2">
                                  <input 
                                    type="text" 
                                    placeholder="Ketik balasan Anda..."
                                    value={commentInputs[item.id] || ''}
                                    onChange={(e) => setCommentInputs(prev => ({ ...prev, [item.id]: e.target.value }))}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') handlePostComment(item.id);
                                    }}
                                    className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none"
                                  />
                                  <button
                                    onClick={() => handlePostComment(item.id)}
                                    className="p-2 bg-[#0B4F8C] text-white hover:bg-[#0B4F8C]/90 rounded-xl cursor-pointer active:scale-95 transition"
                                  >
                                    <Send size={14} />
                                  </button>
                                </div>

                              </div>

                            </div>

                          </div>
                        );
                      })
                    )}
                  </div>

                </div>
              )}

              {/* TAB 9: GENERAL REPORT STATS SUMMARY */}
              {currentTab === 'reports' && (
                <div className="space-y-6">
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
                    <h2 className="text-lg font-bold text-slate-900">Mandat Pelaporan Kemajuan Kabupaten Minahasa</h2>
                    <p className="text-xs text-slate-500 mt-1">Mengonversi data dropping logistik dan progress pembangunan real-time ke dalam metrik pelaporan resmi.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* General performance scorecard */}
                    <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4">
                      <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase">Perkembangan Pembangunan Daerah</h4>
                      <div className="space-y-3 font-mono text-xs text-slate-600">
                        <div className="flex justify-between items-center py-2 border-b border-slate-50">
                          <span>Total Unit Penerima (PB)</span>
                          <span className="font-bold text-slate-800">{stats.pbCount} Unit</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-slate-50">
                          <span>Progress Rata-Rata Kabupaten</span>
                          <span className="font-bold text-slate-800">{stats.averageProgress}%</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-slate-50">
                          <span>Dropping Semen/Besik Selesai</span>
                          <span className="font-bold text-green-600">{stats.completedCount} Unit ({(stats.pbCount > 0 ? Math.round((stats.completedCount / stats.pbCount)*100) : 0)}%)</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-slate-50">
                          <span>Rumah Perlu Perhatian Alasan Khusus</span>
                          <span className="font-bold text-red-500">{stats.needsAttentionCount} Unit</span>
                        </div>
                      </div>
                    </div>

                    {/* Quick Audit Trailing listing visual */}
                    <div className="p-6 bg-white rounded-3xl border border-grey-100 shadow-sm space-y-4">
                      <h4 className="text-xs font-bold font-mono tracking-wider text-slate-400 uppercase font-bold">Rekomendasi Rilis KORKAB</h4>
                      <p className="text-xs text-slate-600 leading-relaxed text-slate-700">
                        Dinas Perumahan Rakyat Kawasan Permukiman dan Pertanahan Kabupaten Minahasa menyatakan bahwa pengiriman material stimulan BSPS Digital 2026 berjalan transparan dan berlandaskan akurasi koordinat dropping GPS yang terkunci rapat pada titik realisasi.
                      </p>
                      <div className="p-3 rounded-2xl bg-[#041E42] text-white text-[11px] font-mono leading-relaxed space-y-1">
                        <p className="font-bold text-amber-400 uppercase text-[9px] tracking-wider">REKAP PERINGATAN SISTEM</p>
                        <p>Total Laporan Temuan Lapangan: {findings.length} Kasus</p>
                        <p>Temuan Belum Terselesaikan: {findings.filter(f => !f.resolved).length} Kasus</p>
                      </div>
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 10: EXPORTS EXCEL/CSV SHEET */}
              {currentTab === 'exports' && (
                <div className="space-y-6">
                  
                  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
                    <h2 className="text-lg font-bold text-slate-900">Rekapitulasi Ekspor & Cetak Berkas Excel/CSV</h2>
                    <p className="text-xs text-slate-500 mt-1">Unduh rekapitulasi data material, status PB, dan progres desa langsung ke dalam spreadsheet komputer Anda.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      { title: 'Ekspor Data PB Resmi', desc: 'Rekap seluruh data penerima bantuan, NIK, alamat, kelompok, dan status.', id: 'recipients' },
                      { title: 'Ekspor Rekap Toko', desc: 'Berisi rekap toko rekanan, penanggung jawab, total drops, dan sengketa.', id: 'stores' },
                      { title: 'Ekspor Rekap Desa', desc: 'Detail persentase progress rata-rata per desa untuk laporan bulanan.', id: 'villages' },
                    ].map((btn, idx) => (
                      <div key={idx} className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm space-y-4 flex flex-col justify-between">
                        <div className="space-y-1">
                          <h4 className="font-extrabold text-[#0B4F8C] uppercase text-xs tracking-tight">{btn.title}</h4>
                          <p className="text-slate-500 text-[11px] leading-relaxed">{btn.desc}</p>
                        </div>
                        <button
                          onClick={() => handleExport(btn.id as any)}
                          className="w-full py-3 rounded-xl bg-[#041E42] hover:bg-slate-900 text-amber-400 font-extrabold text-[10px] uppercase tracking-wider cursor-pointer active:scale-95 transition flex items-center justify-center gap-2 border border-[#F4A300]/20"
                        >
                          <Download size={13} />
                          <span>Mulai Unduh Excel</span>
                        </button>
                      </div>
                    ))}
                  </div>

                </div>
              )}

            </motion.div>
          </AnimatePresence>

        </main>

      </div>

      {/* Global Image Zoom Modal */}
      <AnimatePresence>
        {activePhoto && (
          <div className="fixed inset-0 z-[10000] bg-slate-950/90 flex flex-col justify-center items-center p-6">
            <button 
              onClick={() => setActivePhoto(null)}
              className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full cursor-pointer z-20 font-bold transition transform duration-200 active:scale-95"
            >
              <X size={20} />
            </button>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="max-w-4xl max-h-[80vh] overflow-hidden rounded-3xl shadow-2xl relative border border-white/10"
            >
              <img 
                src={activePhoto} 
                alt="Resolusi Tinggi" 
                className="w-full h-auto max-h-[75vh] object-contain" 
                referrerPolicy="no-referrer"
              />
            </motion.div>
            <p className="text-xs font-mono text-amber-400 font-bold mt-4">SISTEM VALIDASI VISUAL KEMENPKP &bull; SECURE CDN</p>
          </div>
        )}
      </AnimatePresence>

      {/* Footer information bar */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-[10px] text-slate-450 font-mono shrink-0 select-none">
        Monitoring digital Kabupaten Minahasa &bull; Dinas Perumahan dan Kawasan Permukiman &bull; Kementerian PUPR-RI 2026. All Rights Reserved.
      </footer>

    </div>
  );
}
