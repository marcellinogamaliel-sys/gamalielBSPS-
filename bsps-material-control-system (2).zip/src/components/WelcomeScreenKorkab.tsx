import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Sparkles, Navigation, Users, MapPin, Clock, Calendar, ArrowRight } from 'lucide-react';
import { Village } from '../types';

interface WelcomeScreenProps {
  villages: Village[];
  onComplete: () => void;
}

export default function WelcomeScreenKorkab({ villages, onComplete }: WelcomeScreenProps) {
  const [elapsed, setElapsed] = useState<number>(0);
  const [time, setTime] = useState<Date>(new Date());

  // Particles background array
  const [particles] = useState(() => 
    Array.from({ length: 30 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 2,
      duration: Math.random() * 15 + 10,
      delay: Math.random() * -20,
    }))
  );

  // Incrementor for animation stages (0s to 12s)
  useEffect(() => {
    const timer = setInterval(() => {
      setElapsed((prev) => {
        if (prev >= 10) {
          clearInterval(timer);
          // Auto redirect after 10 seconds
          setTimeout(() => {
            onComplete();
          }, 400);
          return 10;
        }
        return prev + 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onComplete]);

  // Realtime clock
  useEffect(() => {
    const clock = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(clock);
  }, []);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }) + ' WITA';
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-[#041E42] via-[#0B4F8C] to-[#1A365D] overflow-hidden flex flex-col justify-between p-6 md:p-12 text-white font-sans select-none">
      
      {/* Animated Glowing Ambient Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-[#0B4F8C]/20 rounded-full blur-[120px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-[#F4A300]/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Particle Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {particles.map((p) => (
          <motion.div
            key={p.id}
            className="absolute bg-amber-400 rounded-full opacity-[0.25]"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: p.size,
              height: p.size,
            }}
            animate={{
              y: ['0vh', '-100vh'],
              opacity: [0, 0.4, 0.4, 0],
            }}
            transition={{
              duration: p.duration,
              repeat: Infinity,
              delay: p.delay,
              ease: 'linear',
            }}
          />
        ))}
      </div>

      {/* Header with Skip Button */}
      <div className="w-full flex justify-between items-center z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/10 rounded-xl backdrop-blur-md border border-white/10">
            <Shield className="text-amber-400 w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-amber-500 font-mono">Executive Portal</span>
            <span className="block text-xs font-bold text-slate-300">KemenPKP Minahasa</span>
          </div>
        </div>

        <button
          onClick={onComplete}
          className="px-5 py-2 rounded-xl bg-white/10 hover:bg-amber-500 hover:text-slate-950 backdrop-blur-md border border-white/10 text-xs font-bold leading-none cursor-pointer flex items-center gap-1.5 transition-all duration-300 active:scale-95 text-amber-400 hover:border-amber-400"
        >
          <span>Skip Animasi</span>
          <ArrowRight size={13} />
        </button>
      </div>

      {/* MAIN CONTAINER FOR CORE STAGED ANIMATIONS */}
      <div className="flex-1 w-full flex flex-col justify-center items-center py-8 z-10 max-w-4xl mx-auto">
        
        {/* ANIMASI PERTAMA: 0 - 2 DETIK (Big PKP Logo + Title) */}
        {elapsed >= 0 && elapsed < 2 && (
          <motion.div
            key="stage1"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-6"
          >
            <div className="relative inline-block">
              {/* Soft Golden Glow Behind Logo */}
              <div className="absolute inset-x-0 inset-y-0 bg-amber-400/20 rounded-full blur-2xl animate-pulse" />
              <img 
                src="/logo.png" 
                alt="Logo PKP" 
                className="relative mx-auto h-28 sm:h-36 w-auto drop-shadow-[0_10px_15px_rgba(244,163,0,0.3)]" 
              />
            </div>
            
            <div className="space-y-2">
              <motion.h2 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
                className="text-2xl sm:text-3xl font-black tracking-widest bg-clip-text text-transparent bg-gradient-to-r from-white via-amber-200 to-amber-400 uppercase font-sans"
              >
                SISTEM MONITORING BSPS DIGITAL
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="text-sm font-bold tracking-widest text-[#C5B374] font-mono uppercase"
              >
                TIM 22 MINAHASA
              </motion.p>
            </div>
          </motion.div>
        )}

        {/* ANIMASI KEDUA: 2 - 5 DETIK (Welcome Executive Card) */}
        {elapsed >= 2 && elapsed < 5 && (
          <motion.div
            key="stage2"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ duration: 0.6, type: 'spring', stiffness: 100 }}
            className="w-full max-w-lg"
          >
            <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-amber-500/30 shadow-[0_25px_50px_rgba(0,0,0,0.3)] relative overflow-hidden text-center space-y-6">
              {/* Gold border glow elements */}
              <div className="absolute top-0 right-0 w-24 h-24 bg-amber-400/10 rounded-full blur-2xl" />
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-[#0B4F8C]/20 rounded-full blur-2xl" />
              
              <div className="space-y-1">
                <Sparkles className="text-amber-400 w-8 h-8 mx-auto mb-2 animate-bounce" />
                <span className="text-xs font-bold tracking-[0.25em] text-amber-500 font-mono uppercase">
                  SELAMAT DATANG
                </span>
                <h3 className="text-sm font-black tracking-widest text-slate-300 uppercase font-mono mt-1">
                  KORKAB MINAHASA
                </h3>
              </div>

              <div className="border-t border-b border-white/5 py-6">
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-white via-amber-200 to-amber-400 bg-clip-text text-transparent uppercase">
                  ADRI MENGKO, ST
                </h1>
              </div>

              <p className="text-xs text-slate-400 italic">
                "Mengemban amanat pemantauan prima program stimulant bantuan stimulan perumahan swadaya kabupaten Minahasa."
              </p>
            </div>
          </motion.div>
        )}

        {/* ANIMASI KETIGA: 5 - 7 DETIK (Team Structure Side-by-Side Cards) */}
        {elapsed >= 5 && elapsed < 7 && (
          <motion.div
            key="stage3"
            className="w-full space-y-6"
          >
            <div className="text-center space-y-1">
              <span className="text-[10px] font-black tracking-[0.25em] text-amber-500 font-mono uppercase">Struktur Komando</span>
              <h2 className="text-xl font-bold tracking-tight text-white uppercase">TIM PELAKSANA LAPANGAN</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full px-4">
              {/* CARD TEKNIS */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, type: 'spring', stiffness: 120 }}
                className="group relative p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-amber-500/50 transition-all duration-300 shadow-lg cursor-pointer"
              >
                <div className="absolute top-3 right-3 opacity-20 group-hover:opacity-100 transition-opacity">
                  <Sparkles size={14} className="text-amber-400" />
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center font-bold text-blue-400 font-mono">
                    TKS
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold tracking-widest text-[#0B4F8C] bg-blue-400/10 px-2 py-0.5 rounded-full font-mono uppercase">
                      TEKNIS
                    </span>
                    <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                      Ir. HARKE IVAN PONTOH, S.Ars
                    </h3>
                  </div>
                </div>
              </motion.div>

              {/* CARD PEMBERDAYAAN */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, type: 'spring', stiffness: 120 }}
                className="group relative p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-amber-500/50 transition-all duration-300 shadow-lg cursor-pointer"
              >
                <div className="absolute top-3 right-3 opacity-20 group-hover:opacity-100 transition-opacity">
                  <Users size={14} className="text-amber-400" />
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#F4A300]/20 border border-[#F4A300]/35 flex items-center justify-center font-bold text-amber-400 font-mono">
                    PMD
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold tracking-widest text-amber-500 bg-amber-400/10 px-2 py-0.5 rounded-full font-mono uppercase font-black">
                      PEMBERDAYAAN
                    </span>
                    <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                      MARCELLINO U.G. TUMIWANG, SAB
                    </h3>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* ANIMASI KEEMPAT: 7 - 10 DETIK (Active Villages Dynamic Drift Chips) */}
        {elapsed >= 7 && elapsed <= 10 && (
          <motion.div
            key="stage4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full space-y-8 px-4 text-center"
          >
            <div className="space-y-1">
              <span className="text-[10px] font-black tracking-[0.25em] text-amber-500 font-mono uppercase">Active Jurisdiction</span>
              <h2 className="text-xl sm:text-2xl font-bold uppercase tracking-tight">DESA BINAAN TIM 22</h2>
            </div>

            {/* Drift Chips Box */}
            <div className="relative h-44 overflow-hidden w-full flex items-center justify-center bg-white/2 rounded-2xl border border-white/5">
              
              {villages.length === 0 ? (
                <div className="flex flex-wrap gap-4 px-6 justify-center">
                  {['SIMBEL', 'TOTOLAN', 'TOLOK', 'TOLOK SATU'].map((vName, idx) => (
                    <motion.div
                      key={vName}
                      className="px-5 py-3 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-xs font-bold leading-none flex items-center gap-2"
                      animate={{
                        y: [0, idx % 2 === 0 ? -12 : 12, 0],
                        x: [0, idx % 2 === 0 ? 8 : -8, 0],
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        delay: idx * 0.5,
                        ease: "easeInOut"
                      }}
                    >
                      <span className={idx % 2 === 0 ? "text-blue-400" : "text-amber-400"}>
                        {idx % 2 === 0 ? '🟦' : '🟨'}
                      </span>
                      <span>{vName}</span>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-wrap gap-4 px-6 justify-center">
                  {villages.map((v, idx) => (
                    <motion.div
                      key={v.id}
                      className="px-5 py-3 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-xs font-bold leading-none flex items-center gap-2 shadow-md hover:border-amber-400/40 transition-colors cursor-default"
                      animate={{
                        y: [0, idx % 2 === 0 ? -10 : 10, 0],
                        x: [0, idx % 3 === 0 ? 6 : -6, 0],
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        delay: idx * 0.4,
                        ease: "easeInOut"
                      }}
                    >
                      <span className={idx % 2 === 0 ? "text-blue-400" : "text-amber-400"}>
                        {idx % 2 === 0 ? '🟦' : '🟨'}
                      </span>
                      <span className="font-semibold tracking-wider">{v.name.toUpperCase()}</span>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}

      </div>

      {/* Footer Content */}
      <div className="w-full border-t border-white/10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left z-10">
        
        {/* Realtime Date and Clock */}
        <div className="flex flex-col md:flex-row items-center gap-4 font-mono">
          <div className="flex items-center gap-1.5 text-xs text-slate-300">
            <Calendar size={13} className="text-amber-400" />
            <span>{formatDate(time)}</span>
          </div>
          <div className="hidden md:block w-1.5 h-1.5 bg-white/20 rounded-full" />
          <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold">
            <Clock size={13} />
            <span>{formatTime(time)}</span>
          </div>
        </div>

        {/* Central Govt Credits */}
        <div className="text-[10px] text-slate-400 leading-normal max-w-sm md:text-right font-medium">
          <p className="font-bold text-slate-200">Monitoring Digital BSPS 2026 &bull; Kabupaten Minahasa</p>
          <p>Kementerian Perumahan dan Kawasan Permukiman Republik Indonesia</p>
        </div>
      </div>

    </div>
  );
}
