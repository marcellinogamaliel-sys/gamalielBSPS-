/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building, Phone, User, MapPin, MessageCircle, 
  Copy, CheckSquare, ChevronRight, FileText, Printer, 
  AlertTriangle, CheckCircle2, Sparkles 
} from 'lucide-react';
import { Store, Recipient, DRPBItem, Distribution, DistributionMedia } from '../types';

interface StoreWatcherProps {
  stores: Store[];
  recipients: Recipient[];
  drpbItems: DRPBItem[];
  distributions: Distribution[];
  media: DistributionMedia[];
  showToast: (message: string, type: 'success' | 'error') => void;
}

export default function StoreWatcher({
  stores,
  recipients,
  drpbItems,
  distributions,
  media,
  showToast
}: StoreWatcherProps) {
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [waDraft, setWaDraft] = useState<string>('');
  const [waUrl, setWaUrl] = useState<string>('');
  const [isCopied, setIsCopied] = useState(false);
  const [generating, setGenerating] = useState(false);

  // Stats calculation per store
  const getStoreOverview = (sId: string) => {
    const storePB = recipients.filter(r => r.store_id === sId);
    const complete = storePB.filter(r => r.status === 'complete').length;
    const inProgress = storePB.filter(r => r.status === 'in_progress').length;
    const notStarted = storePB.filter(r => r.status === 'not_started').length;
    const hasFinding = storePB.filter(r => r.status === 'has_finding').length;

    return {
      total: storePB.length,
      complete,
      inProgress,
      notStarted,
      hasFinding
    };
  };

  // Generate WhatsApp notifications from server endpoint
  const requestStoreWADraft = async (storeId: string) => {
    setGenerating(true);
    setIsCopied(false);
    try {
      const res = await fetch(`/api/stores/${storeId}/whatsapp`);
      if (!res.ok) throw new Error("Gagal mengambil template notifikasi.");
      const data = await res.json();
      setWaDraft(data.text);
      setWaUrl(data.url);
    } catch (e: any) {
      showToast("gagal mengambil data", "error");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Store Lists Cards */}
        <div className="col-span-1 lg:col-span-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-805 font-mono uppercase tracking-wider">Registrasi Toko Rekanan</h3>
          
          <div className="grid grid-cols-1 gap-3">
            {stores.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-6 text-center text-slate-400 text-xs">
                Belum ada toko yang terdaftar di master data.
              </div>
            ) : (
              stores.map(s => {
                const ov = getStoreOverview(s.id);
                const isSelected = selectedStore?.id === s.id;

                return (
                  <div 
                    key={s.id}
                    onClick={() => {
                      setSelectedStore(s);
                      requestStoreWADraft(s.id);
                    }}
                    className={`border rounded-2xl p-5 bg-white hover:shadow-xs transition cursor-pointer select-none space-y-3.5 relative overflow-hidden ${isSelected ? 'border-slate-900 ring-2 ring-slate-100 bg-slate-50/20' : 'border-slate-200'}`}
                  >
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <h4 className="font-extrabold text-[#0f172a] text-sm flex items-center gap-1">
                          <Building className="shrink-0 w-4.5 h-4.5 text-slate-500" />
                          {s.name}
                        </h4>
                        <p className="text-xs text-slate-550 mt-0.5">Pemilik: <span className="font-semibold text-slate-700">{s.owner_name}</span> &bull; +{s.phone_number}</p>
                      </div>
                      <ChevronRight size={16} className={`text-slate-400 mt-1 transition ${isSelected ? 'translate-x-1 text-slate-900' : ''}`} />
                    </div>

                    {/* Deficiencies state bar indicators */}
                    <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-100 text-center text-[10px] font-mono">
                      <div className="p-1 px-1.5 rounded bg-emerald-50 border border-emerald-150">
                        <span className="text-emerald-700 block font-bold">{ov.complete}</span>
                        <span className="text-slate-500 text-[8px] uppercase">Lengkap</span>
                      </div>
                      <div className="p-1 px-1.5 rounded bg-amber-50 border border-amber-150">
                        <span className="text-amber-700 block font-bold">{ov.inProgress}</span>
                        <span className="text-slate-500 text-[8px] uppercase">Proses</span>
                      </div>
                      <div className="p-1 px-1.5 rounded bg-rose-50 border border-rose-150">
                        <span className="text-rose-700 block font-bold">{ov.notStarted}</span>
                        <span className="text-slate-500 text-[8px] uppercase">Belum Kirim</span>
                      </div>
                      <div className="p-1 px-1.5 rounded bg-slate-900 border border-slate-800">
                        <span className="text-white block font-bold">{ov.hasFinding}</span>
                        <span className="text-slate-300 text-[8px] uppercase">Temuan</span>
                      </div>
                    </div>

                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Deficiencies Watcher and WHATSAPP generator */}
        <div className="col-span-1 lg:col-span-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-805 font-mono uppercase tracking-wider">Pemberitahuan Dan Rekapitulasi</h3>

          {!selectedStore ? (
            <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-8 text-center text-slate-400 flex flex-col justify-center items-center h-[350px]">
              <MessageCircle className="w-12 h-12 text-slate-300 mb-3 animate-pulse" />
              <p className="text-xs font-semibold text-slate-500">Belum Ada Toko Terpilih</p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-xs">Pilih salah satu toko di sebelah kiri untuk melihat rekapitulasi kekurangan kirim dan membuat draf pengingat WhatsApp.</p>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 animate-fadeIn">
              
              <div className="border-b border-slate-100 pb-3 flex justify-between items-center bg-sky-50/20 p-2 rounded-xl">
                <div>
                  <span className="text-[9px] font-bold font-mono text-sky-700 uppercase block tracking-wider">Drafting Pengingat Toko</span>
                  <h4 className="font-extrabold text-slate-900 text-sm truncate">{selectedStore.name}</h4>
                </div>
                <span className="text-[10px] font-mono font-bold text-sky-800 bg-sky-100 px-2 py-0.5 rounded">+{selectedStore.phone_number}</span>
              </div>

              {generating ? (
                <div className="py-12 text-center text-xs text-slate-450 space-y-2 font-mono">
                  <div className="w-6 h-6 rounded-full border-t-2 border-slate-900 animate-spin mx-auto" />
                  <p>Menganalisis kekurangan logistik toko...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Draft SMS display box */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1">
                      <Sparkles size={12} className="text-indigo-500" />
                      Auto-Generated WA Draft
                    </span>

                    <textarea
                      readOnly
                      rows={14}
                      value={waDraft}
                      className="w-full text-xs font-mono p-3 border border-slate-200 bg-slate-50 rounded-xl leading-relaxed resize-none cursor-text focus:outline-none focus:ring-1 focus:ring-indigo-300"
                    />
                  </div>

                  {/* Actions buttons */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    
                    {/* Copy to clipboard */}
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(waDraft);
                        setIsCopied(true);
                        setTimeout(() => setIsCopied(false), 2000);
                      }}
                      className="flex-1 py-2.5 px-3 border border-slate-200 bg-slate-50 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition"
                    >
                      {isCopied ? <CheckSquare size={14} className="text-emerald-600" /> : <Copy size={14} />}
                      {isCopied ? 'Salin Berhasil!' : 'Salin Draf Pesan'}
                    </button>

                    {/* Trigger wa.me link */}
                    <a
                      href={waUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition text-center"
                    >
                      <MessageCircle size={14} className="text-emerald-400" />
                      Kirim ke WhatsApp
                    </a>

                    {/* Print option */}
                    <button
                      onClick={() => {
                        const printWindow = window.open('', '_blank');
                        if (printWindow) {
                          printWindow.document.write(`
                            <html>
                              <head>
                                <title>Surat Pengingat BSPS 2026</title>
                                <style>
                                  body { font-family: sans-serif; padding: 40px; line-height: 1.6; }
                                  pre { font-family: sans-serif; white-space: pre-wrap; margin-top: 20px; font-size:14px; background:#f5f5f5; padding:20px; border-radius:8px;}
                                  h2 { border-bottom: 2px solid #334155; padding-bottom: 10px; color:#1e293b; }
                                </style>
                              </head>
                              <body>
                                <h2>SURAT PENGINGAT PENYALURAN MATERIAL BSPS 2026</h2>
                                <pre>${waDraft}</pre>
                                <script>window.print();</script>
                              </body>
                            </html>
                          `);
                          printWindow.document.close();
                        }
                      }}
                      className="py-2.5 px-3 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs text-slate-705 flex justify-center items-center cursor-pointer transition active:scale-90"
                      title="Cetak Surat Fisik"
                    >
                      <Printer size={15} />
                    </button>

                  </div>
                </div>
              )}

              {/* Note helper block */}
              <div className="p-3 bg-amber-50 border border-amber-150 rounded-xl text-[10px] text-amber-900 flex items-start gap-1.5">
                <AlertTriangle size={12} className="shrink-0 mt-0.5" />
                <span>
                  <strong>INFORMASI:</strong> Toko penyedia material tidak perlu memiliki akun login sistem. TFL bertugas mengirimkan teks rekap di atas via WA agar toko segera memobilisasi sisa logistik bangunan.
                </span>
              </div>

            </div>
          )}
        </div>

      </div>

    </div>
  );
}
