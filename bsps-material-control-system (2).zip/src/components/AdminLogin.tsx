import React, { useState } from 'react';

export const AdminLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });

    if (res.ok) {
      const data = await res.json();
      localStorage.setItem('adminToken', data.token);
      window.location.href = '/admin/dashboard';
    } else {
      alert('Login Gagal');
    }
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <form onSubmit={handleLogin} className="p-8 border rounded shadow-md w-96">
        <h2 className="text-xl mb-4 font-bold">Admin Login</h2>
        <input type="text" placeholder="Username" className="w-full p-2 mb-2 border rounded" onChange={e => setUsername(e.target.value)} />
        <input type="password" placeholder="Password" className="w-full p-2 mb-2 border rounded" onChange={e => setPassword(e.target.value)} />
        <button className="w-full p-2 bg-blue-600 text-white rounded">Login</button>
      </form>
    </div>
  );
};
