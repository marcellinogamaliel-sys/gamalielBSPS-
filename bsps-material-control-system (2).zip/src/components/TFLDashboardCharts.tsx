import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { TrendingUp, BarChart3, PieChartIcon } from 'lucide-react';

interface TFLDashboardChartsProps {
  summary: {
    total_pb?: number;
    priority_visits_count?: number;
    unresolved_findings_count?: number;
    pending_confirmations_count?: number;
    disputed_distributions_count?: number;
    material_progress?: Array<{
      material: string;
      unit: string;
      target: number;
      actual: number;
    }>;
  };
}

export default function TFLDashboardCharts({ summary }: TFLDashboardChartsProps) {
  // Chart 1 data: Material progress vs DRPB Target
  const materialChartData = useMemo(() => {
    if (!summary?.material_progress || summary.material_progress.length === 0) {
      return [];
    }
    return summary.material_progress.map(item => ({
      name: `${item.material} (${item.unit})`,
      "Target DRPB": Number(item.target || 0),
      "Delivered (Realisasi)": Number(item.actual || 0)
    }));
  }, [summary?.material_progress]);

  // Chart 2 data: TFL compliance and action tasks
  const taskBreakdownData = useMemo(() => {
    const total = summary?.total_pb ?? 0;
    const visitsLeft = summary?.priority_visits_count ?? 0;
    const completedVisits = Math.max(0, total - visitsLeft);
    
    return [
      { name: 'Kunjungan Selesai', value: completedVisits, color: '#10b981' }, // emerald-500
      { name: 'Perlu Kunjungan', value: visitsLeft, color: '#f59e0b' }, // amber-500
      { name: 'Temuan Masalah', value: summary?.unresolved_findings_count ?? 0, color: '#ef4444' }, // red-500
      { name: 'Pending Penerima', value: summary?.pending_confirmations_count ?? 0, color: '#6366f1' }, // indigo-500
      { name: 'Sengketa Dropping', value: summary?.disputed_distributions_count ?? 0, color: '#ec4899' } // pink-500
    ].filter(item => item.value > 0 || item.name === 'Perlu Kunjungan' || item.name === 'Kunjungan Selesai');
  }, [summary]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Chart 1: Bar chart comparing target vs delivered */}
      <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-3xs flex flex-col justify-between">
        <div className="space-y-1 pb-3 border-b border-slate-100 flex items-center gap-2">
          <TrendingUp className="text-amber-600 w-4 h-4 shrink-0" />
          <div>
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-tight">Kesiapan Material Lapangan vs Target DRPB</h3>
            <p className="text-[10px] text-slate-500 font-semibold">Timbangan volume dropping tersalur vs kuantum rencana stimulan</p>
          </div>
        </div>

        <div className="pt-4">
          {materialChartData.length > 0 ? (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={materialChartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" fontSize={9} tick={{ fill: '#475569', fontWeight: 600 }} />
                  <YAxis fontSize={9} tick={{ fill: '#475569' }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', fontSize: '11px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
                  />
                  <Legend 
                    wrapperStyle={{ fontSize: '10px', pt: 10 }}
                    verticalAlign="bottom"
                    iconSize={10}
                  />
                  <Bar dataKey="Target DRPB" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Delivered (Realisasi)" fill="#d97706" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400 text-xs">
              <BarChart3 className="w-8 h-8 text-slate-300 mb-2" />
              Tidak ada data progres material untuk tim lapangan Anda.
            </div>
          )}
        </div>
      </div>

      {/* Chart 2: Task breakdown donut / status balance */}
      <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-3xs flex flex-col justify-between">
        <div className="space-y-1 pb-3 border-b border-slate-100 flex items-center gap-2">
          <PieChartIcon className="text-indigo-650 w-4 h-4 shrink-0" />
          <div>
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-tight">Status &amp; Keseimbangan Beban Tugas TFL</h3>
            <p className="text-[10px] text-slate-500 font-semibold">Distribusi komparatif problem vs kelancaran lapangan</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center pt-4">
          <div className="sm:col-span-6 h-48 w-full flex justify-center items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={taskBreakdownData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {taskBreakdownData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', fontSize: '10px', border: '1px solid #e2e8f0' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="sm:col-span-6 space-y-2">
            <span className="text-[9px] font-black tracking-wider uppercase text-slate-400 block font-mono">Indikator Lapangan</span>
            <div className="space-y-1.5 text-[10.5px]">
              {taskBreakdownData.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-medium text-slate-650">
                    <span 
                      className="w-2 h-2 rounded-full shrink-0" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="truncate max-w-[100px]">{item.name}</span>
                  </div>
                  <span className="font-bold text-slate-800 font-mono bg-slate-50 border border-slate-100 px-1.5 py-0.25 rounded text-[10px]">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
