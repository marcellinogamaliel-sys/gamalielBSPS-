/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, Check, AlertTriangle, Trash2 } from 'lucide-react';

interface CameraCaptureProps {
  onCaptureCompleted: (photos: { name: string; base64: string }[]) => void;
  onCancel: () => void;
}

const INSTRUCTIONS = [
  { step: 1, arah: "Depan", instruksi: "Arahkan kamera lurus ke DEPAN utama ruangan / luar rumah" },
  { step: 2, arah: "Kanan Depan", instruksi: "Putar sedikit tubuh Anda 45° ke KANAN" },
  { step: 3, arah: "Kanan", instruksi: "Putar lagi hingga 90° ke KANAN" },
  { step: 4, arah: "Kanan Belakang", instruksi: "Putar lagi hingga 135° ke KANAN" },
  { step: 5, arah: "Belakang", instruksi: "Putar lagi hingga 180° menghadap ke BELAKANG utama" },
  { step: 6, arah: "Kiri Belakang", instruksi: "Putar lagi terus 225° ke KANAN (Kiri Belakang)" },
  { step: 7, arah: "Kiri", instruksi: "Putar lagi hingga 270° (menghadap penuh ke KIRI)" },
  { step: 8, arah: "Kiri Depan", instruksi: "Putar lagi 315° ke KANAN menjelang kembali ke arah depan" },
  { step: 9, arah: "Atas", instruksi: "Arahkan kamera ke ATAS (sudut langit-langit / plafon)" },
  { step: 10, arah: "Bawah", instruksi: "Arahkan kamera ke BAWAH (sudut lantai / fondasi)" }
];

export default function CameraCapture({ onCaptureCompleted, onCancel }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [streamActive, setStreamActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedPhotos, setCapturedPhotos] = useState<{ name: string; base64: string }[]>([]);

  // Open the device camera
  useEffect(() => {
    async function startCamera() {
      try {
        setCameraError(null);
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment', // use rear camera
            width: { ideal: 1920 },
            height: { ideal: 1080 }
          },
          audio: false
        });
        
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setStreamActive(true);
      } catch (err: any) {
        console.error("Gagal membuka kamera:", err);
        setCameraError(
          "Tidak dapat mengakses kamera belakang. Pastikan izin kamera telah diberikan di browser."
        );
      }
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, []);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setStreamActive(false);
  };

  const handleCapture = () => {
    if (!videoRef.current || !streamActive) return;

    try {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL('image/jpeg', 0.85);
        
        const currentArah = INSTRUCTIONS[currentStepIndex].arah;
        const newPhotoObj = { name: currentArah, base64 };
        
        const nextPhotos = [...capturedPhotos, newPhotoObj];
        setCapturedPhotos(nextPhotos);

        if (currentStepIndex < INSTRUCTIONS.length - 1) {
          setCurrentStepIndex(currentStepIndex + 1);
        } else {
          // Finished all 10 angles!
          stopCamera();
        }
      }
    } catch (err: any) {
      alert("Gagal mengabadikan foto: " + err.message);
    }
  };

  const handleDeletePhoto = (index: number) => {
    const updated = capturedPhotos.filter((_, i) => i !== index);
    setCapturedPhotos(updated);
    // Move step back if needed
    if (currentStepIndex >= updated.length) {
      setCurrentStepIndex(updated.length);
    }
  };

  const handleReset = () => {
    setCapturedPhotos([]);
    setCurrentStepIndex(0);
    // Restart camera if stopped
    if (!streamRef.current) {
      navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment',
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      }).then(stream => {
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
        setStreamActive(true);
      });
    }
  };

  const handleFinish = () => {
    if (capturedPhotos.length < 5) {
      alert("Harap ambil minimal 5 foto sudut untuk pemrosesan panorama dasar.");
      return;
    }
    onCaptureCompleted(capturedPhotos);
  };

  const activeInstruction = INSTRUCTIONS[currentStepIndex];

  return (
    <div className="space-y-4">
      {/* Banner Intruksi Utama */}
      <div className="bg-amber-500 text-white p-3 rounded-2xl text-center font-bold text-xs uppercase tracking-wide shadow-sm">
        "BERDIRILAH DI TENGAH RUANGAN / TITIK UTAMA. JANGAN BERPINDAH POSISI."
      </div>

      {cameraError ? (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-2xl text-xs space-y-2 flex flex-col items-center text-center">
          <AlertTriangle className="w-8 h-8 text-red-500 animate-bounce" />
          <p className="font-bold">KAMERA TIDAK TERDETEKSI</p>
          <p>{cameraError}</p>
          <button
            onClick={onCancel}
            className="mt-2 text-[11px] bg-red-650 text-white font-extrabold px-4 py-2 rounded-xl transition duration-200 hover:bg-red-700"
          >
            Kembali ke Menu Awal
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          
          {/* Sisi Kiri: Video Stream Live Camera */}
          <div className="lg:col-span-8 flex flex-col space-y-3">
            <div className="relative aspect-video bg-black rounded-3xl overflow-hidden border border-slate-200 shadow-md">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />

              {/* Status Overlay */}
              {capturedPhotos.length < INSTRUCTIONS.length && (
                <div className="absolute top-4 left-4 right-4 bg-slate-900/85 backdrop-blur-sm p-3 rounded-2xl border border-slate-700 text-white">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-extrabold text-amber-400 font-mono tracking-wider uppercase">
                      LANGKAH {currentStepIndex + 1} DARI {INSTRUCTIONS.length}
                    </span>
                    <span className="text-[10px] bg-amber-500 font-bold px-2 py-0.5 rounded-full text-slate-900 font-mono">
                      ARAH: {activeInstruction?.arah}
                    </span>
                  </div>
                  <p className="text-xs font-bold leading-snug">{activeInstruction?.instruksi}</p>
                </div>
              )}

              {capturedPhotos.length === INSTRUCTIONS.length && (
                <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm flex flex-col items-center justify-center text-center text-white p-6">
                  <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center mb-3">
                    <Check className="w-6 h-6 stroke-[3]" />
                  </div>
                  <h4 className="text-sm font-bold uppercase tracking-wider">PENGAMBILAN SELESAI</h4>
                  <p className="text-xs text-slate-300 mt-2 max-w-sm">
                    Seluruh 10 sudut utama telah berhasil diabadikan. Anda dapat mereview daftar foto di panel kanan atau klik selesai.
                  </p>
                </div>
              )}
            </div>

            {/* Tombol Ambil Gambar */}
            <div className="flex justify-center py-2">
              {capturedPhotos.length < INSTRUCTIONS.length ? (
                <button
                  type="button"
                  id="captureBtn"
                  onClick={handleCapture}
                  className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold px-8 py-3.5 rounded-full text-sm shadow-lg shadow-amber-500/30 hover:from-amber-600 hover:to-amber-700 transition transform hover:scale-105"
                >
                  <Camera size={18} />
                  Ambil Foto: {activeInstruction?.arah}
                </button>
              ) : (
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={handleReset}
                    className="flex items-center gap-1.5 border border-slate-300 text-slate-700 font-bold px-5 py-2.5 rounded-2xl text-xs hover:bg-slate-100 transition"
                  >
                    <RefreshCw size={14} />
                    Ulangi Foto
                  </button>
                  <button
                    type="button"
                    onClick={handleFinish}
                    className="flex items-center gap-1.5 bg-emerald-600 text-white font-extrabold px-7 py-2.5 rounded-2xl text-xs hover:bg-emerald-700 shadow-md transition"
                  >
                    <Check size={14} />
                    Selesai & Proses Raw
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Sisi Kanan: Live Checklist & Progress Review */}
          <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-3xl p-4 flex flex-col space-y-3 h-fit">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">Checklist Frame</h4>
              <span className="text-[10px] font-mono font-bold bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full">
                {capturedPhotos.length}/10 Foto
              </span>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden shadow-inner flex">
                <div 
                  className="bg-amber-500 h-2 transition-all duration-300"
                  style={{ width: `${(capturedPhotos.length / INSTRUCTIONS.length) * 100}%` }}
                />
              </div>
              <span className="text-[9px] text-slate-500 block font-mono font-bold">
                PROGRES AMBIL FOTO: {Math.round((capturedPhotos.length / INSTRUCTIONS.length) * 100)}%
              </span>
            </div>

            {/* List of angles */}
            <div className="max-h-[280px] overflow-y-auto scrollbar-thin border border-slate-200 rounded-2xl bg-white p-2 divide-y divide-slate-100">
              {INSTRUCTIONS.map((item, idx) => {
                const isCaptured = capturedPhotos.length > idx;
                const photoObj = isCaptured ? capturedPhotos[idx] : null;

                return (
                  <div key={item.step} className="flex items-center justify-between py-2 px-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 border text-[10px] font-mono font-bold ${
                        isCaptured ? 'bg-emerald-100 text-emerald-700 border-emerald-300' : 
                        currentStepIndex === idx ? 'bg-amber-100 text-amber-700 border-amber-300 animate-pulse' : 
                        'bg-slate-150 text-slate-500 border-slate-200'
                      }`}>
                        {isCaptured ? <Check className="w-3.5 h-3.5 stroke-[2.5]" /> : item.step}
                      </div>
                      <span className={`font-semibold truncate ${
                        isCaptured ? 'text-slate-800' : 'text-slate-400'
                      }`}>
                        {item.arah}
                      </span>
                    </div>

                    {isCaptured && photoObj && (
                      <div className="flex items-center gap-2">
                        <img 
                          src={photoObj.base64} 
                          alt={item.arah} 
                          className="w-8 h-8 rounded-lg object-cover cursor-pointer border border-slate-200 hover:scale-125 transition"
                          referrerPolicy="no-referrer"
                        />
                        <button
                          type="button"
                          onClick={() => handleDeletePhoto(idx)}
                          className="text-slate-400 hover:text-red-500 transition p-1"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {capturedPhotos.length > 0 && (
              <button
                type="button"
                onClick={handleFinish}
                className="w-full bg-slate-900 text-white font-bold py-2 px-4 rounded-xl text-xs hover:bg-slate-800 transition"
              >
                Gunakan {capturedPhotos.length} Foto yg Ada
              </button>
            )}

            <button
              type="button"
              onClick={onCancel}
              className="w-full border border-slate-200 text-slate-500 font-bold py-2 px-4 rounded-xl text-[11px] hover:bg-slate-100 transition text-center"
            >
              Batalkan
            </button>

          </div>

        </div>
      )}
    </div>
  );
}
