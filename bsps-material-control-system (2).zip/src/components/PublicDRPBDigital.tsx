/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Building, MapPin, Landmark, ClipboardCheck, Check, 
  Calendar, Clock, ShieldAlert, Sparkles, AlertCircle, X, AlertTriangle,
  Award, Eye, Home, Loader2, Navigation, Compass, ChevronRight, User, Info, Map, CheckSquare, ListPlus, Camera, Video, FileText, ArrowRight
} from 'lucide-react';
import { Recipient, DRPBItem, Distribution, DistributionMedia, Village, Group, Store, RecipientPhoto } from '../types';
import { formatDateOnly, obfuscateID, getStatusColor, getStatusLabel, formatFullDateTime } from '../utils';
import { ScannedWelcomeScreen } from './ScannedWelcomeScreen';
import { ScannedDetailModal } from './ScannedDetailModal';

interface PublicDRPBDigitalProps {
  recipientId: string;
}

export default function PublicDRPBDigital({
  recipientId
}: PublicDRPBDigitalProps) {
  const [loading, setLoading] = useState(true);
  const [recipient, setRecipient] = useState<Recipient | null>(null);
  const [drpb, setDrpb] = useState<DRPBItem[]>([]);
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [media, setMedia] = useState<DistributionMedia[]>([]);
  const [photos, setPhotos] = useState<RecipientPhoto[]>([]);
  const [villages, setVillages] = useState<Village[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [stores, setStores] = useState<Store[]>([]);

  // Real-time confirmation state
  const [savedDeliverySuccess, setSavedDeliverySuccess] = useState<{
    material: string;
    volume: number;
    unit: string;
    timestamp: string;
  } | null>(null);

  // Welcome Popup & Notifikasi Selesai Input states
  const [showWelcome, setShowWelcome] = useState<boolean>(false);
  const [hasWelcomed, setHasWelcomed] = useState<boolean>(false);
  const [showCompletionModal, setShowCompletionModal] = useState<boolean>(false);
  const [completionDetails, setCompletionDetails] = useState<{
    material: string;
    volume: number;
    unit: string;
    timestamp: string;
    notes: string;
  } | null>(null);

  // Delivery Input Form Toggles and States
  const [showInputForm, setShowInputForm] = useState<boolean>(true); // default true for priority input page placement
  const [selectedDrpbItemId, setSelectedDrpbItemId] = useState<string>('');
  const [materialType, setMaterialType] = useState<string>('');
  const [unit, setUnit] = useState<string>('');
  const [volume, setVolume] = useState<string>('1');
  const [notes, setNotes] = useState<string>('');

  // 4 Media attachment slots bases
  const [photoBefore, setPhotoBefore] = useState<string | null>(null);
  const [videoBase64, setVideoBase64] = useState<string | null>(null);
  const [photoAfter, setPhotoAfter] = useState<string | null>(null);
  const [receiptBase64, setReceiptBase64] = useState<string | null>(null);

  // GPS Coordinate Streams
  const [gpsLatitude, setGpsLatitude] = useState<number | null>(null);
  const [gpsLongitude, setGpsLongitude] = useState<number | null>(null);

  // Image Fullscreen display state
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

  // Selected progress category filter
  const [galleryFilter, setGalleryFilter] = useState<'all' | 'before' | 'during' | 'after'>('all');

  // Map tracking refs
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<any>(null);

  // Toast System
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // NEW REDESIGNED SCANNED WORKFLOW STATES
  const [currentView, setCurrentView] = useState<'welcome' | 'input'>('welcome');
  const [countdown, setCountdown] = useState(10);
  const [fetchProgress, setFetchProgress] = useState(0);
  const [fetchStatusText, setFetchStatusText] = useState('Menghubungkan ke Server Kementerian...');
  const [showDetailModal, setShowDetailModal] = useState<boolean>(false);
  const [showBulkConfirmModal, setShowBulkConfirmModal] = useState<boolean>(false);

  // Recipient confirmation states & functions
  const isPublicRoute = true;
  const [disputingId, setDisputingId] = useState<string | null>(null);
  const [disputeReason, setDisputeReason] = useState<string>('');

  const handleConfirm = async (id: string) => {
    try {
      const res = await fetch(`/api/distributions/${id}/confirm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal mengonfirmasi");
      
      showToast("Penyaluran berhasil dikonfirmasi!", "success");
      fetchPublicData();
    } catch (err: any) {
      showToast(err.message, "error");
    }
  };

  const handleDispute = async (id: string, reason: string) => {
    if (!reason.trim()) {
      showToast("Alasan sanggahan wajib diisi", "error");
      return;
    }
    try {
      const res = await fetch(`/api/distributions/${id}/dispute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menyanggah");

      showToast("Sanggahan berhasil dikirim ke Pengawas Korkab!", "success");
      setDisputingId(null);
      setDisputeReason('');
      fetchPublicData();
    } catch (err: any) {
      showToast(err.message, "error");
    }
  };

  // Initialize Geolocation stream on focus
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGpsLatitude(position.coords.latitude);
          setGpsLongitude(position.coords.longitude);
        },
        (error) => {
          console.warn("Kebenaran akses GPS tidak diizinkan atau tidak didukung perangkat.", error);
        },
        { enableHighAccuracy: true, timeout: 12000 }
      );
    }
  }, []);

  // Welcome countdown and automatic redirect
  useEffect(() => {
    if (currentView === 'welcome' && !loading) {
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setCurrentView('input');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [currentView, loading]);

  // Offline Draft Management - now disabled to avoid storing data on chrome/browser
  const clearLocalDraft = () => {
    // No-op: no data is stored in browser
  };

  // Base64 file handler callback
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setter: (base64: string | null) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 14 * 1024 * 1024) {
      showToast("File terlalu besar", "error");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setter(event.target.result as string);
      }
    };
    reader.onerror = () => {
      showToast("gagal baca file", "error");
    };
    reader.readAsDataURL(file);
  };

  // Submit Callback to save distribution logistics list
  const handleDistributionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDrpbItemId) {
      showToast("Pilih material", "error");
      return;
    }
    if (!volume || Number(volume) <= 0) {
      showToast("Volume tidak valid", "error");
      return;
    }

    const hasAtLeastOneFile = !!photoBefore || !!videoBase64 || !!photoAfter || !!receiptBase64;
    if (!hasAtLeastOneFile) {
      showToast("Lampirkan minimal 1 bukti media", "error");
      return;
    }

    try {
      const payload = {
        recipient_id: recipientId,
        drpb_item_id: selectedDrpbItemId,
        distribution_date: new Date().toISOString(),
        volume: Number(volume),
        notes: notes || "",
        photo_before: photoBefore,
        photo_after: photoAfter,
        video_base64: videoBase64,
        receipt_base64: receiptBase64,
        gps_latitude: gpsLatitude,
        gps_longitude: gpsLongitude,
        operator_id: "TOKO_SUPPLIER_PORTAL"
      };

      const res = await fetch('/api/distributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const responseData = await res.json();
      if (!res.ok) {
        throw new Error(responseData.error || "Gagal menyimpan pengiriman.");
      }

      showToast("Penyaluran Berhasil!", "success");
      clearLocalDraft();
      
      // Reload lists
      fetchPublicData();
      
      // Flush form state
      setSelectedDrpbItemId('');
      setMaterialType('');
      setUnit('');
      setVolume('1');
      setNotes('');
      setPhotoBefore(null);
      setVideoBase64(null);
      setPhotoAfter(null);
      setReceiptBase64(null);
    } catch (err: any) {
      showToast(err.message || "Gagal menyimpan", "error");
    }
  };

  const handleSalurkanSemua = async () => {
    try {
      setLoading(true);
      const pendingItems = drpb.filter((item) => {
        const totalDelivered = distributions
          .filter((d) => d.drpb_item_id === item.id)
          .reduce((sum, curr) => sum + Number(curr.volume), 0);
        return item.required_qty > totalDelivered;
      });

      if (pendingItems.length === 0) {
        showToast("Semua material DRPB sudah lengkap disalurkan!", "success");
        setLoading(false);
        return;
      }

      await Promise.all(
        pendingItems.map(async (item) => {
          const totalDelivered = distributions
            .filter((d) => d.drpb_item_id === item.id)
            .reduce((sum, curr) => sum + Number(curr.volume), 0);
          const remaining = item.required_qty - totalDelivered;

          const payload = {
            recipient_id: recipientId,
            drpb_item_id: item.id,
            distribution_date: new Date().toISOString(),
            volume: remaining,
            notes: "Disalurkan sekaligus via tombol Salurkan Semua",
            photo_before: photoBefore || "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=350&q=80",
            photo_after: photoAfter || "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=350&q=80",
            video_base64: videoBase64,
            receipt_base64: receiptBase64,
            gps_latitude: gpsLatitude,
            gps_longitude: gpsLongitude,
            operator_id: "TOKO_SUPPLIER_PORTAL"
          };

          const res = await fetch('/api/distributions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          return res;
        })
      );

      showToast("Berhasil menyalurkan semua material DRPB!", "success");
      clearLocalDraft();
      fetchPublicData();
    } catch (err: any) {
      showToast("Gagal menyalurkan semua material", "error");
      setLoading(false);
    }
  };

  // Load public data safely with simulated progress loader for unstable networks
  const fetchPublicData = async () => {
    try {
      setLoading(true);
      setFetchProgress(15);
      setFetchStatusText("Menghubungkan ke Server Kementerian...");

      const [vRes, gRes, sRes, svRes] = await Promise.all([
        fetch('/api/villages'),
        fetch('/api/groups'),
        fetch('/api/stores'),
        fetch(`/api/street-view`).catch(() => null)
      ]);
      
      setFetchProgress(35);
      setFetchStatusText("Mengambil data wilayah & toko mitra...");

      const [vData, gData, sData, svData] = await Promise.all([
        vRes.json(),
        gRes.json(),
        sRes.json(),
        svRes ? svRes.json() : []
      ]);

      setFetchProgress(55);
      setFetchStatusText("Sinkronisasi database penerima manfaat...");

      // Fetch recipient details
      const res = await fetch(`/api/recipients/${recipientId}`);
      if (!res.ok) throw new Error("Nomor Registrasi Penerima Bantuan tidak ditemukan.");
      const data = await res.json();
      
      setFetchProgress(75);
      setFetchStatusText("Memproses detail DRPB & Foto Lapangan...");

      setVillages(vData || []);
      setGroups(gData || []);
      setStores(sData || []);
      setRecipient(data.recipient);
      setDrpb(data.drpb || []);
      setDistributions(data.distributions || []);
      setMedia(data.distribution_media || []);
      setPhotos(data.recipient_photos || []);



      setFetchProgress(95);
      setFetchStatusText("Menyiapkan portal input logistik...");
      
      setTimeout(() => {
        setFetchProgress(100);
        setFetchStatusText("Selesai!");
        setLoading(false);
      }, 400);

    } catch (err: any) {
      showToast("Gagal memuat data sistem", "error");
      setLoading(false);
    }
  };

  useEffect(() => {
    if (recipientId) {
      fetchPublicData();
    }
  }, [recipientId]);

  // Leaflet Map mount process
  useEffect(() => {
    if (loading || !recipient || !mapContainerRef.current) return;

    // Check if map container is already loaded
    if (mapRef.current) {
      mapRef.current.remove();
      mapRef.current = null;
    }

    try {
      const lat = recipient.latitude || -1.3324;
      const lng = recipient.longitude || 124.8456;
      
      const map = (window as any).L.map(mapContainerRef.current, {
        zoomControl: true,
        scrollWheelZoom: false,
        zoomAnimation: true
      }).setView([lat, lng], 16);

      (window as any).L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
      }).addTo(map);

      // Add custom styled marker circles
      const color = recipient.status === 'complete' ? '#10b981' : recipient.status === 'in_progress' ? '#f59e0b' : '#ef4444';
      const markerOptions = {
        radius: 10,
        fillColor: color,
        color: '#ffffff',
        weight: 3,
        opacity: 1,
        fillOpacity: 0.85
      };

      const marker = (window as any).L.circleMarker([lat, lng], markerOptions).addTo(map);
      marker.bindPopup(`
        <div style="font-family: sans-serif; padding: 4px;">
          <h4 style="margin: 0 0 5px 0; font-weight: 800; font-size: 13px; color: #0f172a; text-transform: uppercase;">${recipient.full_name}</h4>
          <p style="margin: 0; font-size: 11px; color: #64748b;">Penerima Stimulan Rumah BSPS</p>
          <span style="display: inline-block; margin-top: 6px; padding: 2px 6px; border-radius: 4px; font-size: 9px; font-weight: bold; background: ${color}; color: white;">
            STATUS: ${recipient.status.toUpperCase()}
          </span>
        </div>
      `).openPopup();

      mapRef.current = map;
    } catch (e) {
      console.warn("Leaflet error:", e);
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [loading, recipient, showDetailModal]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-6 text-slate-800 relative overflow-hidden">
        {/* Ambient background glows */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-md w-full bg-white border border-slate-200/85 p-8 rounded-3xl shadow-lg text-center space-y-6 relative z-10">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-amber-50 flex items-center justify-center border border-amber-200">
              <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
            </div>
          </div>

          <div className="space-y-1">
            <h3 className="text-[10px] font-black tracking-widest uppercase text-slate-400 font-mono">PORTAL DIREKTORAT RUSP</h3>
            <h2 className="text-base font-black text-slate-800 tracking-tight uppercase">
              Sistem Monitoring Digital 2026
            </h2>
          </div>

          {/* Progress Bar Container */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-[10px] font-mono font-bold text-slate-500">
              <span>SINKRONISASI DATA</span>
              <span className="text-amber-600 font-black">{fetchProgress}%</span>
            </div>
            <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden border border-slate-200 p-0.5">
              <div 
                className="h-full rounded-full bg-gradient-to-r from-amber-500 via-amber-600 to-amber-400 transition-all duration-300"
                style={{ width: `${fetchProgress}%` }}
              />
            </div>
          </div>

          <p className="text-[10px] text-slate-500 font-mono tracking-wide h-4 animate-pulse font-medium">
            {fetchStatusText}
          </p>
        </div>
      </div>
    );
  }

  if (!recipient) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-6 text-center text-slate-800">
        <div className="max-w-md w-full bg-white border border-slate-200/85 p-8 rounded-3xl shadow-lg flex flex-col items-center">
          <ShieldAlert size={56} className="text-rose-500 mb-4 animate-bounce" />
          <h3 className="text-sm font-black uppercase tracking-wider text-rose-600">
            IDENTITAS DIGITAL PRIVAT / INVALID
          </h3>
          <p className="text-xs text-slate-500 mt-2.5 max-w-sm font-sans leading-relaxed font-semibold">
            Sistem tidak menemukan berkas Penerima Bantuan dengan kode pindaian QR ini. Periksa kembali keabsahan kartu fisik atau hubungi petugas Fasilitator BSPS 2026 setempat.
          </p>
        </div>
      </div>
    );
  }

  const pbVillageName = villages.find(v => v.id === recipient.village_id)?.name || "-";
  const pbGroupName = groups.find(g => g.id === recipient.group_id)?.name || "-";
  const pbStoreName = stores.find(s => s.id === recipient.store_id)?.name || "-";

  // Calculate dynamic build progress percentage
  const totalMaterials = drpb.length;
  const deliveredMaterials = drpb.filter(item => {
    const itemDists = distributions.filter(d => d.drpb_item_id === item.id);
    const delivered = itemDists.reduce((sum, curr) => sum + Number(curr.volume), 0);
    return delivered >= item.required_qty;
  }).length;

  let computedProgress = totalMaterials > 0 ? Math.round((deliveredMaterials / totalMaterials) * 100) : 0;
  if (recipient.status === 'complete') computedProgress = 100;

  // Determine current construction stage name
  let currentStageText = "Tahap Persiapan";
  if (computedProgress >= 100) {
    currentStageText = "Selesai Pembangunan (100%)";
  } else if (computedProgress >= 75) {
    currentStageText = "Pekerjaan Atap & Utilitas (75%)";
  } else if (computedProgress >= 50) {
    currentStageText = "Pemasangan Dinding & Kusen (50%)";
  } else if (computedProgress >= 25) {
    currentStageText = "Pondasi & Struktur Bawah (25%)";
  } else if (computedProgress > 0) {
    currentStageText = "Pengiriman Bahan Material Dasar (15%)";
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between font-sans relative">

      {/* DUAL VIEW ROUTER DETERMINED BY currentView */}
      <AnimatePresence mode="wait">
        {currentView === 'welcome' ? (
          <ScannedWelcomeScreen
            recipient={recipient}
            photos={photos}
            pbVillageName={pbVillageName}
            pbGroupName={pbGroupName}
            computedProgress={computedProgress}
            drpb={drpb}
            countdown={countdown}
            onEnterPortal={() => setCurrentView('input')}
            onSkip={() => setCurrentView('input')}
            currentStageText={currentStageText}
          />
        ) : (
          <motion.div
            key="input-view"
            initial={{ opacity: 0, scale: 0.99 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 bg-slate-50 text-slate-800 p-4 sm:p-6 space-y-6"
          >
            {/* FLOATING HEADER WORKSPACE */}
            <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-205 rounded-3xl p-5 shadow-xs relative">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-center text-lg shadow-inner animate-pulse">🚚</div>
                <div className="text-left">
                  <span className="text-[9px] font-black font-mono text-amber-600 tracking-widest block uppercase">TFL PORTAL PENYALURAN</span>
                  <h1 className="text-base sm:text-lg font-black text-slate-900 uppercase leading-none truncate max-w-xs">{recipient.full_name}</h1>
                </div>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  onClick={() => setShowDetailModal(true)}
                  className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 border border-amber-400 text-xs font-black shadow-md transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
                  title="Cek profil, maps, streetview 360, foto lengkap dll"
                >
                  <User size={13} className="text-slate-950" />
                  CEK DETAIL PB
                </button>
                <button
                  onClick={() => {
                    setCurrentView('welcome');
                    setCountdown(10);
                  }}
                  className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-extrabold border border-slate-205 cursor-pointer"
                  title="Simulasi Rescan QR"
                >
                  🔄 SCAN QR ULANG
                </button>
              </div>
            </header>

            {/* DUAL COLUMN MAIN LAYOUT */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* PRIMARY LEFT COLUMN: INPUT WORKSPACE DATASTORES */}
              <div className="col-span-1 lg:col-span-8 flex flex-col gap-6">

                {/* 1. PORTAL INFORMATION AND VERIFICATION GUIDE */}
                <div className="bg-amber-50/50 border border-amber-200/60 rounded-3xl p-5 sm:p-6 shadow-xs text-left space-y-3 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
                  <div className="flex items-center gap-2 text-amber-700">
                    <span className="text-xl">📋</span>
                    <h2 className="text-sm font-black font-mono uppercase tracking-wider">
                      PORTAL VERIFIKASI DIGITAL PENERIMA BANTUAN
                    </h2>
                  </div>
                  <p className="text-xs text-slate-650 leading-relaxed font-semibold">
                    Selamat datang di portal monitoring resmi BSPS 2026. Sebagai Penerima Bantuan (PB) atau Fasilitator, Anda dapat menggunakan portal ini untuk memverifikasi sisa alokasi DRPB, melihat riwayat drop barang, dan merekam pengiriman material secara instan.
                  </p>
                  <p className="text-xs text-amber-750 font-mono font-bold flex items-center gap-1.5 leading-none">
                    <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    Hubungi Fasilitator (TFL) atau gunakan form input mandiri di bawah ini untuk melaporkan material pengiriman.
                  </p>
                </div>

                {/* LOGISTIK INPUT FORM - PRIORITIZED AS THE PRIMARY ACTION */}
                <div 
                  id="distribution-input-form-target"
                  className="bg-white border-2 border-amber-400 rounded-3xl p-5 sm:p-6 shadow-sm space-y-5 text-left relative overflow-hidden"
                >
                  <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
                  <div className="absolute top-3 right-3 bg-amber-100 border border-amber-200 text-amber-700 px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider">
                    AKSI UTAMA FIELD VERIFICATION
                  </div>

                  <div className="border-b border-slate-200/90 pb-3">
                    <h3 className="text-xs font-black text-slate-900 font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <ListPlus size={14} className="text-amber-600" />
                      LAPORKAN PENGIRIMAN LOGISTIK MATERIAL BARU
                    </h3>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Maksimalisasi tertib administrasi dengan menginput volume dan mengunggah foto bukti fisik bongkar muat.
                    </p>
                  </div>

                  <form onSubmit={handleDistributionSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Select Material */}
                      <div className="space-y-1.5 col-span-1 text-left">
                        <label className="text-[11px] text-slate-650 font-bold block uppercase tracking-wide">
                          Jenis Bahan Material DRPB <span className="text-rose-500">*</span>
                        </label>
                        <select
                          required
                          value={selectedDrpbItemId}
                          onChange={(e) => {
                            const itemId = e.target.value;
                            setSelectedDrpbItemId(itemId);
                            const matched = drpb.find(item => item.id === itemId);
                            if (matched) {
                              setMaterialType(matched.material_type);
                              setUnit(matched.unit);
                              const totalDelivered = distributions
                                .filter((d) => d.drpb_item_id === matched.id)
                                .reduce((sum, curr) => sum + Number(curr.volume), 0);
                              const remaining = Math.max(0, matched.required_qty - totalDelivered);
                              setVolume(remaining.toString());
                            } else {
                              setMaterialType('');
                              setUnit('');
                              setVolume('1');
                            }
                          }}
                          className="w-full bg-slate-50 border border-slate-205 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2.5 text-xs text-slate-800 outline-none transition uppercase font-mono font-bold"
                        >
                          <option value="" className="bg-white text-slate-800">-- Pilih Jenis Material --</option>
                          {drpb.map((item) => {
                            const totalDelivered = distributions
                              .filter((d) => d.drpb_item_id === item.id)
                              .reduce((sum, curr) => sum + Number(curr.volume), 0);
                            const remaining = Math.max(0, item.required_qty - totalDelivered);
                            const isDone = remaining <= 0;
                            return (
                              <option key={item.id} value={item.id} disabled={isDone} className="bg-white py-1.5 text-slate-800">
                                {item.material_type} ({remaining} {item.unit} sisa) {isDone ? ' [LENGKAP]' : ''}
                              </option>
                            );
                          })}
                        </select>
                      </div>

                      {/* Input Volume */}
                      <div className="space-y-1.5 col-span-1 text-left">
                        <label className="text-[11px] text-slate-650 font-bold block uppercase tracking-wide">
                          Volume Drop Terkirim {unit ? `(${unit})` : ''} <span className="text-rose-500">*</span>
                        </label>
                        <div className="relative">
                          <input
                            required
                            type="number"
                            min="0.1"
                            step="any"
                            value={volume}
                            onChange={(e) => setVolume(e.target.value)}
                            placeholder="Contoh: 15"
                            className="w-full bg-slate-50 border border-slate-205 focus:border-amber-500 rounded-xl px-3 py-2.5 text-xs text-slate-900 outline-none transition font-mono font-bold"
                          />
                          {unit && (
                            <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[10px] font-mono font-black text-amber-600 uppercase">
                              {unit}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Media Attachments Block */}
                    <div className="space-y-2 text-left">
                      <label className="text-[11px] text-slate-650 font-bold block uppercase tracking-wide">
                        Bukti Dukung Penyaluran Visual (Min. 1 Lampiran Photo/Video/Nota) <span className="text-rose-500">*</span>
                      </label>
                      
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {/* 1. Photo Before */}
                        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex flex-col items-center justify-center text-center space-y-1.5 relative overflow-hidden min-h-[110px] hover:border-amber-500/30 transition">
                          {photoBefore ? (
                            <div className="absolute inset-0">
                              <img src={photoBefore} className="w-full h-full object-cover rounded-2xl" alt="Foto Sebelum" />
                              <button
                                type="button"
                                onClick={() => setPhotoBefore(null)}
                                className="absolute top-1.5 right-1.5 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-full transition shadow-md"
                              >
                                <X size={10} />
                              </button>
                            </div>
                          ) : (
                            <label className="w-full h-full cursor-pointer flex flex-col items-center justify-center">
                              <Camera size={18} className="text-amber-600 mb-1" />
                              <span className="text-[10px] font-bold text-slate-700 block">FOTO NOL</span>
                              <span className="text-[8px] text-slate-400 font-mono uppercase">Sebelum Drop</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleFileChange(e, setPhotoBefore)}
                                className="hidden"
                              />
                            </label>
                          )}
                        </div>

                        {/* 2. Photo After */}
                        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex flex-col items-center justify-center text-center space-y-1.5 relative overflow-hidden min-h-[110px] hover:border-amber-500/30 transition">
                          {photoAfter ? (
                            <div className="absolute inset-0">
                              <img src={photoAfter} className="w-full h-full object-cover rounded-2xl" alt="Foto Setelah" />
                              <button
                                type="button"
                                onClick={() => setPhotoAfter(null)}
                                className="absolute top-1.5 right-1.5 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-full transition shadow-md"
                              >
                                <X size={10} />
                              </button>
                            </div>
                          ) : (
                            <label className="w-full h-full cursor-pointer flex flex-col items-center justify-center">
                              <Camera size={18} className="text-amber-600 mb-1" />
                              <span className="text-[10px] font-bold text-slate-700 block">FOTO BONGKAR</span>
                              <span className="text-[8px] text-slate-400 font-mono uppercase">Setelah Drop</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleFileChange(e, setPhotoAfter)}
                                className="hidden"
                              />
                            </label>
                          )}
                        </div>

                        {/* 3. Video Mp4 */}
                        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex flex-col items-center justify-center text-center space-y-1.5 relative overflow-hidden min-h-[110px] hover:border-amber-500/30 transition">
                          {videoBase64 ? (
                            <div className="absolute inset-0 bg-slate-900 flex flex-col items-center justify-center p-2 text-center">
                              <Video size={16} className="text-amber-400" />
                              <span className="text-[9px] text-white font-mono font-bold uppercase mt-1 truncate max-w-[80px]">Video Ready</span>
                              <button
                                type="button"
                                onClick={() => setVideoBase64(null)}
                                className="absolute top-1.5 right-1.5 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-full transition shadow-md"
                              >
                                <X size={10} />
                              </button>
                            </div>
                          ) : (
                            <label className="w-full h-full cursor-pointer flex flex-col items-center justify-center">
                              <Video size={18} className="text-amber-600 mb-1" />
                              <span className="text-[10px] font-bold text-slate-700 block">REKAM VIDEO</span>
                              <span className="text-[8px] text-slate-400 font-mono uppercase">MP4 &lt; 14MB</span>
                              <input
                                type="file"
                                accept="video/*"
                                onChange={(e) => handleFileChange(e, setVideoBase64)}
                                className="hidden"
                              />
                            </label>
                          )}
                        </div>

                        {/* 4. Receipt */}
                        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex flex-col items-center justify-center text-center space-y-1.5 relative overflow-hidden min-h-[110px] hover:border-amber-500/30 transition">
                          {receiptBase64 ? (
                            <div className="absolute inset-0 bg-slate-900 flex flex-col items-center justify-center p-2 text-center">
                              <FileText size={16} className="text-amber-400" />
                              <span className="text-[9px] text-white font-mono font-bold uppercase mt-1 truncate max-w-[80px]">NOTA READY</span>
                              <button
                                type="button"
                                onClick={() => setReceiptBase64(null)}
                                className="absolute top-1.5 right-1.5 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-full transition shadow-md"
                              >
                                <X size={10} />
                              </button>
                            </div>
                          ) : (
                            <label className="w-full h-full cursor-pointer flex flex-col items-center justify-center">
                              <FileText size={18} className="text-amber-600 mb-1" />
                              <span className="text-[10px] font-bold text-slate-700 block">SURAT JALAN</span>
                              <span className="text-[8px] text-slate-400 font-mono uppercase">Bukti TTD Toko</span>
                              <input
                                type="file"
                                accept="image/*,application/pdf"
                                onChange={(e) => handleFileChange(e, setReceiptBase64)}
                                className="hidden"
                              />
                            </label>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Notes text */}
                    <div className="space-y-1.5 text-left">
                      <label className="text-[11px] text-slate-650 font-bold block uppercase tracking-wide">
                        Keterangan atau Berita Acara Lapangan
                      </label>
                      <textarea
                        rows={2}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Contoh: Pengantaran material semen 15 sak sukses diterima langsung oleh keluarga bersangkutan."
                        className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 outline-none transition resize-none placeholder:text-slate-400 placeholder:text-[10px]"
                      />
                    </div>

                    {/* GPS Coordinates stream row */}
                    <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-100/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 select-none font-mono text-[9px] text-slate-500 uppercase tracking-widest leading-none">
                      <span className="flex items-center gap-1">
                        <MapPin size={11} className="text-amber-600" />
                        Lokasi GPS Presisi: {gpsLatitude && gpsLongitude ? (
                          <span className="text-amber-600 font-bold ml-1">LOCKED ({gpsLatitude.toFixed(6)}, {gpsLongitude.toFixed(6)})</span>
                        ) : (
                          <span className="text-amber-500 animate-pulse ml-1">AQUIRING LOCK...</span>
                        )}
                      </span>
                      <span>SECURE TRANSACTION</span>
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      className="w-full py-3 px-5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider transition active:scale-97 flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-900/30 border border-amber-400"
                    >
                      <span>Kirim Laporan Pengiriman Fisik</span>
                      <ArrowRight size={13} className="text-slate-950" />
                    </button>
                  </form>
                </div>

                {/* 2. DRPB LISTING WORKPLACE TABLE */}
                <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-left">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div>
                      <h3 className="text-xs font-black text-slate-900 font-mono uppercase tracking-wider flex items-center gap-1.5">
                        <CheckSquare size={15} className="text-amber-600" />
                        DAFTAR RENCANA PEMANFAATAN BAHAN (DRPB) DIGITAL PB
                      </h3>
                      <p className="text-[10px] text-slate-550">Verifikasi sisa alokasi logis bangunan swadaya yang wajib dipasok toko mitra.</p>
                    </div>

                    {/* Bulk delivery + QR Sync tools */}
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowBulkConfirmModal(true)}
                        className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10.5px] font-black uppercase transition active:scale-95 flex items-center gap-1 cursor-pointer"
                        title="Salurkan seluruh sisa logistik material untuk PB ini sekaligus"
                      >
                        🚚 SALURKAN SEMUA
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-slate-150 bg-white">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-[10px] font-bold font-mono text-slate-500 uppercase tracking-wider border-b border-slate-150">
                          <th className="p-3.5 border-r border-slate-150">Nama Barang</th>
                          <th className="p-3.5 text-center border-r border-slate-150">Volume DRPB</th>
                          <th className="p-3.5 text-center border-r border-slate-150">Terkirim</th>
                          <th className="p-3.5 text-center border-r border-slate-150">Sisa</th>
                          <th className="p-3.5 text-center">Aksi Cepat</th>
                        </tr>
                      </thead>
                      <tbody>
                        {drpb.map((item) => {
                          const totalDelivered = distributions
                            .filter((d) => d.drpb_item_id === item.id)
                            .reduce((sum, curr) => sum + Number(curr.volume), 0);
                          const remaining = Math.max(0, item.required_qty - totalDelivered);
                          const isCompleted = remaining <= 0;

                          return (
                            <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50 transition">
                              <td className="p-3 py-4 font-black text-slate-800 flex items-center gap-1.5 font-sans border-r border-slate-100">
                                <span className="text-lg">
                                  {item.material_type.includes('Semen') ? '🧱' : 
                                   item.material_type.includes('Pasir') ? '⏳' :
                                   item.material_type.includes('Batu') ? '🪨' :
                                   item.material_type.includes('Besi') ? '⛓️' :
                                   item.material_type.includes('Seng') ? '🏠' : '🪵'}
                                </span>
                                {item.material_type}
                              </td>
                              <td className="p-3 text-center font-mono font-bold text-slate-600 border-r border-slate-100">
                                {item.required_qty} {item.unit}
                              </td>
                              <td className="p-3 text-center font-mono font-bold text-emerald-600 border-r border-slate-100">
                                {totalDelivered} {item.unit}
                              </td>
                              <td className={`p-3 text-center font-mono font-black border-r border-slate-100 ${isCompleted ? 'text-slate-400' : 'text-amber-600'}`}>
                                {remaining} {item.unit}
                              </td>
                              <td className="p-3 text-center">
                                {!isCompleted ? (
                                  <div className="flex items-center justify-center gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setSelectedDrpbItemId(item.id);
                                        setMaterialType(item.material_type);
                                        setUnit(item.unit);
                                        setVolume(remaining.toString());
                                        showToast(`Pre-fill: ${item.material_type}`, "success");
                                        const formEl = document.getElementById("distribution-input-form-target");
                                        if (formEl) formEl.scrollIntoView({ behavior: 'smooth' });
                                      }}
                                      className="py-1 px-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-[10px] font-black uppercase tracking-tight transition cursor-pointer"
                                      title="Pre-fill form dengan sisa kuantiti"
                                    >
                                      Salurkan
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        showToast(`Material ${item.material_type} ditunda pengirimannya.`, "error");
                                      }}
                                      className="py-1 px-2 bg-slate-100 hover:bg-slate-205 text-slate-500 rounded-lg text-[10px] uppercase font-bold cursor-pointer"
                                    >
                                      Tunda
                                    </button>
                                  </div>
                                ) : (
                                  <span className="text-[10px] font-black text-emerald-600 font-mono tracking-wider bg-emerald-50 border border-emerald-250 p-1 px-2 rounded-lg leading-none inline-block">
                                    LENGKAP ✓
                                  </span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
                  {/* 3. RIWAYAT PENYALURAN (DELIVERY HISTORY LOGS) */}
                <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-left">
                  <div>
                    <h3 className="text-xs font-black text-slate-900 font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <Clock size={15} className="text-amber-600" />
                      RIWAYAT DROP BARANG (TRACKING PENYALURAN)
                    </h3>
                    <p className="text-[10px] text-slate-550">Arsip real-time drop pengantaran logis yang terkoneksi ke database kementerian.</p>
                  </div>

                  {distributions.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-500 font-mono border border-dashed border-slate-200 rounded-2xl italic bg-slate-50">
                      Belum ada laporan penyaluran logistik yang tersimpan untuk penerima bantuan ini.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                      {distributions.map((dist) => {
                        const matchedItem = drpb.find(item => item.id === dist.drpb_item_id);
                        return (
                          <div key={dist.id} className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                            <div className="flex items-center gap-3 text-left">
                              <span className="text-xl">🚚</span>
                              <div>
                                <span className="text-xs font-bold text-slate-800 block uppercase font-sans">
                                  {matchedItem ? matchedItem.material_type : 'Bahan Material'} - {dist.volume} {matchedItem ? matchedItem.unit : 'satuan'}
                                </span>
                                <span className="text-[10px] font-mono text-slate-500 block mt-0.5">Time: {formatFullDateTime(dist.distribution_date)} &bull; Opr: {dist.operator_id}</span>
                                {dist.notes && <p className="text-[11px] text-amber-800 font-semibold italic mt-1 font-mono">"Catatan: {dist.notes}"</p>}
                              </div>
                            </div>
                            <span className="text-[9px] font-mono font-bold text-emerald-600 bg-emerald-50 border border-emerald-250 p-1 px-3.5 rounded-full select-none shrink-0 self-start sm:self-center uppercase">
                              Sukses Terkirim
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

              </div>
              
              {/* SECONDARY RIGHT COLUMN: STATS PANELS VISUALIZATIONS */}
              <div className="col-span-1 lg:col-span-4 flex flex-col gap-6">

                {/* MATERIAL STATUS / PROGRESS SUMMARY CARD */}
                <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-left">
                  <div>
                    <h3 className="text-xs font-black text-slate-900 font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <ClipboardCheck size={15} className="text-amber-600" />
                      STATUS LOGISTIK RECIPIENT
                    </h3>
                  </div>

                  <div className="relative pt-2">
                    <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden border border-slate-205 p-0.5">
                      <div 
                        className="h-full rounded-full bg-gradient-to-r from-amber-500 via-amber-600 to-emerald-500 transition-all duration-700"
                        style={{ width: `${computedProgress}%` }}
                      />
                    </div>
                  </div>
                    <div className="flex justify-between items-center text-[10px] font-mono font-bold text-slate-500 mt-1.5 select-none">
                      <span>0%</span>
                      <span>50%</span>
                      <span>100%</span>
                    </div>

                  <div className="bg-slate-50 border border-slate-150 p-4 rounded-2xl space-y-2">
                    <div className="flex justify-between text-xs font-sans">
                      <span className="text-slate-550 font-medium">Total Material DRPB:</span>
                      <span className="font-extrabold text-slate-800 uppercase">{drpb.length} jenis</span>
                    </div>
                    <div className="flex justify-between text-xs font-sans">
                      <span className="text-slate-550 font-medium">Fisik Tercapai:</span>
                      <span className="font-extrabold text-amber-650 font-mono text-sm">{computedProgress}%</span>
                    </div>
                    <div className="flex justify-between text-xs pt-2 border-t border-slate-250/80 font-sans">
                      <span className="text-slate-550 block font-bold">KONSTRUKSI:</span>
                      <span className="text-slate-800 font-mono uppercase text-[10.5px] font-extrabold">{currentStageText}</span>
                    </div>
                  </div>
                </div>

                {/* SECURE DISCLAIMER CARD FOR MOBILE NETWORKS */}
                <div className="p-4 bg-amber-50/50 rounded-2xl text-slate-650 text-[10px] leading-relaxed border border-amber-200/50 flex items-start gap-2 text-left">
                  <AlertCircle size={14} className="text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                  <p className="font-sans">
                    <strong>Mitra Toko & TFL Note:</strong> Data penyaluran disinkronkan secara real-time ke dashboards KORKAB. Jika sinyal mati di pelosok desa, klik <strong>"SIMPAN DRAFT"</strong> terlebih dahulu agar laporan tidak hilang.
                  </p>
                </div>

              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. THE GRAND MODULAR PROFILE OVERLAY INJECTED */}
      <AnimatePresence>
        <ScannedDetailModal
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(false)}
          recipient={recipient}
          photos={photos}
          pbVillageName={pbVillageName}
          pbGroupName={pbGroupName}
          pbStoreName={pbStoreName}
          formatDateOnly={formatDateOnly}
          galleryFilter={galleryFilter}
          setGalleryFilter={setGalleryFilter}
          setFullscreenImage={setFullscreenImage}
          mapContainerRef={mapContainerRef}
        />
      </AnimatePresence>

      {/* 3. CUSTOM SAFE BATCH DELIVERY CONFIRMATION MODAL OVERLAY */}
      <AnimatePresence>
        {showBulkConfirmModal && (
          <div className="fixed inset-0 z-[10001] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="max-w-md w-full bg-white border border-slate-200 rounded-3xl p-6 text-center space-y-6 shadow-2xl text-slate-900"
            >
              <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-650 rounded-full flex items-center justify-center mx-auto text-xl animate-bounce">
                🚚
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-black font-mono tracking-widest text-[#d97706] uppercase">KONFIRMASI PENYALURAN MASAL DRPB</h3>
                <h2 className="text-lg font-black text-emerald-600">SALURKAN SELURUH MATERIAL</h2>
                <p className="text-xs text-slate-600 leading-relaxed max-w-sm mx-auto font-semibold">
                  Apakah Anda benar-benar yakin ingin langsung menyalurkan <strong>SELURUH sisa alokasi DRPB</strong> untuk Bapak/Ibu <strong>{recipient?.full_name}</strong> secara instan? Tindakan ini akan mengupdate sisa kirim material secara otomatis menjadi 100%.
                </p>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBulkConfirmModal(false)}
                  className="w-1/2 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl text-xs font-bold border border-slate-200 transition"
                >
                  BATALKAN
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowBulkConfirmModal(false);
                    handleSalurkanSemua();
                  }}
                  className="w-1/2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-black uppercase transition active:scale-95 cursor-pointer"
                >
                  YA, SALURKAN SEMUA!
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. FULLSCREEN IMAGE MODAL CHANGER */}
      <AnimatePresence>
        {fullscreenImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setFullscreenImage(null)}
            className="fixed inset-0 bg-black/90 z-[10001] flex items-center justify-center p-4 cursor-zoom-out"
          >
            <div className="relative max-w-4xl max-h-[90vh] w-full h-full flex items-center justify-center">
              <img src={fullscreenImage} className="max-w-full max-h-full object-contain rounded-xl shadow-2xl border border-slate-800" alt="Membuka foto besar" />
              <button
                type="button"
                onClick={() => setFullscreenImage(null)}
                className="absolute top-4 right-4 bg-slate-800/80 hover:bg-slate-700 text-white p-3 rounded-full transition cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 5. TOAST SYSTEM ELEMENT */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed top-4 right-4 z-[10002] p-1"
          >
            <div className={`p-4 flex items-center gap-3 rounded-2xl shadow-2xl border ${
              toast.type === 'success' ? 'bg-emerald-600/95 border-emerald-500 text-white' : 'bg-rose-600/95 border-rose-500 text-white'
            }`}>
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                {toast.type === 'success' ? '✓' : '⚠️'}
              </div>
              <span className="text-xs font-bold leading-tight tracking-tight font-sans">{toast.message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* PORTAL OFFICIAL FOOTER BRANDING */}
      <footer className="bg-slate-950 text-white border-t border-slate-800 py-10 px-6 sm:px-8 text-center space-y-4">
        <div className="max-w-4xl mx-auto flex flex-col items-center justify-center gap-3">
          <img src="/logo.png" className="h-14 w-14 object-contain brightness-110" alt="Logo Kementerian Swadaya" referrerPolicy="no-referrer" />
          
          <div className="space-y-1">
            <h4 className="text-xs font-black tracking-widest text-amber-500 font-mono uppercase">
              SISTEM MONITORING DIGITAL BSPS
            </h4>
            <p className="text-xs sm:text-sm font-extrabold text-slate-200 font-sans">
              Kementerian Perumahan dan Kawasan Permukiman Republik Indonesia
            </p>
            <p className="text-[10px] text-slate-500 font-mono">
              &copy; {new Date().getFullYear()} Kementerian PKP RI. Tim 22 Bantuan Stimulan Swadaya Nasional.
            </p>
          </div>
        </div>
      </footer>

    </div>
  );
}
