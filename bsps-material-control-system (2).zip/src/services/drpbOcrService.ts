/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Recipient } from '../types';

/**
 * Validates whether the provided base64 string is a valid image.
 */
export function validateImage(base64Str: string): { isValid: boolean; error?: string } {
  if (!base64Str) {
    return { isValid: false, error: "Gambar tidak boleh kosong" };
  }

  // Check if it's a valid Data URL or base64 structure
  if (base64Str.startsWith('data:')) {
    const isImage = base64Str.startsWith('data:image/');
    if (!isImage) {
      return { isValid: false, error: "Tipe file harus berupa gambar (JPEG, PNG, JPG)" };
    }
    
    // Check file size approx from base64 (approx 1.37 times original size)
    const approximateBytes = (base64Str.length * 3) / 4;
    // Limit to 15MB
    if (approximateBytes > 15 * 1024 * 1024) {
      return { isValid: false, error: "File terlalu besar. Maksimal ukuran gambar adalah 15MB." };
    }
  } else {
    // If it's raw base64, check basic base64 regex character set
    const isBase64 = /^[A-Za-z0-9+/=]+$/s.test(base64Str.trim());
    if (!isBase64) {
      return { isValid: false, error: "Format string base64 tidak valid." };
    }
  }

  return { isValid: true };
}

/**
 * Validates minimum image dimensions to catch obviously too-small or
 * corrupted photos before sending to the AI, saving the user a wasted
 * round-trip to the API for an image that has no realistic chance of
 * being readable.
 */
export function validateImageDimensions(base64Str: string, minDimension: number = 600): Promise<{ isValid: boolean; error?: string }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      if (img.width < minDimension || img.height < minDimension) {
        resolve({
          isValid: false,
          error: `Resolusi foto terlalu kecil (${img.width}x${img.height}px). Gunakan foto dengan resolusi lebih tinggi (minimal ${minDimension}x${minDimension}px) agar tabel DRPB dapat terbaca jelas.`
        });
      } else {
        resolve({ isValid: true });
      }
    };
    img.onerror = () => {
      resolve({ isValid: false, error: "Gambar tidak dapat dimuat atau rusak." });
    };
    img.src = base64Str;
  });
}

/**
 * Preprocesses the base64 image data to ensure it is cleanly structured for the backend.
 * Strips carriage returns, trims whitespace, and ensures proper prefix formatting.
 */
export function preprocessImage(base64Str: string): string {
  if (!base64Str) return '';
  let cleaned = base64Str.trim();
  // Standardize JPEG mime types if they are sent as jpg
  if (cleaned.startsWith('data:image/jpg;base64,')) {
    cleaned = cleaned.replace('data:image/jpg;base64,', 'data:image/jpeg;base64,');
  }
  return cleaned;
}

/**
 * Calculates similarity score between two words (simplified Levenshtein distance)
 */
function getSimilarityScore(str1: string, str2: string): number {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  
  if (s1 === s2) return 1.0;
  if (s1.includes(s2) || s2.includes(s1)) return 0.8;
  
  // Clean punctuation and simplify words
  const words1 = s1.split(/\s+/);
  const words2 = s2.split(/\s+/);
  
  let matchCount = 0;
  for (const w1 of words1) {
    if (words2.some(w2 => w2 === w1 || w2.includes(w1) || w1.includes(w2))) {
      matchCount++;
    }
  }
  
  return (matchCount * 2) / (words1.length + words2.length);
}

/**
 * Matches a scanned name against existing recipients to handle typos.
 * Returns the best match if similarity is above a threshold.
 */
export function matchRecipient(scannedName: string, recipients: Recipient[]): Recipient | null {
  if (!scannedName || !recipients || recipients.length === 0) return null;
  
  const cleanScanned = scannedName.toLowerCase().trim();
  
  // 1. Direct match or obvious substring match
  const directMatch = recipients.find(r => {
    const rName = String(r.full_name || "").toLowerCase().trim();
    return rName === cleanScanned || rName.includes(cleanScanned) || cleanScanned.includes(rName);
  });
  
  if (directMatch) return directMatch;
  
  // 2. Fuzzy similarity match
  let bestMatch: Recipient | null = null;
  let highestScore = 0;
  
  for (const r of recipients) {
    const rName = String(r.full_name || "").toLowerCase().trim();
    const score = getSimilarityScore(cleanScanned, rName);
    
    if (score > highestScore) {
      highestScore = score;
      bestMatch = r;
    }
  }
  
  // Return if similarity score is promising (e.g. > 0.45 threshold)
  if (highestScore > 0.45) {
    return bestMatch;
  }
  
  return null;
}

export type OcrStep = 'Mengunggah foto...' | 'Menghubungi Gemini AI...' | 'Membaca tabel...' | 'Memvalidasi hasil...' | 'Selesai';

interface ScanOptions {
  imageBase64: string;
  recipientId?: string;
  operatorId?: string;
  type: 'extract' | 'parse';
  maxAttempts?: number;
  onStepChange?: (step: OcrStep) => void;
}

/**
 * Scans a DRPB document image with built-in retry logic and structured progress phase tracking.
 */
export async function scanDRPB(options: ScanOptions): Promise<any> {
  const {
    imageBase64,
    recipientId,
    operatorId,
    type,
    maxAttempts = 3,
    onStepChange
  } = options;

  // 1. Image validation and preprocessing
  const validation = validateImage(imageBase64);
  if (!validation.isValid) {
    throw new Error(validation.error || "Pemeriksaan validitas gambar gagal.");
  }
  
  const processedBase64 = preprocessImage(imageBase64);
  let lastError: any = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      // Step A: Mengunggah foto...
      onStepChange?.('Mengunggah foto...');
      await new Promise(resolve => setTimeout(resolve, 800)); // Mimic loading time for visual experience
      
      // Step B: Menghubungi Gemini AI...
      onStepChange?.('Menghubungi Gemini AI...');
      await new Promise(resolve => setTimeout(resolve, 600));

      const isExtract = type === 'extract';
      const endpoint = isExtract ? "/api/extract-drpb" : "/api/ocr/parse-drpb";
      
      const payload: any = isExtract ? {
        image_base64: processedBase64,
        operator_id: operatorId
      } : {
        imageBase64: processedBase64,
        recipient_id: recipientId,
        operator_id: operatorId
      };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Server merespon dengan status ${res.status}`);
      }

      // Step C: Membaca tabel...
      onStepChange?.('Membaca tabel...');
      await new Promise(resolve => setTimeout(resolve, 600));

      const data = await res.json();
      
      // Step D: Memvalidasi hasil...
      onStepChange?.('Memvalidasi hasil...');
      await new Promise(resolve => setTimeout(resolve, 700));

      // Validate data structure sanity
      if (isExtract) {
        if (!data.success || !data.items || !Array.isArray(data.items)) {
          throw new Error("Struktur data hasil ekstraksi tidak dikenal.");
        }
      } else {
        if (!data.success || !data.items || !Array.isArray(data.items)) {
          throw new Error("Struktur data hasil parse OCR tidak dikenal.");
        }
      }

      // Step E: Selesai
      onStepChange?.('Selesai');
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return data;
    } catch (err: any) {
      console.warn(`Layanan OCR gagal pada percobaan ${attempt}:`, err);
      lastError = err;
      if (attempt < maxAttempts) {
        // Sleep for a short while before retrying
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
    }
  }

  throw lastError || new Error("Gagal menyelesaikan scanning OCR DRPB setelah beberapa kali percobaan.");
}
