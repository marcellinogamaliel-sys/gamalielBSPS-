/**
 * Resize and compress an image file before sending to AI vision API.
 * Keeps aspect ratio, caps max dimension at 1600px, outputs JPEG at quality 0.85.
 * This significantly improves OCR accuracy on document photos by avoiding
 * over-large images that get auto-downscaled unpredictably by the API,
 * while also reducing upload time on slow field connections.
 */
export function resizeImageForOCR(file: File, maxDimension: number = 1600, quality: number = 0.85): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Tidak dapat memproses gambar (canvas context unavailable).'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Gagal memuat gambar untuk diproses. Pastikan file adalah foto yang valid.'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Gagal membaca file gambar.'));
    reader.readAsDataURL(file);
  });
}
