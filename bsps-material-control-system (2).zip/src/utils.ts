/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Format numbers to Indonesian standard
export function formatNumber(val: number): string {
  return new Intl.NumberFormat('id-ID').format(val);
}

// Obfuscate NIK for public visual security
export function obfuscateID(idStr: string): string {
  if (!idStr) return "";
  if (idStr.length < 4) return "****";
  return `****-****-${idStr.substring(idStr.length - 4)}`;
}

// Translate Recipient Status cleanly
export function getStatusLabel(status: string): string {
  switch (status) {
    case 'complete': return 'Lengkap';
    case 'in_progress': return 'Dalam Proses';
    case 'not_started': return 'Belum Disalurkan';
    case 'has_finding': return 'Ada Temuan';
    default: return status;
  }
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'complete': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'in_progress': return 'bg-amber-50 text-amber-700 border-amber-200';
    case 'not_started': return 'bg-rose-50 text-rose-700 border-rose-200';
    case 'has_finding': return 'bg-gray-100 text-gray-900 border-gray-300';
    default: return 'bg-gray-50 text-gray-700 border-gray-200';
  }
}

export function getStatusTextColor(status: string): string {
  switch (status) {
    case 'complete': return 'text-emerald-600';
    case 'in_progress': return 'text-amber-500';
    case 'not_started': return 'text-red-500';
    case 'has_finding': return 'text-gray-900';
    default: return 'text-gray-500';
  }
}

// Format date nicely
export function formatDate(dateStr: string): string {
  if (!dateStr) return "-";
  try {
    const d = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(d);
  } catch (e) {
    return dateStr;
  }
}

export function formatDateOnly(dateStr: string): string {
  if (!dateStr) return "-";
  try {
    const d = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', {
      dateStyle: 'medium'
    }).format(d);
  } catch (e) {
    return dateStr;
  }
}

export function formatFullDateTime(dateStr: string): string {
  if (!dateStr) return "-";
  try {
    const d = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(d) + " WIB";
  } catch (e) {
    return dateStr;
  }
}

