export interface Village {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
}

export interface Team {
  id: string;
  name: string;
  team_code: string;
  korkab_id: string;
  created_at: string;
}

export interface User {
  id: string;
  username: string;
  password: string; // Hashed
  role: 'admin' | 'korkab' | 'tfl';
  team_id?: string;
  created_at: string;
  updated_at: string;
  last_login_at?: string;
  login_info?: {
    ip_address?: string;
    device?: string;
    location?: string;
  };
}

export interface LoginActivity {
  id: string;
  user_id: string;
  timestamp: string;
  ip_address: string;
  device: string;
  location: string;
}

export interface Group {
  id: string;
  name: string;
  village_id: string;
  created_at: string;
  updated_at: string;
}

export interface Store {
  id: string;
  name: string;
  owner_name: string;
  address: string;
  phone_number: string;
  latitude: number;
  longitude: number;
  created_at: string;
  updated_at: string;
}

export type RecipientStatus = 'not_started' | 'in_progress' | 'complete' | 'has_finding';

export interface Recipient {
  id: string;
  full_name: string;
  nik: string;
  kk_number: string;
  address: string;
  village_id: string;
  group_id: string;
  store_id: string;
  latitude: number;
  longitude: number;
  qr_code_url: string;
  status: RecipientStatus;
  created_at: string;
  updated_at: string;
  tfl_team?: string;
}

export interface DRPBItem {
  id: string;
  recipient_id: string;
  material_type: string;
  unit: string;
  required_qty: number;
  created_at: string;
}

export type ShortageReason = 'not_available' | 'waiting_delivery' | 'store_empty' | 'weather' | 'other';

export interface Distribution {
  id: string;
  recipient_id: string;
  drpb_item_id: string;
  distribution_date: string;
  volume: number;
  notes?: string;
  shortage_reason?: ShortageReason | null;
  shortage_notes?: string | null;
  gps_latitude?: number;
  gps_longitude?: number;
  gps_distance_from_home?: number; // meters
  operator_id: string;
  created_at: string;
  confirmation_status?: ConfirmationStatus;
  confirmed_at?: string | null;
  dispute_reason?: string | null;
}

export type ConfirmationStatus = 'pending' | 'confirmed_by_recipient' | 'disputed';

export type MediaType = 'photo_before' | 'photo_during' | 'photo_after' | 'video' | 'receipt';

export interface DistributionMedia {
  id: string;
  distribution_id: string;
  media_type: MediaType;
  file_url: string;
  file_size?: number;
  duration_seconds?: number;
  uploaded_at: string;
}

export type HousePhase = 'initial' | 'mid' | 'final' | 'drpb';

export interface RecipientPhoto {
  id: string;
  recipient_id: string;
  phase: HousePhase;
  file_url: string;
  uploaded_at: string;
}

export type FindingCategory =
  | 'material_discrepancy'
  | 'material_shortage'
  | 'no_receipt'
  | 'no_photo'
  | 'no_video'
  | 'gps_mismatch'
  | 'material_quality'
  | 'recipient_disputed';

export interface Finding {
  id: string;
  recipient_id: string;
  category: FindingCategory;
  description: string;
  reported_by: string;
  resolved: boolean;
  resolved_at?: string | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  entity_type?: string;
  entity_id?: string;
  description: string;
  prev_value?: string;
  post_value?: string;
  ip_address?: string;
  gps_latitude?: number;
  gps_longitude?: number;
  created_at: string;
}

export interface UserSession {
  id: string;
  username: string;
  role: 'tfl' | 'korkab' | 'admin';
}

export interface ArahanComment {
  id: string;
  sender_role: 'korkab' | 'tfl' | 'admin';
  sender_name: string;
  message: string;
  created_at: string;
}

export interface ArahanProof {
  photo?: string;
  document?: string;
  document_name?: string;
  description?: string;
  submitted_at?: string;
}

export interface Arahan {
  id: string;
  title: string;
  category: 'tugas_lapangan' | 'koreksi_data' | 'monitoring_material' | 'progress_fisik' | 'dokumentasi' | 'informasi_umum';
  description: string;
  priority: 'tinggi' | 'sedang' | 'rendah';
  deadline: string;
  status: 'belum_dibaca' | 'dibaca' | 'selesai';
  attachment?: string;
  comments: ArahanComment[];
  proof?: ArahanProof;
  created_at: string;
  updated_at: string;
}
