/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getDatabase, ref, onValue } from './lib/firebaseClient';
import { 
  Users, MapPin, Building, ShieldAlert, History, QrCode, 
  MessageCircle, LayoutDashboard, LogOut, CheckCircle2, 
  Sparkles, Plus, AlertTriangle, Layers, Map, X, Check, Cloud, Shield, Compass, FileSpreadsheet
} from 'lucide-react';

import Dashboard from './components/Dashboard';
import MapTracker from './components/MapTracker';
import LightweightMap from './components/LightweightMap';
import MasterData from './components/MasterData';
import RecipientList from './components/RecipientList';
import RecipientDetail from './components/RecipientDetail';
import StoreWatcher from './components/StoreWatcher';
import QRGenerator from './components/QRGenerator';
import FindingsManager from './components/FindingsManager';
import AuditTrail from './components/AuditTrail';
import PublicDRPBDigital from './components/PublicDRPBDigital';
import PublicViewerMap from './components/PublicViewerMap';
import BackupManager from './components/BackupManager';
import TFLDailyDashboard from './components/TFLDailyDashboard';

import WelcomeScreenKorkab from './components/WelcomeScreenKorkab';
import KorkabCommandCenter from './components/KorkabCommandCenter';
import TFLArahanManager from './components/TFLArahanManager';
import MonitoringPenyaluran from './components/MonitoringPenyaluran';
import QuickDistributionModal from './components/QuickDistributionModal';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';

import { 
  Village, Group, Store, Recipient, DRPBItem, 
  Distribution, DistributionMedia, Finding, AuditLog, Arahan, User
} from './types';

// Global fetch interceptor to inject Authorization headers automatically
if (typeof window !== 'undefined' && !(window as any).__fetch_intercepted__) {
  (window as any).__fetch_intercepted__ = true;
  const originalFetch = window.fetch;
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const token = localStorage.getItem("bsps_token") || localStorage.getItem("adminToken");
    if (token) {
      init = init || {};
      const headers = new Headers(init.headers || {});
      if (!headers.has("Authorization")) {
        headers.set("Authorization", `Bearer ${token}`);
      }
      init.headers = headers;
    }
    return originalFetch(input, init);
  };
}

export interface Coordinator {
  id: string;
  username: string;
  fullName: string;
  restrictionType: 'village' | 'group' | 'all';
  restrictionId: string;
  restrictionName: string;
  created_at: string;
}

export default function App() {
  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>("dashboard");
  const [mapViewMode, setMapViewMode] = useState<'comprehensive' | 'lightweight'>('lightweight');
  const [selectedRecipientId, setSelectedRecipientId] = useState<string | null>(() => {
    return localStorage.getItem("bsps_selected_recipient_id");
  });
  
  // Quick Dispatch modal state
  const [isQuickDistOpen, setIsQuickDistOpen] = useState(false);

  // Public Route Detector
  const [isPublicRoute, setIsPublicRoute] = useState(false);
  const [isViewerRoute, setIsViewerRoute] = useState(false);
  const [isSystemHealthRoute, setIsSystemHealthRoute] = useState(false);
  const [isAdminLoginRoute, setIsAdminLoginRoute] = useState(false);
  const [isAdminDashboardRoute, setIsAdminDashboardRoute] = useState(false);
  const [isAuthenticatedAdmin, setIsAuthenticatedAdmin] = useState(() => !!localStorage.getItem("adminToken"));
  const [publicRecipientId, setPublicRecipientId] = useState<string>('');

  useEffect(() => {
    const path = window.location.pathname;
    if (path.startsWith('/public/')) {
      const id = path.split('/public/')[1];
      if (id) {
        setIsPublicRoute(true);
        setPublicRecipientId(id);
      }
    } else if (path === '/viewer') {
      setIsViewerRoute(true);
    } else if (path === '/system-health') {
      setIsSystemHealthRoute(true);
    } else if (path === '/admin/login') {
      setIsAdminLoginRoute(true);
    } else if (path === '/admin/dashboard') {
      setIsAdminDashboardRoute(true);
    }
  }, []);

  if (isAdminLoginRoute) {
    return <AdminLogin />;
  }

  if (isAdminDashboardRoute) {
    if (!isAuthenticatedAdmin) {
      window.location.href = '/admin/login';
      return null;
    }
    return <AdminDashboard />;
  }

  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem("bsps_authenticated") === "true";
  });
  const [userRole, setUserRole] = useState<'tfl' | 'korkab'>(() => {
    const stored = localStorage.getItem("bsps_user_role");
    if (stored === 'tfl' || stored === 'korkab') {
      return stored;
    }
    // Nilai invalid/usang (termasuk sisa role 'viewer' dari versi lama) dibersihkan otomatis
    if (stored !== null) {
      console.warn(`[Migrasi Role] Nilai userRole tidak valid ditemukan di localStorage: "${stored}". Mereset ke default 'tfl'.`);
      localStorage.removeItem("bsps_user_role");
    }
    return 'tfl';
  });
  const [operatorId, setOperatorId] = useState(() => {
    return localStorage.getItem("bsps_operator_id") || "TIM22";
  });
  const [userTeam, setUserTeam] = useState<string>(() => {
    return localStorage.getItem("bsps_user_team") || "TIM22";
  });
  const [userTflRole, setUserTflRole] = useState<'teknik' | 'pemberdayaan' | null>(() => {
    const role = localStorage.getItem("bsps_user_tfl_role");
    return (role === 'teknik' || role === 'pemberdayaan') ? role : null;
  });
  const [users, setUsers] = useState<User[]>([]);
  const [showWelcomeOverlay, setShowWelcomeOverlay] = useState(false);

  // Database States
  const [villages, setVillages] = useState<Village[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [stores, setStores] = useState<Store[]>([]);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [drpbItems, setDrpbItems] = useState<DRPBItem[]>([]);
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [distributionMedia, setDistributionMedia] = useState<DistributionMedia[]>([]);
  const [findings, setFindings] = useState<Finding[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [arahan, setArahan] = useState<Arahan[]>([]);

  // Coordinator States - now fully memory-based, no browser storage saving
  const [coordinators, setCoordinators] = useState<Coordinator[]>([
    {
      id: "demo_coor_1",
      username: "KOOR_TATELI",
      fullName: "Ahmad Jufri, S.T.",
      restrictionType: "village",
      restrictionId: "v1", // fallback to active ID
      restrictionName: "Desa Tateli",
      created_at: new Date().toISOString()
    }
  ]);

  const [activeImpersonation, setActiveImpersonation] = useState<Coordinator | null>(null);

  const handleAddCoordinator = (coor: Coordinator) => {
    const next = [...coordinators, coor];
    setCoordinators(next);
  };

  const handleDeleteCoordinator = (id: string) => {
    const next = coordinators.filter(c => c.id !== id);
    setCoordinators(next);
    if (activeImpersonation?.id === id) {
      setActiveImpersonation(null);
    }
  };

  // Dynamic Role-Based Data Filtering
  const {
    displayVillages,
    displayGroups,
    displayRecipients,
    displayDrpbItems,
    displayDistributions,
    displayFindings,
    displayAuditLogs
  } = React.useMemo(() => {
    if (!activeImpersonation) {
      return {
        displayVillages: villages,
        displayGroups: groups,
        displayRecipients: recipients,
        displayDrpbItems: drpbItems,
        displayDistributions: distributions,
        displayFindings: findings,
        displayAuditLogs: auditLogs
      };
    }

    const { restrictionType, restrictionId } = activeImpersonation;

    let filteredRecipients = recipients;
    let filteredGroups = groups;
    let filteredVillages = villages;

    // Direct mapping checks
    if (restrictionType === 'village') {
      filteredRecipients = recipients.filter(r => r.village_id === restrictionId);
      filteredGroups = groups.filter(g => g.village_id === restrictionId);
      filteredVillages = villages.filter(v => v.id === restrictionId);
    } else if (restrictionType === 'group') {
      filteredRecipients = recipients.filter(r => r.group_id === restrictionId);
      filteredGroups = groups.filter(g => g.id === restrictionId);
      const parentGroup = groups.find(g => g.id === restrictionId);
      if (parentGroup) {
        filteredVillages = villages.filter(v => v.id === parentGroup.village_id);
      }
    }

    const recIds = filteredRecipients.map(r => r.id);
    const filteredDrpbItems = drpbItems.filter(item => recIds.includes(item.recipient_id));
    const filteredDistributions = distributions.filter(d => recIds.includes(d.recipient_id));
    const filteredFindings = findings.filter(f => recIds.includes(f.recipient_id));
    const filteredAuditLogs = auditLogs.filter(a => a.entity_type === 'recipient' && recIds.includes(a.entity_id || ''));

    // Handle empty database states graciously mapping to seed village ID references for smooth demo fallback
    if (villages.length > 0 && coordinators.length > 0 && coordinators[0].restrictionId === "v1") {
      coordinators[0].restrictionId = villages[0].id;
      coordinators[0].restrictionName = `Desa ${villages[0].name}`;
    }

    return {
      displayVillages: filteredVillages,
      displayGroups: filteredGroups,
      displayRecipients: filteredRecipients,
      displayDrpbItems: filteredDrpbItems,
      displayDistributions: filteredDistributions,
      displayFindings: filteredFindings,
      displayAuditLogs: filteredAuditLogs
    };
  }, [activeImpersonation, villages, groups, recipients, drpbItems, distributions, findings, auditLogs, coordinators]);

  // Simulation flags
  const [loading, setLoading] = useState(true);

  // Toast State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | null }>({ message: '', type: null });

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast({ message: '', type: null }), 3000);
  };

  const getVillagesProgressReport = () => {
    return villages.map(village => {
      const villagePB = recipients.filter(r => r.village_id === village.id);
      
      let totalRequired = 0;
      let totalDelivered = 0;

      villagePB.forEach(pb => {
        const pbDRPB = drpbItems.filter(d => d.recipient_id === pb.id);
        pbDRPB.forEach(item => {
          totalRequired += item.required_qty;
          const itemDists = distributions.filter(d => d.recipient_id === pb.id && d.drpb_item_id === item.id);
          const delivered = itemDists.reduce((acc, curr) => acc + curr.volume, 0);
          totalDelivered += Math.min(item.required_qty, delivered);
        });
      });

      const percentage = totalRequired > 0 ? Math.round((totalDelivered / totalRequired) * 100) : 0;
      const finalPercent = Math.min(100, Math.max(0, percentage));

      return {
        id: village.id,
        name: village.name,
        pbCount: villagePB.length,
        percent: finalPercent,
        delivered: totalDelivered,
        required: totalRequired
      };
    });
  };

  // Check URL path on mount for public QR links: e.g., /public/[id] or /viewer or /system-health
  useEffect(() => {
    const path = window.location.pathname;
    if (path.startsWith('/public/')) {
      const id = path.split('/public/')[1];
      if (id) {
        setIsPublicRoute(true);
        setPublicRecipientId(id);
      }
    } else if (path === '/viewer') {
      setIsViewerRoute(true);
    } else if (path === '/system-health') {
      setIsSystemHealthRoute(true);
    } else if (path === '/admin/login') {
      setIsAdminLoginRoute(true);
    } else if (path === '/admin/dashboard') {
      setIsAdminDashboardRoute(true);
    }
  }, []);

  // Fetch full system data from server APIs
  const fetchAllSystemData = async (silentMode: boolean = false) => {
    if (!silentMode) {
      setLoading(true);
    }

    try {
      let dumpRes: Response | null = null;
      let lastFetchErr: any = null;
      const maxAttempts = 3;
      
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          dumpRes = await fetch('/api/system/dump');
          if (dumpRes.ok) {
            break;
          }
          throw new Error(`HTTP ${dumpRes.status}`);
        } catch (fetchErr: any) {
          lastFetchErr = fetchErr;
          if (attempt < maxAttempts) {
            console.warn(`[System Sync] Hubungan ke server terputus/lambat. Percobaan ${attempt}/${maxAttempts}...`);
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          }
        }
      }

      if (!dumpRes || !dumpRes.ok) {
        throw lastFetchErr || new Error("Tidak dapat mengunduh data dari server.");
      }

      const dbDump = await dumpRes.json();

      const vData = dbDump.villages || [];
      const gData = dbDump.groups || [];
      const sData = dbDump.stores || [];
      const rData = dbDump.recipients || [];
      const fData = dbDump.findings || [];
      const aData = dbDump.audit_logs || [];
      const arData = dbDump.arahan || [];
      
      const allDRPB = dbDump.drpb_items || [];
      const allDistributions = dbDump.distributions || [];
      const allMedia = dbDump.distribution_media || [];

      setVillages(vData);
      setGroups(gData);
      setStores(sData);
      setRecipients(rData);
      setFindings(fData);
      setAuditLogs(aData);
      setArahan(arData);
      setUsers(dbDump.users || []);

      setDrpbItems(allDRPB);
      setDistributions(allDistributions);
      setDistributionMedia(allMedia);

      // --- LOCAL BROWSER STORAGE SAVE FEATURE HAS BEEN REMOVED PER USER DIRECTIVES ---
      // No local storage backups are saved or parsed to protect data privacy.

    } catch (err) {
      console.error("Gagal sinkronisasi ke server:", err);
      showToast("Koneksi gagal, coba lagi", "error");
    } finally {
      if (!silentMode) setLoading(false);
    }
  };


  // --- OFFLINE/SSE REMOVED ---

  useEffect(() => {
    if (!isPublicRoute && isAuthenticated) {
      fetchAllSystemData();
    }
  }, [isPublicRoute, isAuthenticated]);

  // Synchronize dynamic navigation & authentication parameters back to localStorage (PERUBAHAN 1)
  useEffect(() => {
    localStorage.setItem("bsps_authenticated", String(isAuthenticated));
    localStorage.setItem("bsps_user_role", userRole);
    localStorage.setItem("bsps_operator_id", operatorId);
    localStorage.setItem("bsps_user_team", userTeam);
    if (userTflRole) {
      localStorage.setItem("bsps_user_tfl_role", userTflRole);
    } else {
      localStorage.removeItem("bsps_user_tfl_role");
    }
    localStorage.setItem("bsps_current_tab", currentTab);
    if (selectedRecipientId) {
      localStorage.setItem("bsps_selected_recipient_id", selectedRecipientId);
    } else {
      localStorage.removeItem("bsps_selected_recipient_id");
    }
  }, [isAuthenticated, userRole, operatorId, userTeam, userTflRole, currentTab, selectedRecipientId]);

  // React to tab focusing via visibilitychange to complete silent soft data refresh (PERUBAHAN 1)
  useEffect(() => {
    const triggerTabRefreshOnFocus = () => {
      if (document.visibilityState === 'visible') {
        console.log("[App.tsx] Visibility state is visible. Triggering soft data refresh for all lists...");
        if (!isPublicRoute && isAuthenticated) {
          fetchAllSystemData();
        }
      }
    };

    document.addEventListener("visibilitychange", triggerTabRefreshOnFocus);
    return () => {
      document.removeEventListener("visibilitychange", triggerTabRefreshOnFocus);
    };
  }, [isPublicRoute]);

  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regTeam, setRegTeam] = useState('Tim 22');
  const [regRole, setRegRole] = useState<'teknik' | 'pemberdayaan'>('teknik');
  const [registerError, setRegisterError] = useState('');
  const [registerSuccess, setRegisterSuccess] = useState('');

  // LOGIN HANDLER with auto redirection to last remembered node (PERUBAHAN 1)
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    const uName = usernameInput.trim();
    const pWord = passwordInput.trim();

    if (!uName || !pWord) {
      setLoginError("Username dan password wajib diisi");
      return;
    }

    const isKorkab = uName.toLowerCase().includes('korkab') && pWord.toLowerCase().includes('korkab');

    if (isKorkab) {
      setUserRole('korkab');
      setOperatorId('KORKAB');
      setUserTeam("KORKAB");
      setUserTflRole(null);
      setIsAuthenticated(true);
      setActiveImpersonation(null);
      localStorage.setItem("bsps_authenticated", "true");
      localStorage.setItem("bsps_user_role", 'korkab');
      localStorage.setItem("bsps_operator_id", 'KORKAB');
      localStorage.setItem("bsps_user_team", "KORKAB");

      setShowWelcomeOverlay(true); 
      showToast("Menginisialisasi Portal Koordinator Kabupaten (KORKAB)", "success");
      
      // Redirect
      setCurrentTab('dashboard');
    } else if (uName.toLowerCase() === 'admin') {
      // Auto-redirect to admin login route
      window.location.href = '/admin/login';
      return;
    } else {
      try {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: uName, password: pWord })
        });
        const data = await res.json();

        if (data.success && data.user) {
          const mRole = data.user.role === 'admin' || data.user.role === 'korkab' ? data.user.role : 'tfl';
          const mTflRole = data.user.role === 'teknik' || data.user.role === 'pemberdayaan' ? data.user.role : 'teknik';
          
          setUserRole(mRole);
          setOperatorId(data.user.username);
          setUserTeam(data.user.team_id || "Tidak ada tim");
          setUserTflRole(mTflRole);
          setIsAuthenticated(true);
          setActiveImpersonation(null);
          if (data.token) {
            localStorage.setItem("bsps_token", data.token);
          }
          localStorage.setItem("bsps_authenticated", "true");
          localStorage.setItem("bsps_user_role", mRole);
          localStorage.setItem("bsps_operator_id", data.user.username);
          localStorage.setItem("bsps_user_team", data.user.team_id || "Tidak ada tim");
          localStorage.setItem("bsps_user_tfl_role", mTflRole);
  
          showToast(`Berhasil Masuk sebagai TFL - ${data.user.team_id || "Tidak ada tim"}`, "success");
          
          const cachedTab = localStorage.getItem("bsps_current_tab");
          const cachedSelectedPB = localStorage.getItem("bsps_selected_recipient_id");
          
          if (cachedTab) {
            if (cachedTab === 'recipient_detail' && cachedSelectedPB) {
              setSelectedRecipientId(cachedSelectedPB);
              setCurrentTab('recipient_detail');
            } else {
              setCurrentTab(cachedTab);
            }
          } else {
            setCurrentTab('dashboard');
          }
        } else {
          setLoginError(data.message || "Username atau password salah");
          showToast("Gagal Masuk: " + (data.message || "Akun tidak ditemukan"), "error");
        }
      } catch (err) {
        console.error(err);
        setLoginError("Koneksi ke server gagal");
        showToast("Gagal terhubung ke server", "error");
      }
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError('');
    setRegisterSuccess('');

    const uName = regUsername.trim();
    const pWord = regPassword.trim();
    const teamName = regTeam.trim();

    if (!uName || !pWord || !teamName || !regRole) {
      setRegisterError("Semua form wajib diisi!");
      return;
    }

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: uName,
          password: pWord,
          team_id: teamName,
          role: regRole
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || err.error || "Pendaftaran gagal");
      }

      setRegisterSuccess("Registrasi Akun TFL Berhasil! Silakan Masuk.");
      showToast("Registrasi Akun TFL Berhasil!", "success");
      
      // Seed username to login form & switch tab
      setUsernameInput(uName);
      setPasswordInput('');
      setRegUsername('');
      setRegPassword('');
      setTimeout(() => {
        setAuthMode('login');
        setRegisterSuccess('');
      }, 1500);

      // Refresh list of users to dynamic sync
      fetchAllSystemData(true);
    } catch (err: any) {
      setRegisterError(err.message || "Gagal menghubungi server");
      showToast(err.message || "Registrasi Gagal", "error");
    }
  };

  // MASTER UNIFIED ACTIONS HANDLERS
  const handleVillageAction = async (action: 'add' | 'edit' | 'delete', data: any) => {
    try {
      if (action === 'add') {
        const res = await fetch('/api/villages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: data.name, operatorId })
        });
        if (!res.ok) throw new Error("Gagal menambah Desa.");
        showToast("berhasil disimpan", "success");
      } else if (action === 'edit') {
        const res = await fetch(`/api/villages/${data.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: data.name, operatorId })
        });
        if (!res.ok) throw new Error("Gagal mengubah Desa.");
        showToast("berhasil disimpan", "success");
      } else if (action === 'delete') {
        const res = await fetch(`/api/villages/${data.id}?operator_id=${operatorId}`, { method: 'DELETE' });
        if (!res.ok) {
           const err = await res.json();
           throw new Error(err.error || "Gagal menghapus Desa.");
        }
        showToast("berhasil dihapus", "success");
      }
      await fetchAllSystemData();
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  const handleGroupAction = async (action: 'add' | 'edit' | 'delete', data: any) => {
    try {
      if (action === 'add') {
        const res = await fetch('/api/groups', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: data.name, village_id: data.village_id, operatorId })
        });
        if (!res.ok) throw new Error("Gagal menambah Kelompok.");
        showToast("berhasil disimpan", "success");
      } else if (action === 'edit') {
        const res = await fetch(`/api/groups/${data.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: data.name, village_id: data.village_id, operatorId })
        });
        if (!res.ok) throw new Error("Gagal mengubah Kelompok.");
        showToast("berhasil disimpan", "success");
      } else if (action === 'delete') {
        const res = await fetch(`/api/groups/${data.id}?operator_id=${operatorId}`, { method: 'DELETE' });
        if (!res.ok) {
           const err = await res.json();
           throw new Error(err.error || "Gagal menghapus Kelompok.");
        }
        showToast("berhasil dihapus", "success");
      }
      await fetchAllSystemData();
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  const handleStoreAction = async (action: 'add' | 'edit' | 'delete', data: any) => {
    try {
      if (action === 'add') {
        const res = await fetch('/api/stores', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: data.name,
            owner_name: data.owner_name,
            phone_number: data.phone_number,
            latitude: Number(data.latitude),
            longitude: Number(data.longitude),
            address: data.address,
            operatorId
          })
        });
        if (!res.ok) throw new Error("Gagal menambah Toko.");
        showToast("berhasil disimpan", "success");
      } else if (action === 'edit') {
        const res = await fetch(`/api/stores/${data.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: data.name,
            owner_name: data.owner_name,
            phone_number: data.phone_number,
            latitude: Number(data.latitude),
            longitude: Number(data.longitude),
            address: data.address,
            operatorId
          })
        });
        if (!res.ok) throw new Error("Gagal mengubah Toko.");
        showToast("berhasil disimpan", "success");
      } else if (action === 'delete') {
        const res = await fetch(`/api/stores/${data.id}?operator_id=${operatorId}`, { method: 'DELETE' });
        if (!res.ok) {
           const err = await res.json();
           throw new Error(err.error || "Gagal menghapus Toko.");
        }
        showToast("berhasil dihapus", "success");
      }
      await fetchAllSystemData();
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
    }
  };

  // RECIPIENT (PB) HANDLERS
  const handleAddRecipient = async (data: any) => {
    try {
      const res = await fetch('/api/recipients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, operatorId })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Gagal menyimpan PB.");
      }
      await fetchAllSystemData();
      showToast("berhasil disimpan", "success");
    } catch (err: any) {
      showToast("gagal menyimpan", "error");
      throw err;
    }
  };

  const handleDeleteRecipient = async (id: string) => {
    try {
      const res = await fetch(`/api/recipients/${id}?operator_id=${operatorId}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Gagal menghapus Penerima Bantuan");
      }
      await fetchAllSystemData();
      showToast("berhasil dihapus", "success");
    } catch (err: any) {
      showToast("gagal menghapus", "error");
    }
  };

  const handleBulkDeleteRecipients = async (ids: string[]) => {
    try {
      const res = await fetch(`/api/recipients/bulk-delete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ ids, operator_id: operatorId })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Gagal menghapus Penerima Bantuan massal");
      }
      const data = await res.json();
      await fetchAllSystemData();
      showToast(`${data.count} PB berhasil dihapus`, "success");
    } catch (err: any) {
      showToast("Gagal menghapus PB massal", "error");
    }
  };

  const handleBulkDeleteDRPB = async (ids: string[]) => {
    try {
      const res = await fetch(`/api/recipients/bulk-delete-drpb`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ ids, operator_id: operatorId })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Gagal menghapus DRPB massal");
      }
      const data = await res.json();
      await fetchAllSystemData();
      showToast(data.message || `DRPB untuk ${ids.length} PB Berhasil Dihapus`, "success");
    } catch (err: any) {
      showToast("Gagal menghapus DRPB massal", "error");
    }
  };

  const handleClearAllRecipients = async () => {
    try {
      const res = await fetch(`/api/recipients/clear-all`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ operator_id: operatorId })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Gagal mengosongkan data Penerima Bantuan");
      }
      const data = await res.json();
      await fetchAllSystemData();
      showToast(`Semua data (${data.count} PB) berhasil dikosongkan`, "success");
    } catch (err: any) {
      showToast("Gagal mengosongkan data", "error");
    }
  };

  // DRPB HANDLERS
  const handleAddDRPBItem = async (recipientId: string, item: any) => {
    try {
      const res = await fetch(`/api/recipients/${recipientId}/drpb`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...item, operatorId })
      });
      if (!res.ok) throw new Error("Gagal menambah material DRPB.");
      await fetchAllSystemData();
      showToast("berhasil disimpan", "success");
    } catch (err) {
      showToast("Koneksi gagal, coba lagi", "error");
    }
  };

  const handleDeleteDRPBItem = async (itemId: string) => {
    try {
      const res = await fetch(`/api/drpb/${itemId}?operator_id=${operatorId}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Gagal menghapus DRPB item");
      }
      await fetchAllSystemData();
      showToast("berhasil dihapus", "success");
    } catch (err: any) {
      showToast("gagal menghapus", "error");
    }
  };

  const handleClearAllDRPB = async (recipientId: string) => {
    try {
      const res = await fetch(`/api/recipients/${recipientId}/drpb/all?operator_id=${operatorId}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Gagal menghapus semua DRPB");
      }
      const data = await res.json();
      await fetchAllSystemData();
      showToast(`Berhasil menghapus ${data.count} DRPB`, "success");
    } catch (err: any) {
      showToast("Gagal menghapus DRPB", "error");
    }
  };

  const handleResetDRPB = async () => {
    if (!confirm("PERINGATAN: Seluruh data Rencana Material (DRPB) dan Riwayat Penyaluran untuk SEMUA Penerima Bantuan akan dihapus permanen. Lanjutkan?")) return;
    
    try {
      const res = await fetch('/api/system/reset-drpb', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operator_id: operatorId })
      });
      if (!res.ok) throw new Error("Gagal mereset data DRPB.");
      await fetchAllSystemData();
      showToast("data dibersihkan", "success");
    } catch (err: any) {
      showToast("gagal membersihkan", "error");
    }
  };

  // DISTRIBUTION LOGISTICS HANDLERS
  const handleAddDistribution = async (formData: any) => {
    try {
      const res = await fetch('/api/distributions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, operatorId })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Gagal mencatat penyaluran.");
      }
      await fetchAllSystemData();
      showToast("berhasil disimpan", "success");
      return true;
    } catch (err: any) {
      showToast("Koneksi gagal, coba lagi", "error");
      return false;
    }
  };

  // FINDINGS HANDLERS
  const handleAddFinding = async (recipientId: string, data: any) => {
    try {
      const res = await fetch('/api/findings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipient_id: recipientId,
          category: data.category,
          description: data.description,
          is_manual: true,
          reported_by: operatorId
        })
      });
      if (!res.ok) throw new Error("Gagal mendaftarkan laporan temuan.");
      await fetchAllSystemData();
      showToast("berhasil disimpan", "success");
    } catch (err) {
      showToast("Koneksi gagal, coba lagi", "error");
    }
  };

  const handleResolveFinding = async (findingId: string) => {
    try {
      const res = await fetch(`/api/findings/${findingId}/resolve`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operatorId })
      });
      if (!res.ok) throw new Error("Gagal menyelesaikan temuan.");
      await fetchAllSystemData();
      showToast("berhasil disimpan", "success");
    } catch (err) {
      showToast("gagal menyimpan", "error");
    }
  };

  // Navigation dispatcher with explicit local persistence (PERUBAHAN 1 & 5)
  const handlePageNavigation = (tab: string, recipientId?: string) => {
    if (tab === 'recipient_detail' && recipientId) {
      setSelectedRecipientId(recipientId);
      setCurrentTab('recipient_detail');
      localStorage.setItem("bsps_current_tab", 'recipient_detail');
      localStorage.setItem("bsps_selected_recipient_id", recipientId);
    } else {
      setSelectedRecipientId(null);
      setCurrentTab(tab);
      localStorage.setItem("bsps_current_tab", tab);
      localStorage.removeItem("bsps_selected_recipient_id");
    }
  };

  // PUBLIC DRPB QR DECODER DISPATCH
  if (isPublicRoute) {
    return <PublicDRPBDigital recipientId={publicRecipientId} />;
  }

  if (isViewerRoute) {
    return (
      <PublicViewerMap 
        recipients={recipients}
        stores={stores}
        villages={villages}
        groups={groups}
        drpbItems={drpbItems}
        distributions={distributions}
        distributionMedia={distributionMedia}
        findings={findings}
        onExit={() => window.location.href = '/'}
      />
    );
  }

  // LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-50 flex justify-center items-center p-4">
        <div className="bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 w-full max-w-md shadow-lg space-y-6 relative overflow-hidden">
          {/* Subtle colored top strip */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600" />
          
          <div className="text-center space-y-3">
            <img src="/logo.png" alt="Logo" className="mx-auto h-20 w-auto mb-2" />
            <div className="space-y-0.5 mb-2">
              <p className="text-[9px] font-bold text-amber-600 tracking-widest font-mono uppercase">KEMENTERIAN PERUMAHAN DAN KAWASAN PERMUKIMAN</p>
            </div>
            
            <div className="space-y-1">
              <h2 className="text-lg sm:text-xl font-black text-slate-900 font-sans tracking-tight leading-tight uppercase">Material Control System PKP</h2>
            </div>
          </div>

          {/* TAB CONTROLS */}
          <div className="flex border-b border-slate-205">
            <button
              onClick={() => { setAuthMode('login'); setLoginError(''); setRegisterError(''); }}
              className={`flex-1 pb-3 text-xs font-black uppercase text-center border-b-2 transition ${
                authMode === 'login' ? 'border-amber-500 text-slate-900' : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Masuk / Login
            </button>
            <button
              onClick={() => { setAuthMode('register'); setLoginError(''); setRegisterError(''); }}
              className={`flex-1 pb-3 text-xs font-black uppercase text-center border-b-2 transition ${
                authMode === 'register' ? 'border-amber-500 text-slate-900' : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Daftar TFL baru
            </button>
          </div>

          {authMode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {loginError && (
                <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-100 flex items-center gap-2">
                  <span className="text-red-500 text-sm">⚠️</span>
                  <span className="font-semibold">{loginError}</span>
                </div>
              )}

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Username</label>
                  <input
                    required
                    type="text"
                    placeholder="Masukkan username anda"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl border border-slate-250 focus:ring-1 focus:ring-slate-900 focus:outline-none bg-slate-50 font-medium"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Password</label>
                  <input
                    required
                    type="password"
                    placeholder="Masukkan password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl border border-slate-250 focus:ring-1 focus:ring-slate-900 focus:outline-none bg-slate-50 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs rounded-xl cursor-pointer active:scale-95 transition tracking-wider uppercase mt-4"
              >
                Masuk ke Aplikasi
              </button>



              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => window.location.href = '/admin/login'}
                  className="text-xs text-slate-500 hover:text-amber-600 font-bold underline"
                >
                  Masuk sebagai Admin Portal
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {registerError && (
                <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-100 flex items-center gap-2">
                  <span className="text-red-500 text-sm">⚠️</span>
                  <span className="font-semibold">{registerError}</span>
                </div>
              )}
              {registerSuccess && (
                <div className="p-3 bg-emerald-50 text-emerald-800 text-xs rounded-xl border border-emerald-100 flex items-center gap-2 animate-bounce">
                  <span className="text-emerald-500 text-sm">✓</span>
                  <span className="font-semibold">{registerSuccess}</span>
                </div>
              )}

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Username Baru</label>
                  <input
                    required
                    type="text"
                    placeholder="Contoh: ahmad_tfl"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl border border-slate-250 focus:ring-1 focus:ring-slate-900 focus:outline-none bg-slate-50 font-medium"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Password</label>
                  <input
                    required
                    type="password"
                    placeholder="Masukkan sandi rahasia"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl border border-slate-250 focus:ring-1 focus:ring-slate-900 focus:outline-none bg-slate-50 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Nomor Tim</label>
                  <input
                    required
                    type="text"
                    placeholder="Misal: Tim 22"
                    value={regTeam}
                    onChange={(e) => setRegTeam(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl border border-slate-250 focus:ring-1 focus:ring-slate-900 focus:outline-none bg-slate-50 font-semibold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold font-mono uppercase tracking-wider text-slate-500">Role TFL</label>
                  <select
                    value={regRole}
                    onChange={(e) => setRegRole(e.target.value as 'teknik' | 'pemberdayaan')}
                    className="w-full p-2.5 text-xs rounded-xl border border-slate-250 focus:ring-1 focus:ring-slate-900 focus:outline-none bg-slate-50 font-semibold"
                  >
                    <option value="teknik">Fasilitator Teknik (User Teknik)</option>
                    <option value="pemberdayaan">Fasilitator Pemberdayaan (User Pemberdayaan)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs rounded-xl cursor-pointer active:scale-95 transition tracking-wider uppercase mt-4"
              >
                Daftar Akun TFL
              </button>

              <div className="text-[10px] text-indigo-800 bg-indigo-50/75 p-3 rounded-2xl border border-indigo-100 uppercase font-bold tracking-wider leading-relaxed">
                📢 Ketentuan Pendaftaran Tim:<br/>
                Maksimal 2 user terdaftar untuk setiap nomor tim (1 User Teknik + 1 User Pemberdayaan).
              </div>
            </form>
          )}

          {/* Secure disclaimer */}
          <p className="text-[10px] text-center text-slate-400 italic">
            Sistem terekam otomatis di Audit Trail. Menyalahgunakan sistem tanpa data valid melanggar aturan Kementerian PKP.
          </p>

        </div>
      </div>
    );
  }

  // KORKAB PORTAL ROUTER
  if (userRole === 'korkab') {
    if (showWelcomeOverlay) {
      return (
        <WelcomeScreenKorkab 
          villages={villages} 
          onComplete={() => setShowWelcomeOverlay(false)} 
        />
      );
    }
    return (
      <KorkabCommandCenter
        villages={villages}
        groups={groups}
        stores={stores}
        recipients={recipients}
        drpbItems={drpbItems}
        distributions={distributions}
        distributionMedia={distributionMedia}
        findings={findings}
        auditLogs={auditLogs}
        arahan={arahan}
        users={users}
        onRefresh={fetchAllSystemData}
        onLogout={() => {
          setIsAuthenticated(false);
          setShowWelcomeOverlay(false);
          localStorage.removeItem("bsps_token");
          localStorage.removeItem("adminToken");
        }}
        showToast={showToast}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-800 flex flex-col font-sans print:bg-white print:p-0">
      
      {/* TOP DESKTOP HEADER & MOBILE RESPONSIVE NAV */}
      <header className="glass-header sticky top-0 z-30 shadow-xs print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex justify-between items-center">
          
            {/* Logo Brand Title */}
            <div className="flex items-center gap-2.5">
              <img src="/logo.png" alt="KemenPKP Logo" className="h-10 w-auto" />
            </div>
            <div>
              <span className="text-[14.5px] leading-[10.5px] font-black text-[#C5B374] block tracking-wide font-mono uppercase">KEMENTERIAN PKP</span>
              <h1 className="text-[21px] font-black tracking-tight text-slate-900 mt-0.5">Material Control System</h1>
            </div>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-3">
            
            {/* Profile operator info */}
            <div className="hidden md:flex flex-col text-right">
              <span className="text-[10px] font-mono text-slate-600 font-bold leading-none">
                {activeImpersonation ? activeImpersonation.username : operatorId}
              </span>
              <span className="text-[9px] text-emerald-600 font-extrabold uppercase mt-0.5">
                {activeImpersonation ? 'KOORDINATOR WILAYAH' : (userRole === 'tfl' ? 'Tenaga Mandat' : 'Viewer Audit')}
              </span>
            </div>

            {/* Exit/Logout */}
            <button
              onClick={() => {
                setIsAuthenticated(false);
                setActiveImpersonation(null);
                localStorage.removeItem("bsps_token");
              }}
              className="p-1.5 bg-slate-100 hover:bg-slate-200/85 text-slate-600 hover:text-slate-900 rounded-xl cursor-pointer transition"
              title="Logout Sesi TFL"
            >
              <LogOut size={14} />
            </button>

          </div>

        </div>
      </header>


      {/* SIMULATOR WARNING STRIP (IMPERSONATION RECOVERY) */}
      {activeImpersonation && (
        <div className="w-full bg-gradient-to-r from-amber-600 to-amber-700 text-white px-4 py-2.5 text-center text-xs font-bold flex flex-col sm:flex-row items-center justify-between gap-2 shadow-inner print:hidden">
          <div className="flex items-center gap-2">
            <Shield size={14} className="animate-spin text-white" />
            <span>
              <strong>MODUS PORTAL TERBATAS:</strong> Anda sedang mensolusikan & menguji batas akses 
              <strong className="bg-[#5c4033]/30 px-1.5 py-0.5 rounded ml-1">{activeImpersonation.fullName}</strong> ({activeImpersonation.restrictionName}).
            </span>
          </div>
          <button
            onClick={() => setActiveImpersonation(null)}
            className="px-3 py-1 bg-slate-950 text-white rounded-lg text-[10px] font-extrabold pb-1 uppercase hover:bg-slate-900 transition active:scale-95 shadow-sm cursor-pointer"
          >
            Akhiri Simulasi (Kembali ke TFL Utama)
          </button>
        </div>
      )}

      {/* CORE FRAME LAYOUT */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex-1 flex flex-col md:flex-row gap-6">
        
        {/* NAV REEL TABS (SIDEBAR ON SCREEN, TOP REEL ON MOBILE) */}
        <aside className="w-full md:w-56 shrink-0 print:hidden space-y-3.5">
          <span className="text-[10px] font-bold font-mono text-slate-400 tracking-wider block uppercase mb-1">PETA AKTIVITAS TFL</span>
          
          <nav className="flex flex-row md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            
            {/* Dashboard */}
            <button
              onClick={() => handlePageNavigation('dashboard')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'dashboard' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <LayoutDashboard size={14} />
              Dashboard Kerja
            </button>

            {/* Peta GPS */}
            <button
              onClick={() => handlePageNavigation('map')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'map' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <Map size={14} />
              Peta Lokasi PB
            </button>

            {/* Master Data */}
            {!activeImpersonation && (
              <button
                onClick={() => handlePageNavigation('master')}
                className={`border border-white py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'master' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-[#4d4d55] hover:bg-slate-100 hover:text-slate-900'}`}
              >
                <Layers size={14} />
                Master Wilayah/Toko
              </button>
            )}

            {/* Penyaluran */}
            <button
              onClick={() => handlePageNavigation('penyaluran')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'penyaluran' || currentTab === 'recipient_detail' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <Users size={14} />
              Penyaluran PB
            </button>

            {/* Monitoring Penyaluran (PERUBAHAN 5) */}
            <button
              onClick={() => handlePageNavigation('monitoring')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'monitoring' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <FileSpreadsheet size={14} />
              Monitoring Penyaluran
            </button>

            {/* Temuan */}
            <button
              onClick={() => handlePageNavigation('findings')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'findings' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <ShieldAlert size={14} />
              Temuan Kendala
            </button>

            {/* QR Codes */}
            <button
              onClick={() => handlePageNavigation('qr')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'qr' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <QrCode size={14} />
              Cetak QR Card DRPB
            </button>

            {/* Store Notifier Alert */}
            <button
              onClick={() => handlePageNavigation('store_watcher')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'store_watcher' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
            >
              <MessageCircle size={14} />
              Pengingat Toko (WA)
            </button>

            {/* Audit Logs immutable */}
            {!activeImpersonation && (
              <button
                onClick={() => handlePageNavigation('audit')}
                className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'audit' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
              >
                <History size={14} />
                Audit Trail Sistem
              </button>
            )}


            {/* Arahan KORKAB */}
            <button
              onClick={() => handlePageNavigation('arahan')}
              className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'arahan' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'} w-full flex justify-between items-center`}
            >
              <div className="flex items-center gap-2">
                <MessageCircle size={14} />
                <span>Arahan KORKAB</span>
              </div>
              {arahan.filter(a => a.status === 'belum_dibaca').length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[9px] bg-red-500 text-white font-mono font-black scale-90 animate-bounce">
                  {arahan.filter(a => a.status === 'belum_dibaca').length}
                </span>
              )}
            </button>

            {/* Cloud Backup & Sync */}
            {!activeImpersonation && (
              <button
                onClick={() => handlePageNavigation('backup')}
                className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'backup' ? 'bg-amber-600 text-white shadow-sm shadow-amber-200/40' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
              >
                <Cloud size={14} />
                Backup & Sinkronisasi
              </button>
            )}

            {/* System Health Check & Auditing */}
            {!activeImpersonation && (
              <button
                onClick={() => handlePageNavigation('system-health')}
                className={`py-2.5 px-3.5 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition select-none whitespace-nowrap ${currentTab === 'system-health' ? 'bg-indigo-750 text-white shadow-sm shadow-indigo-200/40' : 'bg-indigo-50 text-indigo-700 border border-indigo-100 hover:bg-indigo-100'}`}
              >
                <Shield size={14} />
                Audit & Kesehatan Sistem
              </button>
            )}

          </nav>

          <div className="hidden md:block p-4 glass-panel rounded-2xl text-[10px] text-zinc-500 leading-relaxed space-y-1.5 shadow-sm">
            <span className="font-bold text-slate-800 uppercase block font-display tracking-wide">INFO OPERASI CONSOLE</span>
            <p>Target input &lt; 1 menit per rumah PB. Pastikan mengunci koordinat GPS di lokasi pengantaran rumah penerima bantuan yang sah.</p>
          </div>
        </aside>

        {/* WORK BENCH DISPLAY CONTROLLER */}
        <main className="flex-1 min-w-0">
          
          {loading ? (
            <div className="p-16 text-center space-y-3 font-mono text-xs">
              <div className="w-8 h-8 rounded-full border-t-2 border-slate-900 animate-spin mx-auto" />
              <p className="text-slate-500">Mengkoneksikan bank data material...</p>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div 
                 key={currentTab}
                 initial={{ opacity: 0, x: 20 }}
                 animate={{ opacity: 1, x: 0 }}
                 exit={{ opacity: 0, x: -20 }}
                 transition={{ type: "spring", stiffness: 260, damping: 28 }}
                 className="h-full"
              >
              {currentTab === 'dashboard' && (
                userRole === 'tfl' ? (
                  <TFLDailyDashboard
                    tflTeam={userTeam}
                    onNavigateToRecipient={(id) => {
                      setSelectedRecipientId(id);
                      setCurrentTab('recipient_detail');
                    }}
                    onNavigateToFindings={() => setCurrentTab('findings')}
                    recipients={recipients}
                    villages={villages}
                    groups={groups}
                    distributions={distributions}
                  />
                ) : (
                  <Dashboard 
                    recipients={displayRecipients} 
                    villages={displayVillages} 
                    groups={displayGroups} 
                    stores={stores} 
                    drpbItems={displayDrpbItems}
                    distributions={displayDistributions}
                    findings={displayFindings}
                    onNavigate={handlePageNavigation}
                    onOpenPenyaluranCepat={() => setIsQuickDistOpen(true)}
                  />
                )
              )}

              {currentTab === 'map' && (
                <div className="space-y-4">
                  {/* Selector Mode Peta */}
                  <div className="flex items-center justify-between bg-white border border-slate-200 p-1.5 rounded-xl max-w-sm shadow-sm">
                    <button
                      onClick={() => setMapViewMode('lightweight')}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 text-xs font-bold rounded-lg transition cursor-pointer select-none ${
                        mapViewMode === 'lightweight'
                          ? 'bg-amber-600 text-white shadow-sm'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                      }`}
                    >
                      <Compass size={13} />
                      Peta Ringan (Instan)
                    </button>
                    <button
                      onClick={() => setMapViewMode('comprehensive')}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 text-xs font-bold rounded-lg transition cursor-pointer select-none ${
                        mapViewMode === 'comprehensive'
                          ? 'bg-amber-600 text-white shadow-sm'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                      }`}
                    >
                      <Layers size={13} />
                      Peta Lengkap
                    </button>
                  </div>

                  {mapViewMode === 'lightweight' ? (
                    <LightweightMap
                      recipients={displayRecipients}
                      villages={displayVillages}
                      stores={stores}
                      onNavigate={handlePageNavigation}
                    />
                  ) : (
                    <MapTracker 
                      recipients={displayRecipients} 
                      stores={stores} 
                      villages={displayVillages}
                      drpbItems={displayDrpbItems}
                      distributions={displayDistributions}
                      onNavigate={handlePageNavigation}
                    />
                  )}
                </div>
              )}

              {currentTab === 'master' && (
                <MasterData 
                  villages={displayVillages} 
                  groups={displayGroups} 
                  stores={stores}
                  recipients={displayRecipients}
                  onVillageAction={handleVillageAction}
                  onGroupAction={handleGroupAction}
                  onStoreAction={handleStoreAction}
                  showToast={showToast}
                />
              )}

              {currentTab === 'penyaluran' && (
                <RecipientList 
                  recipients={displayRecipients} 
                  villages={displayVillages} 
                  groups={displayGroups} 
                  stores={stores} 
                  drpbItems={displayDrpbItems}
                  onNavigate={handlePageNavigation}
                  onAddRecipient={handleAddRecipient}
                  onDeleteRecipient={handleDeleteRecipient}
                  onBulkDeleteRecipients={handleBulkDeleteRecipients}
                  onBulkDeleteDRPB={handleBulkDeleteDRPB}
                  onClearAllRecipients={handleClearAllRecipients}
                  onResetDRPB={handleResetDRPB}
                  onRefresh={fetchAllSystemData}
                  showToast={showToast}
                />
              )}

              {currentTab === 'recipient_detail' && selectedRecipientId && (
                <RecipientDetail 
                  recipientId={selectedRecipientId} 
                  onBack={() => handlePageNavigation('penyaluran')}
                  villages={displayVillages}
                  groups={displayGroups}
                  stores={stores}
                  operatorId={operatorId}
                  recipients={recipients}
                  onChangeRecipient={(id: string) => setSelectedRecipientId(id)}
                  onAddDRPBItem={handleAddDRPBItem}
                  onDeleteDRPBItem={handleDeleteDRPBItem}
                  onClearAllDRPB={handleClearAllDRPB}
                  onAddDistribution={handleAddDistribution}
                  onAddFinding={handleAddFinding}
                  onResolveFinding={handleResolveFinding}
                  showToast={showToast}
                />
              )}

              {currentTab === 'findings' && (
                <FindingsManager 
                  findings={displayFindings}
                  recipients={displayRecipients}
                  villages={displayVillages}
                  stores={stores}
                  operatorId={operatorId}
                  onAddFinding={handleAddFinding}
                  onResolveFinding={handleResolveFinding}
                  onNavigate={handlePageNavigation}
                  showToast={showToast}
                />
              )}

              {currentTab === 'qr' && (
                <QRGenerator 
                  recipients={displayRecipients} 
                  villages={displayVillages} 
                  groups={displayGroups} 
                  stores={stores}
                  onRefresh={fetchAllSystemData}
                  showToast={showToast}
                />
              )}

              {currentTab === 'store_watcher' && (
                <StoreWatcher 
                  stores={stores} 
                  recipients={displayRecipients} 
                  drpbItems={displayDrpbItems} 
                  distributions={displayDistributions} 
                  media={distributionMedia} 
                  showToast={showToast}
                />
              )}

              {currentTab === 'audit' && (
                <AuditTrail 
                  logs={displayAuditLogs} 
                  onRefresh={fetchAllSystemData} 
                />
              )}

              {currentTab === 'monitoring' && (
                <MonitoringPenyaluran 
                  recipients={displayRecipients} 
                  villages={displayVillages} 
                  groups={displayGroups}
                  stores={stores}
                  drpbItems={displayDrpbItems}
                  distributions={displayDistributions}
                  media={distributionMedia}
                  findings={displayFindings}
                  operatorId={operatorId}
                  onRefresh={fetchAllSystemData}
                  showToast={showToast}
                />
              )}

              {currentTab === 'arahan' && (
                <TFLArahanManager 
                  arahanList={arahan}
                  onRefresh={fetchAllSystemData}
                  showToast={showToast}
                />
              )}

              {currentTab === 'backup' && (
                <BackupManager 
                  onRefresh={fetchAllSystemData}
                  showToast={showToast}
                  operatorId={operatorId}
                />
              )}

            </motion.div>
          </AnimatePresence>
          )}

        </main>

      </div>

      {/* FOOTER BAR */}
      <footer className="bg-white border-t border-slate-200 py-4 mt-8 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-[10px] text-slate-450 font-mono">
          BSPS Material Control System 2026 &bull; Bidang Penyediaan Perumahan &bull; Dinas Perumahan Kawasan Permukiman dan Pertanahan.
        </div>
      </footer>

      {/* Quick Distribution Modal */}
      <QuickDistributionModal
        isOpen={isQuickDistOpen}
        onClose={() => setIsQuickDistOpen(false)}
        recipients={recipients}
        villages={villages}
        drpbItems={drpbItems}
        distributions={distributions}
        operatorId={operatorId}
        onSave={handleAddDistribution}
        showToast={showToast}
      />

      {/* Global Toast Notification - Enhanced Smooth & Cool UI */}
      <AnimatePresence>
        {toast.type && (
          <motion.div 
            initial={{ opacity: 0, x: 100, y: 0, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.95, transition: { duration: 0.2 } }}
            className="fixed top-20 right-6 z-[9999]"
          >
            <div className={`flex items-center gap-4 px-6 py-4 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.15)] border-2 backdrop-blur-xl transition-all ${
              toast.type === 'success' 
                ? 'bg-emerald-50/90 border-emerald-200 text-emerald-900 ring-4 ring-emerald-500/10' 
                : 'bg-rose-50/90 border-rose-200 text-rose-900 ring-4 ring-rose-500/10'
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                toast.type === 'success' ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
              }`}>
                {toast.type === 'success' ? (
                  <Check size={18} strokeWidth={3} />
                ) : (
                  <AlertTriangle size={18} strokeWidth={3} />
                )}
              </div>
              
              <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-widest opacity-50 mb-0.5 font-mono">
                  Sistem Notifikasi
                </span>
                <span className="text-sm font-bold tracking-tight">{toast.message}</span>
              </div>

              <button 
                onClick={() => setToast({ message: '', type: null })}
                className="ml-4 hover:bg-black/5 p-1.5 rounded-xl transition-colors"
              >
                <X size={16} className="text-slate-400" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
