import { initializeApp, getApps, cert, App } from 'firebase-admin/app';
import { getFirestore, Firestore } from 'firebase-admin/firestore';
import { getDatabase, Database } from 'firebase-admin/database';
import { getStorage, Storage } from 'firebase-admin/storage';

// Validasi semua environment variable wajib ada sebelum inisialisasi
const REQUIRED_ENV = [
  'FIREBASE_PROJECT_ID',
  'FIREBASE_CLIENT_EMAIL',
  'FIREBASE_PRIVATE_KEY',
  'FIREBASE_STORAGE_BUCKET',
  'FIREBASE_DATABASE_URL',
] as const;

for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    throw new Error(
      `[Firebase] Environment variable "${key}" wajib di-set.\n` +
      `Pastikan file .env.local sudah diisi atau secrets sudah dikonfigurasi di platform.`
    );
  }
}

// Fix critical: private key dari env var sering mengandung literal "\\n"
// (dua karakter backslash-n) bukan newline sesungguhnya.
// Harus di-replace agar PEM header/footer terbaca dengan benar oleh Node.js crypto.
const privateKey = process.env.FIREBASE_PRIVATE_KEY!.replace(/\\n/g, '\n');

// Inisialisasi Firebase Admin sebagai singleton
let app: App;
if (!getApps().length) {
  app = initializeApp({
    credential: cert({
      projectId: process.env.FIREBASE_PROJECT_ID!,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL!,
      privateKey,
    }),
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET!,
    databaseURL: process.env.FIREBASE_DATABASE_URL!,
  });
  console.log('[Firebase] Admin SDK berhasil diinisialisasi dengan Service Account credential.');
} else {
  app = getApps()[0];
}

// Export instance layanan Firebase
export const db: Firestore = getFirestore(app);
export const rtdb: Database = getDatabase(app);
export const storage: Storage = getStorage(app);

// Nama koleksi Firestore sebagai konstanta (hindari typo string)
export const COLLECTIONS = {
  VILLAGES: 'villages',
  GROUPS: 'groups',
  STORES: 'stores',
  RECIPIENTS: 'recipients',
  DRPB_ITEMS: 'drpb_items',
  DISTRIBUTIONS: 'distributions',
  DISTRIBUTION_MEDIA: 'distribution_media',
  RECIPIENT_PHOTOS: 'recipient_photos',
  FINDINGS: 'findings',
  AUDIT_LOGS: 'audit_logs',
  ARAHAN: 'arahan',
  USERS: 'users',
  TEAMS: 'teams',
} as const;

// Helper: test koneksi Firestore saat server start (opsional tapi sangat berguna untuk debug)
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await db.collection('_health_check').limit(1).get();
    console.log('[Firebase] Koneksi Firestore berhasil diverifikasi.');
    return true;
  } catch (err: any) {
    console.error('[Firebase] GAGAL terkoneksi ke Firestore:', err.message);
    console.error('[Firebase] Pastikan FIREBASE_PRIVATE_KEY benar dan Service Account memiliki role "Firebase Admin" atau "Cloud Datastore User".');
    return false;
  }
}
