import { initializeApp, getApps } from 'firebase/app';
import { getDatabase, ref, onValue } from 'firebase/database';

const meta = import.meta as any;

const firebaseConfig = {
  apiKey: meta.env?.VITE_FIREBASE_API_KEY,
  authDomain: meta.env?.VITE_FIREBASE_AUTH_DOMAIN,
  databaseURL: meta.env?.VITE_FIREBASE_DATABASE_URL,
  projectId: meta.env?.VITE_FIREBASE_PROJECT_ID,
  storageBucket: meta.env?.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: meta.env?.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: meta.env?.VITE_FIREBASE_APP_ID,
};

if (!getApps().length) initializeApp(firebaseConfig);

export { getDatabase, ref, onValue };
