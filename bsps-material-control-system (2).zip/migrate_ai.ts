import fs from 'fs';
import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const promptInstruction = `
Kamu adalah senior backend engineer. Tugasmu adalah memigrasikan backend Express JS lokal (JSON + fs) ke Firebase (Firestore + RTDB + Storage).
Berikut adalah chunk dari \`server.ts\`. Tolong ubah semua operasi CRUD lokal menjadi operasi Firestore native sesuai instruksi ini:

1. Ganti semua \`const db = getDB();\` dengan Firestore async operations.
2. Semua endpoint (app.get, app.post, dll) HARUS menjadi \`async (req, res) => { ... }\`.
3. Gunakan pola Firestore ini:
- GET all: \`const snap = await db.collection(COLLECTIONS.NAMAKOLEKSI).get(); const list = snap.docs.map(d => ({id: d.id, ...d.data()}));\`
- GET one: \`const doc = await db.collection(COLLECTIONS.NAMAKOLEKSI).doc(id).get();\`
- CREATE: \`await db.collection(COLLECTIONS.NAMAKOLEKSI).doc(newId).set({...data});\`
- UPDATE: \`await db.collection(COLLECTIONS.NAMAKOLEKSI).doc(id).update({...data});\`
- DELETE: \`await db.collection(COLLECTIONS.NAMAKOLEKSI).doc(id).delete();\`
4. Semua penyimpanan gambar via \`fs.writeFileSync\` GANTI dengan:
\`const fileUrl = await uploadBase64ToStorage(base64Data, "path/filename.jpg");\`
5. Hapus semua panggilan \`saveDB()\`.
6. Untuk \`broadcastSync(event, data)\`, tetap biarkan pemanggilannya (tapi pastikan diletakkan setelah operasi database selesai), tapi ganti jika ada modifikasi syncClients. (Saya sudah membuat broadcastSync versi RTDB di bagian atas file, biarkan fungsinya dipanggil).
7. Ganti Array functions (find, filter, push, splice) dengan Firestore native.
8. Koleksi yg tersedia: VILLAGES, GROUPS, STORES, RECIPIENTS, DRPB_ITEMS, DISTRIBUTIONS, DISTRIBUTION_MEDIA, RECIPIENT_PHOTOS, FINDINGS, AUDIT_LOGS, ARAHAN, USERS, TEAMS.

JANGAN menambahkan teks lain selain kode hasil modifikasi. JANGAN gunakan markdown code block (\`\`\`typescript), langsung output kodenya saja.
Pertahankan endpoint yang tidak membutuhkan database/firebase.
`;

async function migrate() {
  const code = fs.readFileSync('server.ts', 'utf-8');
  const chunks = [];
  
  // VERY DANGEROUS to chunk blindly, we should use regex to extract app.get, app.post etc.
  // Instead of doing it in one go, I will let the model know about the chunking.
}

migrate();
