import fs from 'fs';

let code = fs.readFileSync('server.ts', 'utf-8');

// Replace syncClients and broadcastSync
code = code.replace(/interface SyncClient \{[\s\S]*?let syncClients: SyncClient\[\] = \[\];/g, '');

code = code.replace(/function broadcastSync\(event: string, data: any = \{\}\) \{[\s\S]*?\}\n\}/g, \`async function broadcastSync(event: string, data: any = {}) {
  try {
    await rtdb.ref('sync/lastUpdate').set({
      event,
      timestamp: new Date().toISOString(),
      ...data,
    });
  } catch (err) {
    logger.error('[Sync] Gagal broadcast ke Realtime DB:', err);
  }
}\`);

code = code.replace(/function createBackup\(\): void \{[\s\S]*?\}\n\}/g, '');
code = code.replace(/function saveDB\(db: SchemaDB\) \{[\s\S]*?\}\n\}/g, '');
code = code.replace(/function getDB\(\): SchemaDB \{[\s\S]*?return \{[\s\S]*?\}\n\}/g, '');

code = code.replace(/const DATA_DIR = path.resolve\\(process.cwd\\(\\), "data"\\);\\nconst UPLOADS_DIR = path.resolve\\(process.cwd\\(\\), "uploads"\\);\\nconst DB_FILE = path.join\\(DATA_DIR, "database.json"\\);[\\s\\S]*?app.use\\("\\/uploads", express.static\\(UPLOADS_DIR\\)\\);/g, `const DATA_DIR = path.resolve(process.cwd(), "data");
const UPLOADS_DIR = path.resolve(process.cwd(), "uploads");

async function uploadBase64ToStorage(
  base64Data: string, 
  destinationPath: string,
  contentType: string = 'image/jpeg'
): Promise<string> {
  const bucket = storage.bucket();
  const base64Clean = base64Data.replace(/^data:[^;]+;base64,/, '');
  const buffer = Buffer.from(base64Clean, 'base64');
  
  const file = bucket.file(destinationPath);
  await file.save(buffer, {
    metadata: { contentType },
    public: true,
  });
  
  return \`https://storage.googleapis.com/\${bucket.name}/\${destinationPath}\`;
}`);

fs.writeFileSync('server.ts', code);
