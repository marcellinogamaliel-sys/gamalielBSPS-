const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

// Replace synchronous route handlers with async
code = code.replace(/app\.(get|post|put|delete)\("([^"]+)", (?:([^,]+), )?(?:([^,]+), )?\(req, res\) => \{/g, (match, method, route, m1, m2) => {
  let middlewares = [];
  if (m1) middlewares.push(m1);
  if (m2) middlewares.push(m2);
  const midStr = middlewares.length ? middlewares.join(', ') + ', ' : '';
  return "app." + method + '("' + route + '", ' + midStr + "async (req, res) => {";
});

// For dump endpoint
const dumpStr = `app.get("/api/system/dump", authenticate, authorize(['admin', 'korkab']), async (req, res) => {
  try {
    const [villages, groups, stores, recipients, drpbItems, distributions,
           media, photos, findings, auditLogs, arahan, users, teams] = await Promise.all([
      db.collection(COLLECTIONS.VILLAGES).get(),
      db.collection(COLLECTIONS.GROUPS).get(),
      db.collection(COLLECTIONS.STORES).get(),
      db.collection(COLLECTIONS.RECIPIENTS).get(),
      db.collection(COLLECTIONS.DRPB_ITEMS).get(),
      db.collection(COLLECTIONS.DISTRIBUTIONS).get(),
      db.collection(COLLECTIONS.DISTRIBUTION_MEDIA).get(),
      db.collection(COLLECTIONS.RECIPIENT_PHOTOS).get(),
      db.collection(COLLECTIONS.FINDINGS).get(),
      db.collection(COLLECTIONS.AUDIT_LOGS).orderBy('created_at', 'desc').limit(1000).get(),
      db.collection(COLLECTIONS.ARAHAN).get(),
      db.collection(COLLECTIONS.USERS).get(),
      db.collection(COLLECTIONS.TEAMS).get(),
    ]);
    
    const toArr = (snap) => snap.docs.map(d => ({ id: d.id, ...d.data() }));
    
    res.json({
      villages: toArr(villages),
      groups: toArr(groups),
      stores: toArr(stores),
      recipients: toArr(recipients),
      drpb_items: toArr(drpbItems),
      distributions: toArr(distributions),
      distribution_media: toArr(media),
      recipient_photos: toArr(photos),
      findings: toArr(findings),
      audit_logs: toArr(auditLogs),
      arahan: toArr(arahan),
      users: toArr(users).map(u => ({ ...u, password: undefined })),
      teams: toArr(teams),
    });
  } catch (err) {
    logger.error('[Dump] Gagal fetch data:', err);
    res.status(500).json({ error: 'Gagal mengambil data sistem' });
  }
});`;
code = code.replace(/app\.get\("\/api\/system\/dump", (?:[^,]+, )?(?:[^,]+, )?async \(req, res\) => \{[\s\S]*?res\.json\(db\);\n\}\);/g, dumpStr);

const logAuditStr = `async function logAudit(
  userId: string, action: string, entityType?: string, entityId?: string,
  description?: string, ipAddress?: string, gps_latitude?: number, gps_longitude?: number,
  prev_value?: string, post_value?: string
) {
  const logId = randomUUID();
  await db.collection(COLLECTIONS.AUDIT_LOGS).doc(logId).set({
    user_id: userId, action, entity_type: entityType, entity_id: entityId,
    description: description || '', prev_value, post_value,
    ip_address: ipAddress || '127.0.0.1', gps_latitude, gps_longitude,
    created_at: new Date().toISOString(),
  });
}`;
code = code.replace(/function logAudit\([\s\S]*?\{[\s\S]*?const auditLog[\s\S]*?db\.audit_logs\.push\(auditLog\);\n\}/g, logAuditStr);

// GET ALL
code = code.replace(/const db = getDB\(\);\n\s*res\.json\(db\.([a-zA-Z_]+)( \|\| \[\])?\);/g, (match, coll) => {
    return "const snap = await db.collection(COLLECTIONS." + coll.toUpperCase() + ").get();\n  res.json(snap.docs.map(d => ({ id: d.id, ...d.data() })));";
});

fs.writeFileSync('server.ts', code);
