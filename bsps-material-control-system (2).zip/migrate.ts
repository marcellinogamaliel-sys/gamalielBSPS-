import { Project, SyntaxKind, ArrowFunction, FunctionExpression } from 'ts-morph';

const project = new Project();
project.addSourceFileAtPath('server.ts');
const sourceFile = project.getSourceFileOrThrow('server.ts');

// 1. Add imports
sourceFile.addImportDeclaration({
  namedImports: ['db', 'rtdb', 'storage', 'COLLECTIONS'],
  moduleSpecifier: './src/lib/firebase.js'
});
sourceFile.addImportDeclaration({
  namedImports: ['FieldValue'],
  moduleSpecifier: 'firebase-admin/firestore'
});

// Remove old sync logic
const broadcastSyncFunc = sourceFile.getFunction('broadcastSync');
if (broadcastSyncFunc) {
  broadcastSyncFunc.setBodyText(`
  try {
    await rtdb.ref('sync/lastUpdate').set({
      event,
      timestamp: new Date().toISOString(),
      ...data,
    });
  } catch (err) {
    logger.error('[Sync] Gagal broadcast ke Realtime DB:', err);
  }
  `);
  broadcastSyncFunc.setIsAsync(true);
}

const syncClientsVar = sourceFile.getVariableStatement('syncClients');
if (syncClientsVar) syncClientsVar.remove();
const syncClientInt = sourceFile.getInterface('SyncClient');
if (syncClientInt) syncClientInt.remove();

// Remove old file upload
const uploadChunkEndpoint = sourceFile.getStatements().find(s => s.getText().includes('app.post("/api/upload-chunk"'));
if (uploadChunkEndpoint) {
    uploadChunkEndpoint.replaceWithText(`
const chunkBuffer = new Map<string, Buffer[]>();
app.post("/api/upload-chunk", express.json({ limit: "15mb" }), async (req, res) => {
  const { uploadId, chunkIndex, totalChunks, filename, chunkData } = req.body;
  if (!uploadId || chunkIndex === undefined || !totalChunks || !filename || !chunkData) {
    return res.status(400).json({ error: 'Parameter chunk tidak lengkap' });
  }

  try {
    if (!chunkBuffer.has(uploadId)) chunkBuffer.set(uploadId, []);
    const chunks = chunkBuffer.get(uploadId)!;
    const base64Clean = chunkData.replace(/^data:[^;]+;base64,/, '');
    chunks[Number(chunkIndex)] = Buffer.from(base64Clean, 'base64');

    if (chunks.filter(Boolean).length === Number(totalChunks)) {
      const fullBuffer = Buffer.concat(chunks.filter(Boolean));
      chunkBuffer.delete(uploadId);
      
      const ext = path.extname(filename) || '.jpg';
      const storagePath = \`uploads/\${uploadId}\${ext}\`;
      const file = storage.bucket().file(storagePath);
      await file.save(fullBuffer, { metadata: { contentType: 'image/jpeg' }, public: true });
      
      const file_url = \`https://storage.googleapis.com/\${storage.bucket().name}/\${storagePath}\`;
      return res.json({ success: true, message: 'File berhasil diunggah!', file_url });
    }

    return res.json({ success: true, message: \`Chunk \${Number(chunkIndex) + 1}/\${totalChunks} diterima.\` });
  } catch (e: any) {
    logger.error('Chunk upload error:', e);
    return res.status(500).json({ error: 'Gagal memproses upload.' });
  }
});
`);
}


// Save changes
sourceFile.saveSync();
console.log('AST manipulation complete.');
