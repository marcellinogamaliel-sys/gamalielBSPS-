const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf-8');

code = code.replace(/app\.use\("\/uploads", express\.static\(UPLOADS_DIR\)\);/g, \`app.use("/uploads", express.static(UPLOADS_DIR));

async function uploadBase64ToStorage(
  base64Data: string, 
  destinationPath: string,
  contentType = 'image/jpeg'
): Promise<string> {
  const bucket = storage.bucket();
  const base64Clean = base64Data.replace(/^data:[^;]+;base64,/, '');
  const buffer = Buffer.from(base64Clean, 'base64');
  
  const file = bucket.file(destinationPath);
  await file.save(buffer, {
    metadata: { contentType },
    public: true,
  });
  
  return 'https://storage.googleapis.com/' + bucket.name + '/' + destinationPath;
}\`);

code = code.replace(/const filename = \`house_init_\$\{pbId\}_\$\{Date.now\(\)\}\.png\`;\n\s*const fullPath = path\.join\(UPLOADS_DIR, filename\);\n\s*const base64Data = initial_photo\.replace\(\/\^data:image\\\\\/\\\\w\+;base64,\/, ''\);\n\s*fs\.writeFileSync\(fullPath, base64Data, 'base64'\);\n\s*newRecipient\.initial_photo = \`\/uploads\/\$\{filename\}\`;/g, \`const filename = \\\`house_init_\\\${pbId}_\\\${Date.now()}.jpg\\\`;
    newRecipient.initial_photo = await uploadBase64ToStorage(initial_photo, \\\`recipient-photos/\\\${pbId}/\\\${filename}\\\`);\`);

code = code.replace(/const filename = \`house_\$\{type\}_\$\{id\}_\$\{Date\.now\(\)\}\.png\`;\n\s*const fullPath = path\.join\(UPLOADS_DIR, filename\);\n\s*const base64Data = photo_data\.replace\(\/\^data:image\\\\\/\\\\w\+;base64,\/, ''\);\n\s*fs\.writeFileSync\(fullPath, base64Data, 'base64'\);\n\s*const file_url = \`\/uploads\/\$\{filename\}\`;/g, \`const filename = \\\`house_\\\${type}_\\\${id}_\\\${Date.now()}.jpg\\\`;
    const file_url = await uploadBase64ToStorage(photo_data, \\\`recipient-photos/\\\${id}/\\\${filename}\\\`);\`);

code = code.replace(/const filename = \`drpb_\$\{id\}_\$\{Date\.now\(\)\}\.png\`;\n\s*const fullPath = path\.join\(UPLOADS_DIR, filename\);\n\s*const base64Data = photo_data\.replace\(\/\^data:image\\\\\/\\\\w\+;base64,\/, ''\);\n\s*fs\.writeFileSync\(fullPath, base64Data, 'base64'\);\n\s*const file_url = \`\/uploads\/\$\{filename\}\`;/g, \`const filename = \\\`drpb_\\\${id}_\\\${Date.now()}.jpg\\\`;
    const file_url = await uploadBase64ToStorage(photo_data, \\\`recipient-photos/\\\${id}/\\\${filename}\\\`);\`);

code = code.replace(/const filename = \`dist_\$\{Date\.now\(\)\}_\$\{Math\.random\(\)\.toString\(36\)\.substring\(7\)\}\.png\`;\n\s*const fullPath = path\.join\(UPLOADS_DIR, filename\);\n\s*const cleanBase64 = m\.photo_data\.replace\(\/\^data:image\\\\\/\\\\w\+;base64,\/, ""\);\n\s*fs\.writeFileSync\(fullPath, cleanBase64, "base64"\);\n\s*const file_url = \`\/uploads\/\$\{filename\}\`;/g, \`const filename = \\\`dist_\\\${Date.now()}_\\\${Math.random().toString(36).substring(7)}.jpg\\\`;
      const file_url = await uploadBase64ToStorage(m.photo_data, \\\`recipient-photos/\\\${distribution.recipient_id}/\\\${filename}\\\`);\`);

code = code.replace(/app\.post\("\/api\/upload-chunk", express\.json\(\{ limit: "15mb" \}\), \(req, res\) => \{[\s\S]*?\}\);/g, \`const chunkBuffer = new Map<string, Buffer[]>();
app.post("/api/upload-chunk", express.json({ limit: "15mb" }), async (req, res) => {
  const { uploadId, chunkIndex, totalChunks, filename, chunkData } = req.body;
  if (!uploadId || chunkIndex === undefined || !totalChunks || !filename || !chunkData) {
    return res.status(400).json({ error: 'Parameter chunk tidak lengkap' });
  }

  try {
    if (!chunkBuffer.has(uploadId)) chunkBuffer.set(uploadId, []);
    const chunks = chunkBuffer.get(uploadId);
    const base64Clean = chunkData.replace(/^data:[^;]+;base64,/, '');
    chunks[Number(chunkIndex)] = Buffer.from(base64Clean, 'base64');

    if (chunks.filter(Boolean).length === Number(totalChunks)) {
      const fullBuffer = Buffer.concat(chunks.filter(Boolean));
      chunkBuffer.delete(uploadId);
      
      const ext = path.extname(filename) || '.jpg';
      const storagePath = \\\`uploads/\\\${uploadId}\\\${ext}\\\`;
      const file = storage.bucket().file(storagePath);
      await file.save(fullBuffer, { metadata: { contentType: 'image/jpeg' }, public: true });
      
      const file_url = \\\`https://storage.googleapis.com/\\\${storage.bucket().name}/\\\${storagePath}\\\`;
      return res.json({ success: true, message: 'File berhasil diunggah!', file_url });
    }

    return res.json({ success: true, message: \\\`Chunk \\\${Number(chunkIndex) + 1}/\\\${totalChunks} diterima.\\\` });
  } catch (e: any) {
    logger.error('Chunk upload error:', e);
    return res.status(500).json({ error: 'Gagal memproses upload.' });
  }
});\`);

fs.writeFileSync('server.ts', code);
